'use strict'
module.exports = {
  NODE_ENV: '"production"',
  /*这个是我自己服务器上的数据接口地址，你们可以换成自己的本地地址或者服务器上的地址*/
  API_HOST:'"http://zyuanyuan.com:3000"',
  BASE_API:'"/api/vueMusic"'
}
