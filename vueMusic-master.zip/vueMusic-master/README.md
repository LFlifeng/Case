
# vue-app-music

> vue仿网易云音乐APP

#懒得写文档。。。。

## 学习vue而写的一个小项目    o(╥﹏╥)o 如果觉得不错的话，点个Star吧， 我会不断把这个项目修改补充完善。

## 还有很多功能没开始写，还有很多bug没开始改，┗( T﹏T )┛ 

## 慢慢来，不急不急。。。(～￣▽￣)～ 


###部分截图如下：ε(罒ω罒)з        [项目演示地址](http://zyuanyuan.com)   演示效果不是实时更新的哦，因为最近经常修改补充这个项目，所以懒得实时更新服务器上的数据，一般个把天左右更新一下服务器的项目吧。

##里面的数据接口用的是这个：  [NeteaseCloudMusicApi](https://github.com/Binaryify/NeteaseCloudMusicApi)  超级感谢！！！


<img src="https://github.com/zoyoy1203/vueMusic/blob/master/others/images/%E6%88%91%E7%9A%84%E9%A1%B5%E9%9D%A2.png" width="240" height="440" hspace="20" vspace="20"/><img src="https://github.com/zoyoy1203/vueMusic/blob/master/others/images/%E5%B7%A6%E4%BE%A7%E6%BB%91%E6%A0%8F.png" width="240" height="440" hspace="20" vspace="20"/><img src="https://github.com/zoyoy1203/vueMusic/blob/master/others/images/%E6%8E%92%E8%A1%8C%E6%A6%9C.png" width="240" height="440" hspace="20" vspace="20"/><img src="https://github.com/zoyoy1203/vueMusic/blob/master/others/images/%E6%8E%92%E8%A1%8C%E6%A6%9C%E6%AD%8C%E5%8D%95%E5%88%97%E8%A1%A8.png" width="240" height="440" hspace="20" vspace="20"/><img src="https://github.com/zoyoy1203/vueMusic/blob/master/others/images/%E6%92%AD%E6%94%BE%E9%A1%B5%E9%9D%A2.png" width="240" height="440" hspace="20" vspace="20"/><img src="https://github.com/zoyoy1203/vueMusic/blob/master/others/images/%E6%92%AD%E6%94%BE%E9%A1%B5%E9%9D%A2%EF%BC%88%E6%AD%8C%E8%AF%8D%EF%BC%89.png" width="240" height="440" hspace="20" vspace="20"/><img src="https://github.com/zoyoy1203/vueMusic/blob/master/others/images/%E6%9B%B4%E5%A4%9A%E6%AD%8C%E5%8D%95%E9%A1%B5%E9%9D%A2.png" width="240" height="440" hspace="20" vspace="20"/><img src="https://github.com/zoyoy1203/vueMusic/blob/master/others/images/%E6%AF%8F%E6%97%A5%E6%8E%A8%E8%8D%90.png" width="240" height="440" hspace="20" vspace="20"/><img src="https://github.com/zoyoy1203/vueMusic/blob/master/others/images/%E8%BE%93%E5%85%A5%E5%AF%86%E7%A0%81.png" width="240" height="440" hspace="20" vspace="20"/><img src="https://github.com/zoyoy1203/vueMusic/blob/master/others/images/%E8%BE%93%E5%85%A5%E6%89%8B%E6%9C%BA%E5%8F%B7.png" width="240" height="440" hspace="20" vspace="20"/><img src="https://github.com/zoyoy1203/vueMusic/blob/master/others/images/%E9%A6%96%E9%A1%B5.png" width="240" height="440" hspace="20" vspace="20"/><img src="https://github.com/zoyoy1203/vueMusic/blob/master/others/images/%E7%99%BB%E5%BD%95%E9%A1%B5%E9%9D%A2.png" width="240" height="440" hspace="20" vspace="20"/>
