<template>
  <div class="container">
    <img src="http://zoyoy.oss-cn-shanghai.aliyuncs.com/serverImg/404.png" alt="">
  </div>
</template>

<script>
  export default {
    name: 'notFound'
  }
</script>

<style lang="stylus" scoped>
  .container{
    width: 100%;
    height: 100%;
    text-align: center;
  }
  img{
    width: 40%;
    height: auto;
  }
</style>
