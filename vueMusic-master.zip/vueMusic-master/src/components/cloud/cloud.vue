<template>
  <div>
    <m-header></m-header>
  </div>
</template>

<script>
  import MHeader from 'components/m-header/m-header'
  export default {
    name: 'cloud',
    components: {
      'm-header':MHeader
    }
  }
</script>

<style scoped>

</style>
