package com.gmadong.common.sharding;

import java.util.HashMap;
import java.util.Map;

/**
 * 水平分表策略管理者
 * @ClassName: ShardManager
 * @Description: 
 * @author caodong
 * @date 2017年6月8日 上午9:01:21
 *
 */
public class ShardManager
{

	private static ShardManager factory;
	/**
	 * Map<String,String> key 表名  value 处理类
	 */
	private static Map<String,ShardStrategy> map = new HashMap<String,ShardStrategy>();
	
	public static ShardManager getShardManager()
	{
		if(factory==null)
		{
			factory = new ShardManager();
			factory.init();
		}
		return factory;
	}
	public ShardStrategy getStrategy(String table)
	{
		return map.get(table);
	}
	private void init()
	{
		
	}
}
