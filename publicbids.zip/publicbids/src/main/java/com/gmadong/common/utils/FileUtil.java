package com.gmadong.common.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DecimalFormat;

import javax.activation.MimetypesFileTypeMap;


public class FileUtil {

	/**
	 * 得到文件路径 分开存储
	 * @param id
	 * @return
	 */
	public static String getPath(String id)
	{
		String path = "/";
		if(StringUtil.isNotEmpty(id) && id.length() >=32)
		{
			path = path+id.substring(0, 2)+"/"+id.substring(2, 4)+"/";
		}
		return path;
	}
	public static boolean createDir(String destDirName)
	{
        File dir = new File(destDirName);
        if (dir.exists()) {
            return false;
        }
        if (!destDirName.endsWith(File.separator)) {
            destDirName = destDirName + File.separator;
        }
        //创建目录
        if (dir.mkdirs()) {
            return true;
        } else {
            return false;
        }
	}
	
	public static long getFileSize(File f)
	{
		long s=0;
		if (f.exists()) {
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(f);
				s= fis.available();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			try {
				f.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println("文件不存在");
		}
		return s;
	}

	public static String formetFileSize(long fileS) {
		DecimalFormat df = new DecimalFormat("#.00");
		String fileSizeString = "";
		if (fileS < 1024) {
			fileSizeString = df.format((double) fileS) + "B";
		} else if (fileS < 1048576) {
			fileSizeString = df.format((double) fileS / 1024) + "K";
		} else if (fileS < 1073741824) {
			fileSizeString = df.format((double) fileS / 1048576) + "M";
		} else {
			fileSizeString = df.format((double) fileS / 1073741824) + "G";
		}
		return fileSizeString;
	}

	public static String fileSize(File file) {
		return formetFileSize(getFileSize(file));
	}
	
	public static String mimeType(File file){
		MimetypesFileTypeMap sss = new MimetypesFileTypeMap();
		String ttt = sss.getContentType(file);
		return ttt;
	}
	
	
    /**
     * 删除单个文件
     * @param   filePath    被删除文件的文件名及路径
     * @return 单个文件删除成功返回true，否则返回false
     */
    public static boolean removeFile(String filePath) {
    	boolean flag = false;
    	File file = new File(filePath);
        // 路径为文件且不为空则进行删除
        if(file.isFile() && file.exists()){
            file.delete();
            flag = true;
        }
        return flag;
    }
    
    /**
     * 删除目录（文件夹）以及目录下的文件
     * @param   sPath 被删除目录的文件路径
     * @return  目录删除成功返回true，否则返回false
     */
    public static boolean removeDirectory(String sPath) {
        //如果sPath不以文件分隔符结尾，自动添加文件分隔符
        if (!sPath.endsWith(File.separator)) {
            sPath = sPath + File.separator;
        }
        File dirFile = new File(sPath);
        //如果dir对应的文件不存在，或者不是一个目录，则退出
        if (!dirFile.exists() || !dirFile.isDirectory()) {
            return false;
        }
        boolean flag = true;
        //删除文件夹下的所有文件(包括子目录)
        File[] files = dirFile.listFiles();
        for (int i = 0; i < files.length; i++) {
            //删除子文件
            if (files[i].isFile()) {
                flag = removeFile(files[i].getAbsolutePath());
                if (!flag) break;
            } //删除子目录
            else {
                flag = removeDirectory(files[i].getAbsolutePath());
                if (!flag) break;
            }
        }
        if (!flag) return false;
        //删除当前目录
        if (dirFile.delete()) {
            return true;
        } else {
            return false;
        }
    }
}
