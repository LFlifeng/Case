package com.gmadong.common.filter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.gmadong.common.ActionConfig;

/**
 * 
 * @ClassName: AuthorityFilter
 * @Description: 后台权限过滤器(*.action)
 * @author caodong
 * @date 2016年9月8日 上午11:02:28
 *
 */
public class AuthorityFilter  implements Filter
{

	public HttpServletRequest request;
	public HttpServletResponse response;
	
	@Override
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException
	{
		request = (HttpServletRequest) req;
		response = (HttpServletResponse) resp;
		HttpSession session = request.getSession();
		if(session.getAttribute("skin") == null || session.getAttribute("skin").equals("")){
			session.setAttribute("skin",  "/skin/default/");
		}
		// 不需要登录即可访问
		String noLoginRequired = request.getParameter("noLoginRequired") != null ? request.getParameter("noLoginRequired").toString() : "";
		if(noLoginRequired.equals("true"))
		{
			chain.doFilter(req, resp);
			return;
		}else
		{
			// 否则验证访问权限
			// authorityId
			String authorityId = request.getServletPath().replaceAll("\\/", "").replaceAll("\\.action$", "");//action + "_" + act;
			if(authorityId == null || authorityId.equals("")){
				this.backingOut("系统无["+authorityId+"]操作");
				return;
			}
			// 所有权限
			String allActionString = (String)session.getAttribute("allActionString");
			if(allActionString == null || allActionString.length() <= 0)
			{
				allActionString = ActionConfig.getAllActionString();
				session.setAttribute("allActionString", allActionString);
			}
			// 根据authorityId获取其parentAuthority、userType
			Pattern pattern = Pattern.compile(authorityId + ".*?name:\"(.*?)\".*?.*?parent:\"(.*?)\".*?user:\"(.*?)\".*?type:\"(.*?)\"");
			Matcher matcher = pattern.matcher(allActionString);
			String name = "";
			String parent = "";
			String user = "";
			String type = "";
			if(matcher.find())
			{
				name = matcher.group(1);
				parent = matcher.group(2);
				user = matcher.group(3);
				type = matcher.group(4);
				
			}else
			{
				this.backingOut("操作["+authorityId+"]未设置权限");
				return;
			}
			if(type != null)
			{
				if(type.equals("anonymous"))
				{
					chain.doFilter(req, resp);
					return;
				}else if(type.equals("unanonymous") || type.equals("permit") || type.equals("inherit"))
				{
					if(user.indexOf("staff") != -1)
					{
						String staffId = "";
						staffId = session.getAttribute("staffId") != null ? session.getAttribute("staffId").toString() : "";
						if(staffId == null || staffId.equals(""))
						{
							response.sendRedirect("/back.login.action");
							return;
						}
					}
					if(type.equals("unanonymous"))
					{
						chain.doFilter(req, resp);
						return;
					}else if(type.equals("permit") || type.equals("inherit"))
					{
						String userActionString = session.getAttribute("userActionString") != null ? session.getAttribute("userActionString").toString() : "";
						if(userActionString.equals("all") || userActionString.indexOf(authorityId) != -1)
						{
							chain.doFilter(req, resp);
							return;
						}else
						{
							this.backingOut("您没有权限执行[" + name + "]操作1001");
							return;
						}
					}else
					{
						this.backingOut("您没有权限执行" + name + "操作1002");
						return;
					}
				}else
				{
					this.backingOut("您没有权限执行" + name + "操作1003");
					return;
				}
			}else
			{
				this.backingOut("您没有权限执行[" + name + "]操作1004");
				return;
			}
		}
	}
	
	public void backingOut(String message)
	{
		String requestType = request.getHeader("X-Requested-With");
		if(requestType!=null && requestType.equals("XMLHttpRequest"))
		{
			response.setContentType("text/html;charset=utf-8");
			PrintWriter pw = null;
			try{
				pw = response.getWriter();
				pw.write("AuthorityFilter's Fail:" + message);
			}catch(IOException e){
				e.printStackTrace();
				pw.flush();
				pw.close();
			}
		}else
		{
			try 
			{
				response.sendRedirect("back.message.action?message=" + URLEncoder.encode(message, "UTF-8"));
				
			} catch (UnsupportedEncodingException e) 
			{
				e.printStackTrace();
			} catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}
	@Override
	public void destroy()
	{
		
	}
	@Override
	public void init(FilterConfig filterConfig) throws ServletException 
	{
		
	}
}
