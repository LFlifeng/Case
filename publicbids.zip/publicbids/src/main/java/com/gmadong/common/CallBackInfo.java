package com.gmadong.common;

import com.gmadong.common.utils.JsonUtil;

/**
 * 返回回调结果
 * @ClassName: CallBackInfo
 * @Description: 
 * @author caodong
 * @date 2017年6月14日 上午9:13:48
 *
 */
public class CallBackInfo
{
	private String code;
	private String msg;

	public String getCode()
	{
		return code;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	public String getMsg()
	{
		return msg;
	}

	public void setMsg(String msg)
	{
		this.msg = msg;
	}

	public CallBackInfo(String code, String msg)
	{
		super();
		this.code = code;
		this.msg = msg;
	}
	private static String getJson(String code, String msg)
	{
		return JsonUtil.object2json(new CallBackInfo(code, msg));
	}
	public static String getFailJson(String msg)
	{
		return getJson("fail", msg);
	}
	public static String getSuccJson(String msg)
	{
		return getJson("succ", msg);
	}

}
