package com.gmadong.common.quartz;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.servlet.ServletContext;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import com.gmadong.common.ApplicationContextUtil;
import com.gmadong.common.Common;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.modules.staff.SysStaffService;
import com.gmadong.modules.systemInfo.SystemInfo;
import com.gmadong.modules.systemInfo.SystemInfoService;

public class InitJob
{

	/**
	 * 启动时执行一次
	 */
	public void work()
	{	
		System.out.println("初始化完成--->"+DateUtil.getCurrentDate());
		Common.actionConfig = null;
		Common.menuConfig = null;
		
		SystemInfoService systemInfoService =   (SystemInfoService) ApplicationContextUtil.getBean("systemInfoService");
		SystemInfo systemInfo = systemInfoService.getSystemInfo();
		
		
		WebApplicationContext webApplicationContext = ContextLoader.getCurrentWebApplicationContext();
		ServletContext servletContext = webApplicationContext.getServletContext();
		
		servletContext.setAttribute("systemInfo", systemInfo);
		
	}
	
}
