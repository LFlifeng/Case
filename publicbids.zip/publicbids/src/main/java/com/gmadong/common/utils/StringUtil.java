package com.gmadong.common.utils;

import java.util.regex.Pattern;

import javax.swing.text.View;


public class StringUtil 
{
	 /**
     * 手机号码: 
     * 13[0-9], 14[5,7], 15[0, 1, 2, 3, 5, 6, 7, 8, 9], 17[0, 1, 6, 7, 8], 18[0-9]
     * 移动号段: 134,135,136,137,138,139,147,150,151,152,157,158,159,170,178,182,183,184,187,188
     * 联通号段: 130,131,132,145,152,155,156,170,171,176,185,186
     * 电信号段: 133,134,153,170,177,180,181,189
     */
	public static String mobileRegexp = "^1(3[0-9]|4[57]|5[0-35-9]|7[01678]|8[0-9])\\d{8}$";
	
	public static String telRegexp = "^(0[0-9]{2,3}\\-)?([2-9][0-9]{6,7})+(\\-[0-9]{1,4})?$";
	
	public static boolean isEmpty(Object param){
		return param == null || param.equals("") ? true : false;
	}

	public static boolean isNotEmpty(Object param){
		return param == null || param.equals("") ? false : true;
	}

	public static boolean isInt(String param){
		Pattern pattern = Pattern.compile("-{0,1}[0-9]+");
		return pattern.matcher(param).matches();
	}

	public static boolean isPositiveInt(String param){
		Pattern pattern = Pattern.compile("[0-9]+");
		return pattern.matcher(param).matches();
	}

	public static boolean isDouble(String param){
		Pattern pattern = Pattern.compile("-{0,1}[0-9]*(\\.?)[0-9]*");
		return pattern.matcher(param).matches();
	}

	public static boolean isPositiveDouble(String param){
		Pattern pattern = Pattern.compile("[0-9]*(\\.?)[0-9]*");
		return pattern.matcher(param).matches();
	}

	public static int toInt(String param){
		return Integer.valueOf(param);
	}

	public static Float toFloat(String param){
		return Float.valueOf(param);
	}

	public static Double toDouble(String param){
		return Double.valueOf(param);
	}
	public static boolean isMobile(String phone)
	{
		return Pattern.compile(mobileRegexp).matcher(phone).find();
	}
}
