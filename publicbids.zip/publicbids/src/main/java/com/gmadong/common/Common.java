package com.gmadong.common;

public class Common
{

	/**
	 * 消息最小表
	 */
	public static String MSG_MIN_TIME = "2017-07";
	/**
	 * 日报表最小表
	 */
	public static String REPORT_MIN_TIME = "2017";
	/**
	 * 菜单
	 */
	public static String menuConfig = null;
	/**
	 * 所有的权限
	 */
	public static String actionConfig = null;
	
	/**
	 *  wxContact.preContact 联系人的过期时间 48小时
	 */
	public static int REDIS_CONTACT_EXPIRE = 172800;
	/**
	 *  30分钟
	 */
	public static int REDIS_30_MINUTE_EXPIRE = 1800;
	/**
	 *  5分钟
	 */
	public static int REDIS_5_MINUTE_EXPIRE = 300;
	/**
	 *  3分钟
	 */
	public static int REDIS_3_MINUTE_EXPIRE = 180;
	/**
	 *  15分钟
	 */
	public static int REDIS_15_MINUTE_EXPIRE = 900;
	/**
	 *  6小时
	 */
	public static int REDIS_6_HOUR_EXPIRE = 21600;
	/**
	 *  24小时
	 */
	public static int REDIS_24_HOUR_EXPIRE = 86400;
	/**
	 *  48小时
	 */
	public static int REDIS_48_HOUR_EXPIRE = 172800;
	/**
	 *  72小时
	 */
	public static int REDIS_72_HOUR_EXPIRE = 259200;
	
	/**
	 * 是否是测试版本
	 */
	public static boolean isDebug = true;
	public static String uploadPath = "/home/data/upload/attach/";
	
	
}
