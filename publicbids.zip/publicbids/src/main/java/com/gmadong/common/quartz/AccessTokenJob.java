package com.gmadong.common.quartz;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;

import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.modules.wechat.AccessToken;
import com.gmadong.modules.wechat.WeChatUtil;
import com.google.gson.Gson;

public class AccessTokenJob {

	@Autowired
	private JedisClientSingle jedisClientSingle;

	/**
	 * 定时调度查询ACCESS_TOKEN
	 */
	public void work() {
		System.out.println("获取accesstoken----");

		AccessToken accessToken = new AccessToken();
		accessToken = WeChatUtil.getAccessToken();
		Gson gson = new Gson();
		String key = "access_token";
		String atStr = gson.toJson(accessToken);
		jedisClientSingle.set(key, atStr);
		System.out.println(atStr);
	}

}
