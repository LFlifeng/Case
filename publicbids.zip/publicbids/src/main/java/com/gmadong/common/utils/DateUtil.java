package com.gmadong.common.utils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 日期操作公共类
 */
public class DateUtil {
	public static final String STRTIME = "010101";
	
	public final static String LONG_DATE_FORMAT="yyyy-MM-dd HH:mm:ss:SSS";
	
	public final static String SHORT_DATE_FORMAT="yyyy-MM-dd HH:mm:ss";
	
	public final static String ONLY_DATE_FORMAT="yyyy-MM-dd";
	

	private String dateString;	
	
	public static void main(String[] args){
		DateUtil d = new DateUtil();
		System.out.println(d.getStrDay());
	}
	public DateUtil(){
		dateString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
	}
	/**
	 * 根据指定格式，解释字符串，生成日期对象
	 * @param src　日期字符串
	 * @param format　格式化字符串
	 * @return　不能转化时返回Null
	 */		
	public synchronized static Date parseDate(String src,String format){
		Date date=null;
		if(src==null || src.equals(""))
			return null;
		try{
			date=new SimpleDateFormat(format).parse(src);
		}catch(Exception e){
			return null;
		}
		return date;
	}
	

	/**
	 * 根据指定格式，解释字符串，生成日期对象
	 * @param src　日期字符串
	 * @param format　格式化字符串
	 * @return　不能转化时返回Null
	 */
	public synchronized static Timestamp parseTimestamp(String src,String format){
		Date date=null;
		if(src==null || src.equals(""))
			return null;
		try{
			date=new SimpleDateFormat(format).parse(src);
		}catch(Exception e){
			return null;
		}
		return new Timestamp(date.getTime());
	}	

	/**
	 * 把传入的日期，按指定格式返回其字符串形式
	 * @param d　日期对象
	 * @param format　格式字符串
	 * @return　不能转换返回Null
	 */
	public synchronized static String dateToString(Date d,String format){
		String str = null;
		if(d==null){
			return null;
		}
		else{
			try {
				str = new SimpleDateFormat(format).format(d);
			} catch (Exception e) {
				return null;
			}
		}
			return str;
	}

	/**
	 * 把传入的日期，按指定格式返回其字符串形式
	 * @param d　日期对象
	 * @param format　格式字符串
	 * @return　不能转换返回Null
	 */
	public synchronized static String dateToString(Timestamp d,String format){
		String str = null;
		if(d==null){
			return null;
		}
		else{
			try {
				str =  new SimpleDateFormat(format).format(new Date(d.getTime()));
			} catch (Exception e) {
				return null;
			}
		}
			return str;
	}
	
	/**
	 * 获取当前时间yyyy-MM-dd HH:mm:ss字符串形式 
	 * @return
	 */
	public synchronized static String getCurrentDate() {
		return getCurrentDate("yyyy-MM-dd HH:mm:ss");
	}

	/**
	 * 获取当前时间指定格式的字符串形式
	 * 格式错误按yyyy-MM-dd HH:mm:ss
	 * @param String sFormat　日期格式字符串
	 * @return String　转换成指定格式的字符串形式
	 */	
	public synchronized static String getCurrentDate(String sFormat) {
		SimpleDateFormat formatter = new SimpleDateFormat(sFormat);
		return formatter.format(new java.util.Date());
	}	
	/**
	 * 获取当前时间指定格式的字符串形式
	 * 格式错误按yyyy-MM-dd HH:mm:ss
	 * @param String sFormat　日期格式字符串
	 * @return String　转换成指定格式的字符串形式
	 */	
	public synchronized static String getCurrentDateYY(String sFormat) {
		if (sFormat == null || sFormat.equals(""))
			sFormat = "yyyy-MM-dd HH:mm:ss";
		SimpleDateFormat formatter = new SimpleDateFormat(sFormat);
		return formatter.format(new java.util.Date());
	}	
	
	
	/**
	 * 返回年份数值
	 * @return
	 */
	public int getYear() {
		return Integer.parseInt(this.dateString.substring(0, 4));
	}
	/**
	 * 返回4位年份字符串
	 * @return
	 */
	public String getStrYear() {
		return this.dateString.substring(0, 4);
	}

	/**
	 * 返回月份数值
	 * @return int
	 */
	public int getMonth() {
		return Integer.parseInt(this.dateString.substring(5,7));
	}
	
	/**
	 * 返回2位月份字符串
	 * @return string
	 */
	public String getStrMonth() {
		return this.dateString.substring(5,7);
	}

	/**
	 * 返回日数值
	 * @return int
	 */
	public int getDay() {
		return Integer.parseInt(this.dateString.substring(8,10));
	}
	/**
	 * 返回2位日字符串
	 * @return String
	 */
	public String getStrDay() {
		return this.dateString.substring(8,10);
	}
	
	/**
	 * 返回小时值
	 * @return int
	 */
	public int getHour() {
		return Integer.parseInt(this.dateString.substring(11,13));
	}

	/**
	 * 返回2位小时字符串
	 * @return String
	 */
	public String getStrHour() {
		return this.dateString.substring(11,13);
	}

	/**
	 * 返回分钟值
	 * @return int
	 */
	public int getMinute() {
		return Integer.parseInt(this.dateString.substring(10, 12));
	}

	/**
 	 * 返回2位分钟字符串
	 * @return String
	 */
	public String getStrMinute() {
		return this.dateString.substring(14,16);
	}

	/**
	 * 返回秒值
	 * @return int
	 */
	public int getSecond() {
		return Integer.parseInt(this.dateString.substring(14,16));
	}
	/**
 	 * 返回2位秒字符串
	 * @return String
	 */
	public String getStrSecond() {
		return this.dateString.substring(17,19);
	}

	/**
	 * 返回年月日字符串格式如　1997-07-01
	 * @return Sting
	 */
	public String getStrDate() {
		return this.dateString.substring(0,10);
	}
	
	/**
	 * 返回时分秒字符串　01:01:01
	 * @return Sting
	 */
	public String getStrTime() {
		return this.dateString.substring(11,19);
	}	
	
	 /**
     * 获得传入日期所在年份
     * @param seeddate
     * @return
     */
    public static String getYearOfDate(Date seeddate)
    {

        String finalstr = "";

        try
        {

            Calendar seedCalendar = Calendar.getInstance();
            seedCalendar.setTime(seeddate);
            finalstr = String.valueOf(seedCalendar.get(Calendar.YEAR));
            return finalstr;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }

    }
	/**
     * 获得所在日期所在月份
     * @param seeddate
     * @return
     */
    public static String getMonthOfDate(Date seeddate)
    {

        String finalstr = "";

        try
        {

            Calendar seedCalendar = Calendar.getInstance();
            seedCalendar.setTime(seeddate);
            finalstr = String.valueOf(seedCalendar.get(Calendar.MONTH) + 1);
            return finalstr;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }

    }
    
    
    /**
     * 保留一位小数
     * @param seeddate
     * @return
     */
    public static String double2String(String value)
    {

    	NumberFormat   nf=new   DecimalFormat( "0.0"); 
        return nf.format(Double.parseDouble(value));
    }

    /**
     * 判断时间是否在当前时间之前
     * @param seeddate
     * @return
     * isDateBefore("2005-09-09 01:01:01");
     */
    public static boolean isDateBefore(String date2){
    	try{
    		Date date1 = new Date();
//    		System.out.println(date1);
    		DateFormat df = DateFormat.getDateTimeInstance();
    		return date1.before(df.parse(date2));
    	}catch(ParseException e){
//    		System.out.print("[SYS] " + e.getMessage());
    		return false;
    	}
    }

    /**
     * 判断时间1是否在时间2之前
     * @param seeddate
     * @return
     * isDateBefore("2004-09-09 12:12:12","2005-09-09 16:00:00");
     */
    public static boolean isDateBefore(String date1,String date2){
    	try{
    		DateFormat df = DateFormat.getDateTimeInstance();
    		return df.parse(date1).before(df.parse(date2));
    	}catch(ParseException e){
//    		System.out.print("[SYS] " + e.getMessage());
    		return false;
    	}
    }

    /**
     * 判断当前是否在时间1、时间2之间
     * @param seeddate
     * @return
     * isDateBefore("2004-09-09 12:12:12","2005-09-09 16:00:00");
     */
    public static boolean isDateIn(String date1, String date2){
    	try{
    		Date date = new Date();
    		DateFormat df = DateFormat.getDateTimeInstance();
    		return !date.before(df.parse(date1)) && date.before(df.parse(date2));
    	}catch(ParseException e){
//    		System.out.print("[SYS] " + e.getMessage());
    		return false;
    	}
    }
    
    /** *//**
     * 得到日期的前或者后几小时
     *
     * @param iHour
     *                如果要获得前几小时日期，该参数为负数； 如果要获得后几小时日期，该参数为正数
     * @see java.util.Calendar#add(int, int)
     * @return Date 返回参数<code>curDate</code>定义日期的前或者后几小时
     */
    public static Date getDateBeforeOrAfterHours(Date curDate, int iHour) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(curDate);
        cal.add(Calendar.HOUR_OF_DAY, iHour);
        return cal.getTime();
    }
	public static String getFormatDateTime(java.util.Date currDate, String format) {
		  if (currDate == null) {
	            return "";
	        }
	        SimpleDateFormat dtFormatdB = null;
	        try {
	            dtFormatdB = new SimpleDateFormat(format);
	            return dtFormatdB.format(currDate);
	        } catch (Exception e) {
	            dtFormatdB = new SimpleDateFormat(SHORT_DATE_FORMAT);
	            try {
	                return dtFormatdB.format(currDate);
	            } catch (Exception ex) {

	            }
	        }
	        return "";
	}
	
	 /** *//**
     * 根据格式得到格式化后的时间
     *
     * @param currDate
     *                要格式化的时间
     * @param format
     *                时间格式，如yyyy-MM-dd HH:mm:ss
     * @see java.text.SimpleDateFormat#parse(java.lang.String)
     * @return Date 返回格式化后的时间，格式由参数<code>format</code>定义，如yyyy-MM-dd
     *         HH:mm:ss
     */
    public static Date getFormatDateTime(String currDate, String format) {
        if (currDate == null) {
            return null;
        }
        SimpleDateFormat dtFormatdB = null;
        try {
            dtFormatdB = new SimpleDateFormat(format);
            return dtFormatdB.parse(currDate);
        } catch (Exception e) {
            dtFormatdB = new SimpleDateFormat(DateUtil.SHORT_DATE_FORMAT);
            try {
                return dtFormatdB.parse(currDate);
            } catch (Exception ex) {
            }
        }
        return null;
    }
	
	 /** *//**
     * 得到日期的前或者后几小时
     *
     * @param iHour
     *                如果要获得前几小时日期，该参数为负数； 如果要获得后几小时日期，该参数为正数
     * @see java.util.Calendar#add(int, int)
     * @return Date 返回参数<code>curDate</code>定义日期的前或者后几小时
     */
    public static Date getDateBeforeOrAfterHours(String strDate, int iHour) {
        Calendar cal = Calendar.getInstance();
        Date curDate = getFormatDateTime(strDate,DateUtil.SHORT_DATE_FORMAT);
        cal.setTime(curDate);
        cal.add(Calendar.HOUR_OF_DAY, iHour);
        return cal.getTime();
    }
    
    /** *//**
     * 得到日期的前或者后几天
     *
     * @param iDate
     *                如果要获得前几天日期，该参数为负数； 如果要获得后几天日期，该参数为正数
     * @see java.util.Calendar#add(int, int)
     * @return Date 返回参数<code>curDate</code>定义日期的前或者后几天
     */
    public static Date getDateBeforeOrAfter(Date curDate, int iDate) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(curDate);
        cal.add(Calendar.DAY_OF_MONTH, iDate);
        return cal.getTime();
    }
    
    /** *//**
     * 得到日期的在周几
     *
     * @param curDate
     *                进行判断的日期
     * @see java.util.Calendar#add(int, int)
     * @return int 返回参数为周几,周一返回1,周六返回6,周日 返回 0
     */
    public static int getWeekOfDate(Date curDate){
    	 Calendar cal = Calendar.getInstance();
         cal.setTime(curDate);
         
         int week = cal.get(Calendar.DAY_OF_WEEK) - 1;
         return week;
    }
    /** *//**
     * 计算指定日期+addMonth月+15号 返回格式"2008-02-15"
     *
     * @param date
     * @param addMonth
     * @param monthDay
     * @return
     */
    public static String genericSpecdate(Date date, int addMonth, int monthDay) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.MONTH, addMonth);
        cal.set(Calendar.DAY_OF_MONTH, monthDay);
        return getFormatDateTime(cal.getTime(), ONLY_DATE_FORMAT);
    }
}
