package com.gmadong.common.quartz;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.wechat.AccessToken;
import com.gmadong.modules.wechat.MassMsgResult;
import com.gmadong.modules.wechat.Tag;
import com.gmadong.modules.wechat.UserManager;
import com.gmadong.modules.wechat.WeChatService;
import com.gmadong.modules.wechat.WeChatUtil;

import net.sf.json.JSONObject;

/**
 * 每日公告推送
 * 
 * @author Administrator
 *
 */
public class DailyPushBidsJob {

	@Autowired
	private WeChatService weChatService;

	@Autowired
	private JedisClientSingle jedisClientSingle;

	private final String accessTokenKey = "access_token";

	public void work() {

		String data = weChatService.getTxtMessage();
		data = data.replace("'", "\"");
		AccessToken accessToken = null;
		
		try {
			String atStr = jedisClientSingle.get(accessTokenKey);
			if (StringUtil.isNotEmpty(atStr)) {
				JSONObject jsonObject = JSONObject.fromObject(atStr);
				accessToken = (AccessToken) JSONObject.toBean(jsonObject, AccessToken.class);
			} else {
				accessToken = WeChatUtil.getAccessToken();
				atStr = JsonUtil.bean2json(accessToken);
				jedisClientSingle.set(accessTokenKey, atStr, 7000);
			}
		} catch (Exception e) {
		}
		
		//获取标签列表
		List<Tag> list = UserManager.getTags(accessToken.getAccess_token());
		MassMsgResult result = null;
		
		for (Tag tag : list) {
			if ("星标组".equals(tag.getName())) {
				result = UserManager.sendTextToTag(accessToken.getAccess_token(), tag.getId(), data);
			} /*
				 * else if ("北京用户".equals(tag.getName())) { result =
				 * UserManager.sendTextToTag(accessToken.getAccess_token(), tag.getId(), data);
				 * } else if ("深圳用户".equals(tag.getName())) { result =
				 * UserManager.sendTextToTag(accessToken.getAccess_token(), tag.getId(), data);
				 * }
				 */
		}
		if ("0".equals(result.getErrcode())) {
			System.out.println("发送成功");
			return;
		} else {
			System.out.println("发送失败，错误码：" + result.getErrcode());
		}
	}
}
