package com.gmadong.common.datasource;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 * 多个数据源
 * @ClassName: DynamicDataSource
 * @Description: 
 * @author caodong
 * @date 2017年12月5日 下午3:30:35
 *
 */
public class DynamicDataSource extends AbstractRoutingDataSource
{
	@Override
	protected Object determineCurrentLookupKey()
	{
		return CustomerContextHolder.getCustomerType();
	}
}
