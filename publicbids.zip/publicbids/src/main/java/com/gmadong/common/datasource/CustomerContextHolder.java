package com.gmadong.common.datasource;

import com.gmadong.common.utils.StringUtil;

public class CustomerContextHolder
{
	public static final String DATA_SOURCE_MYSQL = "dataSource";
    public static final String BIDS_DATA_SOURCE_MSSQL = "bidsDataSource";
    //用ThreadLocal来设置当前线程使用哪个dataSource
    private static final ThreadLocal<String> contextHolder = new ThreadLocal<String>();
    public static void setCustomerType(String customerType) 
    {
        contextHolder.set(customerType);
    }
    public  static String getCustomerType() 
    {
        String dataSource = contextHolder.get();
        if (StringUtil.isEmpty(dataSource))
        {
            return DATA_SOURCE_MYSQL;
        }
        else 
        {
            return dataSource;
        }
    }
    public static void clearCustomerType() 
    {
        contextHolder.remove();
    }
}
