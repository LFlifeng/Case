package com.gmadong.common.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * 发送验证码工具类
 * @author caodongdong
 *
 */
public class SendMsgCodeUtil
{
	private static final String url = "https://m.5c.com.cn/api/send/index.php";
	private static Map<String, String> map = new HashMap<String, String>();
	static
	{
		map.put("username", "geng");
		map.put("password_md5", "1adbb3178591fd5bb0c248518f39bf6d");
		map.put("apikey", "cda627bc6de81e64229c9ffc6549fc48");
		map.put("encode", "UTF-8");
	}
	public static boolean  sendCode(String code,String mobile)
	{
		map.put("mobile", mobile);
		try
		{
			map.put("content",URLEncoder.encode("【中汇招标网】您的验证码是:"+code, "UTF-8"));
		} catch (UnsupportedEncodingException e)
		{
			return false;
		}
		
		String post = HttpTool.post(url, map);
		if(StringUtil.isEmpty(post))
		{
			return false;
		}
		if(post.startsWith("success:"))
		{
			return true;
		}
		return false;
	}
}
