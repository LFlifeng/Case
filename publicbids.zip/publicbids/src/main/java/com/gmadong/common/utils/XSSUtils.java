package com.gmadong.common.utils;

import java.lang.reflect.Field;

import org.springframework.web.util.HtmlUtils;


/**
 * 防XSS脚本攻击
 * @ClassName: XSSUtils
 * @Description: 
 * @author caodong
 * @date 2017年11月13日 上午10:08:33
 *
 */
public class XSSUtils
{
	
//	/**
//	 * 清空字段的XSS脚本攻击代码
//	 * @param args
//	 */
//	public static void clearXss(String ...args)
//	{
//		for (String item :args)
//		{
//			item = HtmlUtils.htmlEscape(item);
//		}
//	}
	/**
	 * 清空对象的XSS脚本攻击代码
	 * @param instance
	 */
	public static void clearXss(Class clazz,Object instance)
	{
		for(Field field:clazz.getDeclaredFields())
		{
		     String fieldType = field.getType().toString();
		     if(fieldType.equals("class java.lang.String"))
		     {
		    	 field.setAccessible(true);  
		    	 String value = "";
				try
				{
					value = (String) field.get(instance);
				} catch (Exception e)
				{
					e.printStackTrace();
				} 
				if(StringUtil.isNotEmpty(value))
				{
					value = HtmlUtils.htmlEscape(value);
				    try
					{
						field.set(instance, value);
					} catch (Exception e)
					{
						e.printStackTrace();
					} 
				}
		     }
		}

	}
	/**
	 * 单个变量
	 * @param content
	 * @return
	 */
	public static String clearXss(String content)
	{
		return HtmlUtils.htmlEscape(content);
	}
	
	
//	public static void main(String[] args)
//	{
//		/*
//		Orders order = new Orders();
//		order.setHabit("<script>alert(abc)</script>");
//		System.out.println(order.getHabit());
//		clearXss(Order.class, order);
//		System.out.println(order.getHabit());*/
//		
//		String a = "abc2016<script>alert(abc)</script>";
//		String b = "abc2017<script>alert(abc)</script>";
//		System.out.println(a);
//		System.out.println(b);
//		clearXss(a,b);
//		System.out.println(a);
//		System.out.println(b);
//		
//		
//	}
}
