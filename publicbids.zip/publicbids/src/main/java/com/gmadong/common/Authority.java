package com.gmadong.common;

public class Authority implements java.io.Serializable {

	private String id = "";
	private String name = "";
	private String parent = "";
	private String user = "";
	private String type = "";
	public Authority() {
		super();
	}
	public Authority(String id, String name, String parent, String user,
			String type) {
		super();
		this.id = id;
		this.name = name;
		this.parent = parent;
		this.user = user;
		this.type = type;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getParent() {
		return parent;
	}
	public void setParent(String parent) {
		this.parent = parent;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
