package com.gmadong.common.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import com.gmadong.common.utils.StringUtil;
/**
 * 文件防盗链 拦截器
 * @author caodongdong
 */
public class FileFilter implements Filter
{

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException
	{
		HttpServletRequest req = (HttpServletRequest)request;
		String ref = req.getHeader("Referer");
		if(StringUtil.isNotEmpty(ref) && (ref.startsWith("http://127.0.0.1") || ref.startsWith("http://localhost") || ref.startsWith("http://39.96.202.166")))
		{
			chain.doFilter(request, response);
		}
	}
	@Override
	public void init(FilterConfig filterConfig) throws ServletException
	{
		

	}
	@Override
	public void destroy()
	{
	}

}
