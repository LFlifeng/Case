package com.gmadong.common.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gmadong.modules.organize.SysOrganize;

/**
 * HttpTool
 * @author caodongdong
 *
 */
public class HttpTool
{
	public static String post(String url, Map<String,String> map)
	{
		String body = "";
		try
		{
			//创建httpclient对象
			CloseableHttpClient client = HttpClients.createDefault();
			//创建post方式请求对象
			HttpPost httpPost = new HttpPost(url);
			
			//装填参数
			List<NameValuePair> nvps = new ArrayList<NameValuePair>();
			if(map!=null){
				for (Entry<String, String> entry : map.entrySet()) {
					nvps.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
				}
			}
			//设置参数到请求对象中
			httpPost.setEntity(new UrlEncodedFormEntity(nvps, "utf-8"));

			//System.out.println("请求地址："+url);
			//System.out.println("请求参数："+nvps.toString());
			
			//设置header信息
			//指定报文头【Content-type】、【User-Agent】
			httpPost.setHeader("Content-type", "application/x-www-form-urlencoded");
			//httpPost.setHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
			
			//执行请求操作，并拿到结果（同步阻塞）
			CloseableHttpResponse response = client.execute(httpPost);
			//获取结果实体
			HttpEntity entity = response.getEntity();
			if (entity != null) {
				//按指定编码转换结果实体为String类型
				body = EntityUtils.toString(entity, "utf-8");
			}
			EntityUtils.consume(entity);
			//释放链接
			response.close();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
        return body;
	}
	public static String get(String url)
	{
		try
		{
			CloseableHttpClient httpclient = HttpClients.createDefault();
			// 创建httpget.
			HttpGet httpget = new HttpGet(url);
			RequestConfig requestConfig = RequestConfig.custom()    
			        .setConnectTimeout(5000).setConnectionRequestTimeout(1000)    
			        .setSocketTimeout(5000).build();    
			httpget.setConfig(requestConfig);   
			// 执行get请求.
			CloseableHttpResponse response = httpclient.execute(httpget);
			// 获取响应实体
			HttpEntity entity = response.getEntity();
			int code = response.getStatusLine().getStatusCode();
			if(code!=200)
			{
				return "";
				
			}
			InputStream inputStream = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String line = reader.readLine().toString();
			inputStream.close();
			return line;
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return "";
	}
}
