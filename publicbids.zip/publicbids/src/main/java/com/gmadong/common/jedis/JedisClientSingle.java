package com.gmadong.common.jedis;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;



public class JedisClientSingle implements JedisClient
{
	//private static String KEY = "rkyback_";
	private JedisPool jedisPool;
	@Override
	public String set(String key, String value) 
	{
		//key = KEY + key;
		Jedis jedis = jedisPool.getResource();
		String result = "";
		try
		{
			result = jedis.set(key, value);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			jedis.close();
		}
		return result;
	}

	@Override
	public String get(String key) 
	{
		//key = KEY + key;
		Jedis jedis = jedisPool.getResource();
		String result = "";
		try
		{
			result = jedis.get(key);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			jedis.close();
		}
		return result;
	}

	@Override
	public Long hset(String key, String field, String value)
	{
		//key = KEY + key;
		Jedis jedis = jedisPool.getResource();
		Long result = 0L;
		try
		{
			result = jedis.hset(key, field, value);
		} catch (Exception e)
		{
			e.printStackTrace();
		}finally
		{
			jedis.close();
		}
		return result;
	}

	@Override
	public String hget(String key, String field) 
	{
		//key = KEY + key;
		Jedis jedis = jedisPool.getResource();
		String result = "";
		try
		{
			result = jedis.hget(key, field);
		} catch (Exception e)
		{
			e.printStackTrace();
		}finally
		{
			jedis.close();
		}
		return result;
	}

	@Override
	public Long incr(String key) 
	{
		//key = KEY + key;
		Jedis jedis = jedisPool.getResource();
		Long result  = 0L;
		try
		{
			result = jedis.incr(key);
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			jedis.close();
		}
		return result;
	}

	@Override
	public Long decr(String key) 
	{
		//key = KEY + key;
		Jedis jedis = jedisPool.getResource();
		Long result  = 0L;
		try
		{
			result = jedis.decr(key);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}finally
		{
			jedis.close();
		}
		return result;
	}

	@Override
	public Long expire(String key, int second) 
	{
		//key = KEY + key;
		Jedis jedis = jedisPool.getResource();
		Long result  = 0L;
		try
		{
			result = jedis.expire(key, second);
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}finally
		{
			jedis.close();
		}
		return result;
	}
	@Override
	public Long del(String key)
	{
		//key = KEY + key;
		Jedis jedis = jedisPool.getResource();
		Long result  = 0L;
		try
		{
			result = jedis.del(key);
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}finally
		{
			jedis.close();
		}
		return result;
	}
	@Override
	public Long hdel(String key, String field)
	{
		//key = KEY + key;
		Jedis jedis = jedisPool.getResource();
		Long result  = 0L;
		try
		{
			result = jedis.hdel(key, field);
		} catch (Exception e)
		{
			e.printStackTrace();
		}finally
		{
			jedis.close();
		}
		return result;
	}
	@Override
	public Long ttl(String key) 
	{
		//key = KEY + key;
		Jedis jedis = jedisPool.getResource();
		Long result  = 0L;
		try
		{
			result = jedis.ttl(key);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}finally
		{
			jedis.close();
		}
		return result;
	}

	public JedisPool getJedisPool()
	{
		return jedisPool;
	}

	public void setJedisPool(JedisPool jedisPool)
	{
		this.jedisPool = jedisPool;
	}

	@Override
	public void set(String key, String value, int second)
	{
		//key = KEY + key;
		Jedis jedis = jedisPool.getResource();
		try
		{
			jedis.set(key, value);
			jedis.expire(key, second);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			jedis.close();
		}
	}
	@Override
	public void hset(String key, String field, String value, int second)
	{
		//key = KEY + key;
		Jedis jedis = jedisPool.getResource();
		try
		{
			jedis.hset(key, field, value);
			jedis.expire(key, second);
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}finally
		{
			jedis.close();
		}
	}
	@Override
	public Set<String> keys(String key)
	{
		//key = KEY + key;
		Set<String> list = null;
		Jedis jedis = jedisPool.getResource();
		try
		{
			list = jedis.keys(key);
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}finally
		{
			jedis.close();
		}
		return list;
	}
}