package com.gmadong.common.quartz;

import com.gmadong.common.ApplicationContextUtil;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.modules.staff.SysStaffService;

public class QuartzJob 
{
	
	public void work()
	{
		
	}
	public void authority()
	{
		//JedisClientSingle jedisClientSingle =  (JedisClientSingle) ApplicationContextUtil.getBean("jedisClientSingle");
	}
	

}
