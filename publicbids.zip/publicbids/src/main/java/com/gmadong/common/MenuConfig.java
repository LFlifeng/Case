package com.gmadong.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.gmadong.common.jedis.JedisClientSingle;
/***
 * 
 * @ClassName: MenuConfig
 * @Description: 读取菜单信息
 * @author caodong
 * @date 2016年9月8日 上午10:48:21
 *
 */
public class MenuConfig
{	
    public static String getAllMenuString() 
    {
    	if(Common.menuConfig!=null)
    	{
    		return Common.menuConfig;
    	}
    	String filePath = "/com/gmadong/configs/menuConfig.txt";
    	String str = "";
        InputStream txtInputStream = MenuConfig.class.getResourceAsStream(filePath);
        try {
        	BufferedReader br = new BufferedReader(new InputStreamReader(txtInputStream, "utf-8"));
			String data = null;
			while((data = br.readLine()) != null){
				str += data;
			}
			// 去掉空白
			str = str.replaceAll("\\t", "").replaceAll("\\n", "").replaceAll("\\r", "").replaceAll(" ", "");
		} catch (IOException e) {
			e.printStackTrace();
		}
        Common.menuConfig = str;
        return str;
    }
}