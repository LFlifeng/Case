package com.gmadong.common.filter;
import java.io.IOException;
import java.util.HashMap;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.user.User;

/**
 * 
 * @ClassName: AuthorityFilter
 * @Description: 前台权限过滤器(*.action)
 * @author caodong
 * @date 2016年9月8日 上午11:02:28
 *
 */
public class AuthorityFrontFilter  implements Filter
{
	public HttpServletRequest request;
	public HttpServletResponse response;
	@Override
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException
	{
		request = (HttpServletRequest) req;
		response = (HttpServletResponse) resp;
		HttpSession session = request.getSession();
		if(session.getAttribute("skin") == null || session.getAttribute("skin").equals(""))
		{
			session.setAttribute("skin",  "/skin/default/");
		}
		String url = request.getServletPath();
		if(StringUtil.isNotEmpty(url))
		{
			url  = url.replaceAll("\\/", "");
		}
		else
		{
			url = "";
		}
		/*
		String agent =   request.getHeader("User-Agent");
		System.out.println(url);
		System.out.println(agent);*/
		nextChain(req, resp, chain, session, url);
	}
	/**
	 * 分发到下一个拦截器
	 * @param req
	 * @param resp
	 * @param chain
	 * @param session
	 * @throws IOException
	 * @throws ServletException
	 */
	private void nextChain(ServletRequest req, ServletResponse resp, FilterChain chain, HttpSession session,String url)
			throws IOException, ServletException
	{
		User user = (User) session.getAttribute("user");
		if(user==null)
		{
			  String requestType = request.getHeader("X-Requested-With");
			 if ("XMLHttpRequest".equalsIgnoreCase(requestType))
			 {
				  if(AuthorityMap.loginMap.containsKey(url))
				  {
					  response.setHeader("REDIRECT", "REDIRECT");
					  response.setHeader("CONTEXTPATH","/userQd.login.do");
					  response.setStatus(HttpServletResponse.SC_FORBIDDEN);
				  } 
				  else
				  {
					  chain.doFilter(req, resp);
					 
				  }
       		}
			else if(AuthorityMap.loginMap.containsKey(url))
			{
				response.sendRedirect("/userQd.login.do");
			}
			else
			{
				chain.doFilter(req, resp);
			}
		}
		else
		{
			//判断权限
			
			chain.doFilter(req, resp);
		}
	}
	@Override
	public void destroy()
	{
		
	}
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException 
	{
		
	}
}
