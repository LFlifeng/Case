package com.gmadong.common.utils;

import java.util.List;

public class LogUtil
{
   public static void i(String str)
   {
	   System.out.println(str);
   }
   public static void i(String msg,Object obj)
   {
	   System.out.println(msg+JsonUtil.bean2json(obj));
   }
   public static void i(String msg,List list)
   {
	   System.out.println(msg+JsonUtil.listToJson(list));
   }
}
