package com.gmadong.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.springframework.beans.factory.annotation.Autowired;

import com.gmadong.common.jedis.JedisClientSingle;
/**
 * 
 * @ClassName: ActionConfig
 * @Description: 读取权限信息
 * @author caodong
 * @date 2016年9月8日 上午10:47:58
 *
 */
public class ActionConfig {

	
    public static String getAllActionString() 
    {
    	if(Common.actionConfig!=null)
    	{
    		return Common.actionConfig;
    	}
    	String filePath = "/com/gmadong/configs/actionConfig.txt";
    	String str = "";
        InputStream txtInputStream = ActionConfig.class.getResourceAsStream(filePath);
        try {
        	BufferedReader br = new BufferedReader(new InputStreamReader(txtInputStream, "utf-8"));
			String data = null;
			while((data = br.readLine()) != null)
			{
				str += data;
			}
			// 去掉空白
			str = str.replaceAll("\\t", "").replaceAll("\\n", "").replaceAll("\\r", "").replaceAll(" ", "");
			
		} catch (IOException e) {
			e.printStackTrace();
		}
        Common.actionConfig = str;
        return str;
    }
}