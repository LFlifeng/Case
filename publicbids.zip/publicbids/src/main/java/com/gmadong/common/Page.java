package com.gmadong.common;

import java.util.ArrayList;
import java.util.List;

import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;


public class Page {

	
	public static int PAGESIZE = 10;
	private long totalRecord;
	private long totalPage;
	private List<?> list;
	public Page()
	{
		super();
	}
	public Page(long totalRecord, long totalPage, List<?> list)
	{
		super();
		this.totalRecord = totalRecord;
		this.totalPage = totalPage;
		this.list = list;
	}
	public long getTotalRecord() {
		return totalRecord;
	}
	public void setTotalRecord(long totalRecord) {
		this.totalRecord = totalRecord;
	}
	public long getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(long totalPage) {
		this.totalPage = totalPage;
	}
	public List<?> getList()
	{
		return list;
	}
	public void setList(List<?> list) 
	{
		this.list = list;
	}
	public static Page getEmptyPage()
	{
		Page page = new Page();
		page.setList(new ArrayList());
		page.setTotalPage(0);
		page.setTotalRecord(0);
		return page;
	}
	public static String pageToJson(Page page)
	{
		String json = JsonUtil.listToJson(page.getList());
		json = "{\"total\":\""+page.getTotalRecord()+"\",\"rows\":" + json + "}";
		return json;
	}
}