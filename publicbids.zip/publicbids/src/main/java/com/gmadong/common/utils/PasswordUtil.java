package com.gmadong.common.utils;


/**
 * 密码统一加密类
 * @ClassName: PasswordUtil
 * @Description: 
 * @author caodong
 * @date 2016年9月8日 下午1:49:04
 *
 */
public class PasswordUtil 
{
	public enum PasswordUtilType
	{
	    NORMAL,BACK;
	}
	/***
	 * 
	 * @param pwd
	 * @param type  0 普通用户（app,前台所有的客户密码）后16位  
	 *              1 后台管理员   (内部后台密码)后14位
	 *         
	 * @return
	 */
	public static String encrypt(String pwd,PasswordUtilType type)
	{
		String passwd = Md5Util.md5(pwd);
		if(type==PasswordUtilType.NORMAL)
		{
			passwd = Md5Util.md5(passwd.substring(16)+"normal");
		}
		else if(type==PasswordUtilType.BACK)
		{
			passwd = Md5Util.md5(passwd.substring(14)+"back");
		}		
		return passwd;
	}
}
