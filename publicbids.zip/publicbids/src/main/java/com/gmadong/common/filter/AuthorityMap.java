package com.gmadong.common.filter;

import java.util.HashMap;

public class AuthorityMap
{
	public static HashMap<String, Boolean> loginMap = new HashMap<String, Boolean>();
	public static HashMap<String, Boolean> mainMap = new HashMap<String, Boolean>();
	
	static 
	{
		loginMap.put("userQd.center.do", true);
		loginMap.put("userCollection.add.do", true);
		loginMap.put("userCollection.listIndex.do", true);
		loginMap.put("userCollection.Userlist.do", true);
		loginMap.put("userCollection.delete.do", true);
		loginMap.put("userQd.serviceStandards.do",true);
		loginMap.put("userQd.paymentInstruction.do",true);
		loginMap.put("userQd.accountInformationIndex.do",true);
		loginMap.put("userQd.systeminformation.do.do",true);
		loginMap.put("userQd.updateAccountInformation.do", true);
		loginMap.put("userQd.promotionserver.do", true);
		
		
		loginMap.put("mangerelease.index.do", true);
		
		loginMap.put("biddinginfo.add.do", true);
		loginMap.put("biddinginfo.delete.do", true);
		loginMap.put("biddinginfoFront.list.do", true);
		loginMap.put("billinginfo.selectApplyinvoice.do", true);
		loginMap.put("billinginfo.updateApplyinvoice.do", true);
		loginMap.put("billinginfo.publishedList.do", true);
		loginMap.put("userQd.bindEmailIndex.do",true);
		loginMap.put("userQd.bindEmail.do",true);
		
		
		loginMap.put("designedinfo.Userlist.do", true);
		loginMap.put("designedinfo.listIndex.do", true);
		
		loginMap.put("browsingHistory.listIndex.do", true);
		loginMap.put("browsingHistory.Userlist.do", true);
		loginMap.put("browsingHistory.delete.do", true);
		
		loginMap.put("trackerFront.page.do",true);
		loginMap.put("trackerFront.addTracker.do",true);
		loginMap.put("trackerFront.editTracker.do",true);
		
		
		loginMap.put("attach.uploadImage.do", true);
		loginMap.put("attach.upload.do", true);
		
		loginMap.put("sysCity.city.do", true);
		loginMap.put("serQd.memberserver.do", true);
		loginMap.put("systemQd.list.do",true);
		loginMap.put("systemQd.systeminformation.do", true);
		loginMap.put("systemQd.paymentInstruction.do",true);
		loginMap.put("systemQd.deleteSystemById.do",true);
		
		loginMap.put("trackerFront.delete.do", true);
		loginMap.put("trackerFront.list.do", true);
		loginMap.put("trackerFront.doAdd.do",true);
		loginMap.put("trackerFront.doEdit.do",true);
		
		loginMap.put("projectDesigneds.add.do", true);
		
		loginMap.put("publishInformation.index.do", true);
		
		loginMap.put("qualification.buildQyzz.do", true);
		loginMap.put("qualification.list.do", true);
		loginMap.put("qualification.deletelist.do", true);
		loginMap.put("qualification.doAdd.do", true);
		
		
		loginMap.put("product.listshow.do", true);
		loginMap.put("product.buildCpzs.do", true);
		loginMap.put("product.deletelist.do", true);
		loginMap.put("product.doAdd.do", true);
		
		
		loginMap.put("company.auditing.do", true);
		
		loginMap.put("manageCondition.buildJyzz.do", true);
		loginMap.put("manageCondition.list.do", true);
		loginMap.put("manageCondition.deletelist.do", true);
		loginMap.put("manageCondition.doAdd.do", true);
		
//		loginMap.put("application.listIndex.do", true);
		loginMap.put("application.listShow.do", true);
		loginMap.put("application.entry.do", true);
		loginMap.put("application.uploadAudt.do", true);
		
	}
	
	
	
	
	
	

}
