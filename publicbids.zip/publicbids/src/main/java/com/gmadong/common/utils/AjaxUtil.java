package com.gmadong.common.utils;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
/***
 * 统一的ajax输出
 * @ClassName: AjaxUtil
 * @Description: 
 * @author caodong
 * @date 2016年9月8日 下午1:46:37
 *
 */
public class AjaxUtil {

	public static void write(String out,HttpServletResponse response)
	{
		response.setContentType("text/html;charset=utf-8");
		PrintWriter pw = null;
		try
		{
			pw = response.getWriter();
			pw.write(out);
			pw.flush();
			pw.close();
			
		}catch(IOException e)
		{
			e.printStackTrace();
		}
	}
}
