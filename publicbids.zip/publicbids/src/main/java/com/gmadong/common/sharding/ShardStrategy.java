package com.gmadong.common.sharding;

/**
 * 分表接口
 * @ClassName: ShardStrategy
 * @Description: 
 * @author caodong
 * @date 2017年6月7日 下午6:13:55
 *
 */
public interface ShardStrategy
{
	public String getTargetTableName(String tableName, String mapperId);
}
