package com.gmadong.common.utils;

import java.util.Random;
import java.util.UUID;
/**
 * 生成UUID工具类
 * @ClassName: UUIDUtil
 * @Description: 
 * @author caodong
 * @date 2016年9月9日 下午2:28:48
 *
 */
public class UUIDUtil 
{

	public static String getUUID()
	{
		String uuid =  UUID.randomUUID().toString()+new Random().nextInt();
		return Md5Util.md5(uuid);
	}
}
