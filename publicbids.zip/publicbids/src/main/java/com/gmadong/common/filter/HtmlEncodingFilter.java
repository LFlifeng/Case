package com.gmadong.common.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * @ClassName: HtmlEncodingFilter
 * @Description: html编码
 * @author caodong
 * @date 2016年9月12日 上午9:16:24
 *
 */
public class HtmlEncodingFilter implements Filter {

	public void doFilter(ServletRequest request, ServletResponse response, 
						FilterChain chain) throws IOException, ServletException {
		//request.setCharacterEncoding("GBK");
		response.setCharacterEncoding("GBK");
		chain.doFilter(request, response);
	}

	public void init(FilterConfig arg0) throws ServletException {
		
	}

	public void destroy() {
		
	}

}
