package com.gmadong.common.jedis;

import java.util.Set;

public interface JedisClient 
{

	public String set(String key, String value);
	public String get(String key) ;
	public Long del(String key) ;
	public Long hset(String key, String field, String value);
	public String hget(String key, String field) ;
	public Long hdel(String key, String field) ;
	public Long incr(String key) ;
	public Long decr(String key) ;
	public Long expire(String key, int second) ;
	public Long ttl(String key);
	
	public void set(String key, String value,int second);
	public void hset(String key, String field, String value, int second);
	
	public Set<String> keys(String key);
}
