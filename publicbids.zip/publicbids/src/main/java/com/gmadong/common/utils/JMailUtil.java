package com.gmadong.common.utils;

import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class JMailUtil
{

	public static boolean checkEmail(String email)
	{
		boolean flag = false;
        try{
                String check = "^([a-z0-9A-Z]+[-|_|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";          
                Pattern regex = Pattern.compile(check);
                Matcher matcher = regex.matcher(email);
                flag = matcher.matches();
            }catch(Exception e){
                flag = false;
            }
        return flag;
	}
	
	public static void main(String[] args) {
		System.out.println(checkEmail("353225790qq.com"));
	}
	public static boolean sendCode(String email, String code)
	{
		Properties props = new Properties();

		Session session = Session.getInstance(props, null);
		session.setDebug(false);
		Message message = new MimeMessage(session); 
		try
		{
			message.setFrom(new InternetAddress("bjzhzb@126.com")); 
			message.setContent("<b>【中汇招标网】您的验证码是:<font color='red'>"+code+"</font></b>","text/html;charset=utf8"); 
			message.setSubject("中汇招标网"); 
			message.setRecipient(Message.RecipientType.TO, new InternetAddress(email)); 
			Transport transport = session.getTransport("smtp");
			transport.connect("smtp.126.com", "bjzhzb@126.com", "jftg123");
			transport.sendMessage(message, message.getAllRecipients());
			transport.close();
			
			return true;
			
		} catch (AddressException e)
		{

		} catch (MessagingException e)
		{
		}
		return false;
	}
	
}
