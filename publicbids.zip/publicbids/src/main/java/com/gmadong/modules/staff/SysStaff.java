package com.gmadong.modules.staff;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class SysStaff {
    /** ID */
    private String id;

    @NotBlank(message="部门不能为空" ,groups = { ValidateSysStaffSaveAction.class,ValidateSysStaffUpdateAction.class })
    private String organizeId;

    /** 角色ID 只有type等于2时有值 */
    @NotBlank(message="角色不能为空" ,groups = { ValidateSysStaffSaveAction.class ,ValidateSysStaffUpdateAction.class})
    private String roleId;

    /** 登录名 */
    @NotBlank(message="用户名不能为空", groups = { ValidateSysStaffLoginAction.class, ValidateSysStaffSaveAction.class })
    @Size(min=5,max=11,message="请输入正确的用户名",groups = { ValidateSysStaffLoginAction.class, ValidateSysStaffSaveAction.class })
   // @Pattern(regexp = "(^1(3[0-9]|4[57]|5[0-35-9]|7[01678]|8[0-9])\\d{8}$)|(^admin$)", message = "请输入正确的手机号",groups = { ValidateSysStaffLoginAction.class, ValidateSysStaffSaveAction.class })
    private String loginname;

    /** 工号 */
    @NotBlank(message="员工工号不能为空" ,groups = { ValidateSysStaffSaveAction.class ,ValidateSysStaffUpdateAction.class})
    private String jobNumber;

    /** 电话号 */
    @Pattern(regexp = "(^1(3[0-9]|4[57]|5[0-35-9]|7[01678]|8[0-9])\\d{8}$)|(^admin$)", message = "请输入正确的手机号" ,groups = { ValidateSysStaffSaveAction.class,ValidateSysStaffUpdateAction.class })
    private String phone;

    /** 昵称 */
    @NotBlank(message="真实姓名不能为空",groups = { ValidateSysStaffSaveAction.class,ValidateSysStaffUpdateAction.class})
    @Size(min=1,max=20,message="请输入正确的真实姓名",groups = {  ValidateSysStaffSaveAction.class,ValidateSysStaffUpdateAction.class })
    private String nickname;

    /** 密码 */
    @NotBlank(message="密码不能为空",groups = { ValidateSysStaffLoginAction.class, ValidateSysStaffSaveAction.class })
    @Size(min=6,max=12,message="密码长度必须在6到12位之间",groups = { ValidateSysStaffLoginAction.class, ValidateSysStaffSaveAction.class })
    private String pwd;
    
    /** 最后登录时间 */
    private String ltime;

    /** 添加时间 */
    private String ctime;

    /** 状态0-删除 1-正常 */
    private Integer status;

    /**
     * ID
     * @return id
     */
    public String getId() {
        return id;
    }

    /**
     * ID
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getOrganizeId() {
        return organizeId;
    }

    public void setOrganizeId(String organizeId) {
        this.organizeId = organizeId == null ? null : organizeId.trim();
    }

    /**
     * 角色ID 只有type等于2时有值
     * @return roleId
     */
    public String getRoleId() {
        return roleId;
    }

    /**
     * 角色ID 只有type等于2时有值
     * @param roleId
     */
    public void setRoleId(String roleId) {
        this.roleId = roleId == null ? null : roleId.trim();
    }

    /**
     * 登录名
     * @return loginname
     */
    public String getLoginname() {
        return loginname;
    }

    /**
     * 登录名
     * @param loginname
     */
    public void setLoginname(String loginname) {
        this.loginname = loginname == null ? null : loginname.trim();
    }

    /**
     * 工号
     * @return jobNumber
     */
    public String getJobNumber() {
        return jobNumber;
    }

    /**
     * 工号
     * @param jobNumber
     */
    public void setJobNumber(String jobNumber) {
        this.jobNumber = jobNumber == null ? null : jobNumber.trim();
    }

    /**
     * 电话号
     * @return phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * 电话号
     * @param phone
     */
    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    /**
     * 昵称
     * @return nickname
     */
    public String getNickname() {
        return nickname;
    }

    /**
     * 昵称
     * @param nickname
     */
    public void setNickname(String nickname) {
        this.nickname = nickname == null ? null : nickname.trim();
    }

    /**
     * 密码
     * @return pwd
     */
    public String getPwd() {
        return pwd;
    }

    /**
     * 密码
     * @param pwd
     */
    public void setPwd(String pwd) {
        this.pwd = pwd == null ? null : pwd.trim();
    }

   
    /**
     * 添加时间
     * @return ctime
     */
    public String getCtime() {
        return ctime;
    }

    /**
     * 添加时间
     * @param ctime
     */
    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }

    /**
     * 状态0-删除 1-正常
     * @return status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 状态0-删除 1-正常
     * @param status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }
    /**
     * 最后登录时间
     * @return ltime
     */
    public String getLtime() {
        return ltime;
    }

    /**
     * 最后登录时间
     * @param ltime
     */
    public void setLtime(String ltime) {
        this.ltime = ltime == null ? null : ltime.trim();
    }
	@Override
	public String toString()
	{
		return "SysStaff [id=" + id + ", organizeId=" + organizeId
				+ ", roleId=" + roleId + ", loginname=" + loginname
				+ ", jobNumber=" + jobNumber + ", phone=" + phone
				+ ", nickname=" + nickname + ", pwd=" + pwd + ", ctime="
				+ ctime + ", status=" + status + "]";
	}
    
}