package com.gmadong.modules.manageCondition;

import com.gmadong.modules.manageCondition.ManageCondition;
import com.gmadong.modules.manageCondition.ManageConditionExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ManageConditionMapper {
    int countByExample(ManageConditionExample example);

    int deleteByExample(ManageConditionExample example);

    int deleteByPrimaryKey(String id);

    int insert(ManageCondition record);

    int insertSelective(ManageCondition record);

    List<ManageCondition> selectByExample(ManageConditionExample example);

    ManageCondition selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") ManageCondition record, @Param("example") ManageConditionExample example);

    int updateByExample(@Param("record") ManageCondition record, @Param("example") ManageConditionExample example);

    int updateByPrimaryKeySelective(ManageCondition record);

    int updateByPrimaryKey(ManageCondition record);
}