package com.gmadong.modules.columnCategory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.common.utils.XSSUtils;

import com.gmadong.modules.columnCategory.ColumnCategoryExample.Criteria;


@Service("columnCategoryService")
public class ColumnCategoryServiceImpl implements ColumnCategoryService
{	
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private ColumnCategoryMapper columnCategoryMapper;
	private static final String parentCategorysKey = "ColumnCategoryServiceImpl.ParentCategorys";

	@Override
	public boolean save(String columnName, String url, String pId, String sortIndex) {
		ColumnCategory category = new ColumnCategory(url, columnName, pId);
		category.setId(UUIDUtil.getUUID());
		category.setCtime(DateUtil.getCurrentDate());
		category.setSortIndex(Integer.valueOf(sortIndex));

		XSSUtils.clearXss(ColumnCategory.class, category);
		boolean flag = columnCategoryMapper.insert(category) > 0;
		if (flag && StringUtil.isEmpty(pId)) {// 删除缓存
			try 
			{
				jedisClientSingle.del(parentCategorysKey);

			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		return flag;
	}

	@Override
	public Page page(String columnName, String url, String ctime, Integer page, Integer rows) 
	{
		ColumnCategoryExample categoryExample = new ColumnCategoryExample();
		Criteria criteria = categoryExample.createCriteria();
		if (!StringUtil.isEmpty(columnName)) {
			criteria.andColumnNameLike(columnName + "%");
		}
		if (!StringUtil.isEmpty(url)) {
			criteria.andUrlLike(url + "%");
		}
		if (!StringUtil.isEmpty(ctime)) {

			criteria.andCtimeLike(ctime + "%");
		}
		categoryExample.setOrderByClause(" p_ID,sort_index ");

		PageHelper.startPage(page, rows);
		List<ColumnCategory> list = columnCategoryMapper.selectByExample(categoryExample);
		PageInfo<ColumnCategory> pageInfo = new PageInfo<ColumnCategory>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}
	
	@Override
	public boolean deleteById(String ids) {
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");

			ColumnCategoryExample categoryExample = new ColumnCategoryExample();
			Criteria createCriteria = categoryExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			return columnCategoryMapper.deleteByExample(categoryExample) > 0;
		}
		return false;
	}

	@Override
	public List<ColumnCategory> getParent() {
		try {// 从缓存中得到数据
			String list = jedisClientSingle.get(parentCategorysKey);
			if (StringUtil.isNotEmpty(list)) {
				ObjectMapper mapper = new ObjectMapper();
				List<ColumnCategory> keys = mapper.readValue(list, new TypeReference<List<ColumnCategory>>() {
				});
				return keys;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		ColumnCategoryExample categoryExample = new ColumnCategoryExample();
		Criteria criteria = categoryExample.createCriteria();
		criteria.andPIdEqualTo("");
		categoryExample.setOrderByClause(" sort_index ");
		List<ColumnCategory> selectByExample = columnCategoryMapper.selectByExample(categoryExample);
		try {// 添加缓存
			jedisClientSingle.set(parentCategorysKey, JsonUtil.listToJson(selectByExample));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return selectByExample;
	}
	
	@Override
	public boolean update(ColumnCategory category) {
		int updateByPrimaryKey = columnCategoryMapper.updateByPrimaryKey(category);
		if (updateByPrimaryKey == 1) {
			return true;
		} else {
			return false;
		}
	}
	
	@Override
	public ColumnCategory getColumnCategoryById(String id) {
		return columnCategoryMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<ColumnCategoryMiniInfo> getMiniInfo()
	{
		List<ColumnCategoryMiniInfo> list = new ArrayList<ColumnCategoryMiniInfo>();
		List<ColumnCategory> all = columnCategoryMapper.selectAll();
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		for(ColumnCategory item :all)
		{
			if(StringUtil.isEmpty(item.getpId()))
			{
				map.put(item.getId(), list.size());
				list.add(new ColumnCategoryMiniInfo(item.getUrl(), item.getColumnName()));
			}
			else
			{
				if(map.containsKey(item.getpId()))
				{
					ColumnCategoryMiniInfo info = list.get(map.get(item.getpId()));
					info.getList().add(new ColumnCategoryMiniInfo(item.getUrl(), item.getColumnName()));
				}	
			}
		}
		return list;
	}
	
}
