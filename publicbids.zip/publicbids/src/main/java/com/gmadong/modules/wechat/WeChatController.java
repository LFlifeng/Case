package com.gmadong.modules.wechat;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;

import net.sf.json.JSONObject;

/**
 * 获取微信公众号验证控制层
 * 
 * @author Administrator
 *
 */
@Controller
public class WeChatController {

	@Autowired
	private WeChatService weChatService;

	@Autowired
	private JedisClientSingle jedisClientSingle;

	private final String accessTokenKey = "access_token";

	/**
	 * 签名验证
	 * 
	 * @param response
	 * @param signature
	 * @param timestamp
	 * @param nonce
	 * @param echostr
	 * @return
	 */
	@RequestMapping(value = "/wx.index.do", method = RequestMethod.GET)
	public void findLatestRelease(HttpServletResponse response, String signature, String timestamp, String nonce,
			String echostr) {

		String mySignature = WeChatUtil.checkSignature(signature, timestamp, nonce);
		if (!"".equals(signature) && !"".equals(mySignature) && signature.equals(mySignature)) {
			System.out.println("-----签名校验通过-----");
			AjaxUtil.write(echostr, response);
		} else {
			System.out.println("-----校验签名失败-----");
		}

	}

	/**
	 * 接受微信服务器发送的信息
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/wx.index.do", method = RequestMethod.POST)
	public void processMsg(HttpServletRequest request, HttpServletResponse response) {
		String respXml = weChatService.processRequest(request);
		AjaxUtil.write(respXml, response);
	}

	/**
	 * 根据标签id群发每日推荐公告
	 * 
	 * @param request
	 * @param response
	 * @param tagId
	 */
	@RequestMapping(value = "/wx.dailyPush.do")
	public void dailyPush(HttpServletRequest request, HttpServletResponse response, int tagId) {
		String data = weChatService.getTxtMessage();
		data = data.replace("'", "\"");
		AccessToken accessToken = null;
		try {
			String atStr = jedisClientSingle.get(accessTokenKey);
			if (StringUtil.isNotEmpty(atStr)) {
				JSONObject jsonObject = JSONObject.fromObject(atStr);
				accessToken = (AccessToken) JSONObject.toBean(jsonObject, AccessToken.class);
			} else {
				accessToken = WeChatUtil.getAccessToken();
				atStr = JsonUtil.bean2json(accessToken);
				jedisClientSingle.set(accessTokenKey, atStr, 7000);
			}
		} catch (Exception e) {
		}
		MassMsgResult result = UserManager.sendTextToTag(accessToken.getAccess_token(), tagId, data);
		if ("0".equals(result.getErrcode())) {
			AjaxUtil.write("succ", response);
			return;
		} else {
			AjaxUtil.write("fail:" + result.getErrmsg(), response);
		}
	}
}
