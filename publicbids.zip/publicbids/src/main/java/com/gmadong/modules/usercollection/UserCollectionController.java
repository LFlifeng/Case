package com.gmadong.modules.usercollection;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.user.User;

import net.sf.json.JSONObject;

/**
 * 用户中心-我的收藏控制层
 * 
 * @author Administrator
 *
 */
@Controller
public class UserCollectionController {

	@Resource(name = "userCollectionService")
	private UserCollectionService userCollectionService;

	@Autowired
	private JedisClientSingle jedisClientSingle;

	private String listkey = "userCollection.list_";

	/**
	 * 我的收藏页面跳转
	 * 
	 * @return
	 */
	@RequestMapping("/userCollection.listIndex.do")
	public String page() {
		return "/front/usercenter/collection";
	}

	/**
	 * 我的收藏列表查询
	 * 
	 * @param response
	 * @param page
	 * @param rows
	 */
	@RequestMapping("/userCollection.Userlist.do")
	public void list(HttpServletResponse response, @RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "20") Integer rows) {

		User user = (User) Session.get("user");
		if (user == null) {
			AjaxUtil.write("用户未登陆", response);
			return;
		}
		String userId = user.getId();
		String field = page + "-" + rows;
		try {
			String list = jedisClientSingle.hget(listkey + userId, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = userCollectionService.page(userId, page, rows);
		String listStr = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey + userId, field, listStr, Common.REDIS_48_HOUR_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
	}

	/**
	 * 删除我的收藏
	 * 
	 * @param response
	 * @param id
	 */
	@RequestMapping("/userCollection.delete.do")
	public void deleteUserCollection(HttpServletResponse response, String id) {
		User user = (User) Session.get("user");
		if (user == null) {
			AjaxUtil.write("用户未登陆", response);
			return;
		}
		String userId = user.getId();
		if (userCollectionService.deleteById(id)) {
			try {
				jedisClientSingle.del(listkey + userId);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("fail", response);
		}
	}

	/**
	 * 添加我的收藏
	 * 
	 * @param response
	 * @param id
	 */
	@RequestMapping("/userCollection.add.do")
	public void addUserCollection(HttpServletResponse response, String biddingInfoId, String binddingInfoTitle) {
		User user = (User) Session.get("user");
		if (user == null) {
			AjaxUtil.write("用户未登陆", response);
			return;
		}
		UserCollection userCollection;
		userCollection = userCollectionService.selectByBiddingInfoId(biddingInfoId);
		if (userCollection != null) {
			AjaxUtil.write("文章已收藏，请勿重复收藏", response);
			return;
		}
		userCollection = new UserCollection();
		String userId = user.getId();
		userCollection.setBiddinginfoId(biddingInfoId);
		userCollection.setBiddinginfoTitle(binddingInfoTitle);
		userCollection.setUserId(userId);
		userCollection.setId(UUIDUtil.getUUID());
		userCollection.setCtime(DateUtil.getCurrentDate());
		if (userCollectionService.save(userCollection)) {
			try {
				jedisClientSingle.del(listkey + userId);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("收藏成功", response);
		} else {
			AjaxUtil.write("收藏失败", response);

		}
	}
}
