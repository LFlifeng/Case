package com.gmadong.modules.projectDesigneds;

public interface ValidatebProjectDesignedsEditAction
{

}
