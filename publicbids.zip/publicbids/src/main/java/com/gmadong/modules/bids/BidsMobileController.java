package com.gmadong.modules.bids;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.Md5Util;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.biddinginfo.Biddinginfo;
import com.gmadong.modules.biddinginfo.BidsParamsInfo;
import com.gmadong.modules.city.CityMinInfo;
import com.gmadong.modules.city.SysCityService;
import com.gmadong.modules.user.User;

import net.sf.json.JSONObject;

@Controller
public class BidsMobileController
{

	@Resource(name = "bidsService")
	private BidsService bidsService;
	@Autowired
	BidsMobileService bidsMobileService;
	@Autowired
	JedisClientSingle jedisClientSingle;
	@Autowired
	SysCityService sysCityService;
	/**
	 * 查询城市
	 * @param response
	 * @param id
	 * @param type
	 */
	@RequestMapping("/bidsMobile.city.do")
	public void province(HttpServletResponse response,String id,String type)
	{
		String key = "city.key";
		String field = id+"_"+type;
		
		try
		{
			String list = jedisClientSingle.hget(key, field);
			if(StringUtil.isNotEmpty(list))
			{
				AjaxUtil.write(list, response);
				return;
			}
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	
		List<CityMinInfo> selectProvince = sysCityService.selectCityById(id);
		if(StringUtil.isNotEmpty(type))
		{
			if("0".equals(id))
			{
				selectProvince.add(0, new CityMinInfo(-1, "全国"));
			}
			else
			{
				selectProvince.add(0, new CityMinInfo(-2, "全部"));
			}
			
		}
		
		String list = JsonUtil.listToJson(selectProvince);
		try
		{
			jedisClientSingle.hset(key,field, list, Common.REDIS_72_HOUR_EXPIRE);
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		
		AjaxUtil.write(list, response);
	}
	/**
	 * 
	 * @param response
	 * @param infoType
	 * @param date
	 * @param regions
	 * @param keyword
	 * @param industry
	 * @param page
	 * @param rows
	 */
	@RequestMapping("/bidsMobile.list.do")
	public void hotList(HttpServletResponse response,String infoType,String date, String regions,String  keyword, @RequestParam(defaultValue = "1") Integer page,@RequestParam(defaultValue = "20") Integer rows) 
	{
		String key = "bids.list.do";
		String industry ="";
		if(StringUtil.isEmpty(date))
		{
			date = DateUtil.getFormatDateTime(DateUtil.getDateBeforeOrAfter(new Date(), -7), "yyyy-MM-dd");
		}
		
		String field = infoType + "-" + keyword + "-" + date + "-" + regions + "-" + industry + "-" + page + "-" + rows;
		try
		//SELECT id, name, province, time, type from bids WHERE time >= '2018-10-18' AND province like '广东%' order by time desc limit ?,? 
		{//SELECT id, name, province, time, type from bids WHERE time >= '2018-06-11' AND province like '广东省%' order by time desc limit ?,? 
			String list=jedisClientSingle.hget(key,field);
			if(StringUtil.isNotEmpty(list)) {
				 AjaxUtil.write(list, response);
				 return;
			}
		} catch (Exception e)
		{}
		
		
		Page toPage = bidsService.page(infoType, keyword, date, regions, industry, page, rows);
		String listStr = Page.pageToJson(toPage);
		AjaxUtil.write(listStr, response);
		try {
			jedisClientSingle.hset(key, field, listStr, Common.REDIS_6_HOUR_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
     
	}
	/**
	 * 投标详情查询
	 * 
	 * @param response
	 * @param id       公告id
	 */
	@RequestMapping("/bidsMobile.details.do")
	public String details(HttpServletResponse response, Integer id) {
		BidsWithBLOBs bid = null;
		String key = "bids.details-" + id;
		try {

			String detail = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(detail)) {
				JSONObject jsonObject = JSONObject.fromObject(detail);
				bid = (BidsWithBLOBs) JSONObject.toBean(jsonObject, BidsWithBLOBs.class);
				Request.set("detail", bid);
				return "/mobile/detail/detail";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		bid = bidsMobileService.details(id);
		String detail = JsonUtil.bean2json(bid);

		try {
			jedisClientSingle.set(key, detail, Common.REDIS_6_HOUR_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Request.set("detail", bid);
		return "/mobile/detail/detail";
	}
   }





















