package com.gmadong.modules.application;

import java.util.List;

import com.gmadong.common.Page;

public interface ApplicationQdService
{

	Application selectByUserId(String id);
	
	List<ExcellentApplication> findFamousCompany();

	List<ExcellentApplication> findTopFamousCompany();
	
	boolean updateUploadAudit(Application application);

	List<ExcellentApplication> findExcellentApplication();

	Page page(Integer page, Integer rows);

	Application selectCompanyById(String applicationId);

	List<ExcellentApplication> findFamousCompanyWall();

}
