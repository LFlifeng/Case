package com.gmadong.modules.bidsCategory;

import java.util.ArrayList;
import java.util.List;

import com.gmadong.common.Page;
import com.gmadong.common.utils.JsonUtil;

public class BidsCategoryQd 
{
	private String name;
	private List<String> list;

	
	public List<String> getList() {
		return list;
	}
	public void setList(List<String> list) {
		this.list = list;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "BidsCategoryQd [name=" + name + ", list=" + list + "]";
	}
	
	public BidsCategoryQd(String name) {
		super();
		this.name = name;
		this.list = new ArrayList<>();
	}
	public static String bidsToJson(BidsCategoryQd bidsCategoryQd)
	{
		String json = JsonUtil.listToJson(bidsCategoryQd.getList());
		json = "{\"name\":\""+bidsCategoryQd.getName()+"\",\"list\":" + json + "}";
		return json;
	}
	
}
