package com.gmadong.modules.systemMsg;

import com.gmadong.common.Page;

public interface SystemMsgService
{
	public Page page(String msg,String type,String ctime,Integer page,Integer rows);
	public boolean save(SystemMsg systemMsg);
	public boolean update(SystemMsg systemMsg);
	public SystemMsg getSystemMsgById(String id);
	public boolean deleteById(String ids);
}
