package com.gmadong.modules.industry;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gmadong.common.Common;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
@Controller
public class IndustryQdController
{

	@Autowired
	private IndustryService  industryService;
	@Autowired
	private JedisClientSingle jedisClientSingle;
	
	//查询行业 职业
	@RequestMapping("/industry.getChildren.do")
	public void getChildren(HttpServletResponse response,String id)
	{
		String key = "industry.getChildren.action";
		String field = id;
		try
		{
			String list = jedisClientSingle.hget(key, field);
			if(StringUtil.isNotEmpty(list))
			{
				AjaxUtil.write(list, response);
				return;
			}
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		
		List<IndustryMinInfo> list = industryService.getChildren(Integer.valueOf(id));
		 
		String json = JsonUtil.listToJson(list);
		try
		{
			jedisClientSingle.hset(key,field, json, Common.REDIS_72_HOUR_EXPIRE);
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		AjaxUtil.write(json, response);
	}
}
