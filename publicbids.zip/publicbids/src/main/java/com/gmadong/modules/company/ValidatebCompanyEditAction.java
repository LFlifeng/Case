package com.gmadong.modules.company;

public interface ValidatebCompanyEditAction
{

}
