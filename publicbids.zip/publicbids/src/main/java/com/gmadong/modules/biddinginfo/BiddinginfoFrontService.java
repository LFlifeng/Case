package com.gmadong.modules.biddinginfo;

import com.gmadong.common.Page;
import com.gmadong.modules.tracker.Tracker;

public interface BiddinginfoFrontService
{
	public Page page(BidsParamsInfo info, Integer page, Integer rows);
}
