package com.gmadong.modules.wechat;
/**
 * 菜单对象
 * @author Administrator
 *
 */
public class Menu {

	private Button[] button;
 
	public Button[] getButton() {
		return button;
	}
 
	public void setButton(Button[] button) {
		this.button = button;
	}
}
