package com.gmadong.modules.projectDesigneds;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.projectDesigneds.ProjectDesignedsExample.Criteria;

@Service("projectDesignedsService")
public class ProjectDesignedsServiceImpl implements ProjectDesignedsService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private ProjectDesignedsMapper projectDesignedsMapper;
	
	@Override
	public Page page(String projectsName, String ctime, Integer page, Integer rows)
	{
		ProjectDesignedsExample projectDesignedsExample = new ProjectDesignedsExample();
		Criteria createCriteria = projectDesignedsExample.createCriteria();
		if (!StringUtil.isEmpty(projectsName)) {
			createCriteria.andProjectsNameLike(projectsName + "%");
		}
		if (!StringUtil.isEmpty(ctime)) {
			createCriteria.andCtimeLike(ctime + "%");
		}
		projectDesignedsExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<ProjectDesigneds> list = projectDesignedsMapper.selectByExample(projectDesignedsExample);
		PageInfo<ProjectDesigneds> pageInfo = new PageInfo<ProjectDesigneds>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean update(ProjectDesigneds projectDesigneds)
	{
		projectDesigneds.setCtime(null);
		return projectDesignedsMapper.updateByPrimaryKeySelective(projectDesigneds) > 0;
	}

	@Override
	public ProjectDesigneds getProjectDesignedsById(String id)
	{
		return projectDesignedsMapper.selectByPrimaryKey(id);
	}
	@Override
	public boolean deleteById(String ids)
	{
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			ProjectDesignedsExample projectDesignedsExample = new ProjectDesignedsExample();
			Criteria createCriteria = projectDesignedsExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			return projectDesignedsMapper.deleteByExample(projectDesignedsExample) > 0;
		}
		return false;
	}

	@Override
	public ProjectDesigneds getProjectDesigneds(String projectsName)
	{
		if(StringUtil.isEmpty(projectsName))
		{
			return null;
		}
		ProjectDesignedsExample projectDesignedsExample = new ProjectDesignedsExample();
		Criteria criteria = projectDesignedsExample.createCriteria();
		criteria.andProjectsNameEqualTo(projectsName.trim());
		projectDesignedsExample.or(criteria);
		List<ProjectDesigneds> selectByExample = projectDesignedsMapper.selectByExample(projectDesignedsExample);
		if (selectByExample.size()>0)
		{
			return selectByExample.get(0);
		}
		return null;
	}
}

