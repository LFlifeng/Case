package com.gmadong.modules.application;

import com.gmadong.common.Page;

public interface ApplicationService
{
	public Page page(String enterpriseName,String representative,String code,String phone,String state,String showType,String ctime,Integer page,Integer rows);
	public boolean save(Application application);
	public boolean update(Application application);
	public Application getApplicationById(String id);
	public boolean deleteById(String ids);
}
