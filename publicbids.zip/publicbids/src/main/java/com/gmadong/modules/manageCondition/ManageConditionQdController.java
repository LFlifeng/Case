package com.gmadong.modules.manageCondition;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.user.User;
import com.gmadong.modules.user.UserService;

@Controller
public class ManageConditionQdController
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private ManageConditionQdService manageConditionQdService;
	private String listkey = "manageCondition.list.do";
	@Autowired
	private UserService userService;
	
	/**
	 * 跳转到新建经营资质
	 * @return
	 */

	@RequestMapping("manageCondition.buildJyzz.do")
	public String buildJyzz() 
	{
		
		  return "/front/application/buildJyzz";
	}
	/**
	 * 查询经营情况
	 */
	@RequestMapping("/manageCondition.list.do")
	public void list(HttpServletRequest req,HttpServletResponse response,@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows) throws Exception 
	{
		User user = (User)Session.get("user");
		if(user == null)
		{
			AjaxUtil.write(Page.pageToJson(Page.getEmptyPage()), response);
			return;
		}
		
		String field =user.getId();
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = manageConditionQdService.page(user.getId(),page, rows);
		String list = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, list, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(Page.pageToJson(toPage), response);
	}
	/**
	 *  根据id删除当前用户的经营情况
	 */
	@RequestMapping("manageCondition.deletelist.do")
	public void deleteApplicationById(HttpServletResponse res,String id) 
	{
		User user=(User)Session.get("user");
		if(user == null)
		{
			AjaxUtil.write("fail",res);
			return;
		}
		boolean  stat=manageConditionQdService.deleteByPrimaryKey(id);
		if(stat)
		{
			try
			{
				jedisClientSingle.hdel(listkey,user.getId());
				jedisClientSingle.del("manageCondition.list.action");
			} catch (Exception e)
			{
			}
			AjaxUtil.write("succ",res);
		}
		else {
			AjaxUtil.write("fail",res);
		}
	}
	/**
	 * 新增当前用户的经营情况
	 */
			@RequestMapping("/manageCondition.doAdd.do")
			public void doAdd(HttpServletResponse response, @Validated({ ValidatebManageConditionAddAction.class }) ManageCondition manageCondition,BindingResult bindingResult)
			{
				User user=(User)Session.get("user");
				manageCondition.setUserId(user.getId());
				if(bindingResult.hasErrors())
				{
					ObjectError error = bindingResult.getAllErrors().get(0);
					AjaxUtil.write(error.getDefaultMessage(),response);
					return;
				}
				if(manageConditionQdService.save(manageCondition))
				{
					try {
						jedisClientSingle.hdel(listkey,user.getId());
						jedisClientSingle.del("manageCondition.list.action");
					} catch (Exception e) {
						e.printStackTrace();
					}
					AjaxUtil.write("succ", response);
				}
				else {
					AjaxUtil.write("添加失败", response);
				}
			}
}


















