package com.gmadong.modules.user;

public interface ValidatebAccountEditAction
{

}
