package com.gmadong.modules.projectDesigneds;

import com.gmadong.common.Page;



public interface ProjectDesignedsService
{
	public Page page(String projectsName,String ctime,Integer page,Integer rows);
	public boolean update(ProjectDesigneds projectDesigneds);
	public ProjectDesigneds getProjectDesignedsById(String id);
	public boolean deleteById(String ids);
	public ProjectDesigneds getProjectDesigneds(String projectsName);
	
}
