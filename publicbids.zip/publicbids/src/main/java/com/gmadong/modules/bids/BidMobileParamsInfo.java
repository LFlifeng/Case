package com.gmadong.modules.bids;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;

public class BidMobileParamsInfo
{
	private String province = null;
	private String keys = null;
	private String type= null;
	private String time = null;
	
	
	public String getProvince()
	{
		return province;
	}
	public void setProvince(String province)
	{
		this.province = province;
	}
	public String getKeys()
	{
		return keys;
	}
	public void setKeys(String keys)
	{
		this.keys = keys;
	}
	public String getType()
	{
		return type;
	}
	public void setType(String type)
	{
		this.type = type;
	}
	public String getTime()
	{
		return time;
	}
	public void setTime(String time)
	{
		this.time = time;
	}
	
	//新增
	public BidMobileParamsInfo (BidsMobileSearch bisMobileSearch)
	{
		if(bisMobileSearch==null)
		{
			this.time = DateUtil.getFormatDateTime(DateUtil.getDateBeforeOrAfter(new Date(), -7), "yyyy-MM-dd");
			return;
		}
		if(StringUtil.isNotEmpty(bisMobileSearch.getRegions()))
		{
			if("全部".equals(bisMobileSearch.getRegions()))
			{
				this.province= null;
			}
			else
			{
				this.province= bisMobileSearch.getRegions().substring(0, 2);
			}
			
		}
		if(StringUtil.isNotEmpty(bisMobileSearch.getDate()))
		{
			this.time = bisMobileSearch.getDate();
		}
		if(StringUtil.isNotEmpty(bisMobileSearch.getInfoType()))
		{
			if("全部".equals(bisMobileSearch.getInfoType()))
			{
				this.type = null;
			}
			else
			{
				this.type=bisMobileSearch.getInfoType();
			}
			
		}
		if(StringUtil.isNotEmpty(bisMobileSearch.getKeywords()))
		{
			this.keys = bisMobileSearch.getKeywords();
		}
		else
		{
			this.keys = null;
		}
		
	}
	
}
