package com.gmadong.modules.biddinginfo;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.FileUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.application.ValidatebApplicationAddAction;
import com.gmadong.modules.application.ValidatebApplicationEditAction;
import com.gmadong.modules.application.ValidatebApplicationUpdateAction;
import com.gmadong.modules.company.ValidatebCompanyAddAction;
import com.gmadong.modules.company.ValidatebCompanyEditAction;



public class Biddinginfo {
	/** 投标id */
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebBiddinginfoEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebBiddinginfoEditAction.class} )
    private String id;

    private String userId;

    /** 项目名称 */
   	@NotBlank(message="项目名称不能为空!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
    @Size (min=1,max=100,message="请输入正确的项目名称!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class})
    private String projectName;

    /** 项目编码 */
   	@NotBlank(message="项目编码不能为空!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
    @Size (min=1,max=20,message="请输入正确的项目编码!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
    private String projectCode;

    /** 项目类型 */
    private String projectType;

    /** 所在省 */
   	@NotBlank(message="所在省不能为空!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
	@Size (min=1,max=20,message="请输入正确的所在省!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
    private String province;

    /** 所在市 */
   	@NotBlank(message="所在市不能为空!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
	@Size (min=1,max=20,message="请输入正确的所在市!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
    private String city;

   	/** 所在区*/
    private String county;

   	/** 行业一级 */
   	@NotBlank(message="行业一级不能为空!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
    @Size (min=1,max=50,message="请输入正确的行业一级!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
    private String industryOne;

    /** 行业二级 */
   	@NotBlank(message="行业二级不能为空!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
    @Size (min=1,max=50,message="请输入正确的行业二级!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
    private String industryTwo;

   	/** 行业三级 */
   	@NotBlank(message="行业三级不能为空!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
    @Size (min=1,max=50,message="请输入正确的行业三级!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
    private String industryThree;

    /** 投标截止 */
    private String deadline;

    /** 发布人 */
    @NotBlank(message="发布人不能为空!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
    @Size (min=1,max=10,message="请输入正确的发布人!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
    private String issuer;

    /** 发布人电话 */
    @NotBlank(message="发布人电话不能为空!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
	@Size (min=7,max=15,message="请输入正确的发布人电话!" ,groups = {ValidatebBiddinginfoAddAction.class,ValidatebBiddinginfoEditAction.class,ValidatebBiddinginfoAddFrontAction.class})
    private String issuerPhone;

    /** 上传人附件 */
    private String uploadAttachment;

    /** 状态 0 审核中 1审核通过 2审核失败 */
    private String state;

    private String ctime;

    /** 内容 */
    private String content;
    

    private String attaUrl;

	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    /**
     * 项目名称
     * @return projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * 项目名称
     * @param projectName
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName == null ? null : projectName.trim();
    }

    /**
     * 项目编码
     * @return projectCode
     */
    public String getProjectCode() {
        return projectCode;
    }

    /**
     * 项目编码
     * @param projectCode
     */
    public void setProjectCode(String projectCode) {
        this.projectCode = projectCode == null ? null : projectCode.trim();
    }

    /**
     * 项目类型
     * @return projectType
     */
    public String getProjectType() {
        return projectType;
    }

    /**
     * 项目类型
     * @param projectType
     */
    public void setProjectType(String projectType) {
        this.projectType = projectType == null ? null : projectType.trim();
    }

    /**
     * 省
     * @return province
     */
    public String getProvince() {
        return province;
    }

    /**
     * 省
     * @param province
     */
    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    /**
     * 市
     * @return city
     */
    public String getCity() {
        return city;
    }

    /**
     * 市
     * @param city
     */
    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    /**
     * 区
     * @return county
     */
    public String getCounty() {
        return county;
    }

    /**
     * 区
     * @param county
     */
    public void setCounty(String county) {
        this.county = county == null ? null : county.trim();
    }

    /**
     * 行业一级
     * @return industryOne
     */
    public String getIndustryOne() {
        return industryOne;
    }

    /**
     * 行业一级
     * @param industryOne
     */
    public void setIndustryOne(String industryOne) {
        this.industryOne = industryOne == null ? null : industryOne.trim();
    }

    /**
     * 行业二级
     * @return industryTwo
     */
    public String getIndustryTwo() {
        return industryTwo;
    }

    /**
     * 行业二级
     * @param industryTwo
     */
    public void setIndustryTwo(String industryTwo) {
        this.industryTwo = industryTwo == null ? null : industryTwo.trim();
    }

    /**
     * 行业三级
     * @return industryThree
     */
    public String getIndustryThree() {
        return industryThree;
    }

    /**
     * 行业三级
     * @param industryThree
     */
    public void setIndustryThree(String industryThree) {
        this.industryThree = industryThree == null ? null : industryThree.trim();
    }

    /**
     * 投标截止
     * @return deadline
     */
    public String getDeadline() {
        return deadline;
    }

    /**
     * 投标截止
     * @param deadline
     */
    public void setDeadline(String deadline) {
        this.deadline = deadline == null ? null : deadline.trim();
    }

    /**
     * 发布人
     * @return issuer
     */
    public String getIssuer() {
        return issuer;
    }

    /**
     * 发布人
     * @param issuer
     */
    public void setIssuer(String issuer) {
        this.issuer = issuer == null ? null : issuer.trim();
    }

    /**
     * 发布人电话
     * @return issuerPhone
     */
    public String getIssuerPhone() {
        return issuerPhone;
    }

    /**
     * 发布人电话
     * @param issuerPhone
     */
    public void setIssuerPhone(String issuerPhone) {
        this.issuerPhone = issuerPhone == null ? null : issuerPhone.trim();
    }

    /**
     * 上传人附件
     * @return uploadAttachment
     */
    public String getUploadAttachment() {
        return uploadAttachment;
    }

    /**
     * 上传人附件
     * @param uploadAttachment
     */
    public void setUploadAttachment(String uploadAttachment) 
    {
    	if(StringUtil.isNotEmpty(uploadAttachment))
    	{
    		this.attaUrl = "/upload/attach"+FileUtil.getPath(uploadAttachment)+uploadAttachment;
    	}
        this.uploadAttachment = uploadAttachment == null ? null : uploadAttachment.trim();
    }

    /**
     * 状态 0 审核中 1审核通过 2审核失败
     * @return state
     */
    public String getState() {
        return state;
    }

    /**
     * 状态 0 审核中 1审核通过 2审核失败
     * @param state
     */
    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }

    /**
     * 内容
     * @return content
     */
    public String getContent() {
        return content;
    }

    /**
     * 内容
     * @param content
     */
    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

	public String getAttaUrl()
	{
		return attaUrl;
	}

	public void setAttaUrl(String attaUrl)
	{
		this.attaUrl = attaUrl;
	}

	@Override
	public String toString()
	{
		return "Biddinginfo [id=" + id + ", userId=" + userId + ", projectName=" + projectName + ", projectCode="
				+ projectCode + ", projectType=" + projectType + ", province=" + province + ", city=" + city
				+ ", county=" + county + ", industryOne=" + industryOne + ", industryTwo=" + industryTwo
				+ ", industryThree=" + industryThree + ", deadline=" + deadline + ", issuer=" + issuer
				+ ", issuerPhone=" + issuerPhone + ", uploadAttachment=" + uploadAttachment + ", state=" + state
				+ ", ctime=" + ctime + ", content=" + content + ", attaUrl=" + attaUrl + ", getId()=" + getId()
				+ ", getUserId()=" + getUserId() + ", getProjectName()=" + getProjectName() + ", getProjectCode()="
				+ getProjectCode() + ", getProjectType()=" + getProjectType() + ", getProvince()=" + getProvince()
				+ ", getCity()=" + getCity() + ", getCounty()=" + getCounty() + ", getIndustryOne()=" + getIndustryOne()
				+ ", getIndustryTwo()=" + getIndustryTwo() + ", getIndustryThree()=" + getIndustryThree()
				+ ", getDeadline()=" + getDeadline() + ", getIssuer()=" + getIssuer() + ", getIssuerPhone()="
				+ getIssuerPhone() + ", getUploadAttachment()=" + getUploadAttachment() + ", getState()=" + getState()
				+ ", getCtime()=" + getCtime() + ", getContent()=" + getContent() + ", getAttaUrl()=" + getAttaUrl()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
    
}