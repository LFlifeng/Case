package com.gmadong.modules.replacePicture;

public interface ValidatebReplacePictureAddAction
{

}
