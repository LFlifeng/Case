package com.gmadong.modules.attach;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("sysAttachService")
public class SysAttachServiceImpl implements SysAttachService
{
	@Autowired
	private SysAttachMapper sysAttachMapper;

	@Override
	public void save(SysAttach attach)
	{
		sysAttachMapper.insert(attach);
	}

	@Override
	public SysAttach getRow(String id)
	{
		return sysAttachMapper.selectByPrimaryKey(id);
	}

}
