package com.gmadong.modules.wechat;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gmadong.common.Common;
import com.gmadong.common.datasource.CustomerContextHolder;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.application.Application;
import com.gmadong.modules.application.ApplicationMapper;
import com.gmadong.modules.application.ExcellentApplication;
import com.gmadong.modules.biddinginfo.BiddinginfoMapper;
import com.gmadong.modules.bids.Bids;
import com.gmadong.modules.bids.BidsMapper;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * 核心服务类
 * 
 * @author Administrator
 *
 */
@Service("weChatService")
public class WeChatServiceImpl implements WeChatService {

	@Autowired
	private JedisClientSingle jedisClientSingle;

	@Autowired
	private BidsMapper bidsMapper;

	@Autowired
	private ApplicationMapper applicationMapper;

	private final String accessTokenKey = "access_token";

	/**
	 * 处理微信发来的请求
	 */
	public String processRequest(HttpServletRequest request) {

		// xml格式的消息数据
		String respXml = null;
		// 默认返回的文本消息内容
		String respContent = null;

		AccessToken accessToken = null;

		String atStr = null;
		try {
			atStr = jedisClientSingle.get(accessTokenKey);
			if (StringUtil.isNotEmpty(atStr)) {
				JSONObject jsonObject = JSONObject.fromObject(atStr);
				accessToken = (AccessToken) JSONObject.toBean(jsonObject, AccessToken.class);
			} else {
				accessToken = WeChatUtil.getAccessToken();
				atStr = JsonUtil.bean2json(accessToken);
				jedisClientSingle.set(accessTokenKey, atStr, 7000);
			}
		} catch (Exception e) {

		}
		try {

			// 调用parseXml方法解析请求消息
			Map<String, String> requestMap = WeChatUtil.parseXml(request);
			// 消息类型
			String msgType = (String) requestMap.get(WeChatContant.MsgType);
			String mes = null;
			// 文本消息
			if (msgType.equals(WeChatContant.REQ_MESSAGE_TYPE_TEXT)) {
				mes = requestMap.get(WeChatContant.Content).toString();
				if ("我的网站".equals(mes)) {
					List<ArticleItem> items = new ArrayList<>();
					ArticleItem item = new ArticleItem();

					item.setTitle("中汇招标网");
					item.setDescription("中汇招标网");
					item.setPicUrl("http://39.96.202.166/skin/default/front/img/logo.png");
					item.setUrl("http://39.96.202.166/main.index.do");
					items.add(item);

					respXml = MessageUtil.sendArticleMsg(requestMap, items);
				} else if ("我的信息".equals(mes)) {

					WeChatUser weChatUser = UserManager.getUserInfo(accessToken.getAccess_token(),
							requestMap.get(WeChatContant.FromUserName));
					System.out.println(weChatUser.toString());
					String nickname = weChatUser.getNickname();
					String city = weChatUser.getCity();
					String province = weChatUser.getProvince();
					String country = weChatUser.getCountry();
					String headimgurl = weChatUser.getHeadImgUrl();
					List<ArticleItem> items = new ArrayList<>();
					ArticleItem item = new ArticleItem();
					item.setTitle("你的信息");
					item.setDescription("昵称:" + nickname + "  地址:" + country + " " + province + " " + city);
					item.setPicUrl(headimgurl);
					item.setUrl("http://www.baidu.com");
					items.add(item);

					respXml = MessageUtil.sendArticleMsg(requestMap, items);
				} else if ("获得换行的文本消息".equals(mes)) {
					respContent = getTxtMessage();
				} else {
					respContent = "请问有什么可以帮助的？！";
				}

			}
			// 图片消息
			else if (msgType.equals(WeChatContant.REQ_MESSAGE_TYPE_IMAGE)) {
				String mediaId = requestMap.get("MediaId");
				respXml = MessageUtil.sendImageMsg(requestMap, mediaId);

			}
			// 语音消息
			else if (msgType.equals(WeChatContant.REQ_MESSAGE_TYPE_VOICE)) {
				String mediaId = requestMap.get("MediaId");
				respXml = MessageUtil.sendVoiceMsg(requestMap, mediaId);

			}
			// 视频消息
			else if (msgType.equals(WeChatContant.REQ_MESSAGE_TYPE_VIDEO)) {
				String mediaId = requestMap.get("MediaId");

				Video video = new Video();
				video.setTitle("中汇招标网");
				video.setDescription("中汇招标网");
				video.setMediaId(mediaId);
				respXml = MessageUtil.sendVideoMsg(requestMap, video);
			}
			// 地理位置消息
			else if (msgType.equals(WeChatContant.REQ_MESSAGE_TYPE_LOCATION)) {
				respContent = "您发送的是地理位置消息！";

			}
			// 链接消息
			else if (msgType.equals(WeChatContant.REQ_MESSAGE_TYPE_LINK)) {
				respContent = "您发送的是链接消息！";

			}
			// 事件推送
			else if (msgType.equals(WeChatContant.REQ_MESSAGE_TYPE_EVENT)) {
				// 事件类型
				String eventType = (String) requestMap.get(WeChatContant.Event);
				// 关注
				if (eventType.equals(WeChatContant.EVENT_TYPE_SUBSCRIBE)) {
					respContent = "谢谢您的关注！";
				}
				// 取消关注
				else if (eventType.equals(WeChatContant.EVENT_TYPE_UNSUBSCRIBE)) {
					// TODO 取消订阅后用户不会再收到公众账号发送的消息，因此不需要回复
				}
				// 扫描带参数二维码
				else if (eventType.equals(WeChatContant.EVENT_TYPE_SCAN)) {
					// TODO 处理扫描带参数二维码事件
				}
				// 上报地理位置
				else if (eventType.equals(WeChatContant.EVENT_TYPE_LOCATION)) {
					// TODO 处理上报地理位置事件
				}
				// 自定义菜单
				else if (eventType.equals(WeChatContant.EVENT_TYPE_CLICK)) {
					// 事件KEY值，与创建自定义菜单时指定的KEY值对应
					String eventKey = requestMap.get("EventKey");
					if (eventKey.equals("11")) {
						List<ArticleItem> items = new ArrayList<>();
						ArticleItem item = null;
						List<Bids> list = getWechatBids();
						for (Bids bids : list) {
							item = new ArticleItem();
							item.setUrl("http://39.96.202.166/bids.details.do?id=" + bids.getId());
							item.setTitle(bids.getName());
							item.setPicUrl("http://39.96.202.166/skin/default/front/img/favicon.ico");
							item.setDescription(bids.getType());
							items.add(item);
						}
						respXml = MessageUtil.sendArticleMsg(requestMap, items);
					} else if (eventKey.equals("12")) {
						List<ArticleItem> items = new ArrayList<>();
						ArticleItem item = null;
						List<ExcellentApplication> list = null;
						String key = "WechatApplication.do";
						try {
							String listStr = jedisClientSingle.get(key);
							if (StringUtil.isNotEmpty(listStr)) {
								JSONArray jsonArray = JSONArray.fromObject(listStr);
								list = jsonArray.toList(jsonArray, ExcellentApplication.class);
							} else {
								list = applicationMapper.selectWechatApplication();
								String str = JsonUtil.listToJson(list);
								jedisClientSingle.set(key, str, Common.REDIS_30_MINUTE_EXPIRE);
							}
						} catch (Exception e) {
							e.printStackTrace();
						}

						for (ExcellentApplication application : list) {
							item = new ArticleItem();
							item.setUrl(
									"http://39.96.202.166/application.applicationShow.do?id=" + application.getId());
							item.setTitle(application.getEnterpriseName());
							item.setPicUrl(application.getPortraitUrl());
							item.setDescription(application.getAddress());
							items.add(item);
						}
						respXml = MessageUtil.sendArticleMsg(requestMap, items);
					} else if (eventKey.equals("13")) {
						respContent = "周边搜索菜单项被点击！";
					} else if (eventKey.equals("14")) {
						respContent = "历史上的今天菜单项被点击！";
					} else if (eventKey.equals("21")) {
						respContent = "歌曲点播菜单项被点击！";
					} else if (eventKey.equals("22")) {
						respContent = "经典游戏菜单项被点击！";
					} else if (eventKey.equals("23")) {
						respContent = "美女电台菜单项被点击！";
					} else if (eventKey.equals("24")) {
						respContent = "人脸识别菜单项被点击！";
					} else if (eventKey.equals("25")) {
						respContent = "聊天唠嗑菜单项被点击！";
					} else if (eventKey.equals("31")) {
						respContent = "Q友圈菜单项被点击！";
					} else if (eventKey.equals("32")) {
						respContent = "电影排行榜菜单项被点击！";
					} else if (eventKey.equals("33")) {
						respContent = "幽默笑话菜单项被点击！";
					}

				}

			}
			if (!StringUtil.isEmpty(respContent)) {
				respXml = MessageUtil.sendTextMsg(requestMap, respContent);
			}
			mes = mes == null ? "不知道你在干嘛" : mes;
			if (respXml == null)
				respXml = MessageUtil.sendTextMsg(requestMap, mes);
			System.out.println(respXml);
			return respXml;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";

	}

	/**
	 * 每日推送公告
	 */
	public String getTxtMessage() {
		int i = 1;
		StringBuffer data = new StringBuffer();
		data.append("欢迎关注中汇招标公众号，以下是每日推送给您的招标公告，可以点击链接查看详情").append("\n");

		List<Bids> list = getWechatBids();
		for (Bids bid : list) {
			data.append("" + i + "、" + "<a href=" + "'" + "http://39.96.202.166/bids.details.do?id=" + bid.getId() + "'"
					+ ">" + bid.getName() + "</a>").append("\n");
			i++;
		}
		data.append("谢谢关注");
		return data.toString();
	}
	
	/**
	 * 获取最新的招标公告
	 * 
	 * @return
	 */
	public List<Bids> getWechatBids() {
		List<Bids> list = null;
		String key = "WeChatBids.do";
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				JSONArray jsonArray = JSONArray.fromObject(listStr);
				list = jsonArray.toList(jsonArray, Bids.class);
				return list;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		CustomerContextHolder.setCustomerType(CustomerContextHolder.BIDS_DATA_SOURCE_MSSQL);
		list = bidsMapper.selectWechatBids();
		CustomerContextHolder.clearCustomerType();
		String str = JsonUtil.listToJson(list);
		try {
			jedisClientSingle.set(key, str, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}
}
