package com.gmadong.modules.product;

import java.util.List;

import com.gmadong.common.Page;

public interface ProductQdService
{

	Page page(String id, Integer page, Integer rows);

	boolean deleteByPrimaryKey(String id);

	boolean save(Product product);

	Page pageCompany(String applicationId, Integer page, Integer rows);
 
}
