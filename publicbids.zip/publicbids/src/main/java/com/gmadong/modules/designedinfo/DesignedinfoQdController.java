package com.gmadong.modules.designedinfo;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.user.User;

import net.sf.json.JSONObject;

/**
 * 用户中心-项目专盯控制层
 * 
 * @author Administrator
 *
 */
@Controller
public class DesignedinfoQdController {

	@Resource(name = "designedinfoQdService")
	private DesignedinfoQdService designedinfoQdService;

	@Autowired
	private JedisClientSingle jedisClientSingle;

	private String listkey = "designedinfo.list_";

	/**
	 * 项目专盯页面跳转
	 * 
	 * @return
	 */
	@RequestMapping("/designedinfo.listIndex.do")
	public String page() {
		return "/front/usercenter/projectDesigned";
	}

	/**
	 * 项目专盯列表查询
	 * 
	 * @param response
	 * @param page
	 * @param rows
	 */
	@RequestMapping("/designedinfo.Userlist.do")
	public void list(HttpServletResponse response, @RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "20") Integer rows) {

		User user = (User) Session.get("user");
		if (user == null) {
			AjaxUtil.write("用户未登陆", response);
			return;
		}
		String userId = user.getId();
		String field = page + "-" + rows;
		try {
			String list = jedisClientSingle.hget(listkey + userId, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = designedinfoQdService.page(userId, page, rows);
		String listStr = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey + userId, field, listStr, Common.REDIS_48_HOUR_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
	}

}
