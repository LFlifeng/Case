package com.gmadong.modules.browsingHistory;

import java.util.Date;
import java.util.List;

import com.gmadong.common.Page;
import com.gmadong.modules.usercollection.UserCollection;

public interface BrowsingHistoryService {

	Page page(String userId, Integer page, Integer rows);

	boolean deleteById(String id);

	boolean save(BrowsingHistory browsingHistory);

	BrowsingHistory selectByBiddingInfoId(String userId, String titileId);
}
