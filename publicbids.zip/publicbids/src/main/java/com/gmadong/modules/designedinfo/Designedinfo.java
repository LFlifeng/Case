package com.gmadong.modules.designedinfo;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.gmadong.modules.product.ValidatebProductAddAction;
import com.gmadong.modules.product.ValidatebProductEditAction;

public class Designedinfo {
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebDesignedinfoEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebDesignedinfoEditAction.class} )
    private String id;

    /** 后台用户id */
    private String staffId;

    /** 项目专盯id */
    @NotBlank(message="项目专盯id不能为空!" ,groups = {ValidatebDesignedinfoEditAction.class} )
    private String projectId;

    /** 专盯情况 */
    @NotBlank(message="专盯情况不能为空!" ,groups = {ValidatebDesignedinfoAddAction.class,ValidatebDesignedinfoEditAction.class})
    @Size (min=1,max=50,message="请输入正确的专盯情况 !" ,groups = {ValidatebDesignedinfoAddAction.class,ValidatebDesignedinfoEditAction.class})
    private String designedinfo;

    /** 跟进人 */
    private String people;

    /** 备注 */
    @NotBlank(message="备注不能为空!" ,groups = {ValidatebDesignedinfoAddAction.class,ValidatebDesignedinfoEditAction.class})
    @Size (min=1,max=200,message="请输入正确的备注!" ,groups = {ValidatebDesignedinfoAddAction.class,ValidatebDesignedinfoEditAction.class})
    private String remark;

    private String ctime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 后台用户id
     * @return staffId
     */
    public String getStaffId() {
        return staffId;
    }

    /**
     * 后台用户id
     * @param staffId
     */
    public void setStaffId(String staffId) {
        this.staffId = staffId == null ? null : staffId.trim();
    }

    /**
     * 项目专盯id
     * @return projectId
     */
    public String getProjectId() {
        return projectId;
    }

    /**
     * 项目专盯id
     * @param projectId
     */
    public void setProjectId(String projectId) {
        this.projectId = projectId == null ? null : projectId.trim();
    }

    /**
     * 专盯情况
     * @return designedinfo
     */
    public String getDesignedinfo() {
        return designedinfo;
    }

    /**
     * 专盯情况
     * @param designedinfo
     */
    public void setDesignedinfo(String designedinfo) {
        this.designedinfo = designedinfo == null ? null : designedinfo.trim();
    }

    /**
     * 跟进人
     * @return people
     */
    public String getPeople() {
        return people;
    }

    /**
     * 跟进人
     * @param people
     */
    public void setPeople(String people) {
        this.people = people == null ? null : people.trim();
    }

    /**
     * 备注
     * @return remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 备注
     * @param remark
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }

	@Override
	public String toString()
	{
		return "Designedinfo [id=" + id + ", staffId=" + staffId + ", projectId=" + projectId + ", designedinfo="
				+ designedinfo + ", people=" + people + ", remark=" + remark + ", ctime=" + ctime + ", getId()="
				+ getId() + ", getStaffId()=" + getStaffId() + ", getProjectId()=" + getProjectId()
				+ ", getDesignedinfo()=" + getDesignedinfo() + ", getPeople()=" + getPeople() + ", getRemark()="
				+ getRemark() + ", getCtime()=" + getCtime() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}
    
}