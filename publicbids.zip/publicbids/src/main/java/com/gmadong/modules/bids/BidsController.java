package com.gmadong.modules.bids;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.biddinginfo.Biddinginfo;
import com.gmadong.modules.biddinginfo.BiddinginfoQdService;
import com.gmadong.modules.browsingHistory.BrowsingHistory;
import com.gmadong.modules.browsingHistory.BrowsingHistoryService;
import com.gmadong.modules.user.User;

import net.sf.json.JSONObject;

/**
 * 前台招标信息控制层
 * 
 * @author Administrator
 *
 */
@Controller
public class BidsController {

	@Resource(name = "bidsService")
	private BidsService bidsService;

	@Autowired
	private JedisClientSingle jedisClientSingle;

	@Autowired
	private BrowsingHistoryService browsingHistoryService;

	@Resource(name = "biddinginfoQdService")
	private BiddinginfoQdService biddinginfoQdService;
	
	String regex1 = "((13[0-9])|(14[5,7,9])|(15([0-3]|[5-9]))|(166)|(17[0,1,3,5,6,7,8])|(18[0-9])|(19[8|9]))\\d{8}";
	String regex2 = "[0-9]{5,10}";
	/**
	 * 投标列表跳转页面
	 * 
	 * @return
	 */
	@RequestMapping("/bids.listIndex.do")
	public String page() {
		return "/front/bids/list";
	}

	/**
	 * 投标列表查询（包括模糊查询）
	 * 
	 * @param response
	 * @param type     公告类型
	 * @param title    公告标题
	 * @param date     时间戳
	 * @param province 省
	 * @param industry 招标类型
	 * @param page     页数
	 * @param rows     行数
	 */
	@RequestMapping("/bids.list.do")
	public void list(HttpServletResponse response, String type, String title, String date, String province,
			String industry, @RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "20") Integer rows) {
		String key = "bids.list.do";
		if(StringUtil.isEmpty(date))
		{
			date = DateUtil.getFormatDateTime(DateUtil.getDateBeforeOrAfter(new Date(), -7), "yyyy-MM-dd");
		}
		String field = type + "-" + title + "-" + date + "-" + province + "-" + industry + "-" + page + "-" + rows;
		try {
			String list = jedisClientSingle.hget(key, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = bidsService.page(type, title, date, province, industry, page, rows);
		String listStr = Page.pageToJson(toPage);
		AjaxUtil.write(listStr, response);
		try {
			jedisClientSingle.hset(key, field, listStr, Common.REDIS_6_HOUR_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	/**
	 * 投标详情查询
	 * 
	 * @param response
	 * @param id       公告id
	 */
	@RequestMapping("/bidsFront.details.do")
	public String details(HttpServletResponse response, String id)
	{
		User user = (User) Session.get("user");
		int grade = user==null?0:Integer.valueOf(user.getGrade());
		if(StringUtil.isEmpty(id))
		{
			return "/common/500";
		}
		if(id.length() == 32) 
		{
			Biddinginfo biddinginfo = null;
			String key = "biddinginfo.details-" + id;
			try {
				String detail = jedisClientSingle.get(key);
				if (StringUtil.isNotEmpty(detail)) {
					JSONObject jsonObject = JSONObject.fromObject(detail);
					biddinginfo = (Biddinginfo) JSONObject.toBean(jsonObject, Biddinginfo.class);
					Request.set("detail", biddinginfo);
					
					return "/front/biddinginfo/detail";
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

			biddinginfo = biddinginfoQdService.details(id);
			String detail = JsonUtil.bean2json(biddinginfo);
				try {

					jedisClientSingle.set(key, detail, Common.REDIS_6_HOUR_EXPIRE);
				} catch (Exception e) {
					e.printStackTrace();
				
			}
			Request.set("detail", biddinginfo);
			
			return "/front/biddinginfo/detail";
		}else
		{
			BidsWithBLOBs bid = null;
			String key = "bids.details-" + id;
			try {

				String detail = jedisClientSingle.get(key);
				if (StringUtil.isNotEmpty(detail)) {
					JSONObject jsonObject = JSONObject.fromObject(detail);
					bid = (BidsWithBLOBs) JSONObject.toBean(jsonObject, BidsWithBLOBs.class);
					Request.set("detail", bid);
					if(grade == 0) {
						bid.setContentHtml(bid.getContentHtml().replaceAll(regex1, "*****"));
						bid.setContentHtml(bid.getContentHtml().replaceAll(regex2, "*****"));
					}
					return "/front/bids/detail";
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

			bid = bidsService.details(Integer.valueOf(id));
			String detail = JsonUtil.bean2json(bid);

			try {
				jedisClientSingle.set(key, detail, Common.REDIS_6_HOUR_EXPIRE);
			} catch (Exception e) {
				e.printStackTrace();
			}

			Request.set("detail", bid);
			if(grade == 0) {
				bid.setContentHtml(bid.getContentHtml().replaceAll(regex1, "*****"));
				bid.setContentHtml(bid.getContentHtml().replaceAll(regex2, "*****"));
			}
			return "/front/bids/detail";
		}
		
	}
	/**
	 * 投标详情查询
	 * 
	 * @param response
	 * @param id       公告id
	 */
	@RequestMapping("/bids.details.do")
	public String details(HttpServletResponse response, Integer id) {
		BidsWithBLOBs bid = null;
		String key = "bids.details-" + id;
		User user = (User) Session.get("user");
		int grade = user==null?0:Integer.valueOf(user.getGrade());
		try {

			String detail = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(detail)) {
				JSONObject jsonObject = JSONObject.fromObject(detail);
				bid = (BidsWithBLOBs) JSONObject.toBean(jsonObject, BidsWithBLOBs.class);
				if (bid != null) {
					addBrowHistory(bid);
				}
				Request.set("detail", bid);
				if(grade == 0) {
					bid.setContentHtml(bid.getContentHtml().replaceAll(regex1, "*****"));
					bid.setContentHtml(bid.getContentHtml().replaceAll(regex2, "*****"));
				}
				return "/front/bids/detail";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		bid = bidsService.details(id);
		String detail = JsonUtil.bean2json(bid);

		try {
			if (bid != null) {
				addBrowHistory(bid);
			}
			jedisClientSingle.set(key, detail, Common.REDIS_6_HOUR_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Request.set("detail", bid);
		if(grade == 0) {
			bid.setContentHtml(bid.getContentHtml().replaceAll(regex1, "*****"));
			bid.setContentHtml(bid.getContentHtml().replaceAll(regex2, "*****"));
		}
		return "/front/bids/detail";
	}

	/**
	 * 首页今日招标查询
	 * 
	 * @param response
	 */
	@RequestMapping("/bids.todayBids.do")
	public void todayBids(HttpServletResponse response) {
		String key = "bids.todayBids.do";
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Bids> list = bidsService.findTodayBids();
		String listStr = JsonUtil.listToJson(list);
		try {
			if(list.size() == 0) {
				jedisClientSingle.set(key, listStr, Common.REDIS_15_MINUTE_EXPIRE);
			}else {
				jedisClientSingle.set(key, listStr, Common.REDIS_30_MINUTE_EXPIRE);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		AjaxUtil.write(listStr, response);
		return;
	}

	/**
	 * 首页不同公告类型列表查询
	 * 
	 * @param response
	 * @param leixing
	 */
	@RequestMapping("/bids.typeBids.do")
	public void typeBids(HttpServletResponse response, String type) {
		String key = "bids.typeBids-" + type;
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		List<Bids> list = bidsService.findTypeBids(type);
		String listStr = JsonUtil.listToJson(list);
		try {
			if(list.size() == 0) {
				jedisClientSingle.set(key, listStr, Common.REDIS_15_MINUTE_EXPIRE);
			}else {
				jedisClientSingle.set(key, listStr, Common.REDIS_30_MINUTE_EXPIRE);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		AjaxUtil.write(listStr, response);
		return;
	}

	/**
	 * 首页招标资讯查询
	 * 
	 * @param response
	 */
	@RequestMapping("/bids.bidsConsultation.do")
	public void bidsConsultation(HttpServletResponse response) {
		String key = "bids.bidsConsultation.do";
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Bids> list = bidsService.findBidsConsultation();
		String listStr = JsonUtil.listToJson(list);
		try {
			if(list.size() == 0) {
				jedisClientSingle.set(key, listStr, Common.REDIS_15_MINUTE_EXPIRE);
			}else {
				jedisClientSingle.set(key, listStr, Common.REDIS_30_MINUTE_EXPIRE);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
		return;
	}

	/**
	 * 首页免费公告和中标企业查询
	 * 
	 * @param response
	 */
	@RequestMapping("/bids.freeAndWinBids.do")
	public void freeAndWinBids(HttpServletResponse response, String type) {
		if (StringUtil.isEmpty(type)) {
			type = null;
		}
		String key = "bids.freeAndWinBids.list-" + type;
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Bids> list = bidsService.findFreeAndWinBids(type);
		String listStr = JsonUtil.listToJson(list);
		try {
			if(list.size() == 0) {
				jedisClientSingle.set(key, listStr, Common.REDIS_15_MINUTE_EXPIRE);
			}else {
				jedisClientSingle.set(key, listStr, Common.REDIS_30_MINUTE_EXPIRE);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
		return;
	}

	/**
	 * 添加浏览历史
	 * @param bid
	 */
	public void addBrowHistory(Bids bid) {
		User user = (User) Session.get("user");
		if (user == null) {
			return;
		}
		BrowsingHistory browsingHistory = new BrowsingHistory();
		browsingHistory.setId(UUIDUtil.getUUID());
		browsingHistory.setCtime(DateUtil.getCurrentDate());
		browsingHistory.setUserId(user.getId());
		browsingHistory.setBiddinginfoId(String.valueOf(bid.getId()));
		browsingHistory.setBiddinginfoTitle(bid.getName());
		try {
			if (browsingHistoryService.save(browsingHistory)) {
				jedisClientSingle.del("browsingHistory.list_" + user.getId());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

	}

	/**
	 * 详情页独家招标查询
	 * 
	 * @param response
	 */
	@RequestMapping("/bids.exclusiveBids.do")
	public void findExclusiveBids(HttpServletResponse response) {
		String key = "bids.exclusiveBids.do";
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Bids> list = bidsService.findExclusiveBids();
		String listStr = JsonUtil.listToJson(list);
		try {
			if(list.size() == 0) {
				jedisClientSingle.set(key, listStr, Common.REDIS_15_MINUTE_EXPIRE);
			}else {
				jedisClientSingle.set(key, listStr, Common.REDIS_30_MINUTE_EXPIRE);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		AjaxUtil.write(listStr, response);
		return;
	}
	
	/**
	 * 查询供应商页面最新发布
	 * @param response
	 */
	@RequestMapping("/bids.findLatestRelease.do")
	public void findLatestRelease(HttpServletResponse response) {
		String key  = "bids.findLatestRelease.do";
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		List<Biddinginfo> list = bidsService.findLatestRelease();
		String listStr = JsonUtil.listToJson(list);
		try {
			if(list.size() == 0) {
				jedisClientSingle.set(key, listStr, Common.REDIS_15_MINUTE_EXPIRE);
			}else {
				jedisClientSingle.set(key, listStr, Common.REDIS_30_MINUTE_EXPIRE);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		AjaxUtil.write(listStr, response);
		return;
	}
}
