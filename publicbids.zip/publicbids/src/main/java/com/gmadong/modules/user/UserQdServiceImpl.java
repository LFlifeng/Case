package com.gmadong.modules.user;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.PasswordUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.common.utils.PasswordUtil.PasswordUtilType;
import com.gmadong.modules.application.Application;
import com.gmadong.modules.application.ApplicationMapper;
import com.gmadong.modules.application.ApplicationQdService;
import com.gmadong.modules.company.Company;
import com.gmadong.modules.company.CompanyMapper;
import com.gmadong.modules.user.UserExample.Criteria;

@Service("userQdService")
public class UserQdServiceImpl implements UserQdService {
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private UserMapper userMapper;
	@Autowired
	private CompanyMapper companyMapper;
	private static final String parentCategorysKey = "userQdMapper.ParentCategorys";
	@Autowired
	private ApplicationMapper applicationMapper; 

	@Override
	public User selectUserByName(String username) {

		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		if (StringUtil.isNotEmpty(username)) {
			criteria.andNameEqualTo(username);
		}
		List<User> list = userMapper.selectByExample(example);
		if (list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public int updateByltime(String phone, String dtime) {
		return userMapper.updateByltime(phone, dtime);
	}

	@Override
	public boolean saveUserRegister(UserQdRegister reg) {
		User user = new User();
		
		Company company = new Company();
		String gs = reg.getCompany(); // 公司
		String contacts = reg.getContacts();
		String password = reg.getPassword();
		String personalOffice = reg.getPersonalOffice();
		String phone = reg.getPhone();
		user.setContacts(contacts);
		user.setPhone(phone);
		user.setPassword(password);
		user.setPersonalOffice(personalOffice);
		user.setId(UUIDUtil.getUUID());
		user.setPassword(PasswordUtil.encrypt(user.getPassword(), PasswordUtilType.NORMAL));
		user.setCtime(DateUtil.getCurrentDate());
		boolean users = userMapper.insertUserQdUregister(user) > 0;
		company.setNumber(phone);
		company.setTitle(gs);
		company.setContacts(contacts);
		company.setStaffId(user.getId());
		company.setId(UUIDUtil.getUUID());
		company.setCtime(DateUtil.getCurrentDate());
		company.setState("0");
		boolean companys = companyMapper.insert(company) > 0;
		
		//注册成功新增关联申请入驻的用户信息
		Application application=new Application();
		application.setId(UUIDUtil.getUUID());
		application.setCtime(DateUtil.getCurrentDate());
		application.setUserId(user.getId());
		application.setState("0");
		boolean app=applicationMapper.insertSelective(application) > 0;
		
		if (users && companys && app) {
			return true;
		}
		return false;
	}

	@Override
	public User selectUserByPhone(String phone) {
		return userMapper.selectUserByPhone(phone);
	}

	@Override
	public boolean updatePwd(String newPwd, String useId) {
		if (userMapper.updateByPassword(useId, newPwd) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean updatePhone(String phone, String id) {
		if (userMapper.updateByPhone(phone,id) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean updateAccountInformation(String userId,String portrait, String portraitUrl, String nickName, String birthday,
			String sex) {
		User user = new User();
		user.setId(userId);
		user.setPortrait(portrait);
		user.setPortraitUrl(portraitUrl);
		user.setNickname(nickName);
		user.setBirthday(birthday);
		user.setSex(sex);
		if (userMapper.updateByPrimaryKeySelective(user) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean updateEmail(String email, String id) {
		if (userMapper.updateByEmail(email,id) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public User selectUserByEmail(String email) {
		return userMapper.selectUserByEmail(email);
	}

}
