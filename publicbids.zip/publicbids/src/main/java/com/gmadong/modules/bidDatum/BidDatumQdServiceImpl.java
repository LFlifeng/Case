package com.gmadong.modules.bidDatum;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.bidDatum.BidDatumExample.Criteria;


@Service("bidDatumQdService")
public class BidDatumQdServiceImpl implements BidDatumQdService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private BidDatumMapper bidDatumMapper;
	@Override
	public BidDatum details(String id) {
		BidDatum bidDatum =bidDatumMapper.selectByPrimaryKey(id);
		if(bidDatum == null) {
			return new BidDatum();
		}
		return bidDatum;
	}
	@Override
	public Page page(Integer page, Integer rows) {
		BidDatumExample bidDatumExample = new BidDatumExample();
		Criteria createCriteria = bidDatumExample.createCriteria();
		bidDatumExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<BidDatum> list = bidDatumMapper.selectByExample(bidDatumExample);
		PageInfo<BidDatum> pageInfo = new PageInfo<BidDatum>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public List<BidDatum> fidnbidDatumList() {
		List<BidDatum> list = bidDatumMapper.selectbidDatumList();
		if(list.size() > 0) {
			return list;
		}
		return null;
	}

}
