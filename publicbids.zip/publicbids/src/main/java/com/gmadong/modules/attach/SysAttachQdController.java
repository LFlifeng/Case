package com.gmadong.modules.attach;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.gmadong.common.Common;
import com.gmadong.common.Session;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.FileUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.user.User;
@Controller
public class SysAttachQdController
{
	@Resource(name="sysAttachService")
	private SysAttachService sysAttachService;
	@RequestMapping("/attach.upload.do")
	public void upload(HttpServletRequest request,HttpServletResponse response,MultipartFile file)
	{
		String fileName = file.getOriginalFilename();
		String fileOldName = fileName;
		String path =Common.uploadPath;
		String mineType = file.getContentType();
		if(Common.isDebug)
		{
			path = request.getSession().getServletContext().getRealPath("upload")+"/attach/";  
		}
		String id = UUIDUtil.getUUID();
		path = path+FileUtil.getPath(id);
		FileUtil.createDir(path);
		String[] fileArray = fileName.split("\\.");
		if(mineType.contains("image"))
		{
			mineType = "image/png";
			fileName = id+".png";
		}
		else
		{
			fileName = id+"."+fileArray[fileArray.length-1];
		}
		
		path = path +fileName;
		try
		{
			file.transferTo(new File(path));
		}
		catch(Exception e)
		{
			e.printStackTrace();
			 AjaxUtil.write("{\"code\":1,\"msg\":\"上传失败\",\"data\":{\"src\":\"}}", response);
			 return;
		}
		SysAttach attach = new SysAttach();
		attach.setAttachId(id);
 		attach.setFileName(fileOldName);
        attach.setUrl(fileName);
        attach.setMineType(mineType);
        attach.setFileSize(FileUtil.formetFileSize(file.getSize()));
        User user = (User)Session.get("user");
        attach.setStaff(user.getId());
        attach.setStatus("1");
        attach.setCtime(DateUtil.getCurrentDate());
        sysAttachService.save(attach);
        path = fileName;
        AjaxUtil.write("{\"code\":0,\"msg\":\"\",\"data\":{\"src\":\""+path+"\"}}", response);
	}
	@RequestMapping("/attach.uploadImage.do")
	public void uploadImage(HttpServletRequest request,HttpServletResponse response,MultipartFile file)
	{
		String fileName = file.getOriginalFilename();
		String fileOldName = fileName;
		String path =Common.uploadPath;
		String mineType = file.getContentType();
		if(Common.isDebug)
		{
			path = request.getSession().getServletContext().getRealPath("upload")+"/attach/";  
		}
		String id = UUIDUtil.getUUID();
		path = path+FileUtil.getPath(id);
		FileUtil.createDir(path);
		String[] fileArray = fileName.split("\\.");
		if(mineType.contains("image"))
		{
			mineType = "image/png";
			fileName = id+".png";
		}
		else
		{
			fileName = id+"."+fileArray[fileArray.length-1];
		}
		
		path = path +fileName;
		try
		{
			file.transferTo(new File(path));
		}
		catch(Exception e)
		{
			e.printStackTrace();
			 AjaxUtil.write("{\"code\":1,\"msg\":\"上传失败\",\"data\":{\"src\":\"}}", response);
			 return;
		}
		SysAttach attach = new SysAttach();
		attach.setAttachId(id);
 		attach.setFileName(fileOldName);
        attach.setUrl(fileName);
        attach.setMineType(mineType);
        attach.setFileSize(FileUtil.formetFileSize(file.getSize()));
        User user = (User)Session.get("user");
        attach.setStaff(user.getId());
        attach.setStatus("1");
        attach.setCtime(DateUtil.getCurrentDate());
        sysAttachService.save(attach);
        path = "/upload/attach/"+FileUtil.getPath(id) + fileName;
        AjaxUtil.write("{\"code\":0,\"msg\":\"\",\"data\":{\"src\":\""+id+"\",\"url\":\"" + path + "\"}}", response);
	}    
	
	
	
}
