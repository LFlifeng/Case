package com.gmadong.modules.city;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gmadong.common.Common;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
@Controller
public class SysCityQdController
{
	@Resource(name="sysCityService")
	private SysCityService sysCityService;
	@Autowired
	private JedisClientSingle jedisClientSingle;
	/**
	 * 
	 * @param response
	 * @param id
	 */
	@RequestMapping("/sysCity.city.do")
	public void province(HttpServletResponse response,String id,String type)
	{
		String key = "city.key";
		String field = id+"_"+type;
		
		try
		{
			String list = jedisClientSingle.hget(key, field);
			if(StringUtil.isNotEmpty(list))
			{
				AjaxUtil.write(list, response);
				return;
			}
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	
		List<CityMinInfo> selectProvince = sysCityService.selectCityById(id);
		if(StringUtil.isNotEmpty(type))
		{
			if("0".equals(id))
			{
				selectProvince.add(0, new CityMinInfo(-1, "全国"));
			}
			else
			{
				selectProvince.add(0, new CityMinInfo(-2, "全部"));
			}
			
		}
		
		String list = JsonUtil.listToJson(selectProvince);
		try
		{
			jedisClientSingle.hset(key,field, list, Common.REDIS_72_HOUR_EXPIRE);
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		
		AjaxUtil.write(list, response);
	}
}
