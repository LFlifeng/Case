package com.gmadong.modules.bidsCategory;

public interface ValidatebBidCategoryAddAction {

}
