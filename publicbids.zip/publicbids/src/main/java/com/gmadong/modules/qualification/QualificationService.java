package com.gmadong.modules.qualification;

import com.gmadong.common.Page;

public interface QualificationService
{
	public Page page(String aptitudeName,String ctime,Integer page,Integer rows);
	public boolean save(Qualification qualification);
	public boolean update(Qualification qualification);
	public Qualification getQualificationById(String id);
	public boolean deleteById(String ids);
}
