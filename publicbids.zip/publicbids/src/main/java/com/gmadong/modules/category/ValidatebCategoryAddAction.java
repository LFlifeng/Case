package com.gmadong.modules.category;

public interface ValidatebCategoryAddAction {

}
