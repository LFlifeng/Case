package com.gmadong.modules.organize;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.organize.SysOrganizeExample.Criteria;
import com.gmadong.modules.staff.SysStaff;
import com.gmadong.modules.staff.SysStaffExample;
import com.gmadong.modules.staff.SysStaffMapper;


@Service("sysOrganizeService")
public class SysOrganizeServiceImpl implements SysOrganizeService
{

	@Autowired
	private SysOrganizeMapper sysOrganizeMapper;
	@Autowired
	private SysStaffMapper sysStaffMapper;
	
	@Override
	public String getActionByOrganizeIds(String roleIds)
	{
		return null;
	}
	@Override
	public Page page(String OrganizeName, String remark, Integer page,
			Integer rows)
	{
		
		return null;
	}

	@Override
	public List<SysOrganize> getAll()
	{
		SysOrganizeExample example = new SysOrganizeExample();
		Criteria criteria = example.createCriteria();
		criteria.andStatusNotEqualTo("0");
		example.setOrderByClause("create_time ASC");
		List<SysOrganize> list = sysOrganizeMapper.selectByExample(example);
		return list;
	}

	@Override
	public SysOrganize getRow(String organizeId)
	{
		return sysOrganizeMapper.selectByPrimaryKey(organizeId);
	}
	@Override
	public List<SysOrganize> getChlidOrganize(String organizeId)
	{
		SysOrganizeExample example = new SysOrganizeExample();
		Criteria criteria = example.createCriteria();
		criteria.andStatusEqualTo("1");
		criteria.andParentIdEqualTo(organizeId);
		
		Criteria criteria1 = example.createCriteria();
		criteria1.andStatusEqualTo("1");
		criteria1.andOrganizeIdEqualTo(organizeId);
		example.or(criteria1);
		List<SysOrganize> list = sysOrganizeMapper.selectByExample(example);
		return list;
	}

	@Override
	public Page staffPage(String organizeId, String staffName,
			String createTime, Integer page, Integer rows)
	{
		SysStaffExample example = new SysStaffExample();
		SysStaffExample.Criteria criteria = example.createCriteria();
		SysStaffExample.Criteria criteria1 = example.createCriteria();
		criteria.andStatusEqualTo(1);
		if(!StringUtil.isEmpty(organizeId))
		{
			criteria.andOrganizeIdLike(organizeId+"%");
		}
		if(!StringUtil.isEmpty(createTime))
		{
			criteria.andCtimeLike(createTime+"%");
		}
		if(!StringUtil.isEmpty(staffName))
		{
			criteria.andNicknameLike(staffName+"%");
			criteria1.andLoginnameLike(staffName+"%");
			example.or(criteria1);
		}
		example.setOrderByClause("ctime ASC");
		PageHelper.startPage(page,rows);
		List<SysStaff> list = sysStaffMapper.selectByExample(example);
		PageInfo<SysStaff> pageInfo = new PageInfo<SysStaff>(list);
		long total = pageInfo.getTotal();
        Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean save(SysOrganize sysOrganize)
	{
		int insert = sysOrganizeMapper.insert(sysOrganize);
		if(insert==1)
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteByOrganizeIds(String ids)
	{
		if (!StringUtil.isEmpty(ids))
		{
			if (ids.startsWith(","))
			{
				ids = ids.substring(1);
			}
			if(ids.endsWith(","))
			{
				ids = ids.substring(ids.length()-1);
			}
			ids = ids.replaceAll("'", "");
			SysOrganizeExample example = new SysOrganizeExample();
			Criteria criteria = example.createCriteria();
			criteria.andStatusNotEqualTo("2");
			criteria.andOrganizeIdIn(Arrays.asList(ids.split(",")));
			int deleteByExample = sysOrganizeMapper.deleteByExample(example);
			if(deleteByExample>0)
			{
				return true;
			}
		}
		
		return false;
	}

	@Override
	public boolean hasChildOrganize(String ids)
	{
		
		SysOrganizeExample example = new SysOrganizeExample();
		Criteria criteria = example.createCriteria();
		criteria.andStatusNotEqualTo("0");
		criteria.andParentIdEqualTo(ids);
		
		List<SysOrganize> list = sysOrganizeMapper.selectByExample(example);
		if(list.size()>0)
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean update(SysOrganize organize)
	{
		int update = sysOrganizeMapper.updateByPrimaryKey(organize);
		if(update==1)
		{
			return true;
		}
		return false;
	}

}
