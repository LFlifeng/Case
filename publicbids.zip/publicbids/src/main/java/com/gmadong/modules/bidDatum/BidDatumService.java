package com.gmadong.modules.bidDatum;

import com.gmadong.common.Page;

public interface BidDatumService
{
	public Page page(String tltle,String source,String ctime,Integer page,Integer rows);
	public boolean save(BidDatum bidDatum);
	public boolean update(BidDatum bidDatum);
	public BidDatum getBidDatumById(String id);
	public boolean deleteById(String ids);
}
