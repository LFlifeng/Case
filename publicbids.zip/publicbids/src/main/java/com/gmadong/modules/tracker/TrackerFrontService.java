package com.gmadong.modules.tracker;

import com.gmadong.common.Page;

public interface TrackerFrontService
{

	public Page page(String staffId,Integer page,Integer rows);
	public boolean save(Tracker tracker);
	public boolean update(Tracker tracker);
	public Tracker getTrackerById(String id);
}
