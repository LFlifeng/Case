package com.gmadong.modules.product;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.manageCondition.ManageConditionQdService;
import com.gmadong.modules.user.User;
import com.gmadong.modules.user.UserService;

@Controller
public class ProductQdController
{
	@Autowired
	private ProductQdService productQdService;
	@Autowired
	private JedisClientSingle jedisClientSingle;
	private String listkey = "product.listshow.do";
	@Autowired
	private UserService userService;
	
    @RequestMapping("product.buildCpzs.do")
	public String buildJyzz() 
	{
		  return "/front/application/buildCpzs";
	}
	//根据用户id产品展示
	@RequestMapping("product.listshow.do")
	public void list(HttpServletRequest req,HttpServletResponse response,@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows) throws Exception 
	{
		User user = (User)Session.get("user");
		if(user == null)
		{
			AjaxUtil.write(Page.pageToJson(Page.getEmptyPage()), response);
			return;
		}

		String field =user.getId();
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = productQdService.page(user.getId(),page, rows);
		String list = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, list, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(Page.pageToJson(toPage), response);

	}
	@RequestMapping("product.deletelist.do")
	public void deleteProductById(HttpServletResponse res,String id) 
	{
		User user=(User)Session.get("user");
		if(user == null)
		{
			AjaxUtil.write("fail",res);
			return;
		}
		boolean  stat=productQdService.deleteByPrimaryKey(id);
		if(stat)
		{
			try
			{
				jedisClientSingle.hdel(listkey,user.getId());
				jedisClientSingle.del("product.list.action");
			} catch (Exception e)
			{
			}
			AjaxUtil.write("succ",res);
		}
		else {
			AjaxUtil.write("fail",res);
		}
	}
	@RequestMapping("/product.doAdd.do")
	public void doAdd(HttpServletResponse response, @Validated({ ValidatebProductAddAction.class }) Product product,BindingResult bindingResult)
	{
		User user=(User)Session.get("user");
		if(user == null)
		{
			AjaxUtil.write("fail",response);
			return;
		}
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		product.setUserId(user.getId());
		if(productQdService.save(product))
		{
			try {
				jedisClientSingle.hdel(listkey,user.getId());
				jedisClientSingle.del("product.list.action");
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		}
		else {
			AjaxUtil.write("fail", response);
		}
	}
	
	/**
	 * 根据公司id查询供应产品
	 * 
	 * @param response
	 * @param companyId
	 * @param page
	 * @param rows
	 */
	@RequestMapping("/product.companyProductList.do")
	public void companylist(HttpServletResponse response, String applicationId,
			@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "8") Integer rows) {

		String field = applicationId + "-" + page + "-" + rows;
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = productQdService.pageCompany(applicationId, page, rows);
		String listStr = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, listStr, Common.REDIS_24_HOUR_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
	}
}















