package com.gmadong.modules.biddinginfo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.bids.BidsMobileSearch;
import com.gmadong.modules.tracker.CityInfo;
import com.gmadong.modules.tracker.Tracker;

public class BidsParamsInfo
{
	private List<String> provinces = null;
	private List<String> keys = null;
	private List <String> types = null;
	private String time;
	private String trackerId;
	
	public List<String> getKeys()
	{
		return keys;
	}
	public void setKeys(List<String> keys)
	{
		this.keys = keys;
	}
	public List<String> getProvinces()
	{
		return provinces;
	}
	public void setProvinces(List<String> provinces)
	{
		this.provinces = provinces;
	}
	
	public List<String> getTypes()
	{
		return types;
	}
	public void setTypes(List<String> types)
	{
		this.types = types;
	}
	public String getTime()
	{
		return time;
	}
	public void setTime(String time)
	{
		this.time = time;
	}
	
	//新增
	public BidsParamsInfo (BidsMobileSearch bisMobileSearch)
	{
		if(bisMobileSearch==null)
		{
			this.time = DateUtil.getFormatDateTime(DateUtil.getDateBeforeOrAfter(new Date(), -7), "yyyy-MM-dd");
			return;
		}
		if(StringUtil.isNotEmpty(bisMobileSearch.getRegions()))
		{
			this.provinces = new ArrayList<String>();
			String[] split = bisMobileSearch.getRegions().split(",");
			for (String string : split)
			{
				this.provinces.add(string.substring(0, 2));
			}
		}
		if(StringUtil.isNotEmpty(bisMobileSearch.getDate()))
		{
			this.time = bisMobileSearch.getDate();
		}
		if(StringUtil.isNotEmpty(bisMobileSearch.getInfoType()))
		{
			this.types=new ArrayList<String>();
			String[] split = bisMobileSearch.getInfoType().split(",");
			for (String string : split)
			{
				this.types.add(string);
			}
		}
		if(StringUtil.isNotEmpty(bisMobileSearch.getKeywords()))
		{
			this.keys = new ArrayList<String>();
			this.keys.add(bisMobileSearch.getKeywords());
		}
		
	}

	public BidsParamsInfo (Tracker tracker,boolean isLocal)
	{
		if(tracker!=null && tracker.getRegionList()!=null&&tracker.getRegionList().size() >0)
		{
			this.provinces = new ArrayList<String>();
			for(CityInfo cInfo:tracker.getRegionList())
			{
				this.provinces.add(cInfo.getP().substring(0, 2));
			}
		}
		if(tracker!=null && tracker.getKeys()!=null && tracker.getKeys().size()>0)
		{
			this.keys = tracker.getKeys();
		}
		if(tracker!=null && tracker.getInfoType().length() >0)
		{
			String[] split = tracker.getInfoType().split(",");
			this.types = new ArrayList<String>();
			for(String str :split)
			{
				str = str.trim();
				if(str.length() > 0)
				{
					this.types.add(str);
				}
			}
		}
		if(isLocal)
		{
			this.time = DateUtil.getFormatDateTime(DateUtil.getDateBeforeOrAfter(new Date(), -30), "yyyy-MM-dd HH:mm:ss");
		}
		else
		{
			this.time = DateUtil.getFormatDateTime(DateUtil.getDateBeforeOrAfter(new Date(), -30), "yyyy-MM-dd");
		}
		this.trackerId = tracker.getId();
	}
	public String getTrackerId()
	{
		return trackerId;
	}
	public void setTrackerId(String trackerId)
	{
		this.trackerId = trackerId;
	}
	
	
}
