package com.gmadong.modules.news;



import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.datasource.CustomerContextHolder;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.bids.Bids;
import com.gmadong.modules.bids.BidsExample;
import com.gmadong.modules.news.NewsExample.Criteria;



@Service("newsQdService")
public class NewsQdServiceImpl implements NewsQdService{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private NewsMapper newsMapper;
	private static final String parentCategorysKey = "newsQdMapper.ParentCategorys";

	@Override
	public Page page(Integer page, Integer rows,String category,String title) {
		
		NewsExample newsExample = new NewsExample();
		Criteria createCriteria = newsExample.createCriteria();
		if (!StringUtil.isEmpty(category)) {
			createCriteria.andCategoryEqualTo(category);
		}
		if (!StringUtil.isEmpty(title)) {
			createCriteria.andTitleLike("%" + title + "%");
		}
		PageHelper.startPage(page, rows);
		List<News> list = newsMapper.selectNewsList(newsExample);
		PageInfo<News> pageInfo = new PageInfo<News>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public News details(String id) {
		return newsMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<News> findByCategory(String category) {
		List<News> list = newsMapper.selectByCategory(category);
		if(list.size() > 0) {
			return list;
		}
		return null;
				
	}

	@Override
	public List<News> findTodayNews() {
		List<News> list = newsMapper.selectTodayNews();
		if(list.size() > 0) {
			return list;
		}
		return null;
	}

	@Override
	public List<News> findHotNews() {
		List<News> list = newsMapper.selectHotNews();
		if(list.size() > 0) {
			return list;
		}
		return null;
	}
}
