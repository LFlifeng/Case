package com.gmadong.modules.projectDesigneds;

public interface ValidatebProjectDesignedsAddAction
{

}
