package com.gmadong.modules.organize;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.LogUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.role.SysRole;
import com.gmadong.modules.staff.SysStaff;
import com.gmadong.modules.staff.ValidateSysStaffSaveAction;

/**
 * 组织或部门
 * @ClassName: OrganizeController
 * @Description: 
 * @author caodong
 * @date 2017年5月31日 下午1:25:36
 *
 */
@Controller
public class SysOrganizeController
{
	 
    @Resource(name="sysOrganizeService")
    private SysOrganizeService organizeService;
    @Autowired
	private JedisClientSingle jedisClientSingle;
	 /**
	 * 列表页
	 */
	@RequestMapping("/organize.page.action")
	public String page()
	{
		return "/back/organize/page";
	}
	/**
	 * list
	 */
	@RequestMapping("/organize.list.action")
	public void list(HttpServletResponse response,String roleName,String remark,@RequestParam(defaultValue="1") Integer page,@RequestParam(defaultValue="10") Integer rows)
	{
		
	}
	@RequestMapping("/organize.preAdd.action")
	public String preAdd(HttpServletResponse response,String parentId)
	{
		String key = "organize.preAdd";
		try
		{
			String list = jedisClientSingle.get(key);
			if(StringUtil.isNotEmpty(list))
			{
				Request.set("organizesJsonString", list);
				return "/back/organize/add";
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		List<SysOrganize> organizes = organizeService.getAll();
		String organizesJsonString = "[";
		for(SysOrganize organize:organizes)
		{
			organizesJsonString += "{\"id\":\""+organize.getOrganizeId()+"\",\"name\":\""+organize.getOrganizeName()+"\",\"pId\":\""+organize.getParentId()+"\"";
			if(StringUtil.isNotEmpty(parentId) && parentId.indexOf(organize.getOrganizeId())!=-1){
				organizesJsonString += ",\"checked\":\"true\"";
			}
			organizesJsonString += "},";
		}
		if(organizesJsonString.endsWith(","))
		{
			organizesJsonString = organizesJsonString.substring(0, organizesJsonString.length()-1);
		}
		organizesJsonString += "]";
		Request.set("organizesJsonString", organizesJsonString);

		try
		{
			jedisClientSingle.set(key, organizesJsonString, Common.REDIS_48_HOUR_EXPIRE);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return "/back/organize/add";
	}
	@RequestMapping("/organize.doAdd.action")
	public void doAdd(HttpServletResponse response,@Validated AddOrganizeValidate organizeValidate,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		SysOrganize sysOrganize = new SysOrganize();
		sysOrganize.setOrganizeId(UUIDUtil.getUUID());
		sysOrganize.setCreateTime(DateUtil.getCurrentDate());
		sysOrganize.setStatus("1");
		sysOrganize.setOrganizeName(organizeValidate.getOrganizeName());
		sysOrganize.setParentId(organizeValidate.getParentId());
		sysOrganize.setRemark(organizeValidate.getRemark());
		sysOrganize.setType(organizeValidate.getType());
		
		if(organizeService.save(sysOrganize))
		{
			try
			{
				jedisClientSingle.del("organize.preAdd");
				jedisClientSingle.del("organizesJsonString");
				jedisClientSingle.del("organize.detail");
				
			} catch (Exception e)
			{
				e.printStackTrace();
			}
			
			AjaxUtil.write(sysOrganize.getOrganizeId(),response);
		}
		else
		{
			AjaxUtil.write("未知错误",response);
		}
	}   	   
	/**
	 * tree
	 */
	@RequestMapping("/organize.tree.action")
	public String tree(HttpServletResponse response,String currentSelectedOrganize)
	{
		if(!StringUtil.isNotEmpty(currentSelectedOrganize))
		{
			currentSelectedOrganize = "402888e432a9db5a0132a9e007400001";
		}
		Request.set("currentSelectedOrganize", currentSelectedOrganize);
		String organizesJson = "organizesJsonString";
		String allOrganizeJsonString  = "";
		try
		{
			allOrganizeJsonString = jedisClientSingle.get(organizesJson);
			if(StringUtil.isNotEmpty(allOrganizeJsonString))
			{
				Request.set("allOrganizeJsonString", allOrganizeJsonString);
				return "/back/organize/tree";
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		allOrganizeJsonString = JsonUtil.listToJson(organizeService.getAll());
		allOrganizeJsonString = allOrganizeJsonString.replaceAll("organizeId", "id").replaceAll("organizeName", "name").replaceAll("parentId", "pId");
		Request.set("allOrganizeJsonString", allOrganizeJsonString);
		
		try
		{
			jedisClientSingle.set(organizesJson, allOrganizeJsonString, Common.REDIS_48_HOUR_EXPIRE);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return "/back/organize/tree";
	} 
	/**
	 * detail
	 */
	@RequestMapping("/organize.detail.action")
	public String detail(HttpServletResponse response,String organizeId)
	{
		String key = "organize.detail";
		String field = organizeId; 
		try
		{
			String list = jedisClientSingle.hget(key, field);
			if(StringUtil.isNotEmpty(list))
			{
				ObjectMapper mapper = new ObjectMapper();
				SysOrganize organize = mapper.readValue(list, SysOrganize.class);
				Request.set("bean", organize);
				return "/back/organize/detail";
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		SysOrganize organize = organizeService.getRow(organizeId);
		Request.set("bean", organize);
		try
		{
			jedisClientSingle.hset(key, field, JsonUtil.bean2json(organize), Common.REDIS_48_HOUR_EXPIRE);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return "/back/organize/detail";
	}
	/**
	 * doDetail
	 * @param response
	 * @param organizeId
	 * @param organizeName
	 * @param remark
	 * @return
	 */
	@RequestMapping("/organize.doDetail.action")
	public String doDetail(HttpServletResponse response,String organizeId,String organizeName,String remark,String type)
	{
		SysOrganize organize = null;
		String key = "organize.detail";
		String field = organizeId; 
		try
		{
			String list = jedisClientSingle.hget(key, field);
			if(StringUtil.isNotEmpty(list))
			{
				ObjectMapper mapper = new ObjectMapper();
				organize = mapper.readValue(list, SysOrganize.class);
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		if(organize==null)
		{
			organize = organizeService.getRow(organizeId);
		}
		organize.setOrganizeName(organizeName);
		organize.setRemark(remark);
		organize.setType(type);
		organizeService.update(organize);
		Request.set("bean", organize);
		
		try
		{
			jedisClientSingle.del("organize.preAdd");
			jedisClientSingle.del("organizesJsonString");
			jedisClientSingle.del("organize.detail");
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return "/back/organize/detail";
	}
	/**
	 * 员工分页页面
	 */
	@RequestMapping("/organize.staffPage.action")
	public String staffPage(HttpServletResponse response,String organizeId,String spareTwo)
	{
		Request.set("organizeId", organizeId);
		Request.set("spareTwo", spareTwo);
		return "/back/organize/staffPage";
	}
	@RequestMapping("/organize.staffList.action")
	public void staffList(HttpServletResponse response,String organizeId,String staffName,String createTime,@RequestParam(defaultValue="1") Integer page,@RequestParam(defaultValue="10") Integer rows)
	{
		String key = "organize.staffList";
		String field =organizeId+"-"+staffName+"-"+createTime+"-"+page+"-"+rows;
		try
		{
			String list = jedisClientSingle.hget(key, field);
			if(StringUtil.isNotEmpty(list))
			{
				AjaxUtil.write(list,response);
				return;
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		Page toPage = organizeService.staffPage(organizeId,staffName,createTime,page, rows);
		String listStr = Page.pageToJson(toPage);
		try
		{
			jedisClientSingle.hset(key, field, listStr, Common.REDIS_48_HOUR_EXPIRE);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		AjaxUtil.write(listStr,response);
	}
	@RequestMapping("/organize.delete.action")
	public void delete(HttpServletResponse response,String ids)
	{
		if(StringUtil.isNotEmpty(ids)&&!organizeService.hasChildOrganize(ids))
		{
			organizeService.deleteByOrganizeIds(ids);
			try
			{
				jedisClientSingle.del("organize.preAdd");
				jedisClientSingle.del("organizesJsonString");
				jedisClientSingle.del("organize.detail");
				
			} catch (Exception e)
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("未知错误",response);
		}
	}
	@RequestMapping("/organize.setManager.action")
	public void setManager(HttpServletResponse response,String statffId,String organizeId)
	{
		SysOrganize organize = organizeService.getRow(organizeId);
		organize.setSpareTwo(statffId);
		organizeService.update(organize);
		Request.set("spareTwo", statffId);
		try
		{
			jedisClientSingle.del("organize.staffList");
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		AjaxUtil.write("succ",response);
	}
	
}
