package com.gmadong.modules.replacePicture;

import com.gmadong.common.Page;

public interface ReplacePictureService
{
	public Page page(String number,String url,String ctime,Integer page,Integer rows);
	public boolean save(ReplacePicture replacePicture);
	public boolean update(ReplacePicture replacePicture);
	public ReplacePicture getReplacePictureById(String id);
	public boolean deleteById(String ids);
}
