package com.gmadong.modules.application;

public interface ValidatebApplicationEditAction
{

}
