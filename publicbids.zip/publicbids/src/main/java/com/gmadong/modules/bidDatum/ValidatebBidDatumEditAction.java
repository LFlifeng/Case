package com.gmadong.modules.bidDatum;

public interface ValidatebBidDatumEditAction
{

}
