package com.gmadong.modules.category;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;



public class Category {
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebCategoryEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebCategoryEditAction.class} )
    private String id;

    /** 1:新闻 */
	@NotBlank(message="类型不能为空!" ,groups = {ValidatebCategoryAddAction.class,ValidatebCategoryEditAction.class})
	@Max(value=50,message="类型不能大于50!" ,groups = {ValidatebCategoryAddAction.class,ValidatebCategoryEditAction.class})
	@Min(value=0,message="类型不能小于0!" ,groups = {ValidatebCategoryAddAction.class,ValidatebCategoryEditAction.class})
    private String type;

    /** 标题 */
    
    @NotBlank(message="标题不能为空!" ,groups = {ValidatebCategoryAddAction.class,ValidatebCategoryEditAction.class})
    @Size (min=1,max=40,message="请输入正确的标题分类名!" ,groups = {ValidatebCategoryAddAction.class,ValidatebCategoryEditAction.class})
    private String title;
    
    /** 排序序号 */
    @Min(value=0,message="排序序号必须大于等于0!" ,groups = {ValidatebCategoryAddAction.class,ValidatebCategoryEditAction.class})
    @Max(value=99,message="排序序号必须小于等于99!" ,groups = {ValidatebCategoryAddAction.class,ValidatebCategoryEditAction.class})
    /** 排序 */
    private Integer sortIndex;

    private String ctime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 1:新闻
     * @return type
     */
    public String getType() {
        return type;
    }

    /**
     * 1:新闻
     * @param type
     */
    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    /**
     * 标题
     * @return title
     */
    public String getTitle() {
        return title;
    }

    /**
     * 标题
     * @param title
     */
    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    /**
     * 排序
     * @return sortIndex
     */
    public Integer getSortIndex() {
        return sortIndex;
    }

    /**
     * 排序
     * @param sortIndex
     */
    public void setSortIndex(Integer sortIndex) {
        this.sortIndex = sortIndex;
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }
    public Category() {
		
	}
    public Category(String type,String title,Integer sortIndex,String ctime) {
		
    	super();
		this.type = type;
		this.title = title;
		this.sortIndex = sortIndex;
		this.ctime = ctime;
	}
}