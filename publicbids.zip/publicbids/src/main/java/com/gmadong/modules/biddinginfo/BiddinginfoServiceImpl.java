package com.gmadong.modules.biddinginfo;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.biddinginfo.BiddinginfoExample.Criteria;
import com.gmadong.modules.staff.SysStaff;
import com.gmadong.modules.staff.SysStaffExample;
import com.gmadong.modules.tracker.Tracker;
import com.gmadong.modules.tracker.TrackerExample;
@Service("biddinginfoService")
public class BiddinginfoServiceImpl implements BiddinginfoService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private BiddinginfoMapper biddinginfoMapper;
	
	@Override
	public boolean save(Biddinginfo biddinginfo)
	{
		biddinginfo.setId(UUIDUtil.getUUID());
		biddinginfo.setCtime(DateUtil.getCurrentDate());
		boolean flag = biddinginfoMapper.insert(biddinginfo) > 0;
		return flag;
	}
	
	@Override
	public boolean update(Biddinginfo biddinginfo)
	{
		biddinginfo.setCtime(null);
		return biddinginfoMapper.updateByPrimaryKeySelective(biddinginfo) > 0;
	}
	
	@Override
	public Biddinginfo getBiddinginfoById(String id)
	{
		return biddinginfoMapper.selectByPrimaryKey(id);
	}

	@Override
	public boolean deleteById(String ids)
	{
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			BiddinginfoExample biddinginfoExample = new BiddinginfoExample();
			Criteria createCriteria = biddinginfoExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			return biddinginfoMapper.deleteByExample(biddinginfoExample) > 0;
		}
		return false;
	}

	@Override
	public Page page(String projectName, String issuer, String issuerPhone,String projectType,String state, String ctime,Integer page, Integer rows)
	{
		BiddinginfoExample biddinginfoExample = new BiddinginfoExample();
		Criteria createCriteria = biddinginfoExample.createCriteria();
		if (!StringUtil.isEmpty(projectName)) {
			createCriteria.andProjectNameLike(projectName + "%");
		}
		if (!StringUtil.isEmpty(issuer)) {
			createCriteria.andIssuerLike(issuer + "%");
		}
		if (!StringUtil.isEmpty(issuerPhone)) {
			createCriteria.andIssuerPhoneLike(issuerPhone + "%");
		}
		if (!StringUtil.isEmpty(projectType)) {
			createCriteria.andProjectTypeLike(projectType + "%");
		}
		if (!StringUtil.isEmpty(ctime)) {
			createCriteria.andCtimeLike(ctime + "%");
		}
		if (!StringUtil.isEmpty(state)) {
			createCriteria.andStateLike(state + "%");
		}
		biddinginfoExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<Biddinginfo> list = biddinginfoMapper.selectByExample(biddinginfoExample);
		PageInfo<Biddinginfo> pageInfo = new PageInfo<Biddinginfo>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public String getprojectNameById(String id)
	{
		return "";//biddinginfoMapper.getprojectNameByPrimaryKey(id);
	}

	@Override
	public Biddinginfo getBiddinginfoprojectName(String projectName)
	{
		if(StringUtil.isEmpty(projectName))
		{
			return null;
		}
		BiddinginfoExample biddinginfoExample = new BiddinginfoExample();
		Criteria criteria = biddinginfoExample.createCriteria();
		criteria.andProjectNameEqualTo(projectName.trim());
	    List<Biddinginfo> selectByExample = biddinginfoMapper.selectByExample(biddinginfoExample);
		if (selectByExample.size()>0)
		{
			return selectByExample.get(0);
		}
		return null;
	}
}
