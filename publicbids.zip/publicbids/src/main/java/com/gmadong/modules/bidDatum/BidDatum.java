package com.gmadong.modules.bidDatum;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.gmadong.common.utils.FileUtil;
import com.gmadong.common.utils.StringUtil;




public class BidDatum {
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebBidDatumEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebBidDatumEditAction.class} )
    private String id;

    /** 标题 */
    @NotBlank(message="标题不能为空!" ,groups = {ValidatebBidDatumAddAction.class,ValidatebBidDatumEditAction.class})
    @Size (min=1,max=200,message="请输入正确的标题!" ,groups = {ValidatebBidDatumAddAction.class,ValidatebBidDatumEditAction.class})
    private String tltle;

    /** 来源 */
    @NotBlank(message="来源不能为空!" ,groups = {ValidatebBidDatumAddAction.class,ValidatebBidDatumEditAction.class})
    @Size (min=1,max=50,message="请输入正确的来源!" ,groups = {ValidatebBidDatumAddAction.class,ValidatebBidDatumEditAction.class})
    private String source;

    /** 附件 */
    private String accessory;

    private String ctime;

    private String accessoryUrl;
    
    private String attaUrl;
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 标题
     * @return tltle
     */
    public String getTltle() {
        return tltle;
    }

    /**
     * 标题
     * @param tltle
     */
    public void setTltle(String tltle) {
        this.tltle = tltle == null ? null : tltle.trim();
    }

    /**
     * 来源
     * @return source
     */
    public String getSource() {
        return source;
    }

    /**
     * 来源
     * @param source
     */
    public void setSource(String source) {
        this.source = source == null ? null : source.trim();
    }

    /**
     * 附件
     * @return accessory
     */
    public String getAccessory() {
        return accessory;
    }

    /**
     * 附件
     * @param accessory
     */
    public void setAccessory(String accessory) {
    	
    	if(StringUtil.isNotEmpty(accessory))
    	{
    		this.attaUrl = "/upload/attach"+FileUtil.getPath(accessory)+accessory;
    	}
        this.accessory = accessory == null ? null : accessory.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }

	public String getAccessoryUrl() {
		return accessoryUrl;
	}

	public void setAccessoryUrl(String accessoryUrl) {
		this.accessoryUrl = accessoryUrl;
	}

	public String getAttaUrl()
	{
		return attaUrl;
	}

	public void setAttaUrl(String attaUrl)
	{
		this.attaUrl = attaUrl;
	}
}