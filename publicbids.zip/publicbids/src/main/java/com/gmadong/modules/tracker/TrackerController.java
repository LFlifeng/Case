package com.gmadong.modules.tracker;


import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.company.ValidatebCompanyAddAction;
import com.gmadong.modules.user.User;
import com.gmadong.modules.user.UserService;
/**
 * 追踪器
 * @author Administrator
 *
 */
@Controller
public class TrackerController
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private TrackerService trackerService;
	private String listkey = "tracker.list.action";
	@Autowired
	private UserService userService;
	/**
	 * 列表页面
	 * @return
	 */
	@RequestMapping("/tracker.page.action")
	public String page()
	{
		return "/back/tracker/page";
	}
	/**
	 * 页面条件搜索
	 * @return
	 */
	@RequestMapping("/tracker.list.action")
	public void list(HttpServletResponse response,String trackerName,String searchType,String ctime,@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows) 
	{
		String field = trackerName + "_" + searchType + "_" + ctime + "_" + page + "_" + rows;
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = trackerService.page(trackerName, searchType, ctime,page, rows);
		String list = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, list, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(Page.pageToJson(toPage), response);
	}
	/**
	 * 添加页面
	 * @return
	 */
	@RequestMapping("/tracker.preAdd.action")
	public String preAdd() 
	{	
		return "/back/tracker/add";
	}
	/**
	 * 添加操作
	 * @return
	 */
	@RequestMapping("/tracker.doAdd.action")
	public void doAdd(HttpServletResponse response, @Validated({ ValidatebCompanyAddAction.class }) Tracker tracker,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		if(tracker.getProvinces().size()!= tracker.getCitys().size())
		{
			AjaxUtil.write("请选择合法的地区",response);
			return;
		}
		for(int i=0;i<tracker.getProvinces().size();i++)
		{
			tracker.getRegionList().add(new CityInfo(tracker.getProvinces().get(i), tracker.getCitys().get(i)));
		}
		tracker.setRegions(JsonUtil.listToJson(tracker.getRegionList()));
		if(trackerService.save(tracker))
		{
			try {
				jedisClientSingle.del(listkey);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		}
		else {
			AjaxUtil.write("添加失败", response);
		}
	}
	@RequestMapping("/tracker.seachUser.action")
	public void seachUser(HttpServletResponse response,String name)
	{
		User username = userService.getUsername(name);
		if(username == null)
		{
			AjaxUtil.write("fail",response);
			return ;
		}
		AjaxUtil.write("{\"name\":\""+username.getNickname()+"\",\"id\":\""+username.getId()+"\"}",response);
	}
	/**
	 * 修改页面
	 * @return
	 */
	@RequestMapping("/tracker.preEdit.action")
	public String preEdit(String id) 
	{
		
		Tracker trackerById = trackerService.getTrackerById(id);
		if (trackerById == null) {
			return "/common/500";
		}
		
		Request.set("info", trackerById);
		if(StringUtil.isNotEmpty(trackerById.getUserId()))
		{
			Request.set("nickname", userService.getPhoneById(trackerById.getUserId()));
		}
		else
		{
			Request.set("nickname", "");
		}
		return "/back/tracker/edit";
	}
	/**
	 * 修改操作
	 */
	@RequestMapping("/tracker.doEdit.action")
	public void doEdit(HttpServletResponse response,
			@Validated({ ValidatebTrackerEditAction.class }) Tracker tracker, BindingResult bindingResult) 
	{
		if (bindingResult.hasErrors()) {
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(), response);
			return;
		}
		if(tracker.getProvinces().size()!= tracker.getCitys().size())
		{
			AjaxUtil.write("请选择合法的地区",response);
			return;
		}
		for(int i=0;i<tracker.getProvinces().size();i++)
		{
			tracker.getRegionList().add(new CityInfo(tracker.getProvinces().get(i), tracker.getCitys().get(i)));
		}
		tracker.setRegions(JsonUtil.listToJson(tracker.getRegionList()));
		if(trackerService.update(tracker))
		{
			try
			{
				jedisClientSingle.del(listkey);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("修改失败！",response);
		}
	}
	/**
	 * 删除
	 * @return
	 */
	@RequestMapping("/tracker.doDelete.action")
	public void doDelete(HttpServletResponse response, String ids) {
		if (trackerService.deleteById(ids)) {
			try {
				jedisClientSingle.del("tracker.list.action");
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("fail", response);
		}
	}
}
