package com.gmadong.modules.organize;

public class SysOrganize {
    /** 组织架构ID */
    private String organizeId;

    /** 组织架构名称 */
    private String organizeName;

    /** 父级ID */
    private String parentId;

    /** 备注 */
    private String remark;

    /** 保留字段一 */
    private String spareOne;

    /** 保留字段二 */
    private String spareTwo;

    /** 0 正常 1 可接收资源 */
    private String type;

    /** 当前记录状态:0-删除 1-正常 2-不可删除 */
    private String status;

    /** 当前记录创建时间 */
    private String createTime;

    /**
     * 组织架构ID
     * @return organizeId
     */
    public String getOrganizeId() {
        return organizeId;
    }

    /**
     * 组织架构ID
     * @param organizeId
     */
    public void setOrganizeId(String organizeId) {
        this.organizeId = organizeId == null ? null : organizeId.trim();
    }

    /**
     * 组织架构名称
     * @return organizeName
     */
    public String getOrganizeName() {
        return organizeName;
    }

    /**
     * 组织架构名称
     * @param organizeName
     */
    public void setOrganizeName(String organizeName) {
        this.organizeName = organizeName == null ? null : organizeName.trim();
    }

    /**
     * 父级ID
     * @return parentId
     */
    public String getParentId() {
        return parentId;
    }

    /**
     * 父级ID
     * @param parentId
     */
    public void setParentId(String parentId) {
        this.parentId = parentId == null ? null : parentId.trim();
    }

    /**
     * 备注
     * @return remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 备注
     * @param remark
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    /**
     * 保留字段一
     * @return spareOne
     */
    public String getSpareOne() {
        return spareOne;
    }

    /**
     * 保留字段一
     * @param spareOne
     */
    public void setSpareOne(String spareOne) {
        this.spareOne = spareOne == null ? null : spareOne.trim();
    }

    /**
     * 保留字段二
     * @return spareTwo
     */
    public String getSpareTwo() {
        return spareTwo;
    }

    /**
     * 保留字段二
     * @param spareTwo
     */
    public void setSpareTwo(String spareTwo) {
        this.spareTwo = spareTwo == null ? null : spareTwo.trim();
    }

    /**
     * 0 正常 1 可接收资源
     * @return type
     */
    public String getType() {
        return type;
    }

    /**
     * 0 正常 1 可接收资源
     * @param type
     */
    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    /**
     * 当前记录状态:0-删除 1-正常 2-不可删除
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     * 当前记录状态:0-删除 1-正常 2-不可删除
     * @param status
     */
    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    /**
     * 当前记录创建时间
     * @return createTime
     */
    public String getCreateTime() {
        return createTime;
    }

    /**
     * 当前记录创建时间
     * @param createTime
     */
    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }
}