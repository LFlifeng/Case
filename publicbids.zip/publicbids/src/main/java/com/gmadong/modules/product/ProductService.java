package com.gmadong.modules.product;

import com.gmadong.common.Page;

public interface ProductService
{
	public Page page(String productName,String productDescribe,String ctime,Integer page,Integer rows);
	public boolean save(Product product);
	public boolean update(Product product);
	public Product getProductById(String id);
	public boolean deleteById(String ids);
}
