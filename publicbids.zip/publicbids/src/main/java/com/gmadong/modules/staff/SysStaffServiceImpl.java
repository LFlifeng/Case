package com.gmadong.modules.staff;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.staff.SysStaffExample.Criteria;

@Service("staffService")
public class SysStaffServiceImpl implements SysStaffService
{

	@Autowired
	private SysStaffMapper sysStaffMapper;
	@Override
	public SysStaff getStaffByLoginName(String loginName)
	{
		if(StringUtil.isEmpty(loginName))
		{
			return null;
		}
		SysStaffExample staffExample = new SysStaffExample();
		Criteria criteria = staffExample.createCriteria();
		criteria.andLoginnameEqualTo(loginName.trim());
		criteria.andStatusEqualTo(1);
		
		Criteria criteria1 = staffExample.createCriteria();
		criteria1.andLoginnameEqualTo(loginName.trim());
		criteria1.andStatusEqualTo(2);
		staffExample.or(criteria1);
	    List<SysStaff> selectByExample = sysStaffMapper.selectByExample(staffExample);
		if (selectByExample.size()>0)
		{
			return selectByExample.get(0);
		}
		return null;
	}
	@Override
	public Page page(String staffName,String loginName,String createTime,String jobNumber,String orgId,Integer page,Integer rows)
	{
		SysStaffExample example = new SysStaffExample();
		Criteria criteria = example.createCriteria();
		criteria.andStatusEqualTo(1);
		if(!StringUtil.isEmpty(staffName))
		{
			criteria.andNicknameLike(staffName+"%");
		}
		if(!StringUtil.isEmpty(loginName))
		{
			criteria.andLoginnameLike(loginName+"%");
		}
		if(!StringUtil.isEmpty(createTime))
		{
			criteria.andCtimeLike(createTime+"%");
		}
		if(!StringUtil.isEmpty(jobNumber))
		{
			criteria.andJobNumberLike(jobNumber+"%");
		}
		if(!StringUtil.isEmpty(orgId))
		{
			criteria.andOrganizeIdLike(orgId+"%");
		}
		example.setOrderByClause("ctime DESC");
		PageHelper.startPage(page,rows);
		List<SysStaff> list = sysStaffMapper.selectByExample(example);
		PageInfo<SysStaff> pageInfo = new PageInfo<SysStaff>(list);
		long total = pageInfo.getTotal();
        Page toPage = new Page(total, page, list);
		return toPage;
	}
	@Override
	public boolean save(SysStaff staff)
	{
		int insert = sysStaffMapper.insert(staff);
		if(insert==1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	@Override
	public SysStaff getStaffById(String id)
	{
		return sysStaffMapper.selectByPrimaryKey(id);
	}
	@Override
	public boolean update(SysStaff localStaff)
	{
		int update = sysStaffMapper.updateByPrimaryKey(localStaff);
		if(update==1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	@Override
	public boolean deleteByRoleIds(String ids)
	{
		if (!StringUtil.isEmpty(ids))
		{
			if (ids.startsWith(","))
			{
				ids = ids.substring(1);
			}
			if(ids.endsWith(","))
			{
				ids = ids.substring(ids.length()-1);
			}
			ids = ids.replaceAll("'", "");
			
			SysStaffExample example = new SysStaffExample();
			Criteria criteria = example.createCriteria();
			
			criteria.andIdIn(Arrays.asList(ids.split(",")));
			int deleteByExample = sysStaffMapper.deleteByExample(example);
			if(deleteByExample>0)
			{
				return true;
			}
		}		
		return false;
	}
	@Override
	public int copyUseReport(String day)
	{
		return sysStaffMapper.copyUseReport(day);
	}
	@Override
	public int copyMsg(String day)
	{
		return sysStaffMapper.copyMsg(day);
	}
	@Override
	public int copyDayReport(String year)
	{
		return sysStaffMapper.copyDayReport(year);
	}
	@Override
	public String getNicknameById(String id)
	{
		return sysStaffMapper.getNicknameByPrimaryKey(id);
	}
}
