package com.gmadong.modules.staff;

import com.gmadong.common.Page;
import com.gmadong.modules.user.User;

public interface SysStaffService
{
	/**
	 * 根据登录名查找用户信息
	 * @param loginName 登录名
	 * @return
	 */
	public SysStaff getStaffByLoginName(String loginName);

	/**
	 * 用户列表
	 * @param staffName
	 * @param loginName
	 * @param createTime
	 * @param page
	 * @param rows
	 * @return
	 */
	public Page page(String staffName,String loginName,String createTime,String jobNumber,String orgId,Integer page,Integer rows);

	/**
	 * 添加用户
	 * @param staff
	 */
	public boolean save(SysStaff staff);
    /**
     * 根据用户ID查找用户信息
     * @param id 用户ID
     * @return
     */
	public SysStaff getStaffById(String id);
	/**
	 * 更新数据
	 * @param localStaff
	 */
	public boolean update(SysStaff staff);

	public boolean deleteByRoleIds(String ids);
	
	public int copyUseReport(String day);
	public int copyMsg(String day);
	public int copyDayReport(String year);
	
	public String getNicknameById(String id);
	
	
}
