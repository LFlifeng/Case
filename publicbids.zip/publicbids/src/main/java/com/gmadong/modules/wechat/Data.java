package com.gmadong.modules.wechat;

import java.util.List;
/**
 * 返回用户列表中的data类
 * @author Administrator
 *
 */
public class Data {

	private List<String> openid;

	public List<String> getOpenid() {
		return openid;
	}

	public void setOpenid(List<String> openid) {
		this.openid = openid;
	}



}
