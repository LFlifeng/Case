package com.gmadong.modules.city;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gmadong.common.Common;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;

@Controller
public class SysCityController
{
	@Resource(name="sysCityService")
	private SysCityService sysCityService;
	
	@Autowired
	private JedisClientSingle jedisClientSingle;
	
	@RequestMapping("/sysCity.province.action")
	public void province(HttpServletResponse response)
	{
		String key = "province.key";
		try
		{
			String list =  jedisClientSingle.get(key);
			if(StringUtil.isNotEmpty(list))
			{
				AjaxUtil.write(list, response);
				return;
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		List<CityMinInfo> selectProvince = sysCityService.selectProvince();
		String list = JsonUtil.listToJson(selectProvince);
		try
		{
			jedisClientSingle.set(key, list, Common.REDIS_72_HOUR_EXPIRE);
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		
		AjaxUtil.write(list, response);
	}
	/**
	 * 
	 * @param response
	 * @param id
	 * @param type 不为空 省加全国 市加全部
	 */
	@RequestMapping("/sysCity.city.action")
	public void province(HttpServletResponse response,String id,String type)
	{
		
		String key = "city.key";
		String field = id+"_"+type;
		
		try
		{
			String list = jedisClientSingle.hget(key, field);
			if(StringUtil.isNotEmpty(list))
			{
				AjaxUtil.write(list, response);
				return;
			}
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	
		List<CityMinInfo> selectProvince = sysCityService.selectCityById(id);
		if(StringUtil.isNotEmpty(type))
		{
			if("0".equals(id))
			{
				selectProvince.add(0, new CityMinInfo(-1, "全国"));
			}
			else
			{
				selectProvince.add(0, new CityMinInfo(-2, "全部"));
			}
		}
		String list = JsonUtil.listToJson(selectProvince);
		try
		{
			jedisClientSingle.hset(key,field, list);
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		
		AjaxUtil.write(list, response);
		/*
		AjaxUtil.write(city(id), response);*/
	}
	/*
	public static String city(String id)
	{
		if(StringUtil.isEmpty(id))
		{
			return "[]";
		}
		if("0".equals(id))
		{
			return "[{\"id\":\"12\",\"regionName\":\"安徽省\"},{\"id\":\"1\",\"regionName\":\"北京市\"},{\"id\":\"13\",\"regionName\":\"福建省\"},{\"id\":\"28\",\"regionName\":\"甘肃省\"},{\"id\":\"24\",\"regionName\":\"贵州省\"},{\"id\":\"20\",\"regionName\":\"广西壮族自治区\"},{\"id\":\"19\",\"regionName\":\"广东省\"},{\"id\":\"21\",\"regionName\":\"海南省\"},{\"id\":\"18\",\"regionName\":\"湖南省\"},{\"id\":\"17\",\"regionName\":\"湖北省\"},{\"id\":\"16\",\"regionName\":\"河南省\"},{\"id\":\"8\",\"regionName\":\"黑龙江省\"},{\"id\":\"3\",\"regionName\":\"河北省\"},{\"id\":\"14\",\"regionName\":\"江西省\"},{\"id\":\"10\",\"regionName\":\"江苏省\"},{\"id\":\"7\",\"regionName\":\"吉林省\"},{\"id\":\"6\",\"regionName\":\"辽宁省\"},{\"id\":\"30\",\"regionName\":\"宁夏回族自治区\"},{\"id\":\"5\",\"regionName\":\"内蒙古自治区\"},{\"id\":\"29\",\"regionName\":\"青海省\"},{\"id\":\"27\",\"regionName\":\"陕西省\"},{\"id\":\"23\",\"regionName\":\"四川省\"},{\"id\":\"15\",\"regionName\":\"山东省\"},{\"id\":\"9\",\"regionName\":\"上海市\"},{\"id\":\"4\",\"regionName\":\"山西省\"},{\"id\":\"32\",\"regionName\":\"台湾省\"},{\"id\":\"2\",\"regionName\":\"天津市\"},{\"id\":\"31\",\"regionName\":\"新疆维吾尔自治区\"},{\"id\":\"26\",\"regionName\":\"西藏自治区\"},{\"id\":\"25\",\"regionName\":\"云南省\"},{\"id\":\"22\",\"regionName\":\"重庆市\"},{\"id\":\"11\",\"regionName\":\"浙江省\"}]";
		}
		else if("12".equals(id))
		{
			return "[{\"id\":\"5542\",\"regionName\":\"安庆市\"},{\"id\":\"5549\",\"regionName\":\"亳州市\"},{\"id\":\"5537\",\"regionName\":\"蚌埠市\"},{\"id\":\"5550\",\"regionName\":\"池州市\"},{\"id\":\"5547\",\"regionName\":\"巢湖市\"},{\"id\":\"5544\",\"regionName\":\"滁州市\"},{\"id\":\"5545\",\"regionName\":\"阜阳市\"},{\"id\":\"5543\",\"regionName\":\"黄山市\"},{\"id\":\"5540\",\"regionName\":\"淮北市\"},{\"id\":\"5538\",\"regionName\":\"淮南市\"},{\"id\":\"5535\",\"regionName\":\"合肥市\"},{\"id\":\"5548\",\"regionName\":\"六安市\"},{\"id\":\"5539\",\"regionName\":\"马鞍山市\"},{\"id\":\"5546\",\"regionName\":\"宿州市\"},{\"id\":\"5541\",\"regionName\":\"铜陵市\"},{\"id\":\"5536\",\"regionName\":\"芜湖市\"},{\"id\":\"5551\",\"regionName\":\"宣城市\"}]";
		}
		else if("5542".equals(id))
		{
			return "[{\"id\":\"65082\",\"regionName\":\"大观区\"},{\"id\":\"65084\",\"regionName\":\"怀宁县\"},{\"id\":\"65083\",\"regionName\":\"郊　区\"},{\"id\":\"65086\",\"regionName\":\"潜山县\"},{\"id\":\"65088\",\"regionName\":\"宿松县\"},{\"id\":\"650811\",\"regionName\":\"桐城市\"},{\"id\":\"65087\",\"regionName\":\"太湖县\"},{\"id\":\"65089\",\"regionName\":\"望江县\"},{\"id\":\"650810\",\"regionName\":\"岳西县\"},{\"id\":\"65081\",\"regionName\":\"迎江区\"},{\"id\":\"65085\",\"regionName\":\"枞阳县\"}]";
		}
		else if("5549".equals(id))
		{
			return "[{\"id\":\"65154\",\"regionName\":\"利辛县\"},{\"id\":\"65153\",\"regionName\":\"蒙城县\"},{\"id\":\"65151\",\"regionName\":\"谯城区\"},{\"id\":\"65152\",\"regionName\":\"涡阳县\"}]";
		}
		else if("5537".equals(id))
		{
			return "[{\"id\":\"65032\",\"regionName\":\"蚌山区\"},{\"id\":\"65037\",\"regionName\":\"固镇县\"},{\"id\":\"65035\",\"regionName\":\"怀远县\"},{\"id\":\"65034\",\"regionName\":\"淮上区\"},{\"id\":\"65031\",\"regionName\":\"龙子湖区\"},{\"id\":\"65036\",\"regionName\":\"五河县\"},{\"id\":\"65033\",\"regionName\":\"禹会区\"}]";
		}
		else if("5550".equals(id))
		{
			return "[{\"id\":\"65162\",\"regionName\":\"东至县\"},{\"id\":\"65161\",\"regionName\":\"贵池区\"},{\"id\":\"65164\",\"regionName\":\"青阳县\"},{\"id\":\"65163\",\"regionName\":\"石台县\"}]";
		}
		else if("5547".equals(id))
		{
			return "[{\"id\":\"65135\",\"regionName\":\"和　县\"},{\"id\":\"65134\",\"regionName\":\"含山县\"},{\"id\":\"65131\",\"regionName\":\"居巢区\"},{\"id\":\"65132\",\"regionName\":\"庐江县\"},{\"id\":\"65133\",\"regionName\":\"无为县\"}]";
		}
		else if("5544".equals(id))
		{
			return "[{\"id\":\"65105\",\"regionName\":\"定远县\"},{\"id\":\"65106\",\"regionName\":\"凤阳县\"},{\"id\":\"65103\",\"regionName\":\"来安县\"},{\"id\":\"65101\",\"regionName\":\"琅琊区\"},{\"id\":\"65108\",\"regionName\":\"明光市\"},{\"id\":\"65102\",\"regionName\":\"南谯区\"},{\"id\":\"65104\",\"regionName\":\"全椒县\"},{\"id\":\"65107\",\"regionName\":\"天长市\"}]";
		}
		else if("5545".equals(id))
		{
			return "[{\"id\":\"65116\",\"regionName\":\"阜南县\"},{\"id\":\"65118\",\"regionName\":\"界首市\"},{\"id\":\"65114\",\"regionName\":\"临泉县\"},{\"id\":\"65115\",\"regionName\":\"太和县\"},{\"id\":\"65117\",\"regionName\":\"颍上县\"},{\"id\":\"65113\",\"regionName\":\"颍泉区\"},{\"id\":\"65112\",\"regionName\":\"颍东区\"},{\"id\":\"65111\",\"regionName\":\"颍州区\"}]";
		}
		else if("5543".equals(id))
		{
			return "[{\"id\":\"65093\",\"regionName\":\"徽州区\"},{\"id\":\"65092\",\"regionName\":\"黄山区\"},{\"id\":\"65097\",\"regionName\":\"祁门县\"},{\"id\":\"65094\",\"regionName\":\"歙　县\"},{\"id\":\"65091\",\"regionName\":\"屯溪区\"},{\"id\":\"65095\",\"regionName\":\"休宁县\"},{\"id\":\"65096\",\"regionName\":\"黟　县\"}]";
		}
		else if("5540".equals(id))
		{
			return "[{\"id\":\"65061\",\"regionName\":\"杜集区\"},{\"id\":\"65063\",\"regionName\":\"烈山区\"},{\"id\":\"65064\",\"regionName\":\"濉溪县\"},{\"id\":\"65062\",\"regionName\":\"相山区\"}]";
		}
		else if("5538".equals(id))
		{
			return "[{\"id\":\"65044\",\"regionName\":\"八公山区\"},{\"id\":\"65041\",\"regionName\":\"大通区\"},{\"id\":\"65046\",\"regionName\":\"凤台县\"},{\"id\":\"65045\",\"regionName\":\"潘集区\"},{\"id\":\"65042\",\"regionName\":\"田家庵区\"},{\"id\":\"65043\",\"regionName\":\"谢家集区\"}]";
		}
		else if("5535".equals(id))
		{
			return "[{\"id\":\"65014\",\"regionName\":\"包河区\"},{\"id\":\"65017\",\"regionName\":\"肥西县\"},{\"id\":\"65016\",\"regionName\":\"肥东县\"},{\"id\":\"65012\",\"regionName\":\"庐阳区\"},{\"id\":\"65013\",\"regionName\":\"蜀山区\"},{\"id\":\"65011\",\"regionName\":\"瑶海区\"},{\"id\":\"65015\",\"regionName\":\"长丰县\"}]";
		}
		else if("5548".equals(id))
		{
			return "[{\"id\":\"65147\",\"regionName\":\"霍山县\"},{\"id\":\"65144\",\"regionName\":\"霍邱县\"},{\"id\":\"65146\",\"regionName\":\"金寨县\"},{\"id\":\"65141\",\"regionName\":\"金安区\"},{\"id\":\"65145\",\"regionName\":\"舒城县\"},{\"id\":\"65143\",\"regionName\":\"寿　县\"},{\"id\":\"65142\",\"regionName\":\"裕安区\"}]";
		}
		else if("5539".equals(id))
		{
			return "[{\"id\":\"65054\",\"regionName\":\"当涂县\"},{\"id\":\"65052\",\"regionName\":\"花山区\"},{\"id\":\"65051\",\"regionName\":\"金家庄区\"},{\"id\":\"65053\",\"regionName\":\"雨山区\"}]";
		}
		else if("5546".equals(id))
		{
			return "[{\"id\":\"65122\",\"regionName\":\"砀山县\"},{\"id\":\"65124\",\"regionName\":\"灵璧县\"},{\"id\":\"65125\",\"regionName\":\"泗　县\"},{\"id\":\"65123\",\"regionName\":\"萧　县\"},{\"id\":\"65121\",\"regionName\":\"墉桥区\"}]";
		}
		else if("5541".equals(id))
		{
			return "[{\"id\":\"65073\",\"regionName\":\"郊　区\"},{\"id\":\"65072\",\"regionName\":\"狮子山区\"},{\"id\":\"65074\",\"regionName\":\"铜陵县\"},{\"id\":\"65071\",\"regionName\":\"铜官山区\"}]";
		}
		else if("5536".equals(id))
		{
			return "[{\"id\":\"65026\",\"regionName\":\"繁昌县\"},{\"id\":\"65024\",\"regionName\":\"鸠江区\"},{\"id\":\"65021\",\"regionName\":\"镜湖区\"},{\"id\":\"65022\",\"regionName\":\"马塘区\"},{\"id\":\"65027\",\"regionName\":\"南陵县\"},{\"id\":\"65025\",\"regionName\":\"芜湖县\"},{\"id\":\"65023\",\"regionName\":\"新芜区\"}]";
		}
		else if("5551".equals(id))
		{
			return "[{\"id\":\"65173\",\"regionName\":\"广德县\"},{\"id\":\"65176\",\"regionName\":\"旌德县\"},{\"id\":\"65175\",\"regionName\":\"绩溪县\"},{\"id\":\"65174\",\"regionName\":\"泾　县\"},{\"id\":\"65172\",\"regionName\":\"郎溪县\"},{\"id\":\"65177\",\"regionName\":\"宁国市\"},{\"id\":\"65171\",\"regionName\":\"宣州区\"}]";
		}
		else if("1".equals(id))
		{
			return "[{\"id\":\"47\",\"regionName\":\"昌平区\"},{\"id\":\"39\",\"regionName\":\"朝阳区\"},{\"id\":\"37\",\"regionName\":\"崇文区\"},{\"id\":\"48\",\"regionName\":\"大兴区\"},{\"id\":\"35\",\"regionName\":\"东城区\"},{\"id\":\"44\",\"regionName\":\"房山区\"},{\"id\":\"40\",\"regionName\":\"丰台区\"},{\"id\":\"49\",\"regionName\":\"怀柔区\"},{\"id\":\"42\",\"regionName\":\"海淀区\"},{\"id\":\"51\",\"regionName\":\"密云县\"},{\"id\":\"43\",\"regionName\":\"门头沟区\"},{\"id\":\"50\",\"regionName\":\"平谷区\"},{\"id\":\"46\",\"regionName\":\"顺义区\"},{\"id\":\"41\",\"regionName\":\"石景山区\"},{\"id\":\"45\",\"regionName\":\"通州区\"},{\"id\":\"38\",\"regionName\":\"宣武区\"},{\"id\":\"36\",\"regionName\":\"西城区\"},{\"id\":\"52\",\"regionName\":\"延庆县\"}]";
		}
		else if("47".equals(id))
		{
			return "[]";
		}
		else if("39".equals(id))
		{
			return "[]";
		}
		else if("37".equals(id))
		{
			return "[]";
		}
		else if("48".equals(id))
		{
			return "[]";
		}
		else if("35".equals(id))
		{
			return "[]";
		}
		else if("44".equals(id))
		{
			return "[]";
		}
		else if("40".equals(id))
		{
			return "[]";
		}
		else if("49".equals(id))
		{
			return "[]";
		}
		else if("42".equals(id))
		{
			return "[]";
		}
		else if("51".equals(id))
		{
			return "[]";
		}
		else if("43".equals(id))
		{
			return "[]";
		}
		else if("50".equals(id))
		{
			return "[]";
		}
		else if("46".equals(id))
		{
			return "[]";
		}
		else if("41".equals(id))
		{
			return "[]";
		}
		else if("45".equals(id))
		{
			return "[]";
		}
		else if("38".equals(id))
		{
			return "[]";
		}
		else if("36".equals(id))
		{
			return "[]";
		}
		else if("52".equals(id))
		{
			return "[]";
		}
		else if("13".equals(id))
		{
			return "[{\"id\":\"6035\",\"regionName\":\"福州市\"},{\"id\":\"6042\",\"regionName\":\"龙岩市\"},{\"id\":\"6043\",\"regionName\":\"宁德市\"},{\"id\":\"6041\",\"regionName\":\"南平市\"},{\"id\":\"6037\",\"regionName\":\"莆田市\"},{\"id\":\"6039\",\"regionName\":\"泉州市\"},{\"id\":\"6038\",\"regionName\":\"三明市\"},{\"id\":\"6036\",\"regionName\":\"厦门市\"},{\"id\":\"6040\",\"regionName\":\"漳州市\"}]";
		}
		else if("6035".equals(id))
		{
			return "[{\"id\":\"70013\",\"regionName\":\"仓山区\"},{\"id\":\"700112\",\"regionName\":\"福清市\"},{\"id\":\"70011\",\"regionName\":\"鼓楼区\"},{\"id\":\"70015\",\"regionName\":\"晋安区\"},{\"id\":\"70018\",\"regionName\":\"罗源县\"},{\"id\":\"70017\",\"regionName\":\"连江县\"},{\"id\":\"70019\",\"regionName\":\"闽清县\"},{\"id\":\"70016\",\"regionName\":\"闽侯县\"},{\"id\":\"70014\",\"regionName\":\"马尾区\"},{\"id\":\"700111\",\"regionName\":\"平潭县\"},{\"id\":\"70012\",\"regionName\":\"台江区\"},{\"id\":\"700110\",\"regionName\":\"永泰县\"},{\"id\":\"700113\",\"regionName\":\"长乐市\"}]";
		}
		else if("6042".equals(id))
		{
			return "[{\"id\":\"70086\",\"regionName\":\"连城县\"},{\"id\":\"70084\",\"regionName\":\"上杭县\"},{\"id\":\"70085\",\"regionName\":\"武平县\"},{\"id\":\"70081\",\"regionName\":\"新罗区\"},{\"id\":\"70083\",\"regionName\":\"永定县\"},{\"id\":\"70087\",\"regionName\":\"漳平市\"},{\"id\":\"70082\",\"regionName\":\"长汀县\"}]";
		}
		else if("6043".equals(id))
		{
			return "[{\"id\":\"70099\",\"regionName\":\"福鼎市\"},{\"id\":\"70098\",\"regionName\":\"福安市\"},{\"id\":\"70093\",\"regionName\":\"古田县\"},{\"id\":\"70091\",\"regionName\":\"蕉城区\"},{\"id\":\"70094\",\"regionName\":\"屏南县\"},{\"id\":\"70095\",\"regionName\":\"寿宁县\"},{\"id\":\"70092\",\"regionName\":\"霞浦县\"},{\"id\":\"70097\",\"regionName\":\"柘荣县\"},{\"id\":\"70096\",\"regionName\":\"周宁县\"}]";
		}
		else if("6041".equals(id))
		{
			return "[{\"id\":\"70074\",\"regionName\":\"光泽县\"},{\"id\":\"700710\",\"regionName\":\"建阳市\"},{\"id\":\"70079\",\"regionName\":\"建瓯市\"},{\"id\":\"70073\",\"regionName\":\"浦城县\"},{\"id\":\"70077\",\"regionName\":\"邵武市\"},{\"id\":\"70075\",\"regionName\":\"松溪县\"},{\"id\":\"70072\",\"regionName\":\"顺昌县\"},{\"id\":\"70078\",\"regionName\":\"武夷山市\"},{\"id\":\"70071\",\"regionName\":\"延平区\"},{\"id\":\"70076\",\"regionName\":\"政和县\"}]";
		}
		else if("6037".equals(id))
		{
			return "[{\"id\":\"70031\",\"regionName\":\"城厢区\"},{\"id\":\"70032\",\"regionName\":\"涵江区\"},{\"id\":\"70033\",\"regionName\":\"荔城区\"},{\"id\":\"70035\",\"regionName\":\"仙游县\"},{\"id\":\"70034\",\"regionName\":\"秀屿区\"}]";
		}
		else if("6039".equals(id))
		{
			return "[{\"id\":\"70056\",\"regionName\":\"安溪县\"},{\"id\":\"70058\",\"regionName\":\"德化县\"},{\"id\":\"70052\",\"regionName\":\"丰泽区\"},{\"id\":\"70055\",\"regionName\":\"惠安县\"},{\"id\":\"700511\",\"regionName\":\"晋江市\"},{\"id\":\"70059\",\"regionName\":\"金门县\"},{\"id\":\"70053\",\"regionName\":\"洛江区\"},{\"id\":\"70051\",\"regionName\":\"鲤城区\"},{\"id\":\"700512\",\"regionName\":\"南安市\"},{\"id\":\"70054\",\"regionName\":\"泉港区\"},{\"id\":\"700510\",\"regionName\":\"石狮市\"},{\"id\":\"70057\",\"regionName\":\"永春县\"}]";
		}
		else if("6038".equals(id))
		{
			return "[{\"id\":\"70046\",\"regionName\":\"大田县\"},{\"id\":\"700411\",\"regionName\":\"建宁县\"},{\"id\":\"70049\",\"regionName\":\"将乐县\"},{\"id\":\"70043\",\"regionName\":\"明溪县\"},{\"id\":\"70041\",\"regionName\":\"梅列区\"},{\"id\":\"70045\",\"regionName\":\"宁化县\"},{\"id\":\"70044\",\"regionName\":\"清流县\"},{\"id\":\"70048\",\"regionName\":\"沙　县\"},{\"id\":\"70042\",\"regionName\":\"三元区\"},{\"id\":\"700410\",\"regionName\":\"泰宁县\"},{\"id\":\"700412\",\"regionName\":\"永安市\"},{\"id\":\"70047\",\"regionName\":\"尤溪县\"}]";
		}
		else if("6036".equals(id))
		{
			return "[{\"id\":\"70023\",\"regionName\":\"湖里区\"},{\"id\":\"70022\",\"regionName\":\"海沧区\"},{\"id\":\"70024\",\"regionName\":\"集美区\"},{\"id\":\"70021\",\"regionName\":\"思明区\"},{\"id\":\"70025\",\"regionName\":\"同安区\"},{\"id\":\"70026\",\"regionName\":\"翔安区\"}]";
		}
		else if("6040".equals(id))
		{
			return "[{\"id\":\"70067\",\"regionName\":\"东山县\"},{\"id\":\"700610\",\"regionName\":\"华安县\"},{\"id\":\"700611\",\"regionName\":\"龙海市\"},{\"id\":\"70062\",\"regionName\":\"龙文区\"},{\"id\":\"70068\",\"regionName\":\"南靖县\"},{\"id\":\"70069\",\"regionName\":\"平和县\"},{\"id\":\"70061\",\"regionName\":\"芗城区\"},{\"id\":\"70063\",\"regionName\":\"云霄县\"},{\"id\":\"70066\",\"regionName\":\"长泰县\"},{\"id\":\"70065\",\"regionName\":\"诏安县\"},{\"id\":\"70064\",\"regionName\":\"漳浦县\"}]";
		}
		else if("28".equals(id))
		{
			return "[{\"id\":\"13538\",\"regionName\":\"白银市\"},{\"id\":\"13545\",\"regionName\":\"定西市\"},{\"id\":\"13548\",\"regionName\":\"甘南藏族自治州\"},{\"id\":\"13543\",\"regionName\":\"酒泉市\"},{\"id\":\"13537\",\"regionName\":\"金昌市\"},{\"id\":\"13536\",\"regionName\":\"嘉峪关市\"},{\"id\":\"13547\",\"regionName\":\"临夏回族自治州\"},{\"id\":\"13546\",\"regionName\":\"陇南市\"},{\"id\":\"13535\",\"regionName\":\"兰州市\"},{\"id\":\"13542\",\"regionName\":\"平凉市\"},{\"id\":\"13544\",\"regionName\":\"庆阳市\"},{\"id\":\"13539\",\"regionName\":\"天水市\"},{\"id\":\"13540\",\"regionName\":\"武威市\"},{\"id\":\"13541\",\"regionName\":\"张掖市\"}]";
		}
		else if("13538".equals(id))
		{
			return "[{\"id\":\"145041\",\"regionName\":\"白银区\"},{\"id\":\"145044\",\"regionName\":\"会宁县\"},{\"id\":\"145045\",\"regionName\":\"景泰县\"},{\"id\":\"145043\",\"regionName\":\"靖远县\"},{\"id\":\"145042\",\"regionName\":\"平川区\"}]";
		}
		else if("13545".equals(id))
		{
			return "[{\"id\":\"145111\",\"regionName\":\"安定区\"},{\"id\":\"145115\",\"regionName\":\"临洮县\"},{\"id\":\"145113\",\"regionName\":\"陇西县\"},{\"id\":\"145117\",\"regionName\":\"岷　县\"},{\"id\":\"145112\",\"regionName\":\"通渭县\"},{\"id\":\"145114\",\"regionName\":\"渭源县\"},{\"id\":\"145116\",\"regionName\":\"漳　县\"}]";
		}
		else if("13548".equals(id))
		{
			return "[{\"id\":\"145145\",\"regionName\":\"迭部县\"},{\"id\":\"145141\",\"regionName\":\"合作市\"},{\"id\":\"145147\",\"regionName\":\"碌曲县\"},{\"id\":\"145142\",\"regionName\":\"临潭县\"},{\"id\":\"145146\",\"regionName\":\"玛曲县\"},{\"id\":\"145148\",\"regionName\":\"夏河县\"},{\"id\":\"145144\",\"regionName\":\"舟曲县\"},{\"id\":\"145143\",\"regionName\":\"卓尼县\"}]";
		}
		else if("13543".equals(id))
		{
			return "[{\"id\":\"145095\",\"regionName\":\"阿克塞哈萨克族自治县\"},{\"id\":\"145093\",\"regionName\":\"安西县\"},{\"id\":\"145097\",\"regionName\":\"敦煌市\"},{\"id\":\"145092\",\"regionName\":\"金塔县\"},{\"id\":\"145094\",\"regionName\":\"肃北蒙古族自治县\"},{\"id\":\"145091\",\"regionName\":\"肃州区\"},{\"id\":\"145096\",\"regionName\":\"玉门市\"}]";
		}
		else if("13537".equals(id))
		{
			return "[{\"id\":\"145031\",\"regionName\":\"金川区\"},{\"id\":\"145032\",\"regionName\":\"永昌县\"}]";
		}
		else if("13536".equals(id))
		{
			return "[]";
		}
		else if("13547".equals(id))
		{
			return "[{\"id\":\"145137\",\"regionName\":\"东乡族自治县\"},{\"id\":\"145135\",\"regionName\":\"广河县\"},{\"id\":\"145136\",\"regionName\":\"和政县\"},{\"id\":\"145138\",\"regionName\":\"积石山保安族东乡族撒拉族自治县\"},{\"id\":\"145133\",\"regionName\":\"康乐县\"},{\"id\":\"145132\",\"regionName\":\"临夏县\"},{\"id\":\"145131\",\"regionName\":\"临夏市\"},{\"id\":\"145134\",\"regionName\":\"永靖县\"}]";
		}
		else if("13546".equals(id))
		{
			return "[{\"id\":\"145122\",\"regionName\":\"成　县\"},{\"id\":\"145124\",\"regionName\":\"宕昌县\"},{\"id\":\"145128\",\"regionName\":\"徽　县\"},{\"id\":\"145125\",\"regionName\":\"康　县\"},{\"id\":\"145129\",\"regionName\":\"两当县\"},{\"id\":\"145127\",\"regionName\":\"礼　县\"},{\"id\":\"145123\",\"regionName\":\"文　县\"},{\"id\":\"145121\",\"regionName\":\"武都区\"},{\"id\":\"145126\",\"regionName\":\"西和县\"}]";
		}
		else if("13535".equals(id))
		{
			return "[{\"id\":\"145014\",\"regionName\":\"安宁区\"},{\"id\":\"145011\",\"regionName\":\"城关区\"},{\"id\":\"145017\",\"regionName\":\"皋兰县\"},{\"id\":\"145015\",\"regionName\":\"红古区\"},{\"id\":\"145012\",\"regionName\":\"七里河区\"},{\"id\":\"145013\",\"regionName\":\"西固区\"},{\"id\":\"145018\",\"regionName\":\"榆中县\"},{\"id\":\"145016\",\"regionName\":\"永登县\"}]";
		}
		else if("13542".equals(id))
		{
			return "[{\"id\":\"145084\",\"regionName\":\"崇信县\"},{\"id\":\"145085\",\"regionName\":\"华亭县\"},{\"id\":\"145087\",\"regionName\":\"静宁县\"},{\"id\":\"145082\",\"regionName\":\"泾川县\"},{\"id\":\"145081\",\"regionName\":\"崆峒区\"},{\"id\":\"145083\",\"regionName\":\"灵台县\"},{\"id\":\"145086\",\"regionName\":\"庄浪县\"}]";
		}
		else if("13544".equals(id))
		{
			return "[{\"id\":\"145105\",\"regionName\":\"合水县\"},{\"id\":\"145104\",\"regionName\":\"华池县\"},{\"id\":\"145103\",\"regionName\":\"环　县\"},{\"id\":\"145107\",\"regionName\":\"宁　县\"},{\"id\":\"145102\",\"regionName\":\"庆城县\"},{\"id\":\"145101\",\"regionName\":\"西峰区\"},{\"id\":\"145108\",\"regionName\":\"镇原县\"},{\"id\":\"145106\",\"regionName\":\"正宁县\"}]";
		}
		else if("13539".equals(id))
		{
			return "[{\"id\":\"145052\",\"regionName\":\"北道区\"},{\"id\":\"145055\",\"regionName\":\"甘谷县\"},{\"id\":\"145054\",\"regionName\":\"秦安县\"},{\"id\":\"145053\",\"regionName\":\"清水县\"},{\"id\":\"145051\",\"regionName\":\"秦城区\"},{\"id\":\"145056\",\"regionName\":\"武山县\"},{\"id\":\"145057\",\"regionName\":\"张家川回族自治县\"}]";
		}
		else if("13540".equals(id))
		{
			return "[{\"id\":\"145063\",\"regionName\":\"古浪县\"},{\"id\":\"145061\",\"regionName\":\"凉州区\"},{\"id\":\"145062\",\"regionName\":\"民勤县\"},{\"id\":\"145064\",\"regionName\":\"天祝藏族自治县\"}]";
		}
		else if("13541".equals(id))
		{
			return "[{\"id\":\"145075\",\"regionName\":\"高台县\"},{\"id\":\"145071\",\"regionName\":\"甘州区\"},{\"id\":\"145074\",\"regionName\":\"临泽县\"},{\"id\":\"145073\",\"regionName\":\"民乐县\"},{\"id\":\"145076\",\"regionName\":\"山丹县\"},{\"id\":\"145072\",\"regionName\":\"肃南裕固族自治县\"}]";
		}
		else if("24".equals(id))
		{
			return "[{\"id\":\"11538\",\"regionName\":\"安顺市\"},{\"id\":\"11541\",\"regionName\":\"毕节地区\"},{\"id\":\"11535\",\"regionName\":\"贵阳市\"},{\"id\":\"11536\",\"regionName\":\"六盘水市\"},{\"id\":\"11543\",\"regionName\":\"黔南布依族苗族自治州\"},{\"id\":\"11542\",\"regionName\":\"黔东南苗族侗族自治州\"},{\"id\":\"11540\",\"regionName\":\"黔西南布依族苗族自治州\"},{\"id\":\"11539\",\"regionName\":\"铜仁地区\"},{\"id\":\"11537\",\"regionName\":\"遵义市\"}]";
		}
		else if("11538".equals(id))
		{
			return "[{\"id\":\"125045\",\"regionName\":\"关岭布依族苗族自治县\"},{\"id\":\"125043\",\"regionName\":\"普定县\"},{\"id\":\"125042\",\"regionName\":\"平坝县\"},{\"id\":\"125041\",\"regionName\":\"西秀区\"},{\"id\":\"125046\",\"regionName\":\"紫云苗族布依族自治县\"},{\"id\":\"125044\",\"regionName\":\"镇宁布依族苗族自治县\"}]";
		}
		else if("11541".equals(id))
		{
			return "[{\"id\":\"125071\",\"regionName\":\"毕节市\"},{\"id\":\"125072\",\"regionName\":\"大方县\"},{\"id\":\"125078\",\"regionName\":\"赫章县\"},{\"id\":\"125074\",\"regionName\":\"金沙县\"},{\"id\":\"125076\",\"regionName\":\"纳雍县\"},{\"id\":\"125073\",\"regionName\":\"黔西县\"},{\"id\":\"125077\",\"regionName\":\"威宁彝族回族苗族自治县\"},{\"id\":\"125075\",\"regionName\":\"织金县\"}]";
		}
		else if("11535".equals(id))
		{
			return "[{\"id\":\"125015\",\"regionName\":\"白云区\"},{\"id\":\"125013\",\"regionName\":\"花溪区\"},{\"id\":\"125017\",\"regionName\":\"开阳县\"},{\"id\":\"125011\",\"regionName\":\"南明区\"},{\"id\":\"1250110\",\"regionName\":\"清镇市\"},{\"id\":\"125014\",\"regionName\":\"乌当区\"},{\"id\":\"125019\",\"regionName\":\"修文县\"},{\"id\":\"125018\",\"regionName\":\"息烽县\"},{\"id\":\"125016\",\"regionName\":\"小河区\"},{\"id\":\"125012\",\"regionName\":\"云岩区\"}]";
		}
		else if("11536".equals(id))
		{
			return "[{\"id\":\"125022\",\"regionName\":\"六枝特区\"},{\"id\":\"125024\",\"regionName\":\"盘　县\"},{\"id\":\"125023\",\"regionName\":\"水城县\"},{\"id\":\"125021\",\"regionName\":\"钟山区\"}]";
		}
		else if("11543".equals(id))
		{
			return "[{\"id\":\"125096\",\"regionName\":\"独山县\"},{\"id\":\"125091\",\"regionName\":\"都匀市\"},{\"id\":\"125092\",\"regionName\":\"福泉市\"},{\"id\":\"125094\",\"regionName\":\"贵定县\"},{\"id\":\"1250911\",\"regionName\":\"惠水县\"},{\"id\":\"1250910\",\"regionName\":\"龙里县\"},{\"id\":\"125098\",\"regionName\":\"罗甸县\"},{\"id\":\"125093\",\"regionName\":\"荔波县\"},{\"id\":\"125097\",\"regionName\":\"平塘县\"},{\"id\":\"1250912\",\"regionName\":\"三都水族自治县\"},{\"id\":\"125095\",\"regionName\":\"瓮安县\"},{\"id\":\"125099\",\"regionName\":\"长顺县\"}]";
		}
		else if("11542".equals(id))
		{
			return "[{\"id\":\"1250813\",\"regionName\":\"从江县\"},{\"id\":\"125086\",\"regionName\":\"岑巩县\"},{\"id\":\"125082\",\"regionName\":\"黄平县\"},{\"id\":\"125089\",\"regionName\":\"剑河县\"},{\"id\":\"125088\",\"regionName\":\"锦屏县\"},{\"id\":\"125081\",\"regionName\":\"凯里市\"},{\"id\":\"1250814\",\"regionName\":\"雷山县\"},{\"id\":\"1250811\",\"regionName\":\"黎平县\"},{\"id\":\"1250815\",\"regionName\":\"麻江县\"},{\"id\":\"1250812\",\"regionName\":\"榕江县\"},{\"id\":\"125084\",\"regionName\":\"三穗县\"},{\"id\":\"125083\",\"regionName\":\"施秉县\"},{\"id\":\"1250810\",\"regionName\":\"台江县\"},{\"id\":\"125087\",\"regionName\":\"天柱县\"},{\"id\":\"125085\",\"regionName\":\"镇远县\"}]";
		}
		else if("11540".equals(id))
		{
			return "[{\"id\":\"125068\",\"regionName\":\"安龙县\"},{\"id\":\"125067\",\"regionName\":\"册亨县\"},{\"id\":\"125063\",\"regionName\":\"普安县\"},{\"id\":\"125064\",\"regionName\":\"晴隆县\"},{\"id\":\"125066\",\"regionName\":\"望谟县\"},{\"id\":\"125062\",\"regionName\":\"兴仁县\"},{\"id\":\"125061\",\"regionName\":\"兴义市\"},{\"id\":\"125065\",\"regionName\":\"贞丰县\"}]";
		}
		else if("11539".equals(id))
		{
			return "[{\"id\":\"125057\",\"regionName\":\"德江县\"},{\"id\":\"125052\",\"regionName\":\"江口县\"},{\"id\":\"125059\",\"regionName\":\"松桃苗族自治县\"},{\"id\":\"125055\",\"regionName\":\"思南县\"},{\"id\":\"125054\",\"regionName\":\"石阡县\"},{\"id\":\"125051\",\"regionName\":\"铜仁市\"},{\"id\":\"1250510\",\"regionName\":\"万山特区\"},{\"id\":\"125058\",\"regionName\":\"沿河土家族自治县\"},{\"id\":\"125056\",\"regionName\":\"印江土家族苗族自治县\"},{\"id\":\"125053\",\"regionName\":\"玉屏侗族自治县\"}]";
		}
		else if("11537".equals(id))
		{
			return "[{\"id\":\"1250313\",\"regionName\":\"赤水市\"},{\"id\":\"125037\",\"regionName\":\"道真仡佬族苗族自治县\"},{\"id\":\"125039\",\"regionName\":\"凤冈县\"},{\"id\":\"125032\",\"regionName\":\"汇川区\"},{\"id\":\"125031\",\"regionName\":\"红花岗区\"},{\"id\":\"1250310\",\"regionName\":\"湄潭县\"},{\"id\":\"1250314\",\"regionName\":\"仁怀市\"},{\"id\":\"125035\",\"regionName\":\"绥阳县\"},{\"id\":\"125034\",\"regionName\":\"桐梓县\"},{\"id\":\"125038\",\"regionName\":\"务川仡佬族苗族自治县\"},{\"id\":\"1250312\",\"regionName\":\"习水县\"},{\"id\":\"1250311\",\"regionName\":\"余庆县\"},{\"id\":\"125036\",\"regionName\":\"正安县\"},{\"id\":\"125033\",\"regionName\":\"遵义县\"}]";
		}
		else if("20".equals(id))
		{
			return "[{\"id\":\"9544\",\"regionName\":\"百色市\"},{\"id\":\"9539\",\"regionName\":\"北海市\"},{\"id\":\"9548\",\"regionName\":\"崇左市\"},{\"id\":\"9540\",\"regionName\":\"防城港市\"},{\"id\":\"9542\",\"regionName\":\"贵港市\"},{\"id\":\"9537\",\"regionName\":\"桂林市\"},{\"id\":\"9546\",\"regionName\":\"河池市\"},{\"id\":\"9545\",\"regionName\":\"贺州市\"},{\"id\":\"9547\",\"regionName\":\"来宾市\"},{\"id\":\"9536\",\"regionName\":\"柳州市\"},{\"id\":\"9535\",\"regionName\":\"南宁市\"},{\"id\":\"9541\",\"regionName\":\"钦州市\"},{\"id\":\"9538\",\"regionName\":\"梧州市\"},{\"id\":\"9543\",\"regionName\":\"玉林市\"}]";
		}
		else if("9544".equals(id))
		{
			return "[{\"id\":\"105105\",\"regionName\":\"德保县\"},{\"id\":\"105106\",\"regionName\":\"靖西县\"},{\"id\":\"1051012\",\"regionName\":\"隆林各族自治县\"},{\"id\":\"105109\",\"regionName\":\"乐业县\"},{\"id\":\"105108\",\"regionName\":\"凌云县\"},{\"id\":\"105107\",\"regionName\":\"那坡县\"},{\"id\":\"105104\",\"regionName\":\"平果县\"},{\"id\":\"1051010\",\"regionName\":\"田林县\"},{\"id\":\"105103\",\"regionName\":\"田东县\"},{\"id\":\"105102\",\"regionName\":\"田阳县\"},{\"id\":\"1051011\",\"regionName\":\"西林县\"},{\"id\":\"105101\",\"regionName\":\"右江区\"}]";
		}
		else if("9539".equals(id))
		{
			return "[{\"id\":\"105054\",\"regionName\":\"合浦县\"},{\"id\":\"105051\",\"regionName\":\"海城区\"},{\"id\":\"105053\",\"regionName\":\"铁山港区\"},{\"id\":\"105052\",\"regionName\":\"银海区\"}]";
		}
		else if("9548".equals(id))
		{
			return "[{\"id\":\"105145\",\"regionName\":\"大新县\"},{\"id\":\"105142\",\"regionName\":\"扶绥县\"},{\"id\":\"105141\",\"regionName\":\"江洲区\"},{\"id\":\"105144\",\"regionName\":\"龙州县\"},{\"id\":\"105143\",\"regionName\":\"宁明县\"},{\"id\":\"105147\",\"regionName\":\"凭祥市\"},{\"id\":\"105146\",\"regionName\":\"天等县\"}]";
		}
		else if("9540".equals(id))
		{
			return "[{\"id\":\"105064\",\"regionName\":\"东兴市\"},{\"id\":\"105062\",\"regionName\":\"防城区\"},{\"id\":\"105061\",\"regionName\":\"港口区\"},{\"id\":\"105063\",\"regionName\":\"上思县\"}]";
		}
		else if("9542".equals(id))
		{
			return "[{\"id\":\"105085\",\"regionName\":\"桂平市\"},{\"id\":\"105082\",\"regionName\":\"港南区\"},{\"id\":\"105081\",\"regionName\":\"港北区\"},{\"id\":\"105084\",\"regionName\":\"平南县\"},{\"id\":\"105083\",\"regionName\":\"覃塘区\"}]";
		}
		else if("9537".equals(id))
		{
			return "[{\"id\":\"105032\",\"regionName\":\"叠彩区\"},{\"id\":\"1050317\",\"regionName\":\"恭城瑶族自治县\"},{\"id\":\"1050312\",\"regionName\":\"灌阳县\"},{\"id\":\"1050316\",\"regionName\":\"荔蒲县\"},{\"id\":\"1050313\",\"regionName\":\"龙胜各族自治县\"},{\"id\":\"105038\",\"regionName\":\"灵川县\"},{\"id\":\"105037\",\"regionName\":\"临桂县\"},{\"id\":\"1050315\",\"regionName\":\"平乐县\"},{\"id\":\"105039\",\"regionName\":\"全州县\"},{\"id\":\"105034\",\"regionName\":\"七星区\"},{\"id\":\"1050310\",\"regionName\":\"兴安县\"},{\"id\":\"105033\",\"regionName\":\"象山区\"},{\"id\":\"105031\",\"regionName\":\"秀峰区\"},{\"id\":\"1050311\",\"regionName\":\"永福县\"},{\"id\":\"105036\",\"regionName\":\"阳朔县\"},{\"id\":\"105035\",\"regionName\":\"雁山区\"},{\"id\":\"1050314\",\"regionName\":\"资源县\"}]";
		}
		else if("9546".equals(id))
		{
			return "[{\"id\":\"105128\",\"regionName\":\"巴马瑶族自治县\"},{\"id\":\"1051210\",\"regionName\":\"大化瑶族自治县\"},{\"id\":\"105129\",\"regionName\":\"都安瑶族自治县\"},{\"id\":\"105125\",\"regionName\":\"东兰县\"},{\"id\":\"105124\",\"regionName\":\"凤山县\"},{\"id\":\"105127\",\"regionName\":\"环江毛南族自治县\"},{\"id\":\"105121\",\"regionName\":\"金城江区\"},{\"id\":\"105126\",\"regionName\":\"罗城仫佬族自治县\"},{\"id\":\"105122\",\"regionName\":\"南丹县\"},{\"id\":\"105123\",\"regionName\":\"天峨县\"},{\"id\":\"1051211\",\"regionName\":\"宜州市\"}]";
		}
		else if("9545".equals(id))
		{
			return "[{\"id\":\"105111\",\"regionName\":\"八步区\"},{\"id\":\"105114\",\"regionName\":\"富川瑶族自治县\"},{\"id\":\"105113\",\"regionName\":\"钟山县\"},{\"id\":\"105112\",\"regionName\":\"昭平县\"}]";
		}
		else if("9547".equals(id))
		{
			return "[{\"id\":\"105136\",\"regionName\":\"合山市\"},{\"id\":\"105135\",\"regionName\":\"金秀瑶族自治县\"},{\"id\":\"105134\",\"regionName\":\"武宣县\"},{\"id\":\"105133\",\"regionName\":\"象州县\"},{\"id\":\"105132\",\"regionName\":\"忻城县\"},{\"id\":\"105131\",\"regionName\":\"兴宾区\"}]";
		}
		else if("9536".equals(id))
		{
			return "[{\"id\":\"105021\",\"regionName\":\"城中区\"},{\"id\":\"105027\",\"regionName\":\"鹿寨县\"},{\"id\":\"105026\",\"regionName\":\"柳城县\"},{\"id\":\"105025\",\"regionName\":\"柳江县\"},{\"id\":\"105024\",\"regionName\":\"柳北区\"},{\"id\":\"105023\",\"regionName\":\"柳南区\"},{\"id\":\"105029\",\"regionName\":\"融水苗族自治县\"},{\"id\":\"105028\",\"regionName\":\"融安县\"},{\"id\":\"1050210\",\"regionName\":\"三江侗族自治县\"},{\"id\":\"105022\",\"regionName\":\"鱼峰区\"}]";
		}
		else if("9535".equals(id))
		{
			return "[{\"id\":\"1050111\",\"regionName\":\"宾阳县\"},{\"id\":\"1050112\",\"regionName\":\"横　县\"},{\"id\":\"105013\",\"regionName\":\"江南区\"},{\"id\":\"105018\",\"regionName\":\"隆安县\"},{\"id\":\"105015\",\"regionName\":\"良庆区\"},{\"id\":\"105019\",\"regionName\":\"马山县\"},{\"id\":\"105012\",\"regionName\":\"青秀区\"},{\"id\":\"1050110\",\"regionName\":\"上林县\"},{\"id\":\"105017\",\"regionName\":\"武鸣县\"},{\"id\":\"105014\",\"regionName\":\"西乡塘区\"},{\"id\":\"105011\",\"regionName\":\"兴宁区\"},{\"id\":\"105016\",\"regionName\":\"邕宁区\"}]";
		}
		else if("9541".equals(id))
		{
			return "[{\"id\":\"105073\",\"regionName\":\"灵山县\"},{\"id\":\"105074\",\"regionName\":\"浦北县\"},{\"id\":\"105072\",\"regionName\":\"钦北区\"},{\"id\":\"105071\",\"regionName\":\"钦南区\"}]";
		}
		else if("9538".equals(id))
		{
			return "[{\"id\":\"105047\",\"regionName\":\"岑溪市\"},{\"id\":\"105044\",\"regionName\":\"苍梧县\"},{\"id\":\"105042\",\"regionName\":\"蝶山区\"},{\"id\":\"105046\",\"regionName\":\"蒙山县\"},{\"id\":\"105045\",\"regionName\":\"藤　县\"},{\"id\":\"105041\",\"regionName\":\"万秀区\"},{\"id\":\"105043\",\"regionName\":\"长洲区\"}]";
		}
		else if("9543".equals(id))
		{
			return "[{\"id\":\"105096\",\"regionName\":\"北流市\"},{\"id\":\"105094\",\"regionName\":\"博白县\"},{\"id\":\"105093\",\"regionName\":\"陆川县\"},{\"id\":\"105092\",\"regionName\":\"容　县\"},{\"id\":\"105095\",\"regionName\":\"兴业县\"},{\"id\":\"105091\",\"regionName\":\"玉州区\"}]";
		}
		else if("19".equals(id))
		{
			return "[{\"id\":\"9053\",\"regionName\":\"潮州市\"},{\"id\":\"9051\",\"regionName\":\"东莞市\"},{\"id\":\"9040\",\"regionName\":\"佛山市\"},{\"id\":\"9035\",\"regionName\":\"广州市\"},{\"id\":\"9048\",\"regionName\":\"河源市\"},{\"id\":\"9045\",\"regionName\":\"惠州市\"},{\"id\":\"9054\",\"regionName\":\"揭阳市\"},{\"id\":\"9041\",\"regionName\":\"江门市\"},{\"id\":\"9046\",\"regionName\":\"梅州市\"},{\"id\":\"9043\",\"regionName\":\"茂名市\"},{\"id\":\"9050\",\"regionName\":\"清远市\"},{\"id\":\"9047\",\"regionName\":\"汕尾市\"},{\"id\":\"9039\",\"regionName\":\"汕头市\"},{\"id\":\"9037\",\"regionName\":\"深圳市\"},{\"id\":\"9036\",\"regionName\":\"韶关市\"},{\"id\":\"9055\",\"regionName\":\"云浮市\"},{\"id\":\"9049\",\"regionName\":\"阳江市\"},{\"id\":\"9052\",\"regionName\":\"中山市\"},{\"id\":\"9044\",\"regionName\":\"肇庆市\"},{\"id\":\"9042\",\"regionName\":\"湛江市\"},{\"id\":\"9038\",\"regionName\":\"珠海市\"}]";
		}
		else if("9053".equals(id))
		{
			return "[{\"id\":\"100191\",\"regionName\":\"潮安县\"},{\"id\":\"100192\",\"regionName\":\"饶平县\"}]";
		}
		else if("9051".equals(id))
		{
			return "[]";
		}
		else if("9040".equals(id))
		{
			return "[{\"id\":\"100065\",\"regionName\":\"高明区\"},{\"id\":\"100062\",\"regionName\":\"南海区\"},{\"id\":\"100064\",\"regionName\":\"三水区\"},{\"id\":\"100063\",\"regionName\":\"顺德区\"},{\"id\":\"100061\",\"regionName\":\"禅城区\"}]";
		}
		else if("9035".equals(id))
		{
			return "[{\"id\":\"100017\",\"regionName\":\"白云区\"},{\"id\":\"1000112\",\"regionName\":\"从化市\"},{\"id\":\"100011\",\"regionName\":\"东山区\"},{\"id\":\"100019\",\"regionName\":\"番禺区\"},{\"id\":\"100016\",\"regionName\":\"芳村区\"},{\"id\":\"1000110\",\"regionName\":\"花都区\"},{\"id\":\"100018\",\"regionName\":\"黄埔区\"},{\"id\":\"100014\",\"regionName\":\"海珠区\"},{\"id\":\"100012\",\"regionName\":\"荔湾区\"},{\"id\":\"100015\",\"regionName\":\"天河区\"},{\"id\":\"100013\",\"regionName\":\"越秀区\"},{\"id\":\"1000111\",\"regionName\":\"增城市\"}]";
		}
		else if("9048".equals(id))
		{
			return "[{\"id\":\"100146\",\"regionName\":\"东源县\"},{\"id\":\"100145\",\"regionName\":\"和平县\"},{\"id\":\"100144\",\"regionName\":\"连平县\"},{\"id\":\"100143\",\"regionName\":\"龙川县\"},{\"id\":\"100141\",\"regionName\":\"源城区\"},{\"id\":\"100142\",\"regionName\":\"紫金县\"}]";
		}
		else if("9045".equals(id))
		{
			return "[{\"id\":\"100113\",\"regionName\":\"博罗县\"},{\"id\":\"100114\",\"regionName\":\"惠东县\"},{\"id\":\"100112\",\"regionName\":\"惠阳区\"},{\"id\":\"100111\",\"regionName\":\"惠城区\"},{\"id\":\"100115\",\"regionName\":\"龙门县\"}]";
		}
		else if("9054".equals(id))
		{
			return "[{\"id\":\"100204\",\"regionName\":\"惠来县\"},{\"id\":\"100203\",\"regionName\":\"揭西县\"},{\"id\":\"100202\",\"regionName\":\"揭东县\"},{\"id\":\"100205\",\"regionName\":\"普宁市\"},{\"id\":\"100201\",\"regionName\":\"榕城区\"}]";
		}
		else if("9041".equals(id))
		{
			return "[{\"id\":\"100077\",\"regionName\":\"恩平市\"},{\"id\":\"100076\",\"regionName\":\"鹤山市\"},{\"id\":\"100072\",\"regionName\":\"江海区\"},{\"id\":\"100075\",\"regionName\":\"开平市\"},{\"id\":\"100071\",\"regionName\":\"蓬江区\"},{\"id\":\"100074\",\"regionName\":\"台山市\"},{\"id\":\"100073\",\"regionName\":\"新会区\"}]";
		}
		else if("9046".equals(id))
		{
			return "[{\"id\":\"100123\",\"regionName\":\"大埔县\"},{\"id\":\"100124\",\"regionName\":\"丰顺县\"},{\"id\":\"100127\",\"regionName\":\"蕉岭县\"},{\"id\":\"100122\",\"regionName\":\"梅　县\"},{\"id\":\"100121\",\"regionName\":\"梅江区\"},{\"id\":\"100126\",\"regionName\":\"平远县\"},{\"id\":\"100125\",\"regionName\":\"五华县\"},{\"id\":\"100128\",\"regionName\":\"兴宁市\"}]";
		}
		else if("9043".equals(id))
		{
			return "[{\"id\":\"100093\",\"regionName\":\"电白县\"},{\"id\":\"100094\",\"regionName\":\"高州市\"},{\"id\":\"100095\",\"regionName\":\"化州市\"},{\"id\":\"100092\",\"regionName\":\"茂港区\"},{\"id\":\"100091\",\"regionName\":\"茂南区\"},{\"id\":\"100096\",\"regionName\":\"信宜市\"}]";
		}
		else if("9050".equals(id))
		{
			return "[{\"id\":\"100162\",\"regionName\":\"佛冈县\"},{\"id\":\"100168\",\"regionName\":\"连州市\"},{\"id\":\"100165\",\"regionName\":\"连南瑶族自治县\"},{\"id\":\"100164\",\"regionName\":\"连山壮族瑶族自治县\"},{\"id\":\"100166\",\"regionName\":\"清新县\"},{\"id\":\"100161\",\"regionName\":\"清城区\"},{\"id\":\"100167\",\"regionName\":\"英德市\"},{\"id\":\"100163\",\"regionName\":\"阳山县\"}]";
		}
		else if("9047".equals(id))
		{
			return "[{\"id\":\"100131\",\"regionName\":\"城　区\"},{\"id\":\"100132\",\"regionName\":\"海丰县\"},{\"id\":\"100134\",\"regionName\":\"陆丰市\"},{\"id\":\"100133\",\"regionName\":\"陆河县\"}]";
		}
		else if("9039".equals(id))
		{
			return "[{\"id\":\"100056\",\"regionName\":\"澄海区\"},{\"id\":\"100055\",\"regionName\":\"潮南区\"},{\"id\":\"100054\",\"regionName\":\"潮阳区\"},{\"id\":\"100053\",\"regionName\":\"濠江区\"},{\"id\":\"100052\",\"regionName\":\"金平区\"},{\"id\":\"100051\",\"regionName\":\"龙湖区\"},{\"id\":\"100057\",\"regionName\":\"南澳县\"}]";
		}
		else if("9037".equals(id))
		{
			return "[{\"id\":\"100034\",\"regionName\":\"宝安区\"},{\"id\":\"100032\",\"regionName\":\"福田区\"},{\"id\":\"100035\",\"regionName\":\"龙岗区\"},{\"id\":\"100031\",\"regionName\":\"罗湖区\"},{\"id\":\"100033\",\"regionName\":\"南山区\"},{\"id\":\"100036\",\"regionName\":\"盐田区\"}]";
		}
		else if("9036".equals(id))
		{
			return "[{\"id\":\"100029\",\"regionName\":\"乐昌市\"},{\"id\":\"1000210\",\"regionName\":\"南雄市\"},{\"id\":\"100023\",\"regionName\":\"曲江区\"},{\"id\":\"100027\",\"regionName\":\"乳源瑶族自治县\"},{\"id\":\"100025\",\"regionName\":\"仁化县\"},{\"id\":\"100024\",\"regionName\":\"始兴县\"},{\"id\":\"100026\",\"regionName\":\"翁源县\"},{\"id\":\"100021\",\"regionName\":\"武江区\"},{\"id\":\"100028\",\"regionName\":\"新丰县\"},{\"id\":\"100022\",\"regionName\":\"浈江区\"}]";
		}
		else if("9055".equals(id))
		{
			return "[{\"id\":\"100215\",\"regionName\":\"罗定市\"},{\"id\":\"100212\",\"regionName\":\"新兴县\"},{\"id\":\"100214\",\"regionName\":\"云安县\"},{\"id\":\"100213\",\"regionName\":\"郁南县\"},{\"id\":\"100211\",\"regionName\":\"云城区\"}]";
		}
		else if("9049".equals(id))
		{
			return "[{\"id\":\"100151\",\"regionName\":\"江城区\"},{\"id\":\"100154\",\"regionName\":\"阳春市\"},{\"id\":\"100153\",\"regionName\":\"阳东县\"},{\"id\":\"100152\",\"regionName\":\"阳西县\"}]";
		}
		else if("9052".equals(id))
		{
			return "[]";
		}
		else if("9044".equals(id))
		{
			return "[{\"id\":\"100106\",\"regionName\":\"德庆县\"},{\"id\":\"100102\",\"regionName\":\"鼎湖区\"},{\"id\":\"100101\",\"regionName\":\"端州区\"},{\"id\":\"100105\",\"regionName\":\"封开县\"},{\"id\":\"100107\",\"regionName\":\"高要市\"},{\"id\":\"100103\",\"regionName\":\"广宁县\"},{\"id\":\"100104\",\"regionName\":\"怀集县\"},{\"id\":\"100108\",\"regionName\":\"四会市\"}]";
		}
		else if("9042".equals(id))
		{
			return "[{\"id\":\"100081\",\"regionName\":\"赤坎区\"},{\"id\":\"100088\",\"regionName\":\"雷州市\"},{\"id\":\"100087\",\"regionName\":\"廉江市\"},{\"id\":\"100084\",\"regionName\":\"麻章区\"},{\"id\":\"100083\",\"regionName\":\"坡头区\"},{\"id\":\"100085\",\"regionName\":\"遂溪县\"},{\"id\":\"100089\",\"regionName\":\"吴川市\"},{\"id\":\"100086\",\"regionName\":\"徐闻县\"},{\"id\":\"100082\",\"regionName\":\"霞山区\"}]";
		}
		else if("9038".equals(id))
		{
			return "[{\"id\":\"100042\",\"regionName\":\"斗门区\"},{\"id\":\"100043\",\"regionName\":\"金湾区\"},{\"id\":\"100041\",\"regionName\":\"洲区\"}]";
		}
		else if("21".equals(id))
		{
			return "[{\"id\":\"10035\",\"regionName\":\"海口市\"},{\"id\":\"10037\",\"regionName\":\"省直辖县级行政单位\"},{\"id\":\"10036\",\"regionName\":\"三亚市\"}]";
		}
		else if("10035".equals(id))
		{
			return "[{\"id\":\"110012\",\"regionName\":\"龙华区\"},{\"id\":\"110014\",\"regionName\":\"美兰区\"},{\"id\":\"110013\",\"regionName\":\"琼山区\"},{\"id\":\"110011\",\"regionName\":\"秀英区\"}]";
		}
		else if("10037".equals(id))
		{
			return "[{\"id\":\"1100315\",\"regionName\":\"保亭黎族苗族自治县\"},{\"id\":\"1100311\",\"regionName\":\"白沙黎族自治县\"},{\"id\":\"1100312\",\"regionName\":\"昌江黎族自治县\"},{\"id\":\"110039\",\"regionName\":\"澄迈县\"},{\"id\":\"110037\",\"regionName\":\"定安县\"},{\"id\":\"110036\",\"regionName\":\"东方市\"},{\"id\":\"110033\",\"regionName\":\"儋州市\"},{\"id\":\"1100314\",\"regionName\":\"陵水黎族自治县\"},{\"id\":\"1100313\",\"regionName\":\"乐东黎族自治县\"},{\"id\":\"1100310\",\"regionName\":\"临高县\"},{\"id\":\"1100318\",\"regionName\":\"南沙群岛\"},{\"id\":\"1100316\",\"regionName\":\"琼中黎族苗族自治县\"},{\"id\":\"110032\",\"regionName\":\"琼海市\"},{\"id\":\"110038\",\"regionName\":\"屯昌县\"},{\"id\":\"110035\",\"regionName\":\"万宁市\"},{\"id\":\"110034\",\"regionName\":\"文昌市\"},{\"id\":\"110031\",\"regionName\":\"五指山市\"},{\"id\":\"1100317\",\"regionName\":\"西沙群岛\"},{\"id\":\"1100319\",\"regionName\":\"中沙群岛的岛礁及其海域\"}]";
		}
		else if("10036".equals(id))
		{
			return "[]";
		}
		else if("18".equals(id))
		{
			return "[{\"id\":\"8544\",\"regionName\":\"郴州市\"},{\"id\":\"8541\",\"regionName\":\"常德市\"},{\"id\":\"8546\",\"regionName\":\"怀化市\"},{\"id\":\"8538\",\"regionName\":\"衡阳市\"},{\"id\":\"8547\",\"regionName\":\"娄底市\"},{\"id\":\"8539\",\"regionName\":\"邵阳市\"},{\"id\":\"8548\",\"regionName\":\"湘西土家族苗族自治州\"},{\"id\":\"8537\",\"regionName\":\"湘潭市\"},{\"id\":\"8545\",\"regionName\":\"永州市\"},{\"id\":\"8543\",\"regionName\":\"益阳市\"},{\"id\":\"8540\",\"regionName\":\"岳阳市\"},{\"id\":\"8542\",\"regionName\":\"张家界市\"},{\"id\":\"8536\",\"regionName\":\"株洲市\"},{\"id\":\"8535\",\"regionName\":\"长沙市\"}]";
		}
		else if("8544".equals(id))
		{
			return "[{\"id\":\"951010\",\"regionName\":\"安仁县\"},{\"id\":\"95101\",\"regionName\":\"北湖区\"},{\"id\":\"95109\",\"regionName\":\"桂东县\"},{\"id\":\"95103\",\"regionName\":\"桂阳县\"},{\"id\":\"95106\",\"regionName\":\"嘉禾县\"},{\"id\":\"95107\",\"regionName\":\"临武县\"},{\"id\":\"95108\",\"regionName\":\"汝城县\"},{\"id\":\"95102\",\"regionName\":\"苏仙区\"},{\"id\":\"95105\",\"regionName\":\"永兴县\"},{\"id\":\"95104\",\"regionName\":\"宜章县\"},{\"id\":\"951011\",\"regionName\":\"资兴市\"}]";
		}
		else if("8541".equals(id))
		{
			return "[{\"id\":\"95073\",\"regionName\":\"安乡县\"},{\"id\":\"95072\",\"regionName\":\"鼎城区\"},{\"id\":\"95074\",\"regionName\":\"汉寿县\"},{\"id\":\"95079\",\"regionName\":\"津市市\"},{\"id\":\"95076\",\"regionName\":\"临澧县\"},{\"id\":\"95075\",\"regionName\":\"澧　县\"},{\"id\":\"95078\",\"regionName\":\"石门县\"},{\"id\":\"95077\",\"regionName\":\"桃源县\"},{\"id\":\"95071\",\"regionName\":\"武陵区\"}]";
		}
		else if("8546".equals(id))
		{
			return "[{\"id\":\"95124\",\"regionName\":\"辰溪县\"},{\"id\":\"951212\",\"regionName\":\"洪江市\"},{\"id\":\"95126\",\"regionName\":\"会同县\"},{\"id\":\"95121\",\"regionName\":\"鹤城区\"},{\"id\":\"951210\",\"regionName\":\"靖州苗族侗族自治县\"},{\"id\":\"95127\",\"regionName\":\"麻阳苗族自治县\"},{\"id\":\"951211\",\"regionName\":\"通道侗族自治县\"},{\"id\":\"95128\",\"regionName\":\"新晃侗族自治县\"},{\"id\":\"95125\",\"regionName\":\"溆浦县\"},{\"id\":\"95123\",\"regionName\":\"沅陵县\"},{\"id\":\"95129\",\"regionName\":\"芷江侗族自治县\"},{\"id\":\"95122\",\"regionName\":\"中方县\"}]";
		}
		else if("8538".equals(id))
		{
			return "[{\"id\":\"950412\",\"regionName\":\"常宁市\"},{\"id\":\"95049\",\"regionName\":\"衡东县\"},{\"id\":\"95048\",\"regionName\":\"衡山县\"},{\"id\":\"95047\",\"regionName\":\"衡南县\"},{\"id\":\"95046\",\"regionName\":\"衡阳县\"},{\"id\":\"950411\",\"regionName\":\"耒阳市\"},{\"id\":\"95045\",\"regionName\":\"南岳区\"},{\"id\":\"950410\",\"regionName\":\"祁东县\"},{\"id\":\"95043\",\"regionName\":\"石鼓区\"},{\"id\":\"95042\",\"regionName\":\"雁峰区\"},{\"id\":\"95044\",\"regionName\":\"蒸湘区\"},{\"id\":\"95041\",\"regionName\":\"珠晖区\"}]";
		}
		else if("8547".equals(id))
		{
			return "[{\"id\":\"95135\",\"regionName\":\"涟源市\"},{\"id\":\"95134\",\"regionName\":\"冷水江市\"},{\"id\":\"95131\",\"regionName\":\"娄星区\"},{\"id\":\"95132\",\"regionName\":\"双峰县\"},{\"id\":\"95133\",\"regionName\":\"新化县\"}]";
		}
		else if("8539".equals(id))
		{
			return "[{\"id\":\"95053\",\"regionName\":\"北塔区\"},{\"id\":\"950511\",\"regionName\":\"城步苗族自治县\"},{\"id\":\"95058\",\"regionName\":\"洞口县\"},{\"id\":\"95052\",\"regionName\":\"大祥区\"},{\"id\":\"95057\",\"regionName\":\"隆回县\"},{\"id\":\"95059\",\"regionName\":\"绥宁县\"},{\"id\":\"95056\",\"regionName\":\"邵阳县\"},{\"id\":\"95054\",\"regionName\":\"邵东县\"},{\"id\":\"95051\",\"regionName\":\"双清区\"},{\"id\":\"950512\",\"regionName\":\"武冈市\"},{\"id\":\"950510\",\"regionName\":\"新宁县\"},{\"id\":\"95055\",\"regionName\":\"新邵县\"}]";
		}
		else if("8548".equals(id))
		{
			return "[{\"id\":\"95145\",\"regionName\":\"保靖县\"},{\"id\":\"95143\",\"regionName\":\"凤凰县\"},{\"id\":\"95146\",\"regionName\":\"古丈县\"},{\"id\":\"95144\",\"regionName\":\"花垣县\"},{\"id\":\"95141\",\"regionName\":\"吉首市\"},{\"id\":\"95148\",\"regionName\":\"龙山县\"},{\"id\":\"95142\",\"regionName\":\"泸溪县\"},{\"id\":\"95147\",\"regionName\":\"永顺县\"}]";
		}
		else if("8537".equals(id))
		{
			return "[{\"id\":\"95035\",\"regionName\":\"韶山市\"},{\"id\":\"95034\",\"regionName\":\"湘乡市\"},{\"id\":\"95033\",\"regionName\":\"湘潭县\"},{\"id\":\"95032\",\"regionName\":\"岳塘区\"},{\"id\":\"95031\",\"regionName\":\"雨湖区\"}]";
		}
		else if("8545".equals(id))
		{
			return "[{\"id\":\"95116\",\"regionName\":\"道　县\"},{\"id\":\"95114\",\"regionName\":\"东安县\"},{\"id\":\"951111\",\"regionName\":\"江华瑶族自治县\"},{\"id\":\"95117\",\"regionName\":\"江永县\"},{\"id\":\"95119\",\"regionName\":\"蓝山县\"},{\"id\":\"95112\",\"regionName\":\"冷水滩区\"},{\"id\":\"95118\",\"regionName\":\"宁远县\"},{\"id\":\"95113\",\"regionName\":\"祁阳县\"},{\"id\":\"95115\",\"regionName\":\"双牌县\"},{\"id\":\"951110\",\"regionName\":\"新田县\"},{\"id\":\"95111\",\"regionName\":\"芝山区\"}]";
		}
		else if("8543".equals(id))
		{
			return "[{\"id\":\"95095\",\"regionName\":\"安化县\"},{\"id\":\"95092\",\"regionName\":\"赫山区\"},{\"id\":\"95093\",\"regionName\":\"南　县\"},{\"id\":\"95094\",\"regionName\":\"桃江县\"},{\"id\":\"95096\",\"regionName\":\"沅江市\"},{\"id\":\"95091\",\"regionName\":\"资阳区\"}]";
		}
		else if("8540".equals(id))
		{
			return "[{\"id\":\"95065\",\"regionName\":\"华容县\"},{\"id\":\"95063\",\"regionName\":\"君山区\"},{\"id\":\"95069\",\"regionName\":\"临湘市\"},{\"id\":\"95068\",\"regionName\":\"汨罗市\"},{\"id\":\"95067\",\"regionName\":\"平江县\"},{\"id\":\"95066\",\"regionName\":\"湘阴县\"},{\"id\":\"95064\",\"regionName\":\"岳阳县\"},{\"id\":\"95062\",\"regionName\":\"云溪区\"},{\"id\":\"95061\",\"regionName\":\"岳阳楼区\"}]";
		}
		else if("8542".equals(id))
		{
			return "[{\"id\":\"95083\",\"regionName\":\"慈利县\"},{\"id\":\"95084\",\"regionName\":\"桑植县\"},{\"id\":\"95082\",\"regionName\":\"武陵源区\"},{\"id\":\"95081\",\"regionName\":\"永定区\"}]";
		}
		else if("8536".equals(id))
		{
			return "[{\"id\":\"95027\",\"regionName\":\"茶陵县\"},{\"id\":\"95021\",\"regionName\":\"荷塘区\"},{\"id\":\"95029\",\"regionName\":\"醴陵市\"},{\"id\":\"95022\",\"regionName\":\"芦淞区\"},{\"id\":\"95023\",\"regionName\":\"石峰区\"},{\"id\":\"95024\",\"regionName\":\"天元区\"},{\"id\":\"95028\",\"regionName\":\"炎陵县\"},{\"id\":\"95026\",\"regionName\":\"攸　县\"},{\"id\":\"95025\",\"regionName\":\"株洲县\"}]";
		}
		else if("8535".equals(id))
		{
			return "[{\"id\":\"95011\",\"regionName\":\"芙蓉区\"},{\"id\":\"95014\",\"regionName\":\"开福区\"},{\"id\":\"95019\",\"regionName\":\"浏阳市\"},{\"id\":\"95018\",\"regionName\":\"宁乡县\"},{\"id\":\"95012\",\"regionName\":\"天心区\"},{\"id\":\"95017\",\"regionName\":\"望城县\"},{\"id\":\"95015\",\"regionName\":\"雨花区\"},{\"id\":\"95013\",\"regionName\":\"岳麓区\"},{\"id\":\"95016\",\"regionName\":\"长沙县\"}]";
		}
		else if("17".equals(id))
		{
			return "[{\"id\":\"8047\",\"regionName\":\"恩施土家族苗族自治州\"},{\"id\":\"8040\",\"regionName\":\"鄂州市\"},{\"id\":\"8044\",\"regionName\":\"黄冈市\"},{\"id\":\"8036\",\"regionName\":\"黄石市\"},{\"id\":\"8043\",\"regionName\":\"荆州市\"},{\"id\":\"8041\",\"regionName\":\"荆门市\"},{\"id\":\"8048\",\"regionName\":\"省直辖行政单位\"},{\"id\":\"8046\",\"regionName\":\"随州市\"},{\"id\":\"8037\",\"regionName\":\"十堰市\"},{\"id\":\"8035\",\"regionName\":\"武汉市\"},{\"id\":\"8045\",\"regionName\":\"咸宁市\"},{\"id\":\"8042\",\"regionName\":\"孝感市\"},{\"id\":\"8039\",\"regionName\":\"襄樊市\"},{\"id\":\"8038\",\"regionName\":\"宜昌市\"}]";
		}
		else if("8047".equals(id))
		{
			return "[{\"id\":\"90134\",\"regionName\":\"巴东县\"},{\"id\":\"90131\",\"regionName\":\"恩施市\"},{\"id\":\"90138\",\"regionName\":\"鹤峰县\"},{\"id\":\"90133\",\"regionName\":\"建始县\"},{\"id\":\"90137\",\"regionName\":\"来凤县\"},{\"id\":\"90132\",\"regionName\":\"利川市\"},{\"id\":\"90136\",\"regionName\":\"咸丰县\"},{\"id\":\"90135\",\"regionName\":\"宣恩县\"}]";
		}
		else if("8040".equals(id))
		{
			return "[{\"id\":\"90063\",\"regionName\":\"鄂城区\"},{\"id\":\"90062\",\"regionName\":\"华容区\"},{\"id\":\"90061\",\"regionName\":\"梁子湖区\"}]";
		}
		else if("8044".equals(id))
		{
			return "[{\"id\":\"90108\",\"regionName\":\"黄梅县\"},{\"id\":\"90103\",\"regionName\":\"红安县\"},{\"id\":\"90104\",\"regionName\":\"罗田县\"},{\"id\":\"90109\",\"regionName\":\"麻城市\"},{\"id\":\"90107\",\"regionName\":\"蕲春县\"},{\"id\":\"90102\",\"regionName\":\"团风县\"},{\"id\":\"901010\",\"regionName\":\"武穴市\"},{\"id\":\"90106\",\"regionName\":\"浠水县\"},{\"id\":\"90105\",\"regionName\":\"英山县\"},{\"id\":\"90101\",\"regionName\":\"州区\"}]";
		}
		else if("8036".equals(id))
		{
			return "[{\"id\":\"90026\",\"regionName\":\"大冶市\"},{\"id\":\"90021\",\"regionName\":\"黄石港区\"},{\"id\":\"90024\",\"regionName\":\"铁山区\"},{\"id\":\"90023\",\"regionName\":\"下陆区\"},{\"id\":\"90022\",\"regionName\":\"西塞山区\"},{\"id\":\"90025\",\"regionName\":\"阳新县\"}]";
		}
		else if("8043".equals(id))
		{
			return "[{\"id\":\"90093\",\"regionName\":\"公安县\"},{\"id\":\"90097\",\"regionName\":\"洪湖市\"},{\"id\":\"90095\",\"regionName\":\"江陵县\"},{\"id\":\"90094\",\"regionName\":\"监利县\"},{\"id\":\"90092\",\"regionName\":\"荆州区\"},{\"id\":\"90098\",\"regionName\":\"松滋市\"},{\"id\":\"90096\",\"regionName\":\"石首市\"},{\"id\":\"90091\",\"regionName\":\"沙市区\"}]";
		}
		else if("8041".equals(id))
		{
			return "[{\"id\":\"90075\",\"regionName\":\"东宝区\"},{\"id\":\"90074\",\"regionName\":\"掇刀区\"},{\"id\":\"90073\",\"regionName\":\"京山县\"},{\"id\":\"90072\",\"regionName\":\"沙洋县\"},{\"id\":\"90071\",\"regionName\":\"钟祥市\"}]";
		}
		else if("8048".equals(id))
		{
			return "[{\"id\":\"90142\",\"regionName\":\"潜江市\"},{\"id\":\"90144\",\"regionName\":\"神农架林区\"},{\"id\":\"90143\",\"regionName\":\"天门市\"},{\"id\":\"90141\",\"regionName\":\"仙桃市\"}]";
		}
		else if("8046".equals(id))
		{
			return "[{\"id\":\"90121\",\"regionName\":\"曾都区\"},{\"id\":\"90122\",\"regionName\":\"广水市\"}]";
		}
		else if("8037".equals(id))
		{
			return "[{\"id\":\"90038\",\"regionName\":\"丹江口市\"},{\"id\":\"90037\",\"regionName\":\"房　县\"},{\"id\":\"90031\",\"regionName\":\"茅箭区\"},{\"id\":\"90034\",\"regionName\":\"郧西县\"},{\"id\":\"90033\",\"regionName\":\"郧　县\"},{\"id\":\"90036\",\"regionName\":\"竹溪县\"},{\"id\":\"90035\",\"regionName\":\"竹山县\"},{\"id\":\"90032\",\"regionName\":\"张湾区\"}]";
		}
		else if("8035".equals(id))
		{
			return "[{\"id\":\"900110\",\"regionName\":\"蔡甸区\"},{\"id\":\"90018\",\"regionName\":\"东西湖区\"},{\"id\":\"900112\",\"regionName\":\"黄陂区\"},{\"id\":\"90019\",\"regionName\":\"汉南区\"},{\"id\":\"90017\",\"regionName\":\"洪山区\"},{\"id\":\"90014\",\"regionName\":\"汉阳区\"},{\"id\":\"900111\",\"regionName\":\"江夏区\"},{\"id\":\"90012\",\"regionName\":\"江汉区\"},{\"id\":\"90011\",\"regionName\":\"江岸区\"},{\"id\":\"90016\",\"regionName\":\"青山区\"},{\"id\":\"90013\",\"regionName\":\"乔口区\"},{\"id\":\"90015\",\"regionName\":\"武昌区\"},{\"id\":\"900113\",\"regionName\":\"新洲区\"}]";
		}
		else if("8045".equals(id))
		{
			return "[{\"id\":\"90116\",\"regionName\":\"赤壁市\"},{\"id\":\"90114\",\"regionName\":\"崇阳县\"},{\"id\":\"90112\",\"regionName\":\"嘉鱼县\"},{\"id\":\"90115\",\"regionName\":\"通山县\"},{\"id\":\"90113\",\"regionName\":\"通城县\"},{\"id\":\"90111\",\"regionName\":\"咸安区\"}]";
		}
		else if("8042".equals(id))
		{
			return "[{\"id\":\"90081\",\"regionName\":\"安陆市\"},{\"id\":\"90084\",\"regionName\":\"大悟县\"},{\"id\":\"90087\",\"regionName\":\"汉川市\"},{\"id\":\"90086\",\"regionName\":\"孝南区\"},{\"id\":\"90085\",\"regionName\":\"孝昌县\"},{\"id\":\"90083\",\"regionName\":\"云梦县\"},{\"id\":\"90082\",\"regionName\":\"应城市\"}]";
		}
		else if("8039".equals(id))
		{
			return "[{\"id\":\"90056\",\"regionName\":\"保康县\"},{\"id\":\"90052\",\"regionName\":\"樊城区\"},{\"id\":\"90055\",\"regionName\":\"谷城县\"},{\"id\":\"90057\",\"regionName\":\"老河口市\"},{\"id\":\"90054\",\"regionName\":\"南漳县\"},{\"id\":\"90053\",\"regionName\":\"襄阳区\"},{\"id\":\"90051\",\"regionName\":\"襄城区\"},{\"id\":\"90059\",\"regionName\":\"宜城市\"},{\"id\":\"90058\",\"regionName\":\"枣阳市\"}]";
		}
		else if("8038".equals(id))
		{
			return "[{\"id\":\"900412\",\"regionName\":\"当阳市\"},{\"id\":\"90043\",\"regionName\":\"点军区\"},{\"id\":\"900410\",\"regionName\":\"五峰土家族自治县\"},{\"id\":\"90042\",\"regionName\":\"伍家岗区\"},{\"id\":\"90047\",\"regionName\":\"兴山县\"},{\"id\":\"90041\",\"regionName\":\"西陵区\"},{\"id\":\"900411\",\"regionName\":\"宜都市\"},{\"id\":\"90046\",\"regionName\":\"远安县\"},{\"id\":\"90045\",\"regionName\":\"夷陵区\"},{\"id\":\"90044\",\"regionName\":\"猇亭区\"},{\"id\":\"900413\",\"regionName\":\"枝江市\"},{\"id\":\"90049\",\"regionName\":\"长阳土家族自治县\"},{\"id\":\"90048\",\"regionName\":\"秭归县\"}]";
		}
		else if("16".equals(id))
		{
			return "[{\"id\":\"7539\",\"regionName\":\"安阳市\"},{\"id\":\"7540\",\"regionName\":\"鹤壁市\"},{\"id\":\"7542\",\"regionName\":\"焦作市\"},{\"id\":\"7536\",\"regionName\":\"开封市\"},{\"id\":\"7545\",\"regionName\":\"漯河市\"},{\"id\":\"7537\",\"regionName\":\"洛阳市\"},{\"id\":\"7547\",\"regionName\":\"南阳市\"},{\"id\":\"7543\",\"regionName\":\"濮阳市\"},{\"id\":\"7538\",\"regionName\":\"平顶山市\"},{\"id\":\"7548\",\"regionName\":\"商丘市\"},{\"id\":\"7546\",\"regionName\":\"三门峡市\"},{\"id\":\"7549\",\"regionName\":\"信阳市\"},{\"id\":\"7544\",\"regionName\":\"许昌市\"},{\"id\":\"7541\",\"regionName\":\"新乡市\"},{\"id\":\"7551\",\"regionName\":\"驻马店市\"},{\"id\":\"7550\",\"regionName\":\"周口市\"},{\"id\":\"7535\",\"regionName\":\"郑州市\"}]";
		}
		else if("7539".equals(id))
		{
			return "[{\"id\":\"85055\",\"regionName\":\"安阳县\"},{\"id\":\"85052\",\"regionName\":\"北关区\"},{\"id\":\"85057\",\"regionName\":\"滑　县\"},{\"id\":\"85059\",\"regionName\":\"林州市\"},{\"id\":\"85054\",\"regionName\":\"龙安区\"},{\"id\":\"85058\",\"regionName\":\"内黄县\"},{\"id\":\"85056\",\"regionName\":\"汤阴县\"},{\"id\":\"85051\",\"regionName\":\"文峰区\"},{\"id\":\"85053\",\"regionName\":\"殷都区\"}]";
		}
		else if("7540".equals(id))
		{
			return "[{\"id\":\"85061\",\"regionName\":\"鹤山区\"},{\"id\":\"85064\",\"regionName\":\"浚　县\"},{\"id\":\"85065\",\"regionName\":\"淇　县\"},{\"id\":\"85063\",\"regionName\":\"淇滨区\"},{\"id\":\"85062\",\"regionName\":\"山城区\"}]";
		}
		else if("7542".equals(id))
		{
			return "[{\"id\":\"85086\",\"regionName\":\"博爱县\"},{\"id\":\"85089\",\"regionName\":\"济源市\"},{\"id\":\"85081\",\"regionName\":\"解放区\"},{\"id\":\"850811\",\"regionName\":\"孟州市\"},{\"id\":\"85083\",\"regionName\":\"马村区\"},{\"id\":\"850810\",\"regionName\":\"沁阳市\"},{\"id\":\"85084\",\"regionName\":\"山阳区\"},{\"id\":\"85088\",\"regionName\":\"温　县\"},{\"id\":\"85087\",\"regionName\":\"武陟县\"},{\"id\":\"85085\",\"regionName\":\"修武县\"},{\"id\":\"85082\",\"regionName\":\"中站区\"}]";
		}
		else if("7536".equals(id))
		{
			return "[{\"id\":\"85023\",\"regionName\":\"鼓楼区\"},{\"id\":\"85025\",\"regionName\":\"郊　区\"},{\"id\":\"85029\",\"regionName\":\"开封县\"},{\"id\":\"850210\",\"regionName\":\"兰考县\"},{\"id\":\"85021\",\"regionName\":\"龙亭区\"},{\"id\":\"85024\",\"regionName\":\"南关区\"},{\"id\":\"85026\",\"regionName\":\"杞　县\"},{\"id\":\"85022\",\"regionName\":\"顺河回族区\"},{\"id\":\"85027\",\"regionName\":\"通许县\"},{\"id\":\"85028\",\"regionName\":\"尉氏县\"}]";
		}
		else if("7545".equals(id))
		{
			return "[{\"id\":\"85115\",\"regionName\":\"临颍县\"},{\"id\":\"85114\",\"regionName\":\"舞阳县\"},{\"id\":\"85112\",\"regionName\":\"郾城区\"},{\"id\":\"85111\",\"regionName\":\"源汇区\"},{\"id\":\"85113\",\"regionName\":\"召陵区\"}]";
		}
		else if("7537".equals(id))
		{
			return "[{\"id\":\"85033\",\"regionName\":\"廛河回族区\"},{\"id\":\"85035\",\"regionName\":\"吉利区\"},{\"id\":\"85034\",\"regionName\":\"涧西区\"},{\"id\":\"850313\",\"regionName\":\"洛宁县\"},{\"id\":\"85039\",\"regionName\":\"栾川县\"},{\"id\":\"85036\",\"regionName\":\"洛龙区\"},{\"id\":\"85031\",\"regionName\":\"老城区\"},{\"id\":\"85037\",\"regionName\":\"孟津县\"},{\"id\":\"850311\",\"regionName\":\"汝阳县\"},{\"id\":\"850310\",\"regionName\":\"嵩　县\"},{\"id\":\"85038\",\"regionName\":\"新安县\"},{\"id\":\"85032\",\"regionName\":\"西工区\"},{\"id\":\"850315\",\"regionName\":\"偃师市\"},{\"id\":\"850314\",\"regionName\":\"伊川县\"},{\"id\":\"850312\",\"regionName\":\"宜阳县\"}]";
		}
		else if("7547".equals(id))
		{
			return "[{\"id\":\"851313\",\"regionName\":\"邓州市\"},{\"id\":\"85134\",\"regionName\":\"方城县\"},{\"id\":\"85137\",\"regionName\":\"内乡县\"},{\"id\":\"85133\",\"regionName\":\"南召县\"},{\"id\":\"85139\",\"regionName\":\"社旗县\"},{\"id\":\"851312\",\"regionName\":\"桐柏县\"},{\"id\":\"851310\",\"regionName\":\"唐河县\"},{\"id\":\"85132\",\"regionName\":\"卧龙区\"},{\"id\":\"85131\",\"regionName\":\"宛城区\"},{\"id\":\"851311\",\"regionName\":\"新野县\"},{\"id\":\"85138\",\"regionName\":\"淅川县\"},{\"id\":\"85135\",\"regionName\":\"西峡县\"},{\"id\":\"85136\",\"regionName\":\"镇平县\"}]";
		}
		else if("7543".equals(id))
		{
			return "[{\"id\":\"85094\",\"regionName\":\"范　县\"},{\"id\":\"85091\",\"regionName\":\"华龙区\"},{\"id\":\"85093\",\"regionName\":\"南乐县\"},{\"id\":\"85096\",\"regionName\":\"濮阳县\"},{\"id\":\"85092\",\"regionName\":\"清丰县\"},{\"id\":\"85095\",\"regionName\":\"台前县\"}]";
		}
		else if("7538".equals(id))
		{
			return "[{\"id\":\"85045\",\"regionName\":\"宝丰县\"},{\"id\":\"85048\",\"regionName\":\"郏　县\"},{\"id\":\"85047\",\"regionName\":\"鲁山县\"},{\"id\":\"850410\",\"regionName\":\"汝州市\"},{\"id\":\"85043\",\"regionName\":\"石龙区\"},{\"id\":\"85049\",\"regionName\":\"舞钢市\"},{\"id\":\"85042\",\"regionName\":\"卫东区\"},{\"id\":\"85041\",\"regionName\":\"新华区\"},{\"id\":\"85046\",\"regionName\":\"叶　县\"},{\"id\":\"85044\",\"regionName\":\"湛河区\"}]";
		}
		else if("7548".equals(id))
		{
			return "[{\"id\":\"85141\",\"regionName\":\"梁园区\"},{\"id\":\"85143\",\"regionName\":\"民权县\"},{\"id\":\"85145\",\"regionName\":\"宁陵县\"},{\"id\":\"85144\",\"regionName\":\"睢　县\"},{\"id\":\"85142\",\"regionName\":\"睢阳区\"},{\"id\":\"85148\",\"regionName\":\"夏邑县\"},{\"id\":\"85149\",\"regionName\":\"永城市\"},{\"id\":\"85147\",\"regionName\":\"虞城县\"},{\"id\":\"85146\",\"regionName\":\"柘城县\"}]";
		}
		else if("7546".equals(id))
		{
			return "[{\"id\":\"85121\",\"regionName\":\"湖滨区\"},{\"id\":\"85126\",\"regionName\":\"灵宝市\"},{\"id\":\"85124\",\"regionName\":\"卢氏县\"},{\"id\":\"85122\",\"regionName\":\"渑池县\"},{\"id\":\"85123\",\"regionName\":\"陕　县\"},{\"id\":\"85125\",\"regionName\":\"义马市\"}]";
		}
		else if("7549".equals(id))
		{
			return "[{\"id\":\"85157\",\"regionName\":\"固始县\"},{\"id\":\"85154\",\"regionName\":\"光山县\"},{\"id\":\"85159\",\"regionName\":\"淮滨县\"},{\"id\":\"85158\",\"regionName\":\"潢川县\"},{\"id\":\"85153\",\"regionName\":\"罗山县\"},{\"id\":\"85152\",\"regionName\":\"平桥区\"},{\"id\":\"85156\",\"regionName\":\"商城县\"},{\"id\":\"85151\",\"regionName\":\"师河区\"},{\"id\":\"851510\",\"regionName\":\"息　县\"},{\"id\":\"85155\",\"regionName\":\"新　县\"}]";
		}
		else if("7544".equals(id))
		{
			return "[{\"id\":\"85101\",\"regionName\":\"魏都区\"},{\"id\":\"85104\",\"regionName\":\"襄城县\"},{\"id\":\"85102\",\"regionName\":\"许昌县\"},{\"id\":\"85105\",\"regionName\":\"禹州市\"},{\"id\":\"85103\",\"regionName\":\"鄢陵县\"},{\"id\":\"85106\",\"regionName\":\"长葛市\"}]";
		}
		else if("7541".equals(id))
		{
			return "[{\"id\":\"85079\",\"regionName\":\"封丘县\"},{\"id\":\"85073\",\"regionName\":\"凤泉区\"},{\"id\":\"850712\",\"regionName\":\"辉县市\"},{\"id\":\"85076\",\"regionName\":\"获嘉县\"},{\"id\":\"85071\",\"regionName\":\"红旗区\"},{\"id\":\"85074\",\"regionName\":\"牧野区\"},{\"id\":\"850711\",\"regionName\":\"卫辉市\"},{\"id\":\"85072\",\"regionName\":\"卫滨区\"},{\"id\":\"85075\",\"regionName\":\"新乡县\"},{\"id\":\"85078\",\"regionName\":\"延津县\"},{\"id\":\"85077\",\"regionName\":\"原阳县\"},{\"id\":\"850710\",\"regionName\":\"长垣县\"}]";
		}
		else if("7551".equals(id))
		{
			return "[{\"id\":\"85177\",\"regionName\":\"泌阳县\"},{\"id\":\"85174\",\"regionName\":\"平舆县\"},{\"id\":\"85176\",\"regionName\":\"确山县\"},{\"id\":\"85178\",\"regionName\":\"汝南县\"},{\"id\":\"85179\",\"regionName\":\"遂平县\"},{\"id\":\"85173\",\"regionName\":\"上蔡县\"},{\"id\":\"851710\",\"regionName\":\"新蔡县\"},{\"id\":\"85172\",\"regionName\":\"西平县\"},{\"id\":\"85171\",\"regionName\":\"驿城区\"},{\"id\":\"85175\",\"regionName\":\"正阳县\"}]";
		}
		else if("7550".equals(id))
		{
			return "[{\"id\":\"85161\",\"regionName\":\"川汇区\"},{\"id\":\"85166\",\"regionName\":\"郸城县\"},{\"id\":\"85162\",\"regionName\":\"扶沟县\"},{\"id\":\"85167\",\"regionName\":\"淮阳县\"},{\"id\":\"85169\",\"regionName\":\"鹿邑县\"},{\"id\":\"85165\",\"regionName\":\"沈丘县\"},{\"id\":\"85164\",\"regionName\":\"商水县\"},{\"id\":\"85168\",\"regionName\":\"太康县\"},{\"id\":\"851610\",\"regionName\":\"项城市\"},{\"id\":\"85163\",\"regionName\":\"西华县\"}]";
		}
		else if("7535".equals(id))
		{
			return "[{\"id\":\"850112\",\"regionName\":\"登封市\"},{\"id\":\"85012\",\"regionName\":\"二七区\"},{\"id\":\"85018\",\"regionName\":\"巩义市\"},{\"id\":\"85013\",\"regionName\":\"管城回族区\"},{\"id\":\"85014\",\"regionName\":\"金水区\"},{\"id\":\"85016\",\"regionName\":\"邙山区\"},{\"id\":\"85015\",\"regionName\":\"上街区\"},{\"id\":\"850111\",\"regionName\":\"新郑市\"},{\"id\":\"850110\",\"regionName\":\"新密市\"},{\"id\":\"85019\",\"regionName\":\"荥阳市\"},{\"id\":\"85017\",\"regionName\":\"中牟县\"},{\"id\":\"85011\",\"regionName\":\"中原区\"}]";
		}
		else if("8".equals(id))
		{
			return "[{\"id\":\"3547\",\"regionName\":\"大兴安岭地区\"},{\"id\":\"3540\",\"regionName\":\"大庆市\"},{\"id\":\"3545\",\"regionName\":\"黑河市\"},{\"id\":\"3538\",\"regionName\":\"鹤岗市\"},{\"id\":\"3535\",\"regionName\":\"哈尔滨市\"},{\"id\":\"3542\",\"regionName\":\"佳木斯市\"},{\"id\":\"3537\",\"regionName\":\"鸡西市\"},{\"id\":\"3544\",\"regionName\":\"牡丹江市\"},{\"id\":\"3543\",\"regionName\":\"七台河市\"},{\"id\":\"3536\",\"regionName\":\"齐齐哈尔市\"},{\"id\":\"3546\",\"regionName\":\"绥化市\"},{\"id\":\"3539\",\"regionName\":\"双鸭山市\"},{\"id\":\"3541\",\"regionName\":\"伊春市\"}]";
		}
		else if("3547".equals(id))
		{
			return "[{\"id\":\"45131\",\"regionName\":\"呼玛县\"},{\"id\":\"45133\",\"regionName\":\"漠河县\"},{\"id\":\"45132\",\"regionName\":\"塔河县\"}]";
		}
		else if("3540".equals(id))
		{
			return "[{\"id\":\"45069\",\"regionName\":\"杜尔伯特蒙古族自治县\"},{\"id\":\"45065\",\"regionName\":\"大同区\"},{\"id\":\"45064\",\"regionName\":\"红岗区\"},{\"id\":\"45068\",\"regionName\":\"林甸县\"},{\"id\":\"45062\",\"regionName\":\"龙凤区\"},{\"id\":\"45063\",\"regionName\":\"让胡路区\"},{\"id\":\"45061\",\"regionName\":\"萨尔图区\"},{\"id\":\"45067\",\"regionName\":\"肇源县\"},{\"id\":\"45066\",\"regionName\":\"肇州县\"}]";
		}
		else if("3545".equals(id))
		{
			return "[{\"id\":\"45111\",\"regionName\":\"爱辉区\"},{\"id\":\"45115\",\"regionName\":\"北安市\"},{\"id\":\"45112\",\"regionName\":\"嫩江县\"},{\"id\":\"45114\",\"regionName\":\"孙吴县\"},{\"id\":\"45116\",\"regionName\":\"五大连池市\"},{\"id\":\"45113\",\"regionName\":\"逊克县\"}]";
		}
		else if("3538".equals(id))
		{
			return "[{\"id\":\"45045\",\"regionName\":\"东山区\"},{\"id\":\"45042\",\"regionName\":\"工农区\"},{\"id\":\"45047\",\"regionName\":\"萝北县\"},{\"id\":\"45043\",\"regionName\":\"南山区\"},{\"id\":\"45048\",\"regionName\":\"绥滨县\"},{\"id\":\"45046\",\"regionName\":\"兴山区\"},{\"id\":\"45044\",\"regionName\":\"兴安区\"},{\"id\":\"45041\",\"regionName\":\"向阳区\"}]";
		}
		else if("3535".equals(id))
		{
			return "[{\"id\":\"450116\",\"regionName\":\"阿城市\"},{\"id\":\"450112\",\"regionName\":\"巴彦县\"},{\"id\":\"450111\",\"regionName\":\"宾　县\"},{\"id\":\"45015\",\"regionName\":\"动力区\"},{\"id\":\"45013\",\"regionName\":\"道外区\"},{\"id\":\"45011\",\"regionName\":\"道里区\"},{\"id\":\"450110\",\"regionName\":\"方正县\"},{\"id\":\"45018\",\"regionName\":\"呼兰区\"},{\"id\":\"450113\",\"regionName\":\"木兰县\"},{\"id\":\"45012\",\"regionName\":\"南岗区\"},{\"id\":\"45016\",\"regionName\":\"平房区\"},{\"id\":\"450118\",\"regionName\":\"尚志市\"},{\"id\":\"450117\",\"regionName\":\"双城市\"},{\"id\":\"45017\",\"regionName\":\"松北区\"},{\"id\":\"450114\",\"regionName\":\"通河县\"},{\"id\":\"450119\",\"regionName\":\"五常市\"},{\"id\":\"45014\",\"regionName\":\"香坊区\"},{\"id\":\"450115\",\"regionName\":\"延寿县\"},{\"id\":\"45019\",\"regionName\":\"依兰县\"}]";
		}
		else if("3542".equals(id))
		{
			return "[{\"id\":\"45084\",\"regionName\":\"东风区\"},{\"id\":\"450811\",\"regionName\":\"富锦市\"},{\"id\":\"45089\",\"regionName\":\"抚远县\"},{\"id\":\"45087\",\"regionName\":\"桦川县\"},{\"id\":\"45086\",\"regionName\":\"桦南县\"},{\"id\":\"45085\",\"regionName\":\"郊　区\"},{\"id\":\"45083\",\"regionName\":\"前进区\"},{\"id\":\"450810\",\"regionName\":\"同江市\"},{\"id\":\"45088\",\"regionName\":\"汤原县\"},{\"id\":\"45082\",\"regionName\":\"向阳区\"},{\"id\":\"45081\",\"regionName\":\"永红区\"}]";
		}
		else if("3537".equals(id))
		{
			return "[{\"id\":\"45035\",\"regionName\":\"城子河区\"},{\"id\":\"45033\",\"regionName\":\"滴道区\"},{\"id\":\"45038\",\"regionName\":\"虎林市\"},{\"id\":\"45032\",\"regionName\":\"恒山区\"},{\"id\":\"45037\",\"regionName\":\"鸡东县\"},{\"id\":\"45031\",\"regionName\":\"鸡冠区\"},{\"id\":\"45034\",\"regionName\":\"梨树区\"},{\"id\":\"45039\",\"regionName\":\"密山市\"},{\"id\":\"45036\",\"regionName\":\"麻山区\"}]";
		}
		else if("3544".equals(id))
		{
			return "[{\"id\":\"45103\",\"regionName\":\"爱民区\"},{\"id\":\"45105\",\"regionName\":\"东宁县\"},{\"id\":\"45101\",\"regionName\":\"东安区\"},{\"id\":\"45108\",\"regionName\":\"海林市\"},{\"id\":\"45106\",\"regionName\":\"林口县\"},{\"id\":\"451010\",\"regionName\":\"穆棱市\"},{\"id\":\"45109\",\"regionName\":\"宁安市\"},{\"id\":\"45107\",\"regionName\":\"绥芬河市\"},{\"id\":\"45104\",\"regionName\":\"西安区\"},{\"id\":\"45102\",\"regionName\":\"阳明区\"}]";
		}
		else if("3543".equals(id))
		{
			return "[{\"id\":\"45094\",\"regionName\":\"勃利县\"},{\"id\":\"45093\",\"regionName\":\"茄子河区\"},{\"id\":\"45092\",\"regionName\":\"桃山区\"},{\"id\":\"45091\",\"regionName\":\"新兴区\"}]";
		}
		else if("3536".equals(id))
		{
			return "[{\"id\":\"45024\",\"regionName\":\"昂昂溪区\"},{\"id\":\"450214\",\"regionName\":\"拜泉县\"},{\"id\":\"450211\",\"regionName\":\"富裕县\"},{\"id\":\"45025\",\"regionName\":\"富拉尔基区\"},{\"id\":\"450210\",\"regionName\":\"甘南县\"},{\"id\":\"45022\",\"regionName\":\"建华区\"},{\"id\":\"450213\",\"regionName\":\"克东县\"},{\"id\":\"450212\",\"regionName\":\"克山县\"},{\"id\":\"45028\",\"regionName\":\"龙江县 依安县\"},{\"id\":\"45021\",\"regionName\":\"龙沙区\"},{\"id\":\"45027\",\"regionName\":\"梅里斯达斡尔族区\"},{\"id\":\"450215\",\"regionName\":\"讷河市\"},{\"id\":\"45026\",\"regionName\":\"碾子山区\"},{\"id\":\"45029\",\"regionName\":\"泰来县\"},{\"id\":\"45023\",\"regionName\":\"铁锋区\"}]";
		}
		else if("3546".equals(id))
		{
			return "[{\"id\":\"45128\",\"regionName\":\"安达市\"},{\"id\":\"45121\",\"regionName\":\"北林区\"},{\"id\":\"451210\",\"regionName\":\"海伦市\"},{\"id\":\"45123\",\"regionName\":\"兰西县\"},{\"id\":\"45126\",\"regionName\":\"明水县\"},{\"id\":\"45125\",\"regionName\":\"庆安县\"},{\"id\":\"45124\",\"regionName\":\"青冈县\"},{\"id\":\"45127\",\"regionName\":\"绥棱县\"},{\"id\":\"45122\",\"regionName\":\"望奎县\"},{\"id\":\"45129\",\"regionName\":\"肇东市\"}]";
		}
		else if("3539".equals(id))
		{
			return "[{\"id\":\"45057\",\"regionName\":\"宝清县\"},{\"id\":\"45054\",\"regionName\":\"宝山区\"},{\"id\":\"45055\",\"regionName\":\"集贤县\"},{\"id\":\"45051\",\"regionName\":\"尖山区\"},{\"id\":\"45052\",\"regionName\":\"岭东区\"},{\"id\":\"45058\",\"regionName\":\"饶河县\"},{\"id\":\"45053\",\"regionName\":\"四方台区\"},{\"id\":\"45056\",\"regionName\":\"友谊县\"}]";
		}
		else if("3541".equals(id))
		{
			return "[{\"id\":\"45075\",\"regionName\":\"翠峦区\"},{\"id\":\"450712\",\"regionName\":\"带岭区\"},{\"id\":\"450714\",\"regionName\":\"红星区\"},{\"id\":\"450716\",\"regionName\":\"嘉荫县\"},{\"id\":\"45078\",\"regionName\":\"金山屯区\"},{\"id\":\"45077\",\"regionName\":\"美溪区\"},{\"id\":\"45072\",\"regionName\":\"南岔区\"},{\"id\":\"450715\",\"regionName\":\"上甘岭区\"},{\"id\":\"450717\",\"regionName\":\"铁力市\"},{\"id\":\"450711\",\"regionName\":\"汤旺河区\"},{\"id\":\"450713\",\"regionName\":\"乌伊岭区\"},{\"id\":\"450710\",\"regionName\":\"乌马河区\"},{\"id\":\"45079\",\"regionName\":\"五营区\"},{\"id\":\"45076\",\"regionName\":\"新青区\"},{\"id\":\"45074\",\"regionName\":\"西林区\"},{\"id\":\"45073\",\"regionName\":\"友好区\"},{\"id\":\"45071\",\"regionName\":\"伊春区\"}]";
		}
		else if("3".equals(id))
		{
			return "[{\"id\":\"1040\",\"regionName\":\"保定市\"},{\"id\":\"1045\",\"regionName\":\"沧州市\"},{\"id\":\"1042\",\"regionName\":\"承德市\"},{\"id\":\"1044\",\"regionName\":\"衡水市\"},{\"id\":\"1038\",\"regionName\":\"邯郸市\"},{\"id\":\"1043\",\"regionName\":\"廊坊市\"},{\"id\":\"1037\",\"regionName\":\"秦皇岛市\"},{\"id\":\"1035\",\"regionName\":\"石家庄市\"},{\"id\":\"1036\",\"regionName\":\"唐山市\"},{\"id\":\"1039\",\"regionName\":\"邢台市\"},{\"id\":\"1041\",\"regionName\":\"张家口市\"}]";
		}
		else if("1040".equals(id))
		{
			return "[{\"id\":\"200624\",\"regionName\":\"安国市\"},{\"id\":\"200615\",\"regionName\":\"安新县\"},{\"id\":\"200620\",\"regionName\":\"博野县\"},{\"id\":\"20062\",\"regionName\":\"北市区\"},{\"id\":\"200623\",\"regionName\":\"定州市\"},{\"id\":\"20069\",\"regionName\":\"定兴县\"},{\"id\":\"20067\",\"regionName\":\"阜平县\"},{\"id\":\"200625\",\"regionName\":\"高碑店市\"},{\"id\":\"200611\",\"regionName\":\"高阳县\"},{\"id\":\"200618\",\"regionName\":\"蠡　县\"},{\"id\":\"200613\",\"regionName\":\"涞源县\"},{\"id\":\"20066\",\"regionName\":\"涞水县\"},{\"id\":\"20064\",\"regionName\":\"满城县\"},{\"id\":\"20063\",\"regionName\":\"南市区\"},{\"id\":\"200617\",\"regionName\":\"曲阳县\"},{\"id\":\"20065\",\"regionName\":\"清苑县\"},{\"id\":\"200612\",\"regionName\":\"容城县\"},{\"id\":\"200619\",\"regionName\":\"顺平县\"},{\"id\":\"200610\",\"regionName\":\"唐　县\"},{\"id\":\"200614\",\"regionName\":\"望都县\"},{\"id\":\"200621\",\"regionName\":\"雄　县\"},{\"id\":\"20068\",\"regionName\":\"徐水县\"},{\"id\":\"20061\",\"regionName\":\"新市区\"},{\"id\":\"200616\",\"regionName\":\"易县\"},{\"id\":\"200622\",\"regionName\":\"涿州市\"}]";
		}
		else if("1045".equals(id))
		{
			return "[{\"id\":\"201113\",\"regionName\":\"泊头市\"},{\"id\":\"20113\",\"regionName\":\"沧　县\"},{\"id\":\"20115\",\"regionName\":\"东光县\"},{\"id\":\"201116\",\"regionName\":\"河间市\"},{\"id\":\"201115\",\"regionName\":\"黄骅市\"},{\"id\":\"20116\",\"regionName\":\"海兴县\"},{\"id\":\"201112\",\"regionName\":\"孟村回族自治县\"},{\"id\":\"20119\",\"regionName\":\"南皮县\"},{\"id\":\"20114\",\"regionName\":\"青　县\"},{\"id\":\"201114\",\"regionName\":\"任丘市\"},{\"id\":\"20118\",\"regionName\":\"肃宁县\"},{\"id\":\"201110\",\"regionName\":\"吴桥县\"},{\"id\":\"201111\",\"regionName\":\"献　县\"},{\"id\":\"20111\",\"regionName\":\"新华区\"},{\"id\":\"20117\",\"regionName\":\"盐山县\"},{\"id\":\"20112\",\"regionName\":\"运河区\"}]";
		}
		else if("1042".equals(id))
		{
			return "[{\"id\":\"200811\",\"regionName\":\" 围场满族蒙古族自治县\"},{\"id\":\"20084\",\"regionName\":\"承德县\"},{\"id\":\"20089\",\"regionName\":\"丰宁满族自治县\"},{\"id\":\"200810\",\"regionName\":\"宽城满族自治\"},{\"id\":\"20088\",\"regionName\":\"隆化县\"},{\"id\":\"20087\",\"regionName\":\"滦平县\"},{\"id\":\"20086\",\"regionName\":\"平泉县\"},{\"id\":\"20082\",\"regionName\":\"双滦区\"},{\"id\":\"20081\",\"regionName\":\"双桥区\"},{\"id\":\"20085\",\"regionName\":\"兴隆县\"},{\"id\":\"20083\",\"regionName\":\"鹰手营子矿区\"}]";
		}
		else if("1044".equals(id))
		{
			return "[{\"id\":\"20106\",\"regionName\":\"安平县\"},{\"id\":\"20109\",\"regionName\":\"阜城县\"},{\"id\":\"20107\",\"regionName\":\"故城县\"},{\"id\":\"201010\",\"regionName\":\"冀州市\"},{\"id\":\"20108\",\"regionName\":\"景　县\"},{\"id\":\"20105\",\"regionName\":\"饶阳县\"},{\"id\":\"201011\",\"regionName\":\"深州市\"},{\"id\":\"20101\",\"regionName\":\"桃城区\"},{\"id\":\"20104\",\"regionName\":\"武强县\"},{\"id\":\"20103\",\"regionName\":\"武邑县\"},{\"id\":\"20102\",\"regionName\":\"枣强县\"}]";
		}
		else if("1038".equals(id))
		{
			return "[{\"id\":\"200411\",\"regionName\":\"磁　县\"},{\"id\":\"20048\",\"regionName\":\"成安县\"},{\"id\":\"20043\",\"regionName\":\"丛台区\"},{\"id\":\"20049\",\"regionName\":\"大名县\"},{\"id\":\"200412\",\"regionName\":\"肥乡县\"},{\"id\":\"20045\",\"regionName\":\"峰峰矿区\"},{\"id\":\"20044\",\"regionName\":\"复兴区\"},{\"id\":\"200417\",\"regionName\":\"馆陶县\"},{\"id\":\"200416\",\"regionName\":\"广平县\"},{\"id\":\"20046\",\"regionName\":\"邯郸县\"},{\"id\":\"20042\",\"regionName\":\"邯山区\"},{\"id\":\"200415\",\"regionName\":\"鸡泽县\"},{\"id\":\"20047\",\"regionName\":\"临漳县\"},{\"id\":\"200419\",\"regionName\":\"曲周县\"},{\"id\":\"200414\",\"regionName\":\"邱　县\"},{\"id\":\"200410\",\"regionName\":\"涉　县\"},{\"id\":\"20041\",\"regionName\":\"市辖区\"},{\"id\":\"200420\",\"regionName\":\"武安市\"},{\"id\":\"200418\",\"regionName\":\"魏县\"},{\"id\":\"200413\",\"regionName\":\"永年县\"}]";
		}
		else if("1043".equals(id))
		{
			return "[{\"id\":\"20091\",\"regionName\":\"安次区\"},{\"id\":\"20099\",\"regionName\":\"霸州市\"},{\"id\":\"20098\",\"regionName\":\"大厂回族自治县\"},{\"id\":\"20096\",\"regionName\":\"大城县\"},{\"id\":\"20093\",\"regionName\":\"固安县\"},{\"id\":\"20092\",\"regionName\":\"广阳区\"},{\"id\":\"200910\",\"regionName\":\"三河市\"},{\"id\":\"20097\",\"regionName\":\"文安县\"},{\"id\":\"20095\",\"regionName\":\"香河县\"},{\"id\":\"20094\",\"regionName\":\"永清县\"}]";
		}
		else if("1037".equals(id))
		{
			return "[{\"id\":\"20033\",\"regionName\":\"北戴河区\"},{\"id\":\"20035\",\"regionName\":\"昌黎县\"},{\"id\":\"20036\",\"regionName\":\"抚宁县\"},{\"id\":\"20031\",\"regionName\":\"海港区\"},{\"id\":\"20037\",\"regionName\":\"卢龙县\"},{\"id\":\"20034\",\"regionName\":\"青龙满族自治县\"},{\"id\":\"20032\",\"regionName\":\"山海关区\"}]";
		}
		else if("1035".equals(id))
		{
			return "[{\"id\":\"200120\",\"regionName\":\"藁城市\"},{\"id\":\"200112\",\"regionName\":\"高邑县\"},{\"id\":\"200121\",\"regionName\":\"晋州市\"},{\"id\":\"20017\",\"regionName\":\"井陉县\"},{\"id\":\"20015\",\"regionName\":\"井陉矿区\"},{\"id\":\"200123\",\"regionName\":\"鹿泉市\"},{\"id\":\"200111\",\"regionName\":\"灵寿县\"},{\"id\":\"20019\",\"regionName\":\"栾城县\"},{\"id\":\"200116\",\"regionName\":\"平山县\"},{\"id\":\"20013\",\"regionName\":\"桥西区\"},{\"id\":\"20012\",\"regionName\":\"桥东区\"},{\"id\":\"200113\",\"regionName\":\"深泽县\"},{\"id\":\"200115\",\"regionName\":\"无极县\"},{\"id\":\"200122\",\"regionName\":\"新乐市\"},{\"id\":\"200119\",\"regionName\":\"辛集市\"},{\"id\":\"200110\",\"regionName\":\"行唐县\"},{\"id\":\"20014\",\"regionName\":\"新华区\"},{\"id\":\"200117\",\"regionName\":\"元氏县\"},{\"id\":\"20016\",\"regionName\":\"裕华区\"},{\"id\":\"200118\",\"regionName\":\"赵　县\"},{\"id\":\"200114\",\"regionName\":\"赞皇县\"},{\"id\":\"20018\",\"regionName\":\"正定县\"},{\"id\":\"20011\",\"regionName\":\"长安区\"}]";
		}
		else if("1036".equals(id))
		{
			return "[{\"id\":\"20026\",\"regionName\":\"丰润区\"},{\"id\":\"20025\",\"regionName\":\"丰南区\"},{\"id\":\"20023\",\"regionName\":\"古冶区\"},{\"id\":\"20024\",\"regionName\":\"开平区\"},{\"id\":\"20029\",\"regionName\":\"乐亭县\"},{\"id\":\"20028\",\"regionName\":\"滦南县\"},{\"id\":\"20027\",\"regionName\":\"滦　县\"},{\"id\":\"20022\",\"regionName\":\"路北区\"},{\"id\":\"20021\",\"regionName\":\"路南区\"},{\"id\":\"200214\",\"regionName\":\"迁安市\"},{\"id\":\"200210\",\"regionName\":\"迁西县\"},{\"id\":\"200212\",\"regionName\":\"唐海县\"},{\"id\":\"200211\",\"regionName\":\"玉田县\"},{\"id\":\"200213\",\"regionName\":\"遵化市\"}]";
		}
		else if("1039".equals(id))
		{
			return "[{\"id\":\"20056\",\"regionName\":\"柏乡县\"},{\"id\":\"200513\",\"regionName\":\"广宗县\"},{\"id\":\"200511\",\"regionName\":\"巨鹿县\"},{\"id\":\"200517\",\"regionName\":\"临西县\"},{\"id\":\"20057\",\"regionName\":\"隆尧县\"},{\"id\":\"20054\",\"regionName\":\"临城县\"},{\"id\":\"200518\",\"regionName\":\"南宫市\"},{\"id\":\"200510\",\"regionName\":\"宁晋县\"},{\"id\":\"20059\",\"regionName\":\"南和县\"},{\"id\":\"20055\",\"regionName\":\"内丘县\"},{\"id\":\"200514\",\"regionName\":\"平乡县\"},{\"id\":\"200516\",\"regionName\":\"清河县\"},{\"id\":\"20052\",\"regionName\":\"桥西区\"},{\"id\":\"20051\",\"regionName\":\"桥东区\"},{\"id\":\"20058\",\"regionName\":\"任　县\"},{\"id\":\"200519\",\"regionName\":\"沙河市\"},{\"id\":\"200515\",\"regionName\":\"威　县\"},{\"id\":\"200512\",\"regionName\":\"新河县\"},{\"id\":\"20053\",\"regionName\":\"邢台县\"}]";
		}
		else if("1041".equals(id))
		{
			return "[{\"id\":\"200717\",\"regionName\":\"崇礼县\"},{\"id\":\"200716\",\"regionName\":\"赤城县\"},{\"id\":\"20078\",\"regionName\":\"沽源县\"},{\"id\":\"200714\",\"regionName\":\"怀来县\"},{\"id\":\"200712\",\"regionName\":\"怀安县\"},{\"id\":\"20077\",\"regionName\":\"康保县\"},{\"id\":\"20072\",\"regionName\":\"桥西区\"},{\"id\":\"20071\",\"regionName\":\"桥东区\"},{\"id\":\"20079\",\"regionName\":\"尚义县\"},{\"id\":\"200713\",\"regionName\":\"万全县\"},{\"id\":\"20075\",\"regionName\":\"宣化县\"},{\"id\":\"20074\",\"regionName\":\"下花园区\"},{\"id\":\"20073\",\"regionName\":\"宣化区\"},{\"id\":\"200711\",\"regionName\":\"阳原县\"},{\"id\":\"200710\",\"regionName\":\"蔚　县\"},{\"id\":\"200715\",\"regionName\":\"涿鹿县\"},{\"id\":\"20076\",\"regionName\":\"张北县\"}]";
		}
		else if("14".equals(id))
		{
			return "[{\"id\":\"6544\",\"regionName\":\"抚州市\"},{\"id\":\"6541\",\"regionName\":\"赣州市\"},{\"id\":\"6542\",\"regionName\":\"吉安市\"},{\"id\":\"6538\",\"regionName\":\"九江市\"},{\"id\":\"6536\",\"regionName\":\"景德镇市\"},{\"id\":\"6535\",\"regionName\":\"南昌市\"},{\"id\":\"6537\",\"regionName\":\"萍乡市\"},{\"id\":\"6545\",\"regionName\":\"上饶市\"},{\"id\":\"6539\",\"regionName\":\"新余市\"},{\"id\":\"6543\",\"regionName\":\"宜春市\"},{\"id\":\"6540\",\"regionName\":\"鹰潭市\"}]";
		}
		else if("6544".equals(id))
		{
			return "[{\"id\":\"75105\",\"regionName\":\"崇仁县\"},{\"id\":\"751010\",\"regionName\":\"东乡县\"},{\"id\":\"751011\",\"regionName\":\"广昌县\"},{\"id\":\"75108\",\"regionName\":\"金溪县\"},{\"id\":\"75106\",\"regionName\":\"乐安县\"},{\"id\":\"75103\",\"regionName\":\"黎川县\"},{\"id\":\"75101\",\"regionName\":\"临川区\"},{\"id\":\"75104\",\"regionName\":\"南丰县\"},{\"id\":\"75102\",\"regionName\":\"南城县\"},{\"id\":\"75107\",\"regionName\":\"宜黄县\"},{\"id\":\"75109\",\"regionName\":\"资溪县\"}]";
		}
		else if("6541".equals(id))
		{
			return "[{\"id\":\"75077\",\"regionName\":\"安远县\"},{\"id\":\"75076\",\"regionName\":\"崇义县\"},{\"id\":\"75079\",\"regionName\":\"定南县\"},{\"id\":\"75074\",\"regionName\":\"大余县\"},{\"id\":\"75072\",\"regionName\":\"赣　县\"},{\"id\":\"750714\",\"regionName\":\"会昌县\"},{\"id\":\"75078\",\"regionName\":\"龙南县\"},{\"id\":\"750718\",\"regionName\":\"南康市\"},{\"id\":\"750711\",\"regionName\":\"宁都县\"},{\"id\":\"750710\",\"regionName\":\"全南县\"},{\"id\":\"750717\",\"regionName\":\"瑞金市\"},{\"id\":\"750716\",\"regionName\":\"石城县\"},{\"id\":\"75075\",\"regionName\":\"上犹县\"},{\"id\":\"750715\",\"regionName\":\"寻乌县\"},{\"id\":\"750713\",\"regionName\":\"兴国县\"},{\"id\":\"75073\",\"regionName\":\"信丰县\"},{\"id\":\"750712\",\"regionName\":\"于都县\"},{\"id\":\"75071\",\"regionName\":\"章贡区\"}]";
		}
		else if("6542".equals(id))
		{
			return "[{\"id\":\"750811\",\"regionName\":\"安福县\"},{\"id\":\"750813\",\"regionName\":\"井冈山市\"},{\"id\":\"75084\",\"regionName\":\"吉水县\"},{\"id\":\"75083\",\"regionName\":\"吉安县\"},{\"id\":\"75081\",\"regionName\":\"吉州区\"},{\"id\":\"75082\",\"regionName\":\"青原区\"},{\"id\":\"75089\",\"regionName\":\"遂川县\"},{\"id\":\"75088\",\"regionName\":\"泰和县\"},{\"id\":\"750810\",\"regionName\":\"万安县\"},{\"id\":\"75086\",\"regionName\":\"新干县\"},{\"id\":\"75085\",\"regionName\":\"峡江县\"},{\"id\":\"750812\",\"regionName\":\"永新县\"},{\"id\":\"75087\",\"regionName\":\"永丰县\"}]";
		}
		else if("6538".equals(id))
		{
			return "[{\"id\":\"75049\",\"regionName\":\"都昌县\"},{\"id\":\"75047\",\"regionName\":\"德安县\"},{\"id\":\"750410\",\"regionName\":\"湖口县\"},{\"id\":\"75043\",\"regionName\":\"九江县\"},{\"id\":\"75041\",\"regionName\":\"庐山区\"},{\"id\":\"750411\",\"regionName\":\"彭泽县\"},{\"id\":\"750412\",\"regionName\":\"瑞昌市\"},{\"id\":\"75044\",\"regionName\":\"武宁县\"},{\"id\":\"75048\",\"regionName\":\"星子县\"},{\"id\":\"75045\",\"regionName\":\"修水县\"},{\"id\":\"75042\",\"regionName\":\"浔阳区\"},{\"id\":\"75046\",\"regionName\":\"永修县\"}]";
		}
		else if("6536".equals(id))
		{
			return "[{\"id\":\"75021\",\"regionName\":\"昌江区\"},{\"id\":\"75023\",\"regionName\":\"浮梁县\"},{\"id\":\"75024\",\"regionName\":\"乐平市\"},{\"id\":\"75022\",\"regionName\":\"珠山区\"}]";
		}
		else if("6535".equals(id))
		{
			return "[{\"id\":\"75018\",\"regionName\":\"安义县\"},{\"id\":\"75011\",\"regionName\":\"东湖区\"},{\"id\":\"75019\",\"regionName\":\"进贤县\"},{\"id\":\"75016\",\"regionName\":\"南昌县\"},{\"id\":\"75015\",\"regionName\":\"青山湖区\"},{\"id\":\"75013\",\"regionName\":\"青云谱区\"},{\"id\":\"75014\",\"regionName\":\"湾里区\"},{\"id\":\"75017\",\"regionName\":\"新建县\"},{\"id\":\"75012\",\"regionName\":\"西湖区\"}]";
		}
		else if("6537".equals(id))
		{
			return "[{\"id\":\"75031\",\"regionName\":\"安源区\"},{\"id\":\"75035\",\"regionName\":\"芦溪县\"},{\"id\":\"75033\",\"regionName\":\"莲花县\"},{\"id\":\"75034\",\"regionName\":\"上栗县\"},{\"id\":\"75032\",\"regionName\":\"湘东区\"}]";
		}
		else if("6545".equals(id))
		{
			return "[{\"id\":\"751112\",\"regionName\":\"德兴市\"},{\"id\":\"75113\",\"regionName\":\"广丰县\"},{\"id\":\"75116\",\"regionName\":\"横峰县\"},{\"id\":\"75119\",\"regionName\":\"鄱阳县\"},{\"id\":\"75115\",\"regionName\":\"铅山县\"},{\"id\":\"75112\",\"regionName\":\"上饶县\"},{\"id\":\"751111\",\"regionName\":\"婺源县\"},{\"id\":\"751110\",\"regionName\":\"万年县\"},{\"id\":\"75111\",\"regionName\":\"信州区\"},{\"id\":\"75118\",\"regionName\":\"余干县\"},{\"id\":\"75117\",\"regionName\":\"弋阳县\"},{\"id\":\"75114\",\"regionName\":\"玉山县\"}]";
		}
		else if("6539".equals(id))
		{
			return "[{\"id\":\"75052\",\"regionName\":\"分宜县\"},{\"id\":\"75051\",\"regionName\":\"渝水区\"}]";
		}
		else if("6543".equals(id))
		{
			return "[{\"id\":\"75098\",\"regionName\":\"丰城市\"},{\"id\":\"75092\",\"regionName\":\"奉新县\"},{\"id\":\"750910\",\"regionName\":\"高安市\"},{\"id\":\"75096\",\"regionName\":\"靖安县\"},{\"id\":\"75094\",\"regionName\":\"上高县\"},{\"id\":\"75097\",\"regionName\":\"铜鼓县\"},{\"id\":\"75093\",\"regionName\":\"万载县\"},{\"id\":\"75095\",\"regionName\":\"宜丰县\"},{\"id\":\"75091\",\"regionName\":\"袁州区\"},{\"id\":\"75099\",\"regionName\":\"樟树市\"}]";
		}
		else if("6540".equals(id))
		{
			return "[{\"id\":\"75063\",\"regionName\":\"贵溪市\"},{\"id\":\"75062\",\"regionName\":\"余江县\"},{\"id\":\"75061\",\"regionName\":\"月湖区\"}]";
		}
		else if("10".equals(id))
		{
			return "[{\"id\":\"4538\",\"regionName\":\"常州市\"},{\"id\":\"4542\",\"regionName\":\"淮安市\"},{\"id\":\"4541\",\"regionName\":\"连云港市\"},{\"id\":\"4540\",\"regionName\":\"南通市\"},{\"id\":\"4535\",\"regionName\":\"南京市\"},{\"id\":\"4547\",\"regionName\":\"宿迁市\"},{\"id\":\"4539\",\"regionName\":\"苏州市\"},{\"id\":\"4546\",\"regionName\":\"泰州市\"},{\"id\":\"4536\",\"regionName\":\"无锡市\"},{\"id\":\"4537\",\"regionName\":\"徐州市\"},{\"id\":\"4544\",\"regionName\":\"扬州市\"},{\"id\":\"4543\",\"regionName\":\"盐城市\"},{\"id\":\"4545\",\"regionName\":\"镇江市\"}]";
		}
		else if("4538".equals(id))
		{
			return "[{\"id\":\"55047\",\"regionName\":\"金坛市\"},{\"id\":\"55046\",\"regionName\":\"溧阳市\"},{\"id\":\"55043\",\"regionName\":\"戚墅堰区\"},{\"id\":\"55041\",\"regionName\":\"天宁区\"},{\"id\":\"55045\",\"regionName\":\"武进区\"},{\"id\":\"55044\",\"regionName\":\"新北区\"},{\"id\":\"55042\",\"regionName\":\"钟楼区\"}]";
		}
		else if("4542".equals(id))
		{
			return "[{\"id\":\"55082\",\"regionName\":\"楚州区\"},{\"id\":\"55086\",\"regionName\":\"洪泽县\"},{\"id\":\"55083\",\"regionName\":\"淮阴区\"},{\"id\":\"55088\",\"regionName\":\"金湖县\"},{\"id\":\"55085\",\"regionName\":\"涟水县\"},{\"id\":\"55084\",\"regionName\":\"清浦区\"},{\"id\":\"55081\",\"regionName\":\"清河区\"},{\"id\":\"55087\",\"regionName\":\"盱眙县\"}]";
		}
		else if("4541".equals(id))
		{
			return "[{\"id\":\"55075\",\"regionName\":\"东海县\"},{\"id\":\"55077\",\"regionName\":\"灌南县\"},{\"id\":\"55076\",\"regionName\":\"灌云县\"},{\"id\":\"55074\",\"regionName\":\"赣榆县\"},{\"id\":\"55073\",\"regionName\":\"海州区\"},{\"id\":\"55071\",\"regionName\":\"连云区\"},{\"id\":\"55072\",\"regionName\":\"新浦区\"}]";
		}
		else if("4540".equals(id))
		{
			return "[{\"id\":\"55061\",\"regionName\":\"崇川区\"},{\"id\":\"55062\",\"regionName\":\"港闸区\"},{\"id\":\"55068\",\"regionName\":\"海门市\"},{\"id\":\"55063\",\"regionName\":\"海安县\"},{\"id\":\"55065\",\"regionName\":\"启东市\"},{\"id\":\"55066\",\"regionName\":\"如皋市\"},{\"id\":\"55064\",\"regionName\":\"如东县\"},{\"id\":\"55067\",\"regionName\":\"通州市\"}]";
		}
		else if("4535".equals(id))
		{
			return "[{\"id\":\"55012\",\"regionName\":\"白下区\"},{\"id\":\"550113\",\"regionName\":\"高淳县\"},{\"id\":\"55015\",\"regionName\":\"鼓楼区\"},{\"id\":\"550110\",\"regionName\":\"江宁区\"},{\"id\":\"55014\",\"regionName\":\"建邺区\"},{\"id\":\"550112\",\"regionName\":\"溧水县\"},{\"id\":\"550111\",\"regionName\":\"六合区\"},{\"id\":\"55017\",\"regionName\":\"浦口区\"},{\"id\":\"55018\",\"regionName\":\"栖霞区\"},{\"id\":\"55013\",\"regionName\":\"秦淮区\"},{\"id\":\"55011\",\"regionName\":\"武区\"},{\"id\":\"55016\",\"regionName\":\"下关区\"},{\"id\":\"55019\",\"regionName\":\"雨花台区\"}]";
		}
		else if("4547".equals(id))
		{
			return "[{\"id\":\"55135\",\"regionName\":\"泗洪县\"},{\"id\":\"55134\",\"regionName\":\"泗阳县\"},{\"id\":\"55133\",\"regionName\":\"沭阳县\"},{\"id\":\"55132\",\"regionName\":\"宿豫区\"},{\"id\":\"55131\",\"regionName\":\"宿城区\"}]";
		}
		else if("4539".equals(id))
		{
			return "[{\"id\":\"55057\",\"regionName\":\"常熟市\"},{\"id\":\"55051\",\"regionName\":\"沧浪区\"},{\"id\":\"55054\",\"regionName\":\"虎丘区\"},{\"id\":\"55053\",\"regionName\":\"金阊区\"},{\"id\":\"55059\",\"regionName\":\"昆山市\"},{\"id\":\"55052\",\"regionName\":\"平江区\"},{\"id\":\"550511\",\"regionName\":\"太仓市\"},{\"id\":\"550510\",\"regionName\":\"吴江市\"},{\"id\":\"55055\",\"regionName\":\"吴中区\"},{\"id\":\"55056\",\"regionName\":\"相城区\"},{\"id\":\"55058\",\"regionName\":\"张家港市\"}]";
		}
		else if("4546".equals(id))
		{
			return "[{\"id\":\"55122\",\"regionName\":\"高港区\"},{\"id\":\"55121\",\"regionName\":\"海陵区\"},{\"id\":\"55126\",\"regionName\":\"姜堰市\"},{\"id\":\"55124\",\"regionName\":\"靖江市\"},{\"id\":\"55125\",\"regionName\":\"泰兴市\"},{\"id\":\"55123\",\"regionName\":\"兴化市\"}]";
		}
		else if("4536".equals(id))
		{
			return "[{\"id\":\"55026\",\"regionName\":\"滨湖区\"},{\"id\":\"55023\",\"regionName\":\"北塘区\"},{\"id\":\"55021\",\"regionName\":\"崇安区\"},{\"id\":\"55025\",\"regionName\":\"惠山区\"},{\"id\":\"55027\",\"regionName\":\"江阴市\"},{\"id\":\"55022\",\"regionName\":\"南长区\"},{\"id\":\"55024\",\"regionName\":\"锡山区\"},{\"id\":\"55028\",\"regionName\":\"宜兴市\"}]";
		}
		else if("4537".equals(id))
		{
			return "[{\"id\":\"55036\",\"regionName\":\"丰　县\"},{\"id\":\"55031\",\"regionName\":\"鼓楼区\"},{\"id\":\"55034\",\"regionName\":\"贾汪区\"},{\"id\":\"55033\",\"regionName\":\"九里区\"},{\"id\":\"550311\",\"regionName\":\"邳州市\"},{\"id\":\"55037\",\"regionName\":\"沛　县\"},{\"id\":\"55035\",\"regionName\":\"泉山区\"},{\"id\":\"55039\",\"regionName\":\"睢宁县\"},{\"id\":\"55038\",\"regionName\":\"铜山县\"},{\"id\":\"550310\",\"regionName\":\"新沂市\"},{\"id\":\"55032\",\"regionName\":\"云龙区\"}]";
		}
		else if("4544".equals(id))
		{
			return "[{\"id\":\"55104\",\"regionName\":\"宝应县\"},{\"id\":\"55106\",\"regionName\":\"高邮市\"},{\"id\":\"55101\",\"regionName\":\"广陵区\"},{\"id\":\"55102\",\"regionName\":\"邗江区\"},{\"id\":\"55107\",\"regionName\":\"江都市\"},{\"id\":\"55103\",\"regionName\":\"郊　区\"},{\"id\":\"55105\",\"regionName\":\"仪征市\"}]";
		}
		else if("4543".equals(id))
		{
			return "[{\"id\":\"55094\",\"regionName\":\"滨海县\"},{\"id\":\"55099\",\"regionName\":\"大丰市\"},{\"id\":\"55098\",\"regionName\":\"东台市\"},{\"id\":\"55095\",\"regionName\":\"阜宁县\"},{\"id\":\"55097\",\"regionName\":\"建湖县\"},{\"id\":\"55096\",\"regionName\":\"射阳县\"},{\"id\":\"55091\",\"regionName\":\"亭湖区\"},{\"id\":\"55093\",\"regionName\":\"响水县\"},{\"id\":\"55092\",\"regionName\":\"盐都区\"}]";
		}
		else if("4545".equals(id))
		{
			return "[{\"id\":\"55114\",\"regionName\":\"丹阳市\"},{\"id\":\"55113\",\"regionName\":\"丹徒区\"},{\"id\":\"55116\",\"regionName\":\"句容市\"},{\"id\":\"55111\",\"regionName\":\"京口区\"},{\"id\":\"55112\",\"regionName\":\"润州区\"},{\"id\":\"55115\",\"regionName\":\"扬中市\"}]";
		}
		else if("7".equals(id))
		{
			return "[{\"id\":\"3042\",\"regionName\":\"白城市\"},{\"id\":\"3040\",\"regionName\":\"白山市\"},{\"id\":\"3036\",\"regionName\":\"吉林市\"},{\"id\":\"3038\",\"regionName\":\"辽源市\"},{\"id\":\"3041\",\"regionName\":\"松原市\"},{\"id\":\"3037\",\"regionName\":\"四平市\"},{\"id\":\"3039\",\"regionName\":\"通化市\"},{\"id\":\"3043\",\"regionName\":\"延边朝鲜族自治州\"},{\"id\":\"3035\",\"regionName\":\"长春市\"}]";
		}
		else if("3042".equals(id))
		{
			return "[{\"id\":\"40085\",\"regionName\":\"大安市\"},{\"id\":\"40084\",\"regionName\":\"洮南市\"},{\"id\":\"40083\",\"regionName\":\"通榆县\"},{\"id\":\"40081\",\"regionName\":\"洮北区\"},{\"id\":\"40082\",\"regionName\":\"镇赉县\"}]";
		}
		else if("3040".equals(id))
		{
			return "[{\"id\":\"40061\",\"regionName\":\"八道江区\"},{\"id\":\"40062\",\"regionName\":\"抚松县\"},{\"id\":\"40065\",\"regionName\":\"江源县\"},{\"id\":\"40063\",\"regionName\":\"靖宇县\"},{\"id\":\"40066\",\"regionName\":\"临江市\"},{\"id\":\"40064\",\"regionName\":\"长白朝鲜族自治县\"}]";
		}
		else if("3036".equals(id))
		{
			return "[{\"id\":\"40023\",\"regionName\":\"船营区\"},{\"id\":\"40021\",\"regionName\":\"昌邑区\"},{\"id\":\"40024\",\"regionName\":\"丰满区\"},{\"id\":\"40027\",\"regionName\":\"桦甸市\"},{\"id\":\"40026\",\"regionName\":\"蛟河市\"},{\"id\":\"40022\",\"regionName\":\"龙潭区\"},{\"id\":\"40029\",\"regionName\":\"磐石市\"},{\"id\":\"40028\",\"regionName\":\"舒兰市\"},{\"id\":\"40025\",\"regionName\":\"永吉县\"}]";
		}
		else if("3038".equals(id))
		{
			return "[{\"id\":\"40044\",\"regionName\":\"东辽县\"},{\"id\":\"40043\",\"regionName\":\"东丰县\"},{\"id\":\"40041\",\"regionName\":\"龙山区\"},{\"id\":\"40042\",\"regionName\":\"西安区\"}]";
		}
		else if("3041".equals(id))
		{
			return "[{\"id\":\"40075\",\"regionName\":\"扶余县\"},{\"id\":\"40071\",\"regionName\":\"宁江区\"},{\"id\":\"40074\",\"regionName\":\"乾安县\"},{\"id\":\"40072\",\"regionName\":\"前郭尔罗斯蒙古族自治县\"},{\"id\":\"40073\",\"regionName\":\"长岭县\"}]";
		}
		else if("3037".equals(id))
		{
			return "[{\"id\":\"40035\",\"regionName\":\"公主岭市\"},{\"id\":\"40033\",\"regionName\":\"梨树县\"},{\"id\":\"40036\",\"regionName\":\"双辽市\"},{\"id\":\"40032\",\"regionName\":\"铁东区\"},{\"id\":\"40031\",\"regionName\":\"铁西区\"},{\"id\":\"40034\",\"regionName\":\"伊通满族自治县\"}]";
		}
		else if("3039".equals(id))
		{
			return "[{\"id\":\"40051\",\"regionName\":\"东昌区\"},{\"id\":\"40052\",\"regionName\":\"二道江区\"},{\"id\":\"40054\",\"regionName\":\"辉南县\"},{\"id\":\"40057\",\"regionName\":\"集安市\"},{\"id\":\"40055\",\"regionName\":\"柳河县\"},{\"id\":\"40056\",\"regionName\":\"梅河口市\"},{\"id\":\"40053\",\"regionName\":\"通化县\"}]";
		}
		else if("3043".equals(id))
		{
			return "[{\"id\":\"40098\",\"regionName\":\"安图县\"},{\"id\":\"40093\",\"regionName\":\"敦化市\"},{\"id\":\"40096\",\"regionName\":\"和龙市\"},{\"id\":\"40094\",\"regionName\":\"珲春市\"},{\"id\":\"40095\",\"regionName\":\"龙井市\"},{\"id\":\"40092\",\"regionName\":\"图们市\"},{\"id\":\"40097\",\"regionName\":\"汪清县\"},{\"id\":\"40091\",\"regionName\":\"延吉市\"}]";
		}
		else if("3035".equals(id))
		{
			return "[{\"id\":\"40013\",\"regionName\":\"朝阳区\"},{\"id\":\"400110\",\"regionName\":\"德惠市\"},{\"id\":\"40014\",\"regionName\":\"二道区\"},{\"id\":\"40018\",\"regionName\":\"九台市\"},{\"id\":\"40012\",\"regionName\":\"宽城区\"},{\"id\":\"40015\",\"regionName\":\"绿园区\"},{\"id\":\"40017\",\"regionName\":\"农安县\"},{\"id\":\"40011\",\"regionName\":\"南关区\"},{\"id\":\"40016\",\"regionName\":\"双阳区\"},{\"id\":\"40019\",\"regionName\":\"榆树市\"}]";
		}
		else if("6".equals(id))
		{
			return "[{\"id\":\"2537\",\"regionName\":\"鞍山市\"},{\"id\":\"2539\",\"regionName\":\"本溪市\"},{\"id\":\"2547\",\"regionName\":\"朝阳市\"},{\"id\":\"2540\",\"regionName\":\"丹东市\"},{\"id\":\"2536\",\"regionName\":\"大连市\"},{\"id\":\"2543\",\"regionName\":\"阜新市\"},{\"id\":\"2538\",\"regionName\":\"抚顺市\"},{\"id\":\"2548\",\"regionName\":\"葫芦岛市\"},{\"id\":\"2541\",\"regionName\":\"锦州市\"},{\"id\":\"2544\",\"regionName\":\"辽阳市\"},{\"id\":\"2545\",\"regionName\":\"盘锦市\"},{\"id\":\"2535\",\"regionName\":\"沈阳市\"},{\"id\":\"2546\",\"regionName\":\"铁岭市\"},{\"id\":\"2542\",\"regionName\":\"营口市\"}]";
		}
		else if("2537".equals(id))
		{
			return "[{\"id\":\"35037\",\"regionName\":\"海城市\"},{\"id\":\"35033\",\"regionName\":\"立山区\"},{\"id\":\"35034\",\"regionName\":\"千山区\"},{\"id\":\"35035\",\"regionName\":\"台安县\"},{\"id\":\"35032\",\"regionName\":\"铁西区\"},{\"id\":\"35031\",\"regionName\":\"铁东区\"},{\"id\":\"35036\",\"regionName\":\"岫岩满族自治县\"}]";
		}
		else if("2539".equals(id))
		{
			return "[{\"id\":\"35055\",\"regionName\":\"本溪满族自治县\"},{\"id\":\"35056\",\"regionName\":\"桓仁满族自治县\"},{\"id\":\"35053\",\"regionName\":\"明山区\"},{\"id\":\"35054\",\"regionName\":\"南芬区\"},{\"id\":\"35051\",\"regionName\":\"平山区\"},{\"id\":\"35052\",\"regionName\":\"溪湖区\"}]";
		}
		else if("2547".equals(id))
		{
			return "[{\"id\":\"35136\",\"regionName\":\"北票市\"},{\"id\":\"35133\",\"regionName\":\"朝阳县\"},{\"id\":\"35134\",\"regionName\":\"建平县\"},{\"id\":\"35135\",\"regionName\":\"喀喇沁左翼蒙古族自治县\"},{\"id\":\"35137\",\"regionName\":\"凌源市\"},{\"id\":\"35132\",\"regionName\":\"龙城区\"},{\"id\":\"35131\",\"regionName\":\"双塔区\"}]";
		}
		else if("2540".equals(id))
		{
			return "[{\"id\":\"35065\",\"regionName\":\"东港市\"},{\"id\":\"35066\",\"regionName\":\"凤城市\"},{\"id\":\"35064\",\"regionName\":\"宽甸满族自治县\"},{\"id\":\"35061\",\"regionName\":\"元宝区\"},{\"id\":\"35063\",\"regionName\":\"振安区\"},{\"id\":\"35062\",\"regionName\":\"振兴区\"}]";
		}
		else if("2536".equals(id))
		{
			return "[{\"id\":\"35024\",\"regionName\":\"甘井子区\"},{\"id\":\"35026\",\"regionName\":\"金州区\"},{\"id\":\"35025\",\"regionName\":\"旅顺口区\"},{\"id\":\"35029\",\"regionName\":\"普兰店市\"},{\"id\":\"35023\",\"regionName\":\"沙河口区\"},{\"id\":\"35028\",\"regionName\":\"瓦房店市\"},{\"id\":\"35022\",\"regionName\":\"西岗区\"},{\"id\":\"350210\",\"regionName\":\"庄河市\"},{\"id\":\"35027\",\"regionName\":\"长海县\"},{\"id\":\"35021\",\"regionName\":\"中山区\"}]";
		}
		else if("2543".equals(id))
		{
			return "[{\"id\":\"35096\",\"regionName\":\"阜新蒙古族自治县\"},{\"id\":\"35091\",\"regionName\":\"海州区\"},{\"id\":\"35094\",\"regionName\":\"清河门区\"},{\"id\":\"35093\",\"regionName\":\"太平区\"},{\"id\":\"35095\",\"regionName\":\"细河区\"},{\"id\":\"35092\",\"regionName\":\"新邱区\"},{\"id\":\"35097\",\"regionName\":\"彰武县\"}]";
		}
		else if("2538".equals(id))
		{
			return "[{\"id\":\"35042\",\"regionName\":\"东洲区\"},{\"id\":\"35045\",\"regionName\":\"抚顺县\"},{\"id\":\"35047\",\"regionName\":\"清原满族自治县\"},{\"id\":\"35044\",\"regionName\":\"顺城区\"},{\"id\":\"35043\",\"regionName\":\"望花区\"},{\"id\":\"35046\",\"regionName\":\"新宾满族自治县\"},{\"id\":\"35041\",\"regionName\":\"新抚区\"}]";
		}
		else if("2548".equals(id))
		{
			return "[{\"id\":\"35145\",\"regionName\":\"建昌县\"},{\"id\":\"35142\",\"regionName\":\"龙港区\"},{\"id\":\"35141\",\"regionName\":\"连山区\"},{\"id\":\"35143\",\"regionName\":\"南票区\"},{\"id\":\"35144\",\"regionName\":\"绥中县\"},{\"id\":\"35146\",\"regionName\":\"兴城市\"}]";
		}
		else if("2541".equals(id))
		{
			return "[{\"id\":\"35077\",\"regionName\":\"北宁市\"},{\"id\":\"35071\",\"regionName\":\"古塔区\"},{\"id\":\"35074\",\"regionName\":\"黑山县\"},{\"id\":\"35076\",\"regionName\":\"凌海市\"},{\"id\":\"35072\",\"regionName\":\"凌河区\"},{\"id\":\"35073\",\"regionName\":\"太和区\"},{\"id\":\"35075\",\"regionName\":\"义　县\"}]";
		}
		else if("2544".equals(id))
		{
			return "[{\"id\":\"35101\",\"regionName\":\"白塔区\"},{\"id\":\"35107\",\"regionName\":\"灯塔市\"},{\"id\":\"35104\",\"regionName\":\"弓长岭区\"},{\"id\":\"35103\",\"regionName\":\"宏伟区\"},{\"id\":\"35106\",\"regionName\":\"辽阳县\"},{\"id\":\"35105\",\"regionName\":\"太子河区\"},{\"id\":\"35102\",\"regionName\":\"文圣区\"}]";
		}
		else if("2545".equals(id))
		{
			return "[{\"id\":\"35113\",\"regionName\":\"大洼县\"},{\"id\":\"35114\",\"regionName\":\"盘山县\"},{\"id\":\"35111\",\"regionName\":\"双台子区\"},{\"id\":\"35112\",\"regionName\":\"兴隆台区\"}]";
		}
		else if("2535".equals(id))
		{
			return "[{\"id\":\"35017\",\"regionName\":\"东陵区\"},{\"id\":\"35013\",\"regionName\":\"大东区\"},{\"id\":\"350112\",\"regionName\":\"法库县\"},{\"id\":\"35014\",\"regionName\":\"皇姑区\"},{\"id\":\"35011\",\"regionName\":\"和平区\"},{\"id\":\"350111\",\"regionName\":\"康平县\"},{\"id\":\"350110\",\"regionName\":\"辽中县\"},{\"id\":\"35016\",\"regionName\":\"苏家屯区\"},{\"id\":\"35012\",\"regionName\":\"沈河区\"},{\"id\":\"35015\",\"regionName\":\"铁西区\"},{\"id\":\"350113\",\"regionName\":\"新民市\"},{\"id\":\"35018\",\"regionName\":\"新城子区\"},{\"id\":\"35019\",\"regionName\":\"于洪区\"}]";
		}
		else if("2546".equals(id))
		{
			return "[{\"id\":\"35125\",\"regionName\":\"昌图县\"},{\"id\":\"35126\",\"regionName\":\"调兵山市\"},{\"id\":\"35127\",\"regionName\":\"开原市\"},{\"id\":\"35122\",\"regionName\":\"清河区\"},{\"id\":\"35123\",\"regionName\":\"铁岭县\"},{\"id\":\"35124\",\"regionName\":\"西丰县\"},{\"id\":\"35121\",\"regionName\":\"银州区\"}]";
		}
		else if("2542".equals(id))
		{
			return "[{\"id\":\"35083\",\"regionName\":\"鲅鱼圈区\"},{\"id\":\"35086\",\"regionName\":\"大石桥市\"},{\"id\":\"35085\",\"regionName\":\"盖州市\"},{\"id\":\"35084\",\"regionName\":\"老边区\"},{\"id\":\"35082\",\"regionName\":\"西市区\"},{\"id\":\"35081\",\"regionName\":\"站前区\"}]";
		}
		else if("30".equals(id))
		{
			return "[{\"id\":\"14538\",\"regionName\":\"固原市\"},{\"id\":\"14536\",\"regionName\":\"石嘴山市\"},{\"id\":\"14537\",\"regionName\":\"吴忠市\"},{\"id\":\"14535\",\"regionName\":\"银川市\"},{\"id\":\"14539\",\"regionName\":\"中卫市\"}]";
		}
		else if("14538".equals(id))
		{
			return "[{\"id\":\"155044\",\"regionName\":\"泾源县\"},{\"id\":\"155043\",\"regionName\":\"隆德县\"},{\"id\":\"155045\",\"regionName\":\"彭阳县\"},{\"id\":\"155042\",\"regionName\":\"西吉县\"},{\"id\":\"155041\",\"regionName\":\"原州区\"}]";
		}
		else if("14536".equals(id))
		{
			return "[{\"id\":\"155021\",\"regionName\":\"大武口区\"},{\"id\":\"155022\",\"regionName\":\"惠农区\"},{\"id\":\"155023\",\"regionName\":\"平罗县\"}]";
		}
		else if("14537".equals(id))
		{
			return "[{\"id\":\"155031\",\"regionName\":\"利通区\"},{\"id\":\"155034\",\"regionName\":\"青铜峡市\"},{\"id\":\"155033\",\"regionName\":\"同心县\"},{\"id\":\"155032\",\"regionName\":\"盐池县\"}]";
		}
		else if("14535".equals(id))
		{
			return "[{\"id\":\"155015\",\"regionName\":\"贺兰县\"},{\"id\":\"155013\",\"regionName\":\"金凤区\"},{\"id\":\"155016\",\"regionName\":\"灵武市\"},{\"id\":\"155012\",\"regionName\":\"西夏区\"},{\"id\":\"155011\",\"regionName\":\"兴庆区\"},{\"id\":\"155014\",\"regionName\":\"永宁县\"}]";
		}
		else if("14539".equals(id))
		{
			return "[{\"id\":\"155053\",\"regionName\":\"海原县\"},{\"id\":\"155051\",\"regionName\":\"沙坡头区\"},{\"id\":\"155052\",\"regionName\":\"中宁县\"}]";
		}
		else if("5".equals(id))
		{
			return "[{\"id\":\"2046\",\"regionName\":\"阿拉善盟\"},{\"id\":\"2042\",\"regionName\":\"巴彦淖尔市\"},{\"id\":\"2036\",\"regionName\":\"包头市\"},{\"id\":\"2038\",\"regionName\":\"赤峰市\"},{\"id\":\"2040\",\"regionName\":\"鄂尔多斯市\"},{\"id\":\"2041\",\"regionName\":\"呼伦贝尔市\"},{\"id\":\"2035\",\"regionName\":\"呼和浩特市\"},{\"id\":\"2039\",\"regionName\":\"通辽市\"},{\"id\":\"2043\",\"regionName\":\"乌兰察布市\"},{\"id\":\"2037\",\"regionName\":\"乌海市\"},{\"id\":\"2045\",\"regionName\":\"锡林郭勒盟\"},{\"id\":\"2044\",\"regionName\":\"兴安盟\"}]";
		}
		else if("2046".equals(id))
		{
			return "[{\"id\":\"30122\",\"regionName\":\"阿拉善右旗\"},{\"id\":\"30121\",\"regionName\":\"阿拉善左旗\"},{\"id\":\"30123\",\"regionName\":\"额济纳旗\"}]";
		}
		else if("2042".equals(id))
		{
			return "[{\"id\":\"30083\",\"regionName\":\"磴口县\"},{\"id\":\"30087\",\"regionName\":\"杭锦后旗\"},{\"id\":\"30081\",\"regionName\":\"临河区\"},{\"id\":\"30086\",\"regionName\":\"乌拉特后旗\"},{\"id\":\"30085\",\"regionName\":\"乌拉特中旗\"},{\"id\":\"30084\",\"regionName\":\"乌拉特前旗\"},{\"id\":\"30082\",\"regionName\":\"五原县\"}]";
		}
		else if("2036".equals(id))
		{
			return "[{\"id\":\"30025\",\"regionName\":\"白云矿区\"},{\"id\":\"30029\",\"regionName\":\"达尔罕茂明安联合旗\"},{\"id\":\"30021\",\"regionName\":\"东河区\"},{\"id\":\"30028\",\"regionName\":\"固阳县\"},{\"id\":\"30026\",\"regionName\":\"九原区\"},{\"id\":\"30022\",\"regionName\":\"昆都仑区\"},{\"id\":\"30023\",\"regionName\":\"青山区\"},{\"id\":\"30024\",\"regionName\":\"石拐区\"},{\"id\":\"30027\",\"regionName\":\"土默特右旗\"}]";
		}
		else if("2038".equals(id))
		{
			return "[{\"id\":\"300412\",\"regionName\":\"敖汉旗\"},{\"id\":\"30044\",\"regionName\":\"阿鲁科尔沁旗\"},{\"id\":\"30046\",\"regionName\":\"巴林右旗\"},{\"id\":\"30045\",\"regionName\":\"巴林左旗\"},{\"id\":\"30041\",\"regionName\":\"红山区\"},{\"id\":\"300410\",\"regionName\":\"喀喇沁旗\"},{\"id\":\"30048\",\"regionName\":\"克什克腾旗\"},{\"id\":\"30047\",\"regionName\":\"林西县\"},{\"id\":\"300411\",\"regionName\":\"宁城县\"},{\"id\":\"30043\",\"regionName\":\"松山区\"},{\"id\":\"30049\",\"regionName\":\"翁牛特旗\"},{\"id\":\"30042\",\"regionName\":\"元宝山区\"}]";
		}
		else if("2040".equals(id))
		{
			return "[{\"id\":\"30062\",\"regionName\":\"达拉特旗\"},{\"id\":\"30061\",\"regionName\":\"东胜区\"},{\"id\":\"30065\",\"regionName\":\"鄂托克旗\"},{\"id\":\"30064\",\"regionName\":\"鄂托克前旗\"},{\"id\":\"30066\",\"regionName\":\"杭锦旗\"},{\"id\":\"30067\",\"regionName\":\"乌审旗\"},{\"id\":\"30068\",\"regionName\":\"伊金霍洛旗\"},{\"id\":\"30063\",\"regionName\":\"准格尔旗\"}]";
		}
		else if("2041".equals(id))
		{
			return "[{\"id\":\"30072\",\"regionName\":\"阿荣旗\"},{\"id\":\"30076\",\"regionName\":\"陈巴尔虎旗\"},{\"id\":\"300712\",\"regionName\":\"额尔古纳市\"},{\"id\":\"30075\",\"regionName\":\"鄂温克族自治旗\"},{\"id\":\"30074\",\"regionName\":\"鄂伦春自治旗\"},{\"id\":\"300713\",\"regionName\":\"根河市\"},{\"id\":\"30071\",\"regionName\":\"海拉尔区\"},{\"id\":\"30079\",\"regionName\":\"满洲里市\"},{\"id\":\"30073\",\"regionName\":\"莫力达瓦达斡尔族自治旗\"},{\"id\":\"30078\",\"regionName\":\"新巴尔虎右旗\"},{\"id\":\"30077\",\"regionName\":\"新巴尔虎左旗\"},{\"id\":\"300710\",\"regionName\":\"牙克石市\"},{\"id\":\"300711\",\"regionName\":\"扎兰屯市\"}]";
		}
		else if("2035".equals(id))
		{
			return "[{\"id\":\"30017\",\"regionName\":\"和林格尔县\"},{\"id\":\"30012\",\"regionName\":\"回民区\"},{\"id\":\"30018\",\"regionName\":\"清水河县\"},{\"id\":\"30014\",\"regionName\":\"赛罕区\"},{\"id\":\"30016\",\"regionName\":\"托克托县\"},{\"id\":\"30015\",\"regionName\":\"土默特左旗\"},{\"id\":\"30019\",\"regionName\":\"武川县\"},{\"id\":\"30011\",\"regionName\":\"新城区\"},{\"id\":\"30013\",\"regionName\":\"玉泉区\"}]";
		}
		else if("2039".equals(id))
		{
			return "[{\"id\":\"30058\",\"regionName\":\"霍林郭勒市\"},{\"id\":\"30055\",\"regionName\":\"库伦旗\"},{\"id\":\"30054\",\"regionName\":\"开鲁县\"},{\"id\":\"30053\",\"regionName\":\"科尔沁左翼后旗\"},{\"id\":\"30052\",\"regionName\":\"科尔沁左翼中旗\"},{\"id\":\"30051\",\"regionName\":\"科尔沁区\"},{\"id\":\"30056\",\"regionName\":\"奈曼旗\"},{\"id\":\"30057\",\"regionName\":\"扎鲁特旗\"}]";
		}
		else if("2043".equals(id))
		{
			return "[{\"id\":\"30099\",\"regionName\":\"察哈尔右翼后旗\"},{\"id\":\"30098\",\"regionName\":\"察哈尔右翼中旗\"},{\"id\":\"30097\",\"regionName\":\"察哈尔右翼前旗\"},{\"id\":\"300911\",\"regionName\":\"丰镇市\"},{\"id\":\"30093\",\"regionName\":\"化德县\"},{\"id\":\"30091\",\"regionName\":\"集宁区\"},{\"id\":\"30096\",\"regionName\":\"凉城县\"},{\"id\":\"300910\",\"regionName\":\"四子王旗\"},{\"id\":\"30094\",\"regionName\":\"商都县\"},{\"id\":\"30095\",\"regionName\":\"兴和县\"},{\"id\":\"30092\",\"regionName\":\"卓资县\"}]";
		}
		else if("2037".equals(id))
		{
			return "[{\"id\":\"30032\",\"regionName\":\"海南区\"},{\"id\":\"30031\",\"regionName\":\"海勃湾区\"},{\"id\":\"30033\",\"regionName\":\"乌达区\"}]";
		}
		else if("2045".equals(id))
		{
			return "[{\"id\":\"30113\",\"regionName\":\"阿巴嘎旗\"},{\"id\":\"301112\",\"regionName\":\"多伦县\"},{\"id\":\"30116\",\"regionName\":\"东乌珠穆沁旗\"},{\"id\":\"30111\",\"regionName\":\"二连浩特市\"},{\"id\":\"30115\",\"regionName\":\"苏尼特右旗\"},{\"id\":\"30114\",\"regionName\":\"苏尼特左旗\"},{\"id\":\"30118\",\"regionName\":\"太仆寺旗\"},{\"id\":\"30119\",\"regionName\":\"镶黄旗\"},{\"id\":\"30117\",\"regionName\":\"西乌珠穆沁旗\"},{\"id\":\"30112\",\"regionName\":\"锡林浩特市\"},{\"id\":\"301111\",\"regionName\":\"正蓝旗\"},{\"id\":\"301110\",\"regionName\":\"正镶白旗\"}]";
		}
		else if("2044".equals(id))
		{
			return "[{\"id\":\"30102\",\"regionName\":\"阿尔山市\"},{\"id\":\"30104\",\"regionName\":\"科尔沁右翼中旗\"},{\"id\":\"30103\",\"regionName\":\"科尔沁右翼前旗\"},{\"id\":\"30106\",\"regionName\":\"突泉县\"},{\"id\":\"30101\",\"regionName\":\"乌兰浩特市\"},{\"id\":\"30105\",\"regionName\":\"扎赉特旗\"}]";
		}
		else if("29".equals(id))
		{
			return "[{\"id\":\"14040\",\"regionName\":\"果洛藏族自治州\"},{\"id\":\"14042\",\"regionName\":\"海西蒙古族藏族自治州\"},{\"id\":\"14039\",\"regionName\":\"海南藏族自治州\"},{\"id\":\"14038\",\"regionName\":\"黄南藏族自治州\"},{\"id\":\"14037\",\"regionName\":\"海北藏族自治州\"},{\"id\":\"14036\",\"regionName\":\"海东地区\"},{\"id\":\"14035\",\"regionName\":\"西宁市\"},{\"id\":\"14041\",\"regionName\":\"玉树藏族自治州\"}]";
		}
		else if("14040".equals(id))
		{
			return "[{\"id\":\"150062\",\"regionName\":\"班玛县\"},{\"id\":\"150064\",\"regionName\":\"达日县\"},{\"id\":\"150063\",\"regionName\":\"甘德县\"},{\"id\":\"150065\",\"regionName\":\"久治县\"},{\"id\":\"150066\",\"regionName\":\"玛多县\"},{\"id\":\"150061\",\"regionName\":\"玛沁县\"}]";
		}
		else if("14042".equals(id))
		{
			return "[{\"id\":\"150084\",\"regionName\":\"都兰县\"},{\"id\":\"150082\",\"regionName\":\"德令哈市\"},{\"id\":\"150081\",\"regionName\":\"格尔木市\"},{\"id\":\"150085\",\"regionName\":\"天峻县\"},{\"id\":\"150083\",\"regionName\":\"乌兰县\"}]";
		}
		else if("14039".equals(id))
		{
			return "[{\"id\":\"150055\",\"regionName\":\"贵南县\"},{\"id\":\"150053\",\"regionName\":\"贵德县\"},{\"id\":\"150051\",\"regionName\":\"共和县\"},{\"id\":\"150052\",\"regionName\":\"同德县\"},{\"id\":\"150054\",\"regionName\":\"兴海县\"}]";
		}
		else if("14038".equals(id))
		{
			return "[{\"id\":\"150044\",\"regionName\":\"河南蒙古族自治县\"},{\"id\":\"150042\",\"regionName\":\"尖扎县\"},{\"id\":\"150041\",\"regionName\":\"同仁县\"},{\"id\":\"150043\",\"regionName\":\"泽库县\"}]";
		}
		else if("14037".equals(id))
		{
			return "[{\"id\":\"150034\",\"regionName\":\"刚察县\"},{\"id\":\"150033\",\"regionName\":\"海晏县\"},{\"id\":\"150031\",\"regionName\":\"门源回族自治县\"},{\"id\":\"150032\",\"regionName\":\"祁连县\"}]";
		}
		else if("14036".equals(id))
		{
			return "[{\"id\":\"150025\",\"regionName\":\"化隆回族自治县\"},{\"id\":\"150024\",\"regionName\":\"互助土族自治县\"},{\"id\":\"150023\",\"regionName\":\"乐都县\"},{\"id\":\"150022\",\"regionName\":\"民和回族土族自治县\"},{\"id\":\"150021\",\"regionName\":\"平安县\"},{\"id\":\"150026\",\"regionName\":\"循化撒拉族自治县\"}]";
		}
		else if("14035".equals(id))
		{
			return "[{\"id\":\"150014\",\"regionName\":\"城北区\"},{\"id\":\"150013\",\"regionName\":\"城西区\"},{\"id\":\"150012\",\"regionName\":\"城中区\"},{\"id\":\"150011\",\"regionName\":\"城东区\"},{\"id\":\"150015\",\"regionName\":\"大通回族土族自治县\"},{\"id\":\"150017\",\"regionName\":\"湟源县\"},{\"id\":\"150016\",\"regionName\":\"湟中县\"}]";
		}
		else if("14041".equals(id))
		{
			return "[{\"id\":\"150073\",\"regionName\":\"称多县\"},{\"id\":\"150075\",\"regionName\":\"囊谦县\"},{\"id\":\"150076\",\"regionName\":\"曲麻莱县\"},{\"id\":\"150071\",\"regionName\":\"玉树县\"},{\"id\":\"150074\",\"regionName\":\"治多县\"},{\"id\":\"150072\",\"regionName\":\"杂多县\"}]";
		}
		else if("27".equals(id))
		{
			return "[{\"id\":\"13043\",\"regionName\":\"安康市\"},{\"id\":\"13037\",\"regionName\":\"宝鸡市\"},{\"id\":\"13041\",\"regionName\":\"汉中市\"},{\"id\":\"13044\",\"regionName\":\"商洛市\"},{\"id\":\"13036\",\"regionName\":\"铜川市\"},{\"id\":\"13039\",\"regionName\":\"渭南市\"},{\"id\":\"13038\",\"regionName\":\"咸阳市\"},{\"id\":\"13035\",\"regionName\":\"西安市\"},{\"id\":\"13042\",\"regionName\":\"榆林市\"},{\"id\":\"13040\",\"regionName\":\"延安市\"}]";
		}
		else if("13043".equals(id))
		{
			return "[{\"id\":\"1400910\",\"regionName\":\"白河县\"},{\"id\":\"140092\",\"regionName\":\"汉阴县\"},{\"id\":\"140091\",\"regionName\":\"汉滨区\"},{\"id\":\"140096\",\"regionName\":\"岚皋县\"},{\"id\":\"140094\",\"regionName\":\"宁陕县\"},{\"id\":\"140097\",\"regionName\":\"平利县\"},{\"id\":\"140093\",\"regionName\":\"石泉县\"},{\"id\":\"140099\",\"regionName\":\"旬阳县\"},{\"id\":\"140098\",\"regionName\":\"镇坪县\"},{\"id\":\"140095\",\"regionName\":\"紫阳县\"}]";
		}
		else if("13037".equals(id))
		{
			return "[{\"id\":\"140031\",\"regionName\":\"滨区\"},{\"id\":\"140033\",\"regionName\":\"陈仓区\"},{\"id\":\"1400311\",\"regionName\":\"凤　县\"},{\"id\":\"140036\",\"regionName\":\"扶风县\"},{\"id\":\"140034\",\"regionName\":\"凤翔县\"},{\"id\":\"140032\",\"regionName\":\"金台区\"},{\"id\":\"1400310\",\"regionName\":\"麟游县\"},{\"id\":\"140038\",\"regionName\":\"陇　县\"},{\"id\":\"140037\",\"regionName\":\"眉　县\"},{\"id\":\"140039\",\"regionName\":\"千阳县\"},{\"id\":\"140035\",\"regionName\":\"岐山县\"},{\"id\":\"1400312\",\"regionName\":\"太白县\"}]";
		}
		else if("13041".equals(id))
		{
			return "[{\"id\":\"140073\",\"regionName\":\"城固县\"},{\"id\":\"1400711\",\"regionName\":\"佛坪县\"},{\"id\":\"140071\",\"regionName\":\"汉台区\"},{\"id\":\"1400710\",\"regionName\":\"留坝县\"},{\"id\":\"140078\",\"regionName\":\"略阳县\"},{\"id\":\"140076\",\"regionName\":\"勉　县\"},{\"id\":\"140077\",\"regionName\":\"宁强县\"},{\"id\":\"140072\",\"regionName\":\"南郑县\"},{\"id\":\"140075\",\"regionName\":\"西乡县\"},{\"id\":\"140074\",\"regionName\":\"洋　县\"},{\"id\":\"140079\",\"regionName\":\"镇巴县\"}]";
		}
		else if("13044".equals(id))
		{
			return "[{\"id\":\"140103\",\"regionName\":\"丹凤县\"},{\"id\":\"140102\",\"regionName\":\"洛南县\"},{\"id\":\"140105\",\"regionName\":\"山阳县\"},{\"id\":\"140104\",\"regionName\":\"商南县\"},{\"id\":\"140101\",\"regionName\":\"商州区\"},{\"id\":\"140107\",\"regionName\":\"柞水县\"},{\"id\":\"140106\",\"regionName\":\"镇安县\"}]";
		}
		else if("13036".equals(id))
		{
			return "[{\"id\":\"140021\",\"regionName\":\"王益区\"},{\"id\":\"140024\",\"regionName\":\"宜君县\"},{\"id\":\"140023\",\"regionName\":\"耀州区\"},{\"id\":\"140022\",\"regionName\":\"印台区\"}]";
		}
		else if("13039".equals(id))
		{
			return "[{\"id\":\"140058\",\"regionName\":\"白水县\"},{\"id\":\"140056\",\"regionName\":\"澄城县\"},{\"id\":\"140054\",\"regionName\":\"大荔县\"},{\"id\":\"140059\",\"regionName\":\"富平县\"},{\"id\":\"1400511\",\"regionName\":\"华阴市\"},{\"id\":\"1400510\",\"regionName\":\"韩城市\"},{\"id\":\"140055\",\"regionName\":\"合阳县\"},{\"id\":\"140052\",\"regionName\":\"华　县\"},{\"id\":\"140051\",\"regionName\":\"临渭区\"},{\"id\":\"140057\",\"regionName\":\"蒲城县\"},{\"id\":\"140053\",\"regionName\":\"潼关县\"}]";
		}
		else if("13038".equals(id))
		{
			return "[{\"id\":\"140049\",\"regionName\":\"彬　县\"},{\"id\":\"1400412\",\"regionName\":\"淳化县\"},{\"id\":\"140045\",\"regionName\":\"泾阳县\"},{\"id\":\"140047\",\"regionName\":\"礼泉县\"},{\"id\":\"140046\",\"regionName\":\"乾　县\"},{\"id\":\"140041\",\"regionName\":\"秦都区\"},{\"id\":\"140044\",\"regionName\":\"三原县\"},{\"id\":\"1400413\",\"regionName\":\"武功县\"},{\"id\":\"140043\",\"regionName\":\"渭城区\"},{\"id\":\"1400414\",\"regionName\":\"兴平市\"},{\"id\":\"1400411\",\"regionName\":\"旬邑县\"},{\"id\":\"140048\",\"regionName\":\"永寿县\"},{\"id\":\"140042\",\"regionName\":\"杨凌区\"},{\"id\":\"1400410\",\"regionName\":\"长武县\"}]";
		}
		else if("13035".equals(id))
		{
			return "[{\"id\":\"140014\",\"regionName\":\"灞桥区\"},{\"id\":\"140012\",\"regionName\":\"碑林区\"},{\"id\":\"1400113\",\"regionName\":\"高陵县\"},{\"id\":\"1400112\",\"regionName\":\"户　县\"},{\"id\":\"1400110\",\"regionName\":\"蓝田县\"},{\"id\":\"140018\",\"regionName\":\"临潼区\"},{\"id\":\"140013\",\"regionName\":\"莲湖区\"},{\"id\":\"140015\",\"regionName\":\"未央区\"},{\"id\":\"140011\",\"regionName\":\"新城区\"},{\"id\":\"140017\",\"regionName\":\"阎良区\"},{\"id\":\"140016\",\"regionName\":\"雁塔区\"},{\"id\":\"1400111\",\"regionName\":\"周至县\"},{\"id\":\"140019\",\"regionName\":\"长安区\"}]";
		}
		else if("13042".equals(id))
		{
			return "[{\"id\":\"140086\",\"regionName\":\"定边县\"},{\"id\":\"140083\",\"regionName\":\"府谷县\"},{\"id\":\"140084\",\"regionName\":\"横山县\"},{\"id\":\"140089\",\"regionName\":\"佳　县\"},{\"id\":\"140085\",\"regionName\":\"靖边县\"},{\"id\":\"140088\",\"regionName\":\"米脂县\"},{\"id\":\"1400811\",\"regionName\":\"清涧县\"},{\"id\":\"140087\",\"regionName\":\"绥德县\"},{\"id\":\"140082\",\"regionName\":\"神木县\"},{\"id\":\"1400810\",\"regionName\":\"吴堡县\"},{\"id\":\"140081\",\"regionName\":\"榆阳区\"},{\"id\":\"1400812\",\"regionName\":\"子洲县\"}]";
		}
		else if("13040".equals(id))
		{
			return "[{\"id\":\"140065\",\"regionName\":\"安塞县\"},{\"id\":\"140061\",\"regionName\":\"宝塔区\"},{\"id\":\"140069\",\"regionName\":\"富　县\"},{\"id\":\"140068\",\"regionName\":\"甘泉县\"},{\"id\":\"1400613\",\"regionName\":\"黄陵县\"},{\"id\":\"1400612\",\"regionName\":\"黄龙县\"},{\"id\":\"1400610\",\"regionName\":\"洛川县\"},{\"id\":\"140067\",\"regionName\":\"吴旗县\"},{\"id\":\"1400611\",\"regionName\":\"宜川县\"},{\"id\":\"140063\",\"regionName\":\"延川县\"},{\"id\":\"140062\",\"regionName\":\"延长县\"},{\"id\":\"140066\",\"regionName\":\"志丹县\"},{\"id\":\"140064\",\"regionName\":\"子长县\"}]";
		}
		else if("23".equals(id))
		{
			return "[{\"id\":\"11053\",\"regionName\":\"阿坝藏族羌族自治州\"},{\"id\":\"11051\",\"regionName\":\"巴中市\"},{\"id\":\"11035\",\"regionName\":\"成都市\"},{\"id\":\"11049\",\"regionName\":\"达州市\"},{\"id\":\"11039\",\"regionName\":\"德阳市\"},{\"id\":\"11054\",\"regionName\":\"甘孜藏族自治州\"},{\"id\":\"11048\",\"regionName\":\"广安市\"},{\"id\":\"11041\",\"regionName\":\"广元市\"},{\"id\":\"11055\",\"regionName\":\"凉山彝族自治州\"},{\"id\":\"11044\",\"regionName\":\"乐山市\"},{\"id\":\"11038\",\"regionName\":\"泸州市\"},{\"id\":\"11046\",\"regionName\":\"眉山市\"},{\"id\":\"11040\",\"regionName\":\"绵阳市\"},{\"id\":\"11045\",\"regionName\":\"南充市\"},{\"id\":\"11043\",\"regionName\":\"内江市\"},{\"id\":\"11037\",\"regionName\":\"攀枝花市\"},{\"id\":\"11042\",\"regionName\":\"遂宁市\"},{\"id\":\"11050\",\"regionName\":\"雅安市\"},{\"id\":\"11047\",\"regionName\":\"宜宾市\"},{\"id\":\"11052\",\"regionName\":\"资阳市\"},{\"id\":\"11036\",\"regionName\":\"自贡市\"}]";
		}
		else if("11053".equals(id))
		{
			return "[{\"id\":\"1201911\",\"regionName\":\"阿坝县\"},{\"id\":\"1201913\",\"regionName\":\"红原县\"},{\"id\":\"120198\",\"regionName\":\"黑水县\"},{\"id\":\"120196\",\"regionName\":\"金川县\"},{\"id\":\"120195\",\"regionName\":\"九寨沟县\"},{\"id\":\"120192\",\"regionName\":\"理　县\"},{\"id\":\"120199\",\"regionName\":\"马尔康县\"},{\"id\":\"120193\",\"regionName\":\"茂　县\"},{\"id\":\"1201912\",\"regionName\":\"若尔盖县\"},{\"id\":\"1201910\",\"regionName\":\"壤塘县\"},{\"id\":\"120194\",\"regionName\":\"松潘县\"},{\"id\":\"120191\",\"regionName\":\"汶川县\"},{\"id\":\"120197\",\"regionName\":\"小金县\"}]";
		}
		else if("11051".equals(id))
		{
			return "[{\"id\":\"120171\",\"regionName\":\"巴州区\"},{\"id\":\"120173\",\"regionName\":\"南江县\"},{\"id\":\"120174\",\"regionName\":\"平昌县\"},{\"id\":\"120172\",\"regionName\":\"通江县\"}]";
		}
		else if("11035".equals(id))
		{
			return "[{\"id\":\"1200119\",\"regionName\":\"崇州市\"},{\"id\":\"120015\",\"regionName\":\"成华区\"},{\"id\":\"1200116\",\"regionName\":\"都江堰市\"},{\"id\":\"1200113\",\"regionName\":\"大邑县\"},{\"id\":\"1200110\",\"regionName\":\"金堂县\"},{\"id\":\"120013\",\"regionName\":\"金牛区\"},{\"id\":\"120011\",\"regionName\":\"锦江区\"},{\"id\":\"120016\",\"regionName\":\"龙泉驿区\"},{\"id\":\"1200117\",\"regionName\":\"彭州市\"},{\"id\":\"1200114\",\"regionName\":\"蒲江县\"},{\"id\":\"1200112\",\"regionName\":\"郫　县\"},{\"id\":\"1200118\",\"regionName\":\"邛崃市\"},{\"id\":\"120017\",\"regionName\":\"青白江区\"},{\"id\":\"120012\",\"regionName\":\"青羊区\"},{\"id\":\"1200111\",\"regionName\":\"双流县\"},{\"id\":\"120019\",\"regionName\":\"温江区\"},{\"id\":\"120014\",\"regionName\":\"武侯区\"},{\"id\":\"1200115\",\"regionName\":\"新津县\"},{\"id\":\"120018\",\"regionName\":\"新都区\"}]";
		}
		else if("11049".equals(id))
		{
			return "[{\"id\":\"120155\",\"regionName\":\"大竹县\"},{\"id\":\"120152\",\"regionName\":\"达　县\"},{\"id\":\"120154\",\"regionName\":\"开江县\"},{\"id\":\"120156\",\"regionName\":\"渠　县\"},{\"id\":\"120151\",\"regionName\":\"通川区\"},{\"id\":\"120157\",\"regionName\":\"万源市\"},{\"id\":\"120153\",\"regionName\":\"宣汉县\"}]";
		}
		else if("11039".equals(id))
		{
			return "[{\"id\":\"120054\",\"regionName\":\"广汉市\"},{\"id\":\"120051\",\"regionName\":\"旌阳区\"},{\"id\":\"120053\",\"regionName\":\"罗江县\"},{\"id\":\"120056\",\"regionName\":\"绵竹市\"},{\"id\":\"120055\",\"regionName\":\"什邡市\"},{\"id\":\"120052\",\"regionName\":\"中江县\"}]";
		}
		else if("11054".equals(id))
		{
			return "[{\"id\":\"1202015\",\"regionName\":\"巴塘县\"},{\"id\":\"1202011\",\"regionName\":\"白玉县\"},{\"id\":\"1202018\",\"regionName\":\"得荣县\"},{\"id\":\"1202017\",\"regionName\":\"稻城县\"},{\"id\":\"1202010\",\"regionName\":\"德格县\"},{\"id\":\"120206\",\"regionName\":\"道孚县\"},{\"id\":\"120203\",\"regionName\":\"丹巴县\"},{\"id\":\"120208\",\"regionName\":\"甘孜县\"},{\"id\":\"120204\",\"regionName\":\"九龙县\"},{\"id\":\"120201\",\"regionName\":\"康定县\"},{\"id\":\"1202014\",\"regionName\":\"理塘县\"},{\"id\":\"120207\",\"regionName\":\"炉霍县\"},{\"id\":\"120202\",\"regionName\":\"泸定县\"},{\"id\":\"1202013\",\"regionName\":\"色达县\"},{\"id\":\"1202012\",\"regionName\":\"石渠县\"},{\"id\":\"1202016\",\"regionName\":\"乡城县\"},{\"id\":\"120209\",\"regionName\":\"新龙县\"},{\"id\":\"120205\",\"regionName\":\"雅江县\"}]";
		}
		else if("11048".equals(id))
		{
			return "[{\"id\":\"120141\",\"regionName\":\"广安区\"},{\"id\":\"120145\",\"regionName\":\"华莹市\"},{\"id\":\"120144\",\"regionName\":\"邻水县\"},{\"id\":\"120143\",\"regionName\":\"武胜县\"},{\"id\":\"120142\",\"regionName\":\"岳池县\"}]";
		}
		else if("11041".equals(id))
		{
			return "[{\"id\":\"120077\",\"regionName\":\"苍溪县\"},{\"id\":\"120073\",\"regionName\":\"朝天区\"},{\"id\":\"120076\",\"regionName\":\"剑阁县\"},{\"id\":\"120075\",\"regionName\":\"青川县\"},{\"id\":\"120071\",\"regionName\":\"市中区\"},{\"id\":\"120074\",\"regionName\":\"旺苍县\"},{\"id\":\"120072\",\"regionName\":\"元坝区\"}]";
		}
		else if("11055".equals(id))
		{
			return "[{\"id\":\"120219\",\"regionName\":\"布拖县\"},{\"id\":\"120214\",\"regionName\":\"德昌县\"},{\"id\":\"1202115\",\"regionName\":\"甘洛县\"},{\"id\":\"120216\",\"regionName\":\"会东县\"},{\"id\":\"120215\",\"regionName\":\"会理县\"},{\"id\":\"1202110\",\"regionName\":\"金阳县\"},{\"id\":\"1202117\",\"regionName\":\"雷波县\"},{\"id\":\"1202116\",\"regionName\":\"美姑县\"},{\"id\":\"1202113\",\"regionName\":\"冕宁县\"},{\"id\":\"120212\",\"regionName\":\"木里藏族自治县\"},{\"id\":\"120217\",\"regionName\":\"宁南县\"},{\"id\":\"120218\",\"regionName\":\"普格县\"},{\"id\":\"1202112\",\"regionName\":\"喜德县\"},{\"id\":\"120211\",\"regionName\":\"西昌市\"},{\"id\":\"1202114\",\"regionName\":\"越西县\"},{\"id\":\"120213\",\"regionName\":\"盐源县\"},{\"id\":\"1202111\",\"regionName\":\"昭觉县\"}]";
		}
		else if("11044".equals(id))
		{
			return "[{\"id\":\"1201011\",\"regionName\":\"峨眉山市\"},{\"id\":\"120109\",\"regionName\":\"峨边彝族自治县\"},{\"id\":\"120107\",\"regionName\":\"夹江县\"},{\"id\":\"120106\",\"regionName\":\"井研县\"},{\"id\":\"120105\",\"regionName\":\"犍为县\"},{\"id\":\"120104\",\"regionName\":\"金口河区\"},{\"id\":\"1201010\",\"regionName\":\"马边彝族自治县\"},{\"id\":\"120108\",\"regionName\":\"沐川县\"},{\"id\":\"120102\",\"regionName\":\"沙湾区\"},{\"id\":\"120101\",\"regionName\":\"市中区\"},{\"id\":\"120103\",\"regionName\":\"五通桥区\"}]";
		}
		else if("11038".equals(id))
		{
			return "[{\"id\":\"120047\",\"regionName\":\"古蔺县\"},{\"id\":\"120045\",\"regionName\":\"合江县\"},{\"id\":\"120041\",\"regionName\":\"江阳区\"},{\"id\":\"120044\",\"regionName\":\"泸　县\"},{\"id\":\"120043\",\"regionName\":\"龙马潭区\"},{\"id\":\"120042\",\"regionName\":\"纳溪区\"},{\"id\":\"120046\",\"regionName\":\"叙永县\"}]";
		}
		else if("11046".equals(id))
		{
			return "[{\"id\":\"120125\",\"regionName\":\"丹棱县\"},{\"id\":\"120121\",\"regionName\":\"东坡区\"},{\"id\":\"120124\",\"regionName\":\"洪雅县\"},{\"id\":\"120123\",\"regionName\":\"彭山县\"},{\"id\":\"120126\",\"regionName\":\"青神县\"},{\"id\":\"120122\",\"regionName\":\"仁寿县\"}]";
		}
		else if("11040".equals(id))
		{
			return "[{\"id\":\"120065\",\"regionName\":\"安　县\"},{\"id\":\"120067\",\"regionName\":\"北川羌族自治县\"},{\"id\":\"120061\",\"regionName\":\"涪城区\"},{\"id\":\"120069\",\"regionName\":\"江油市\"},{\"id\":\"120068\",\"regionName\":\"平武县\"},{\"id\":\"120063\",\"regionName\":\"三台县\"},{\"id\":\"120064\",\"regionName\":\"盐亭县\"},{\"id\":\"120062\",\"regionName\":\"游仙区\"},{\"id\":\"120066\",\"regionName\":\"梓潼县\"}]";
		}
		else if("11045".equals(id))
		{
			return "[{\"id\":\"120112\",\"regionName\":\"高坪区\"},{\"id\":\"120113\",\"regionName\":\"嘉陵区\"},{\"id\":\"120119\",\"regionName\":\"阆中市\"},{\"id\":\"120114\",\"regionName\":\"南部县\"},{\"id\":\"120116\",\"regionName\":\"蓬安县\"},{\"id\":\"120111\",\"regionName\":\"顺庆区\"},{\"id\":\"120118\",\"regionName\":\"西充县\"},{\"id\":\"120117\",\"regionName\":\"仪陇县\"},{\"id\":\"120115\",\"regionName\":\"营山县\"}]";
		}
		else if("11043".equals(id))
		{
			return "[{\"id\":\"120092\",\"regionName\":\"东兴区\"},{\"id\":\"120095\",\"regionName\":\"隆昌县\"},{\"id\":\"120091\",\"regionName\":\"市中区\"},{\"id\":\"120093\",\"regionName\":\"威远县\"},{\"id\":\"120094\",\"regionName\":\"资中县\"}]";
		}
		else if("11037".equals(id))
		{
			return "[{\"id\":\"120031\",\"regionName\":\"东　区\"},{\"id\":\"120034\",\"regionName\":\"米易县\"},{\"id\":\"120033\",\"regionName\":\"仁和区\"},{\"id\":\"120032\",\"regionName\":\"西　区\"},{\"id\":\"120035\",\"regionName\":\"盐边县\"}]";
		}
		else if("11042".equals(id))
		{
			return "[{\"id\":\"120082\",\"regionName\":\"安居区\"},{\"id\":\"120081\",\"regionName\":\"船山区\"},{\"id\":\"120085\",\"regionName\":\"大英县\"},{\"id\":\"120083\",\"regionName\":\"蓬溪县\"},{\"id\":\"120084\",\"regionName\":\"射洪县\"}]";
		}
		else if("11050".equals(id))
		{
			return "[{\"id\":\"120168\",\"regionName\":\"宝兴县\"},{\"id\":\"120164\",\"regionName\":\"汉源县\"},{\"id\":\"120167\",\"regionName\":\"芦山县\"},{\"id\":\"120162\",\"regionName\":\"名山县\"},{\"id\":\"120165\",\"regionName\":\"石棉县\"},{\"id\":\"120166\",\"regionName\":\"天全县\"},{\"id\":\"120163\",\"regionName\":\"荥经县\"},{\"id\":\"120161\",\"regionName\":\"雨城区\"}]";
		}
		else if("11047".equals(id))
		{
			return "[{\"id\":\"120131\",\"regionName\":\"翠屏区\"},{\"id\":\"120137\",\"regionName\":\"珙　县\"},{\"id\":\"120136\",\"regionName\":\"高　县\"},{\"id\":\"120134\",\"regionName\":\"江安县\"},{\"id\":\"120133\",\"regionName\":\"南溪县\"},{\"id\":\"1201310\",\"regionName\":\"屏山县\"},{\"id\":\"120139\",\"regionName\":\"兴文县\"},{\"id\":\"120138\",\"regionName\":\"筠连县\"},{\"id\":\"120132\",\"regionName\":\"宜宾县\"},{\"id\":\"120135\",\"regionName\":\"长宁县\"}]";
		}
		else if("11052".equals(id))
		{
			return "[{\"id\":\"120182\",\"regionName\":\"安岳县\"},{\"id\":\"120184\",\"regionName\":\"简阳市\"},{\"id\":\"120183\",\"regionName\":\"乐至县\"},{\"id\":\"120181\",\"regionName\":\"雁江区\"}]";
		}
		else if("11036".equals(id))
		{
			return "[{\"id\":\"120023\",\"regionName\":\"大安区\"},{\"id\":\"120026\",\"regionName\":\"富顺县\"},{\"id\":\"120022\",\"regionName\":\"贡井区\"},{\"id\":\"120025\",\"regionName\":\"荣　县\"},{\"id\":\"120024\",\"regionName\":\"沿滩区\"},{\"id\":\"120021\",\"regionName\":\"自流井区\"}]";
		}
		else if("15".equals(id))
		{
			return "[{\"id\":\"7049\",\"regionName\":\"滨州市\"},{\"id\":\"7047\",\"regionName\":\"德州市\"},{\"id\":\"7050\",\"regionName\":\"荷泽市\"},{\"id\":\"7041\",\"regionName\":\"济宁市\"},{\"id\":\"7035\",\"regionName\":\"济南市\"},{\"id\":\"7048\",\"regionName\":\"聊城市\"},{\"id\":\"7046\",\"regionName\":\"临沂市\"},{\"id\":\"7045\",\"regionName\":\"莱芜市\"},{\"id\":\"7036\",\"regionName\":\"青岛市\"},{\"id\":\"7044\",\"regionName\":\"日照市\"},{\"id\":\"7042\",\"regionName\":\"泰安市\"},{\"id\":\"7043\",\"regionName\":\"威海市\"},{\"id\":\"7040\",\"regionName\":\"潍坊市\"},{\"id\":\"7039\",\"regionName\":\"烟台市\"},{\"id\":\"7038\",\"regionName\":\"枣庄市\"},{\"id\":\"7037\",\"regionName\":\"淄博市\"}]";
		}
		else if("7049".equals(id))
		{
			return "[{\"id\":\"80156\",\"regionName\":\"博兴县\"},{\"id\":\"80151\",\"regionName\":\"滨城区\"},{\"id\":\"80152\",\"regionName\":\"惠民县\"},{\"id\":\"80154\",\"regionName\":\"无棣县\"},{\"id\":\"80153\",\"regionName\":\"阳信县\"},{\"id\":\"80157\",\"regionName\":\"邹平县\"},{\"id\":\"80155\",\"regionName\":\"沾化县\"}]";
		}
		else if("7047".equals(id))
		{
			return "[{\"id\":\"80131\",\"regionName\":\"德城区\"},{\"id\":\"801310\",\"regionName\":\"乐陵市\"},{\"id\":\"80135\",\"regionName\":\"临邑县\"},{\"id\":\"80132\",\"regionName\":\"陵　县\"},{\"id\":\"80133\",\"regionName\":\"宁津县\"},{\"id\":\"80137\",\"regionName\":\"平原县\"},{\"id\":\"80136\",\"regionName\":\"齐河县\"},{\"id\":\"80134\",\"regionName\":\"庆云县\"},{\"id\":\"80139\",\"regionName\":\"武城县\"},{\"id\":\"80138\",\"regionName\":\"夏津县\"},{\"id\":\"801311\",\"regionName\":\"禹城市\"}]";
		}
		else if("7050".equals(id))
		{
			return "[{\"id\":\"80164\",\"regionName\":\"成武县\"},{\"id\":\"80162\",\"regionName\":\"曹　县\"},{\"id\":\"80169\",\"regionName\":\"东明县\"},{\"id\":\"80168\",\"regionName\":\"定陶县\"},{\"id\":\"80163\",\"regionName\":\"单　县\"},{\"id\":\"80167\",\"regionName\":\"鄄城县\"},{\"id\":\"80165\",\"regionName\":\"巨野县\"},{\"id\":\"80161\",\"regionName\":\"牡丹区\"},{\"id\":\"80166\",\"regionName\":\"郓城县\"}]";
		}
		else if("7041".equals(id))
		{
			return "[{\"id\":\"80076\",\"regionName\":\"嘉祥县\"},{\"id\":\"80075\",\"regionName\":\"金乡县\"},{\"id\":\"80079\",\"regionName\":\"梁山县\"},{\"id\":\"800710\",\"regionName\":\"曲阜市\"},{\"id\":\"80072\",\"regionName\":\"任城区\"},{\"id\":\"80078\",\"regionName\":\"泗水县\"},{\"id\":\"80071\",\"regionName\":\"市中区\"},{\"id\":\"80077\",\"regionName\":\"汶上县\"},{\"id\":\"80073\",\"regionName\":\"微山县\"},{\"id\":\"800711\",\"regionName\":\"兖州市\"},{\"id\":\"80074\",\"regionName\":\"鱼台县\"},{\"id\":\"800712\",\"regionName\":\"邹城市\"}]";
		}
		else if("7035".equals(id))
		{
			return "[{\"id\":\"80013\",\"regionName\":\"槐荫区\"},{\"id\":\"80018\",\"regionName\":\"济阳县\"},{\"id\":\"80015\",\"regionName\":\"历城区\"},{\"id\":\"80011\",\"regionName\":\"历下区\"},{\"id\":\"80017\",\"regionName\":\"平阴县\"},{\"id\":\"80019\",\"regionName\":\"商河县\"},{\"id\":\"80012\",\"regionName\":\"市中区\"},{\"id\":\"80014\",\"regionName\":\"天桥区\"},{\"id\":\"800110\",\"regionName\":\"章丘市\"},{\"id\":\"80016\",\"regionName\":\"长清区\"}]";
		}
		else if("7048".equals(id))
		{
			return "[{\"id\":\"80144\",\"regionName\":\"茌平县\"},{\"id\":\"80145\",\"regionName\":\"东阿县\"},{\"id\":\"80141\",\"regionName\":\"东昌府区\"},{\"id\":\"80147\",\"regionName\":\"高唐县\"},{\"id\":\"80146\",\"regionName\":\"冠　县\"},{\"id\":\"80148\",\"regionName\":\"临清市\"},{\"id\":\"80143\",\"regionName\":\"莘　县\"},{\"id\":\"80142\",\"regionName\":\"阳谷县\"}]";
		}
		else if("7046".equals(id))
		{
			return "[{\"id\":\"80127\",\"regionName\":\"苍山县\"},{\"id\":\"80128\",\"regionName\":\"费　县\"},{\"id\":\"80123\",\"regionName\":\"河东区\"},{\"id\":\"801210\",\"regionName\":\"莒南县\"},{\"id\":\"801212\",\"regionName\":\"临沭县\"},{\"id\":\"80122\",\"regionName\":\"罗庄区\"},{\"id\":\"80121\",\"regionName\":\"兰山区\"},{\"id\":\"801211\",\"regionName\":\"蒙阴县\"},{\"id\":\"80129\",\"regionName\":\"平邑县\"},{\"id\":\"80125\",\"regionName\":\"郯城县\"},{\"id\":\"80126\",\"regionName\":\"沂水县\"},{\"id\":\"80124\",\"regionName\":\"沂南县\"}]";
		}
		else if("7045".equals(id))
		{
			return "[{\"id\":\"80112\",\"regionName\":\"钢城区\"},{\"id\":\"80111\",\"regionName\":\"莱城区\"}]";
		}
		else if("7036".equals(id))
		{
			return "[{\"id\":\"80027\",\"regionName\":\"城阳区\"},{\"id\":\"80024\",\"regionName\":\"黄岛区\"},{\"id\":\"800211\",\"regionName\":\"胶南市\"},{\"id\":\"80029\",\"regionName\":\"即墨市\"},{\"id\":\"80028\",\"regionName\":\"胶州市\"},{\"id\":\"800212\",\"regionName\":\"莱西市\"},{\"id\":\"80026\",\"regionName\":\"李沧区\"},{\"id\":\"80025\",\"regionName\":\"崂山区\"},{\"id\":\"800210\",\"regionName\":\"平度市\"},{\"id\":\"80023\",\"regionName\":\"四方区\"},{\"id\":\"80022\",\"regionName\":\"市北区\"},{\"id\":\"80021\",\"regionName\":\"市南区\"}]";
		}
		else if("7044".equals(id))
		{
			return "[{\"id\":\"80101\",\"regionName\":\"东港区\"},{\"id\":\"80104\",\"regionName\":\"莒　县\"},{\"id\":\"80102\",\"regionName\":\"岚山区\"},{\"id\":\"80103\",\"regionName\":\"五莲县\"}]";
		}
		else if("7042".equals(id))
		{
			return "[{\"id\":\"80084\",\"regionName\":\"东平县\"},{\"id\":\"80082\",\"regionName\":\"岱岳区\"},{\"id\":\"80086\",\"regionName\":\"肥城市\"},{\"id\":\"80083\",\"regionName\":\"宁阳县\"},{\"id\":\"80081\",\"regionName\":\"泰山区\"},{\"id\":\"80085\",\"regionName\":\"新泰市\"}]";
		}
		else if("7043".equals(id))
		{
			return "[{\"id\":\"80091\",\"regionName\":\"环翠区\"},{\"id\":\"80094\",\"regionName\":\"乳山市\"},{\"id\":\"80093\",\"regionName\":\"荣成市\"},{\"id\":\"80092\",\"regionName\":\"文登市\"}]";
		}
		else if("7040".equals(id))
		{
			return "[{\"id\":\"800610\",\"regionName\":\"安丘市\"},{\"id\":\"800612\",\"regionName\":\"昌邑市\"},{\"id\":\"80066\",\"regionName\":\"昌乐县\"},{\"id\":\"80063\",\"regionName\":\"坊子区\"},{\"id\":\"800611\",\"regionName\":\"高密市\"},{\"id\":\"80062\",\"regionName\":\"寒亭区\"},{\"id\":\"80064\",\"regionName\":\"奎文区\"},{\"id\":\"80065\",\"regionName\":\"临朐县\"},{\"id\":\"80067\",\"regionName\":\"青州市\"},{\"id\":\"80069\",\"regionName\":\"寿光市\"},{\"id\":\"80061\",\"regionName\":\"潍城区\"},{\"id\":\"80068\",\"regionName\":\"诸城市\"}]";
		}
		else if("7039".equals(id))
		{
			return "[{\"id\":\"80052\",\"regionName\":\"福山区\"},{\"id\":\"800512\",\"regionName\":\"海阳市\"},{\"id\":\"80058\",\"regionName\":\"莱州市\"},{\"id\":\"80057\",\"regionName\":\"莱阳市\"},{\"id\":\"80056\",\"regionName\":\"龙口市\"},{\"id\":\"80054\",\"regionName\":\"莱山区\"},{\"id\":\"80053\",\"regionName\":\"牟平区\"},{\"id\":\"80059\",\"regionName\":\"蓬莱市\"},{\"id\":\"800511\",\"regionName\":\"栖霞市\"},{\"id\":\"800510\",\"regionName\":\"招远市\"},{\"id\":\"80055\",\"regionName\":\"长岛县\"},{\"id\":\"80051\",\"regionName\":\"芝罘区\"}]";
		}
		else if("7038".equals(id))
		{
			return "[{\"id\":\"80045\",\"regionName\":\"山亭区\"},{\"id\":\"80041\",\"regionName\":\"市中区\"},{\"id\":\"80046\",\"regionName\":\"滕州市\"},{\"id\":\"80044\",\"regionName\":\"台儿庄区\"},{\"id\":\"80042\",\"regionName\":\"薛城区\"},{\"id\":\"80043\",\"regionName\":\"峄城区\"}]";
		}
		else if("7037".equals(id))
		{
			return "[{\"id\":\"80033\",\"regionName\":\"博山区\"},{\"id\":\"80037\",\"regionName\":\"高青县\"},{\"id\":\"80036\",\"regionName\":\"桓台县\"},{\"id\":\"80034\",\"regionName\":\"临淄区\"},{\"id\":\"80038\",\"regionName\":\"沂源县\"},{\"id\":\"80035\",\"regionName\":\"周村区\"},{\"id\":\"80032\",\"regionName\":\"张店区\"},{\"id\":\"80031\",\"regionName\":\"淄川区\"}]";
		}
		else if("9".equals(id))
		{
			return "[{\"id\":\"4045\",\"regionName\":\"宝山区\"},{\"id\":\"4053\",\"regionName\":\"崇明县\"},{\"id\":\"4052\",\"regionName\":\"奉贤区\"},{\"id\":\"4042\",\"regionName\":\"虹口区\"},{\"id\":\"4035\",\"regionName\":\"黄浦区\"},{\"id\":\"4048\",\"regionName\":\"金山区\"},{\"id\":\"4046\",\"regionName\":\"嘉定区\"},{\"id\":\"4039\",\"regionName\":\"静安区\"},{\"id\":\"4036\",\"regionName\":\"卢湾区\"},{\"id\":\"4044\",\"regionName\":\"闵行区\"},{\"id\":\"4051\",\"regionName\":\"南汇区\"},{\"id\":\"4047\",\"regionName\":\"浦东新区\"},{\"id\":\"4040\",\"regionName\":\"普陀区\"},{\"id\":\"4050\",\"regionName\":\"青浦区\"},{\"id\":\"4049\",\"regionName\":\"松江区\"},{\"id\":\"4037\",\"regionName\":\"徐汇区\"},{\"id\":\"4043\",\"regionName\":\"杨浦区\"},{\"id\":\"4041\",\"regionName\":\"闸北区\"},{\"id\":\"4038\",\"regionName\":\"长宁区\"}]";
		}
		else if("4045".equals(id))
		{
			return "[]";
		}
		else if("4053".equals(id))
		{
			return "[]";
		}
		else if("4052".equals(id))
		{
			return "[]";
		}
		else if("4042".equals(id))
		{
			return "[]";
		}
		else if("4035".equals(id))
		{
			return "[]";
		}
		else if("4048".equals(id))
		{
			return "[]";
		}
		else if("4046".equals(id))
		{
			return "[]";
		}
		else if("4039".equals(id))
		{
			return "[]";
		}
		else if("4036".equals(id))
		{
			return "[]";
		}
		else if("4044".equals(id))
		{
			return "[]";
		}
		else if("4051".equals(id))
		{
			return "[]";
		}
		else if("4047".equals(id))
		{
			return "[]";
		}
		else if("4040".equals(id))
		{
			return "[]";
		}
		else if("4050".equals(id))
		{
			return "[]";
		}
		else if("4049".equals(id))
		{
			return "[]";
		}
		else if("4037".equals(id))
		{
			return "[]";
		}
		else if("4043".equals(id))
		{
			return "[]";
		}
		else if("4041".equals(id))
		{
			return "[]";
		}
		else if("4038".equals(id))
		{
			return "[]";
		}
		else if("4".equals(id))
		{
			return "[{\"id\":\"1536\",\"regionName\":\"大同市\"},{\"id\":\"1541\",\"regionName\":\"晋中市\"},{\"id\":\"1539\",\"regionName\":\"晋城市\"},{\"id\":\"1545\",\"regionName\":\"吕梁市\"},{\"id\":\"1544\",\"regionName\":\"临汾市\"},{\"id\":\"1540\",\"regionName\":\"朔州市\"},{\"id\":\"1535\",\"regionName\":\"太原市\"},{\"id\":\"1543\",\"regionName\":\"忻州市\"},{\"id\":\"1542\",\"regionName\":\"运城市\"},{\"id\":\"1537\",\"regionName\":\"阳泉市\"},{\"id\":\"1538\",\"regionName\":\"长治市\"}]";
		}
		else if("1536".equals(id))
		{
			return "[{\"id\":\"250210\",\"regionName\":\"城　区\"},{\"id\":\"25029\",\"regionName\":\"大同县\"},{\"id\":\"25025\",\"regionName\":\"广灵县\"},{\"id\":\"25027\",\"regionName\":\"浑源县\"},{\"id\":\"250211\",\"regionName\":\"矿　区\"},{\"id\":\"25026\",\"regionName\":\"灵丘县\"},{\"id\":\"250212\",\"regionName\":\"南郊区\"},{\"id\":\"25021\",\"regionName\":\"南郊区\"},{\"id\":\"25024\",\"regionName\":\"天镇县\"},{\"id\":\"25022\",\"regionName\":\"新荣区\"},{\"id\":\"25023\",\"regionName\":\"阳高县\"},{\"id\":\"25028\",\"regionName\":\"左云县\"}]";
		}
		else if("1541".equals(id))
		{
			return "[{\"id\":\"25074\",\"regionName\":\"和顺县\"},{\"id\":\"250711\",\"regionName\":\"介休市\"},{\"id\":\"250710\",\"regionName\":\"灵石县\"},{\"id\":\"25079\",\"regionName\":\"平遥县\"},{\"id\":\"25078\",\"regionName\":\"祁　县\"},{\"id\":\"25076\",\"regionName\":\"寿阳县\"},{\"id\":\"25077\",\"regionName\":\"太谷县\"},{\"id\":\"25075\",\"regionName\":\"昔阳县\"},{\"id\":\"25072\",\"regionName\":\"榆社县\"},{\"id\":\"25071\",\"regionName\":\"榆次区\"},{\"id\":\"25073\",\"regionName\":\"左权县\"}]";
		}
		else if("1539".equals(id))
		{
			return "[{\"id\":\"25051\",\"regionName\":\"城　区\"},{\"id\":\"25056\",\"regionName\":\"高平市\"},{\"id\":\"25054\",\"regionName\":\"陵川县\"},{\"id\":\"25052\",\"regionName\":\"沁水县\"},{\"id\":\"25053\",\"regionName\":\"阳城县\"},{\"id\":\"25055\",\"regionName\":\"泽州县\"}]";
		}
		else if("1545".equals(id))
		{
			return "[{\"id\":\"251113\",\"regionName\":\"汾阳市\"},{\"id\":\"25119\",\"regionName\":\"方山县\"},{\"id\":\"251111\",\"regionName\":\"交口县\"},{\"id\":\"25113\",\"regionName\":\"交城县\"},{\"id\":\"25118\",\"regionName\":\"岚　县\"},{\"id\":\"25116\",\"regionName\":\"柳林县\"},{\"id\":\"25115\",\"regionName\":\"临　县\"},{\"id\":\"25111\",\"regionName\":\"离石区\"},{\"id\":\"25117\",\"regionName\":\"石楼县\"},{\"id\":\"25112\",\"regionName\":\"文水县\"},{\"id\":\"251112\",\"regionName\":\"孝义市\"},{\"id\":\"25114\",\"regionName\":\"兴　县\"},{\"id\":\"251110\",\"regionName\":\"中阳县\"}]";
		}
		else if("1544".equals(id))
		{
			return "[{\"id\":\"25107\",\"regionName\":\"安泽县\"},{\"id\":\"251011\",\"regionName\":\"大宁县\"},{\"id\":\"251015\",\"regionName\":\"汾西县\"},{\"id\":\"25108\",\"regionName\":\"浮山县\"},{\"id\":\"25106\",\"regionName\":\"古　县\"},{\"id\":\"251017\",\"regionName\":\"霍州市\"},{\"id\":\"251016\",\"regionName\":\"侯马市\"},{\"id\":\"25105\",\"regionName\":\"洪洞县\"},{\"id\":\"25109\",\"regionName\":\"吉　县\"},{\"id\":\"251014\",\"regionName\":\"蒲　县\"},{\"id\":\"25102\",\"regionName\":\"曲沃县\"},{\"id\":\"251012\",\"regionName\":\"隰　县\"},{\"id\":\"251010\",\"regionName\":\"乡宁县\"},{\"id\":\"25104\",\"regionName\":\"襄汾县\"},{\"id\":\"251013\",\"regionName\":\"永和县\"},{\"id\":\"25103\",\"regionName\":\"翼城县\"},{\"id\":\"25101\",\"regionName\":\"尧都区\"}]";
		}
		else if("1540".equals(id))
		{
			return "[{\"id\":\"25066\",\"regionName\":\"怀仁县\"},{\"id\":\"25062\",\"regionName\":\"平鲁区\"},{\"id\":\"25063\",\"regionName\":\"山阴县\"},{\"id\":\"25061\",\"regionName\":\"朔城区\"},{\"id\":\"25065\",\"regionName\":\"右玉县\"},{\"id\":\"25064\",\"regionName\":\"应　县\"}]";
		}
		else if("1535".equals(id))
		{
			return "[{\"id\":\"250110\",\"regionName\":\"古交市\"},{\"id\":\"25016\",\"regionName\":\"晋源区\"},{\"id\":\"25014\",\"regionName\":\"尖草坪区\"},{\"id\":\"25019\",\"regionName\":\"娄烦县\"},{\"id\":\"25017\",\"regionName\":\"清徐县\"},{\"id\":\"25015\",\"regionName\":\"万柏林区\"},{\"id\":\"25013\",\"regionName\":\"杏花岭区\"},{\"id\":\"25011\",\"regionName\":\"小店区\"},{\"id\":\"25018\",\"regionName\":\"阳曲县\"},{\"id\":\"25012\",\"regionName\":\"迎泽区\"}]";
		}
		else if("1543".equals(id))
		{
			return "[{\"id\":\"250912\",\"regionName\":\"保德县\"},{\"id\":\"25094\",\"regionName\":\"代　县\"},{\"id\":\"25092\",\"regionName\":\"定襄县\"},{\"id\":\"25095\",\"regionName\":\"繁峙县\"},{\"id\":\"250911\",\"regionName\":\"河曲县\"},{\"id\":\"25097\",\"regionName\":\"静乐县\"},{\"id\":\"250910\",\"regionName\":\"岢岚县\"},{\"id\":\"25096\",\"regionName\":\"宁武县\"},{\"id\":\"250913\",\"regionName\":\"偏关县\"},{\"id\":\"25098\",\"regionName\":\"神池县\"},{\"id\":\"25099\",\"regionName\":\"五寨县\"},{\"id\":\"25093\",\"regionName\":\"五台县\"},{\"id\":\"25091\",\"regionName\":\"忻府区\"},{\"id\":\"250914\",\"regionName\":\"原平市\"}]";
		}
		else if("1542".equals(id))
		{
			return "[{\"id\":\"250813\",\"regionName\":\"河津市\"},{\"id\":\"25087\",\"regionName\":\"绛　县\"},{\"id\":\"25085\",\"regionName\":\"稷山县\"},{\"id\":\"25082\",\"regionName\":\"临猗县\"},{\"id\":\"250810\",\"regionName\":\"平陆县\"},{\"id\":\"250811\",\"regionName\":\"芮城县\"},{\"id\":\"25084\",\"regionName\":\"闻喜县\"},{\"id\":\"25083\",\"regionName\":\"万荣县\"},{\"id\":\"25089\",\"regionName\":\"夏　县\"},{\"id\":\"25086\",\"regionName\":\"新绛县\"},{\"id\":\"250812\",\"regionName\":\"永济市\"},{\"id\":\"25088\",\"regionName\":\"垣曲县\"},{\"id\":\"25081\",\"regionName\":\"盐湖区\"}]";
		}
		else if("1537".equals(id))
		{
			return "[{\"id\":\"25031\",\"regionName\":\"城　区\"},{\"id\":\"25033\",\"regionName\":\"郊　区\"},{\"id\":\"25032\",\"regionName\":\"矿　区\"},{\"id\":\"25034\",\"regionName\":\"平定县\"},{\"id\":\"25035\",\"regionName\":\"盂　县\"}]";
		}
		else if("1538".equals(id))
		{
			return "[{\"id\":\"25041\",\"regionName\":\"城　区\"},{\"id\":\"25048\",\"regionName\":\"壶关县\"},{\"id\":\"25042\",\"regionName\":\"郊　区\"},{\"id\":\"250413\",\"regionName\":\"潞城市\"},{\"id\":\"25047\",\"regionName\":\"黎城县\"},{\"id\":\"25046\",\"regionName\":\"平顺县\"},{\"id\":\"250412\",\"regionName\":\"沁源县\"},{\"id\":\"250411\",\"regionName\":\"沁　县\"},{\"id\":\"25045\",\"regionName\":\"屯留县\"},{\"id\":\"250410\",\"regionName\":\"武乡县\"},{\"id\":\"25044\",\"regionName\":\"襄垣县\"},{\"id\":\"25049\",\"regionName\":\"长子县\"},{\"id\":\"25043\",\"regionName\":\"长治县\"}]";
		}
		else if("32".equals(id))
		{
			return "[]";
		}
		else if("2".equals(id))
		{
			return "[{\"id\":\"549\",\"regionName\":\"宝坻区\"},{\"id\":\"547\",\"regionName\":\"北辰区\"},{\"id\":\"544\",\"regionName\":\"东丽区\"},{\"id\":\"543\",\"regionName\":\"大港区\"},{\"id\":\"542\",\"regionName\":\"汉沽区\"},{\"id\":\"540\",\"regionName\":\"红桥区\"},{\"id\":\"539\",\"regionName\":\"河北区\"},{\"id\":\"537\",\"regionName\":\"河西区\"},{\"id\":\"536\",\"regionName\":\"河东区\"},{\"id\":\"535\",\"regionName\":\"和平区\"},{\"id\":\"552\",\"regionName\":\"蓟　县\"},{\"id\":\"551\",\"regionName\":\"静海县\"},{\"id\":\"546\",\"regionName\":\"津南区\"},{\"id\":\"550\",\"regionName\":\"宁河县\"},{\"id\":\"538\",\"regionName\":\"南开区\"},{\"id\":\"541\",\"regionName\":\"塘沽区\"},{\"id\":\"548\",\"regionName\":\"武清区\"},{\"id\":\"545\",\"regionName\":\"西青区\"}]";
		}
		else if("549".equals(id))
		{
			return "[]";
		}
		else if("547".equals(id))
		{
			return "[]";
		}
		else if("544".equals(id))
		{
			return "[]";
		}
		else if("543".equals(id))
		{
			return "[]";
		}
		else if("542".equals(id))
		{
			return "[]";
		}
		else if("540".equals(id))
		{
			return "[]";
		}
		else if("539".equals(id))
		{
			return "[]";
		}
		else if("537".equals(id))
		{
			return "[]";
		}
		else if("536".equals(id))
		{
			return "[]";
		}
		else if("535".equals(id))
		{
			return "[]";
		}
		else if("552".equals(id))
		{
			return "[]";
		}
		else if("551".equals(id))
		{
			return "[]";
		}
		else if("546".equals(id))
		{
			return "[]";
		}
		else if("550".equals(id))
		{
			return "[]";
		}
		else if("538".equals(id))
		{
			return "[]";
		}
		else if("541".equals(id))
		{
			return "[]";
		}
		else if("548".equals(id))
		{
			return "[]";
		}
		else if("545".equals(id))
		{
			return "[]";
		}
		else if("31".equals(id))
		{
			return "[{\"id\":\"15048\",\"regionName\":\"阿勒泰地区\"},{\"id\":\"15042\",\"regionName\":\"阿克苏地区\"},{\"id\":\"15041\",\"regionName\":\"巴音郭楞蒙古自治州\"},{\"id\":\"15040\",\"regionName\":\"博尔塔拉蒙古自治州\"},{\"id\":\"15039\",\"regionName\":\"昌吉回族自治州\"},{\"id\":\"15045\",\"regionName\":\"和田地区\"},{\"id\":\"15038\",\"regionName\":\"哈密地区\"},{\"id\":\"15044\",\"regionName\":\"喀什地区\"},{\"id\":\"15043\",\"regionName\":\"克孜勒苏柯尔克孜自治州\"},{\"id\":\"15036\",\"regionName\":\"克拉玛依市\"},{\"id\":\"15049\",\"regionName\":\"省直辖行政单位\"},{\"id\":\"15047\",\"regionName\":\"塔城地区\"},{\"id\":\"15037\",\"regionName\":\"吐鲁番地区\"},{\"id\":\"15035\",\"regionName\":\"乌鲁木齐市\"},{\"id\":\"15046\",\"regionName\":\"伊犁哈萨克自治州\"}]";
		}
		else if("15048".equals(id))
		{
			return "[{\"id\":\"160141\",\"regionName\":\"阿勒泰市\"},{\"id\":\"160142\",\"regionName\":\"布尔津县\"},{\"id\":\"160144\",\"regionName\":\"福海县\"},{\"id\":\"160143\",\"regionName\":\"富蕴县\"},{\"id\":\"160145\",\"regionName\":\"哈巴河县\"},{\"id\":\"160147\",\"regionName\":\"吉木乃县\"},{\"id\":\"160146\",\"regionName\":\"青河县\"}]";
		}
		else if("15042".equals(id))
		{
			return "[{\"id\":\"160088\",\"regionName\":\"阿瓦提县\"},{\"id\":\"160081\",\"regionName\":\"阿克苏市\"},{\"id\":\"160086\",\"regionName\":\"拜城县\"},{\"id\":\"160089\",\"regionName\":\"柯坪县\"},{\"id\":\"160083\",\"regionName\":\"库车县\"},{\"id\":\"160084\",\"regionName\":\"沙雅县\"},{\"id\":\"160087\",\"regionName\":\"乌什县\"},{\"id\":\"160082\",\"regionName\":\"温宿县\"},{\"id\":\"160085\",\"regionName\":\"新和县\"}]";
		}
		else if("15041".equals(id))
		{
			return "[{\"id\":\"160079\",\"regionName\":\"博湖县\"},{\"id\":\"160078\",\"regionName\":\"和硕县\"},{\"id\":\"160077\",\"regionName\":\"和静县\"},{\"id\":\"160071\",\"regionName\":\"库尔勒市\"},{\"id\":\"160072\",\"regionName\":\"轮台县\"},{\"id\":\"160075\",\"regionName\":\"且末县\"},{\"id\":\"160074\",\"regionName\":\"若羌县\"},{\"id\":\"160073\",\"regionName\":\"尉犁县\"},{\"id\":\"160076\",\"regionName\":\"焉耆回族自治县\"}]";
		}
		else if("15040".equals(id))
		{
			return "[{\"id\":\"160061\",\"regionName\":\"博乐市\"},{\"id\":\"160062\",\"regionName\":\"精河县\"},{\"id\":\"160063\",\"regionName\":\"温泉县\"}]";
		}
		else if("15039".equals(id))
		{
			return "[{\"id\":\"160051\",\"regionName\":\"昌吉市\"},{\"id\":\"160052\",\"regionName\":\"阜康市\"},{\"id\":\"160054\",\"regionName\":\"呼图壁县\"},{\"id\":\"160057\",\"regionName\":\"吉木萨尔县\"},{\"id\":\"160058\",\"regionName\":\"木垒哈萨克自治县\"},{\"id\":\"160055\",\"regionName\":\"玛纳斯县\"},{\"id\":\"160053\",\"regionName\":\"米泉市\"},{\"id\":\"160056\",\"regionName\":\"奇台县\"}]";
		}
		else if("15045".equals(id))
		{
			return "[{\"id\":\"160116\",\"regionName\":\"策勒县\"},{\"id\":\"160112\",\"regionName\":\"和田县\"},{\"id\":\"160111\",\"regionName\":\"和田市\"},{\"id\":\"160115\",\"regionName\":\"洛浦县\"},{\"id\":\"160118\",\"regionName\":\"民丰县\"},{\"id\":\"160113\",\"regionName\":\"墨玉县\"},{\"id\":\"160114\",\"regionName\":\"皮山县\"},{\"id\":\"160117\",\"regionName\":\"于田县\"}]";
		}
		else if("15038".equals(id))
		{
			return "[{\"id\":\"160042\",\"regionName\":\"巴里坤哈萨克自治县\"},{\"id\":\"160041\",\"regionName\":\"哈密市\"},{\"id\":\"160043\",\"regionName\":\"伊吾县\"}]";
		}
		else if("15044".equals(id))
		{
			return "[{\"id\":\"1601011\",\"regionName\":\"巴楚县\"},{\"id\":\"1601010\",\"regionName\":\"伽师县\"},{\"id\":\"160101\",\"regionName\":\"喀什市\"},{\"id\":\"160108\",\"regionName\":\"麦盖提县\"},{\"id\":\"160106\",\"regionName\":\"莎车县\"},{\"id\":\"160103\",\"regionName\":\"疏勒县\"},{\"id\":\"160102\",\"regionName\":\"疏附县\"},{\"id\":\"1601012\",\"regionName\":\"塔什库尔干塔吉克自治县\"},{\"id\":\"160109\",\"regionName\":\"岳普湖县\"},{\"id\":\"160107\",\"regionName\":\"叶城县\"},{\"id\":\"160104\",\"regionName\":\"英吉沙县\"},{\"id\":\"160105\",\"regionName\":\"泽普县\"}]";
		}
		else if("15043".equals(id))
		{
			return "[{\"id\":\"160093\",\"regionName\":\"阿合奇县\"},{\"id\":\"160092\",\"regionName\":\"阿克陶县\"},{\"id\":\"160091\",\"regionName\":\"阿图什市\"},{\"id\":\"160094\",\"regionName\":\"乌恰县\"}]";
		}
		else if("15036".equals(id))
		{
			return "[{\"id\":\"160023\",\"regionName\":\"白碱滩区\"},{\"id\":\"160021\",\"regionName\":\"独山子区\"},{\"id\":\"160022\",\"regionName\":\"克拉玛依区\"},{\"id\":\"160024\",\"regionName\":\"乌尔禾区\"}]";
		}
		else if("15049".equals(id))
		{
			return "[{\"id\":\"160152\",\"regionName\":\"阿拉尔市\"},{\"id\":\"160151\",\"regionName\":\"石河子市\"},{\"id\":\"160153\",\"regionName\":\"图木舒克市\"}]";
		}
		else if("15047".equals(id))
		{
			return "[{\"id\":\"160133\",\"regionName\":\"额敏县\"},{\"id\":\"160137\",\"regionName\":\"和布克赛尔蒙古自治县\"},{\"id\":\"160134\",\"regionName\":\"沙湾县\"},{\"id\":\"160135\",\"regionName\":\"托里县\"},{\"id\":\"160131\",\"regionName\":\"塔城市\"},{\"id\":\"160132\",\"regionName\":\"乌苏市\"},{\"id\":\"160136\",\"regionName\":\"裕民县\"}]";
		}
		else if("15037".equals(id))
		{
			return "[{\"id\":\"160032\",\"regionName\":\"鄯善县\"},{\"id\":\"160033\",\"regionName\":\"托克逊县\"},{\"id\":\"160031\",\"regionName\":\"吐鲁番市\"}]";
		}
		else if("15035".equals(id))
		{
			return "[{\"id\":\"160017\",\"regionName\":\"东山区\"},{\"id\":\"160016\",\"regionName\":\"达坂城区\"},{\"id\":\"160014\",\"regionName\":\"水磨沟区\"},{\"id\":\"160012\",\"regionName\":\"沙依巴克区\"},{\"id\":\"160015\",\"regionName\":\"头屯河区\"},{\"id\":\"160011\",\"regionName\":\"天山区\"},{\"id\":\"160018\",\"regionName\":\"乌鲁木齐县\"},{\"id\":\"160013\",\"regionName\":\"新市区\"}]";
		}
		else if("15046".equals(id))
		{
			return "[{\"id\":\"160124\",\"regionName\":\"察布查尔锡伯自治县\"},{\"id\":\"160126\",\"regionName\":\"巩留县\"},{\"id\":\"160125\",\"regionName\":\"霍城县\"},{\"id\":\"160122\",\"regionName\":\"奎屯市\"},{\"id\":\"1601210\",\"regionName\":\"尼勒克县\"},{\"id\":\"160129\",\"regionName\":\"特克斯县\"},{\"id\":\"160127\",\"regionName\":\"新源县\"},{\"id\":\"160123\",\"regionName\":\"伊宁县\"},{\"id\":\"160121\",\"regionName\":\"伊宁市\"},{\"id\":\"160128\",\"regionName\":\"昭苏县\"}]";
		}
		else if("26".equals(id))
		{
			return "[{\"id\":\"12540\",\"regionName\":\"阿里地区\"},{\"id\":\"12536\",\"regionName\":\"昌都地区\"},{\"id\":\"12541\",\"regionName\":\"林芝地区\"},{\"id\":\"12535\",\"regionName\":\"拉萨市\"},{\"id\":\"12539\",\"regionName\":\"那曲地区\"},{\"id\":\"12538\",\"regionName\":\"日喀则地区\"},{\"id\":\"12537\",\"regionName\":\"山南地区\"}]";
		}
		else if("12540".equals(id))
		{
			return "[{\"id\":\"135067\",\"regionName\":\"措勤县\"},{\"id\":\"135066\",\"regionName\":\"改则县\"},{\"id\":\"135065\",\"regionName\":\"革吉县\"},{\"id\":\"135063\",\"regionName\":\"噶尔县\"},{\"id\":\"135061\",\"regionName\":\"普兰县\"},{\"id\":\"135064\",\"regionName\":\"日土县\"},{\"id\":\"135062\",\"regionName\":\"札达县\"}]";
		}
		else if("12536".equals(id))
		{
			return "[{\"id\":\"1350211\",\"regionName\":\"边坝县\"},{\"id\":\"135027\",\"regionName\":\"八宿县\"},{\"id\":\"135026\",\"regionName\":\"察雅县\"},{\"id\":\"135021\",\"regionName\":\"昌都县\"},{\"id\":\"135025\",\"regionName\":\"丁青县\"},{\"id\":\"135023\",\"regionName\":\"贡觉县\"},{\"id\":\"135022\",\"regionName\":\"江达县\"},{\"id\":\"1350210\",\"regionName\":\"洛隆县\"},{\"id\":\"135024\",\"regionName\":\"类乌齐县\"},{\"id\":\"135029\",\"regionName\":\"芒康县\"},{\"id\":\"135028\",\"regionName\":\"左贡县\"}]";
		}
		else if("12541".equals(id))
		{
			return "[{\"id\":\"135075\",\"regionName\":\"波密县\"},{\"id\":\"135076\",\"regionName\":\"察隅县\"},{\"id\":\"135072\",\"regionName\":\"工布江达县\"},{\"id\":\"135077\",\"regionName\":\"朗　县\"},{\"id\":\"135071\",\"regionName\":\"林芝县\"},{\"id\":\"135074\",\"regionName\":\"墨脱县\"},{\"id\":\"135073\",\"regionName\":\"米林县\"}]";
		}
		else if("12535".equals(id))
		{
			return "[{\"id\":\"135011\",\"regionName\":\"城关区\"},{\"id\":\"135017\",\"regionName\":\"达孜县\"},{\"id\":\"135016\",\"regionName\":\"堆龙德庆县\"},{\"id\":\"135013\",\"regionName\":\"当雄县\"},{\"id\":\"135012\",\"regionName\":\"林周县\"},{\"id\":\"135018\",\"regionName\":\"墨竹工卡县\"},{\"id\":\"135014\",\"regionName\":\"尼木县\"},{\"id\":\"135015\",\"regionName\":\"曲水县\"}]";
		}
		else if("12539".equals(id))
		{
			return "[{\"id\":\"135055\",\"regionName\":\"安多县\"},{\"id\":\"135059\",\"regionName\":\"巴青县\"},{\"id\":\"135058\",\"regionName\":\"班戈县\"},{\"id\":\"135053\",\"regionName\":\"比如县\"},{\"id\":\"135052\",\"regionName\":\"嘉黎县\"},{\"id\":\"1350510\",\"regionName\":\"尼玛县\"},{\"id\":\"135054\",\"regionName\":\"聂荣县\"},{\"id\":\"135051\",\"regionName\":\"那曲县\"},{\"id\":\"135057\",\"regionName\":\"索　县\"},{\"id\":\"135056\",\"regionName\":\"申扎县\"}]";
		}
		else if("12538".equals(id))
		{
			return "[{\"id\":\"135047\",\"regionName\":\"昂仁县\"},{\"id\":\"135049\",\"regionName\":\"白朗县\"},{\"id\":\"1350412\",\"regionName\":\"定结县\"},{\"id\":\"135044\",\"regionName\":\"定日县\"},{\"id\":\"1350418\",\"regionName\":\"岗巴县\"},{\"id\":\"1350415\",\"regionName\":\"吉隆县\"},{\"id\":\"135043\",\"regionName\":\"江孜县\"},{\"id\":\"1350411\",\"regionName\":\"康马县\"},{\"id\":\"135046\",\"regionName\":\"拉孜县\"},{\"id\":\"1350416\",\"regionName\":\"聂拉木县\"},{\"id\":\"135042\",\"regionName\":\"南木林县\"},{\"id\":\"1350410\",\"regionName\":\"仁布县\"},{\"id\":\"135041\",\"regionName\":\"日喀则市\"},{\"id\":\"1350417\",\"regionName\":\"萨嘎县\"},{\"id\":\"135045\",\"regionName\":\"萨迦县\"},{\"id\":\"135048\",\"regionName\":\"谢通门县\"},{\"id\":\"1350414\",\"regionName\":\"亚东县\"},{\"id\":\"1350413\",\"regionName\":\"仲巴县\"}]";
		}
		else if("12537".equals(id))
		{
			return "[{\"id\":\"1350311\",\"regionName\":\"错那县\"},{\"id\":\"135037\",\"regionName\":\"措美县\"},{\"id\":\"135033\",\"regionName\":\"贡嘎县\"},{\"id\":\"135039\",\"regionName\":\"加查县\"},{\"id\":\"1350312\",\"regionName\":\"浪卡子县\"},{\"id\":\"1350310\",\"regionName\":\"隆子县\"},{\"id\":\"135038\",\"regionName\":\"洛扎县\"},{\"id\":\"135031\",\"regionName\":\"乃东县\"},{\"id\":\"135036\",\"regionName\":\"曲松县\"},{\"id\":\"135035\",\"regionName\":\"琼结县\"},{\"id\":\"135034\",\"regionName\":\"桑日县\"},{\"id\":\"135032\",\"regionName\":\"扎囊县\"}]";
		}
		else if("25".equals(id))
		{
			return "[{\"id\":\"12038\",\"regionName\":\"保山市\"},{\"id\":\"12043\",\"regionName\":\"楚雄彝族自治州\"},{\"id\":\"12050\",\"regionName\":\"迪庆藏族自治州\"},{\"id\":\"12048\",\"regionName\":\"德宏傣族景颇族自治州\"},{\"id\":\"12047\",\"regionName\":\"大理白族自治州\"},{\"id\":\"12044\",\"regionName\":\"红河哈尼族彝族自治州\"},{\"id\":\"12035\",\"regionName\":\"昆明市\"},{\"id\":\"12042\",\"regionName\":\"临沧市\"},{\"id\":\"12040\",\"regionName\":\"丽江市\"},{\"id\":\"12049\",\"regionName\":\"怒江傈僳族自治州\"},{\"id\":\"12036\",\"regionName\":\"曲靖市\"},{\"id\":\"12041\",\"regionName\":\"思茅市\"},{\"id\":\"12045\",\"regionName\":\"文山壮族苗族自治州\"},{\"id\":\"12046\",\"regionName\":\"西双版纳傣族自治州\"},{\"id\":\"12037\",\"regionName\":\"玉溪市\"},{\"id\":\"12039\",\"regionName\":\"昭通市\"}]";
		}
		else if("12038".equals(id))
		{
			return "[{\"id\":\"130045\",\"regionName\":\"昌宁县\"},{\"id\":\"130044\",\"regionName\":\"龙陵县\"},{\"id\":\"130041\",\"regionName\":\"隆阳区\"},{\"id\":\"130042\",\"regionName\":\"施甸县\"},{\"id\":\"130043\",\"regionName\":\"腾冲县\"}]";
		}
		else if("12043".equals(id))
		{
			return "[{\"id\":\"130091\",\"regionName\":\"楚雄市\"},{\"id\":\"130096\",\"regionName\":\"大姚县\"},{\"id\":\"1300910\",\"regionName\":\"禄丰县\"},{\"id\":\"130093\",\"regionName\":\"牟定县\"},{\"id\":\"130094\",\"regionName\":\"南华县\"},{\"id\":\"130092\",\"regionName\":\"双柏县\"},{\"id\":\"130099\",\"regionName\":\"武定县\"},{\"id\":\"130098\",\"regionName\":\"元谋县\"},{\"id\":\"130097\",\"regionName\":\"永仁县\"},{\"id\":\"130095\",\"regionName\":\"姚安县\"}]";
		}
		else if("12050".equals(id))
		{
			return "[{\"id\":\"130162\",\"regionName\":\"德钦县\"},{\"id\":\"130163\",\"regionName\":\"维西傈僳族自治县\"},{\"id\":\"130161\",\"regionName\":\"香格里拉县\"}]";
		}
		else if("12048".equals(id))
		{
			return "[{\"id\":\"130145\",\"regionName\":\"陇川县\"},{\"id\":\"130143\",\"regionName\":\"梁河县\"},{\"id\":\"130142\",\"regionName\":\"潞西市\"},{\"id\":\"130141\",\"regionName\":\"瑞丽市\"},{\"id\":\"130144\",\"regionName\":\"盈江县\"}]";
		}
		else if("12047".equals(id))
		{
			return "[{\"id\":\"130134\",\"regionName\":\"宾川县\"},{\"id\":\"130131\",\"regionName\":\"大理市\"},{\"id\":\"1301310\",\"regionName\":\"洱源县\"},{\"id\":\"1301312\",\"regionName\":\"鹤庆县\"},{\"id\":\"1301311\",\"regionName\":\"剑川县\"},{\"id\":\"130135\",\"regionName\":\"弥渡县\"},{\"id\":\"130136\",\"regionName\":\"南涧彝族自治县\"},{\"id\":\"130137\",\"regionName\":\"巍山彝族回族自治县\"},{\"id\":\"130133\",\"regionName\":\"祥云县\"},{\"id\":\"130139\",\"regionName\":\"云龙县\"},{\"id\":\"130138\",\"regionName\":\"永平县\"},{\"id\":\"130132\",\"regionName\":\"漾濞彝族自治县\"}]";
		}
		else if("12044".equals(id))
		{
			return "[{\"id\":\"130101\",\"regionName\":\"个旧市\"},{\"id\":\"1301012\",\"regionName\":\"河口瑶族自治县\"},{\"id\":\"1301010\",\"regionName\":\"金平苗族瑶族傣族自治县\"},{\"id\":\"130105\",\"regionName\":\"建水县\"},{\"id\":\"130102\",\"regionName\":\"开远市\"},{\"id\":\"1301011\",\"regionName\":\"绿春县\"},{\"id\":\"130108\",\"regionName\":\"泸西县\"},{\"id\":\"130107\",\"regionName\":\"弥勒县\"},{\"id\":\"130103\",\"regionName\":\"蒙自县\"},{\"id\":\"130104\",\"regionName\":\"屏边苗族自治县\"},{\"id\":\"130106\",\"regionName\":\"石屏县\"},{\"id\":\"130109\",\"regionName\":\"元阳县\"}]";
		}
		else if("12035".equals(id))
		{
			return "[{\"id\":\"1300114\",\"regionName\":\"安宁市\"},{\"id\":\"130016\",\"regionName\":\"呈贡县\"},{\"id\":\"130015\",\"regionName\":\"东川区\"},{\"id\":\"130018\",\"regionName\":\"富民县\"},{\"id\":\"130013\",\"regionName\":\"官渡区\"},{\"id\":\"130017\",\"regionName\":\"晋宁县\"},{\"id\":\"1300112\",\"regionName\":\"禄劝彝族苗族自治县\"},{\"id\":\"130012\",\"regionName\":\"盘龙区\"},{\"id\":\"1300111\",\"regionName\":\"嵩明县\"},{\"id\":\"1300110\",\"regionName\":\"石林彝族自治县\"},{\"id\":\"130011\",\"regionName\":\"五华区\"},{\"id\":\"1300113\",\"regionName\":\"寻甸回族彝族自治县\"},{\"id\":\"130014\",\"regionName\":\"西山区\"},{\"id\":\"130019\",\"regionName\":\"宜良县\"}]";
		}
		else if("12042".equals(id))
		{
			return "[{\"id\":\"130088\",\"regionName\":\"沧源佤族自治县\"},{\"id\":\"130082\",\"regionName\":\"凤庆县\"},{\"id\":\"130087\",\"regionName\":\"耿马傣族佤族自治县\"},{\"id\":\"130081\",\"regionName\":\"临翔区\"},{\"id\":\"130086\",\"regionName\":\"双江拉祜族佤族布朗族傣族自治县\"},{\"id\":\"130084\",\"regionName\":\"永德县\"},{\"id\":\"130083\",\"regionName\":\"云　县\"},{\"id\":\"130085\",\"regionName\":\"镇康县\"}]";
		}
		else if("12040".equals(id))
		{
			return "[{\"id\":\"130061\",\"regionName\":\"古城区\"},{\"id\":\"130064\",\"regionName\":\"华坪县\"},{\"id\":\"130065\",\"regionName\":\"宁蒗彝族自治县\"},{\"id\":\"130063\",\"regionName\":\"永胜县\"},{\"id\":\"130062\",\"regionName\":\"玉龙纳西族自治县\"}]";
		}
		else if("12049".equals(id))
		{
			return "[{\"id\":\"130152\",\"regionName\":\"福贡县\"},{\"id\":\"130153\",\"regionName\":\"贡山独龙族怒族自治县\"},{\"id\":\"130154\",\"regionName\":\"兰坪白族普米族自治县\"},{\"id\":\"130151\",\"regionName\":\"泸水县\"}]";
		}
		else if("12036".equals(id))
		{
			return "[{\"id\":\"130026\",\"regionName\":\"富源县\"},{\"id\":\"130027\",\"regionName\":\"会泽县\"},{\"id\":\"130025\",\"regionName\":\"罗平县\"},{\"id\":\"130023\",\"regionName\":\"陆良县\"},{\"id\":\"130022\",\"regionName\":\"马龙县\"},{\"id\":\"130021\",\"regionName\":\"麒麟区\"},{\"id\":\"130024\",\"regionName\":\"师宗县\"},{\"id\":\"130029\",\"regionName\":\"宣威市\"},{\"id\":\"130028\",\"regionName\":\"沾益县\"}]";
		}
		else if("12041".equals(id))
		{
			return "[{\"id\":\"130071\",\"regionName\":\"翠云区\"},{\"id\":\"130077\",\"regionName\":\"江城哈尼族彝族自治县\"},{\"id\":\"130075\",\"regionName\":\"景谷傣族彝族自治县\"},{\"id\":\"130074\",\"regionName\":\"景东彝族自治县\"},{\"id\":\"130079\",\"regionName\":\"澜沧拉祜族自治县\"},{\"id\":\"130078\",\"regionName\":\"孟连傣族拉祜族佤族自治县\"},{\"id\":\"130073\",\"regionName\":\"墨江哈尼族自治县\"},{\"id\":\"130072\",\"regionName\":\"普洱哈尼族彝族自治县\"},{\"id\":\"1300710\",\"regionName\":\"西盟佤族自治县\"},{\"id\":\"130076\",\"regionName\":\"镇沅彝族哈尼族拉祜族自治县\"}]";
		}
		else if("12045".equals(id))
		{
			return "[{\"id\":\"130118\",\"regionName\":\"富宁县\"},{\"id\":\"130117\",\"regionName\":\"广南县\"},{\"id\":\"130115\",\"regionName\":\"马关县\"},{\"id\":\"130114\",\"regionName\":\"麻栗坡县\"},{\"id\":\"130116\",\"regionName\":\"丘北县\"},{\"id\":\"130111\",\"regionName\":\"文山县\"},{\"id\":\"130113\",\"regionName\":\"西畴县\"},{\"id\":\"130112\",\"regionName\":\"砚山县\"}]";
		}
		else if("12046".equals(id))
		{
			return "[{\"id\":\"130121\",\"regionName\":\"景洪市\"},{\"id\":\"130123\",\"regionName\":\"勐腊县\"},{\"id\":\"130122\",\"regionName\":\"勐海县\"}]";
		}
		else if("12037".equals(id))
		{
			return "[{\"id\":\"130033\",\"regionName\":\"澄江县\"},{\"id\":\"130037\",\"regionName\":\"峨山彝族自治县\"},{\"id\":\"130035\",\"regionName\":\"华宁县\"},{\"id\":\"130031\",\"regionName\":\"红塔区\"},{\"id\":\"130032\",\"regionName\":\"江川县\"},{\"id\":\"130034\",\"regionName\":\"通海县\"},{\"id\":\"130038\",\"regionName\":\"新平彝族傣族自治县\"},{\"id\":\"130039\",\"regionName\":\"元江哈尼族彝族傣族自治县\"},{\"id\":\"130036\",\"regionName\":\"易门县\"}]";
		}
		else if("12039".equals(id))
		{
			return "[{\"id\":\"130055\",\"regionName\":\"大关县\"},{\"id\":\"130052\",\"regionName\":\"鲁甸县\"},{\"id\":\"130053\",\"regionName\":\"巧家县\"},{\"id\":\"1300511\",\"regionName\":\"水富县\"},{\"id\":\"130057\",\"regionName\":\"绥江县\"},{\"id\":\"1300510\",\"regionName\":\"威信县\"},{\"id\":\"130059\",\"regionName\":\"彝良县\"},{\"id\":\"130056\",\"regionName\":\"永善县\"},{\"id\":\"130054\",\"regionName\":\"盐津县\"},{\"id\":\"130058\",\"regionName\":\"镇雄县\"},{\"id\":\"130051\",\"regionName\":\"昭阳区\"}]";
		}
		else if("22".equals(id))
		{
			return "[{\"id\":\"10555\",\"regionName\":\"璧山县\"},{\"id\":\"10547\",\"regionName\":\"巴南区\"},{\"id\":\"10543\",\"regionName\":\"北碚区\"},{\"id\":\"10557\",\"regionName\":\"城口县\"},{\"id\":\"10559\",\"regionName\":\"垫江县\"},{\"id\":\"10553\",\"regionName\":\"大足县\"},{\"id\":\"10538\",\"regionName\":\"大渡口区\"},{\"id\":\"10564\",\"regionName\":\"奉节县\"},{\"id\":\"10558\",\"regionName\":\"丰都县\"},{\"id\":\"10536\",\"regionName\":\"涪陵区\"},{\"id\":\"10572\",\"regionName\":\"合川市\"},{\"id\":\"10571\",\"regionName\":\"江津市\"},{\"id\":\"10541\",\"regionName\":\"九龙坡区\"},{\"id\":\"10539\",\"regionName\":\"江北区\"},{\"id\":\"10562\",\"regionName\":\"开　县\"},{\"id\":\"10556\",\"regionName\":\"梁平县\"},{\"id\":\"10574\",\"regionName\":\"南川市\"},{\"id\":\"10542\",\"regionName\":\"南岸区\"},{\"id\":\"10570\",\"regionName\":\"彭水苗族土家族自治县\"},{\"id\":\"10550\",\"regionName\":\"綦江县\"},{\"id\":\"10548\",\"regionName\":\"黔江区\"},{\"id\":\"10554\",\"regionName\":\"荣昌县\"},{\"id\":\"10567\",\"regionName\":\"石柱土家族自治县\"},{\"id\":\"10545\",\"regionName\":\"双桥区\"},{\"id\":\"10540\",\"regionName\":\"沙坪坝区\"},{\"id\":\"10552\",\"regionName\":\"铜梁县\"},{\"id\":\"10551\",\"regionName\":\"潼南县\"},{\"id\":\"10566\",\"regionName\":\"巫溪县\"},{\"id\":\"10565\",\"regionName\":\"巫山县\"},{\"id\":\"10560\",\"regionName\":\"武隆县\"},{\"id\":\"10544\",\"regionName\":\"万盛区\"},{\"id\":\"10535\",\"regionName\":\"万州区\"},{\"id\":\"10568\",\"regionName\":\"秀山土家族苗族自治县\"},{\"id\":\"10573\",\"regionName\":\"永川市\"},{\"id\":\"10569\",\"regionName\":\"酉阳土家族苗族自治县\"},{\"id\":\"10563\",\"regionName\":\"云阳县\"},{\"id\":\"10546\",\"regionName\":\"渝北区\"},{\"id\":\"10537\",\"regionName\":\"渝中区\"},{\"id\":\"10561\",\"regionName\":\"忠　县\"},{\"id\":\"10549\",\"regionName\":\"长寿区\"}]";
		}
		else if("10555".equals(id))
		{
			return "[]";
		}
		else if("10547".equals(id))
		{
			return "[]";
		}
		else if("10543".equals(id))
		{
			return "[]";
		}
		else if("10557".equals(id))
		{
			return "[]";
		}
		else if("10559".equals(id))
		{
			return "[]";
		}
		else if("10553".equals(id))
		{
			return "[]";
		}
		else if("10538".equals(id))
		{
			return "[]";
		}
		else if("10564".equals(id))
		{
			return "[]";
		}
		else if("10558".equals(id))
		{
			return "[]";
		}
		else if("10536".equals(id))
		{
			return "[]";
		}
		else if("10572".equals(id))
		{
			return "[]";
		}
		else if("10571".equals(id))
		{
			return "[]";
		}
		else if("10541".equals(id))
		{
			return "[]";
		}
		else if("10539".equals(id))
		{
			return "[]";
		}
		else if("10562".equals(id))
		{
			return "[]";
		}
		else if("10556".equals(id))
		{
			return "[]";
		}
		else if("10574".equals(id))
		{
			return "[]";
		}
		else if("10542".equals(id))
		{
			return "[]";
		}
		else if("10570".equals(id))
		{
			return "[]";
		}
		else if("10550".equals(id))
		{
			return "[]";
		}
		else if("10548".equals(id))
		{
			return "[]";
		}
		else if("10554".equals(id))
		{
			return "[]";
		}
		else if("10567".equals(id))
		{
			return "[]";
		}
		else if("10545".equals(id))
		{
			return "[]";
		}
		else if("10540".equals(id))
		{
			return "[]";
		}
		else if("10552".equals(id))
		{
			return "[]";
		}
		else if("10551".equals(id))
		{
			return "[]";
		}
		else if("10566".equals(id))
		{
			return "[]";
		}
		else if("10565".equals(id))
		{
			return "[]";
		}
		else if("10560".equals(id))
		{
			return "[]";
		}
		else if("10544".equals(id))
		{
			return "[]";
		}
		else if("10535".equals(id))
		{
			return "[]";
		}
		else if("10568".equals(id))
		{
			return "[]";
		}
		else if("10573".equals(id))
		{
			return "[]";
		}
		else if("10569".equals(id))
		{
			return "[]";
		}
		else if("10563".equals(id))
		{
			return "[]";
		}
		else if("10546".equals(id))
		{
			return "[]";
		}
		else if("10537".equals(id))
		{
			return "[]";
		}
		else if("10561".equals(id))
		{
			return "[]";
		}
		else if("10549".equals(id))
		{
			return "[]";
		}
		else if("11".equals(id))
		{
			return "[{\"id\":\"5039\",\"regionName\":\"湖州市\"},{\"id\":\"5035\",\"regionName\":\"杭州市\"},{\"id\":\"5041\",\"regionName\":\"金华市\"},{\"id\":\"5038\",\"regionName\":\"嘉兴市\"},{\"id\":\"5045\",\"regionName\":\"丽水市\"},{\"id\":\"5036\",\"regionName\":\"宁波市\"},{\"id\":\"5042\",\"regionName\":\"衢州市\"},{\"id\":\"5040\",\"regionName\":\"绍兴市\"},{\"id\":\"5044\",\"regionName\":\"台州市\"},{\"id\":\"5037\",\"regionName\":\"温州市\"},{\"id\":\"5043\",\"regionName\":\"舟山市\"}]";
		}
		else if("5039".equals(id))
		{
			return "[{\"id\":\"60055\",\"regionName\":\"安吉县\"},{\"id\":\"60053\",\"regionName\":\"德清县\"},{\"id\":\"60052\",\"regionName\":\"南浔区\"},{\"id\":\"60051\",\"regionName\":\"吴兴区\"},{\"id\":\"60054\",\"regionName\":\"长兴县\"}]";
		}
		else if("5035".equals(id))
		{
			return "[{\"id\":\"60016\",\"regionName\":\"滨江区\"},{\"id\":\"600110\",\"regionName\":\"淳安县\"},{\"id\":\"600112\",\"regionName\":\"富阳市\"},{\"id\":\"60014\",\"regionName\":\"拱墅区\"},{\"id\":\"600111\",\"regionName\":\"建德市\"},{\"id\":\"60013\",\"regionName\":\"江干区\"},{\"id\":\"600113\",\"regionName\":\"临安市\"},{\"id\":\"60011\",\"regionName\":\"上城区\"},{\"id\":\"60019\",\"regionName\":\"桐庐县\"},{\"id\":\"60017\",\"regionName\":\"萧山区\"},{\"id\":\"60015\",\"regionName\":\"西湖区\"},{\"id\":\"60012\",\"regionName\":\"下城区\"},{\"id\":\"60018\",\"regionName\":\"余杭区\"}]";
		}
		else if("5041".equals(id))
		{
			return "[{\"id\":\"60078\",\"regionName\":\"东阳市\"},{\"id\":\"60072\",\"regionName\":\"金东区\"},{\"id\":\"60076\",\"regionName\":\"兰溪市\"},{\"id\":\"60075\",\"regionName\":\"磐安县\"},{\"id\":\"60074\",\"regionName\":\"浦江县\"},{\"id\":\"60073\",\"regionName\":\"武义县\"},{\"id\":\"60071\",\"regionName\":\"婺城区\"},{\"id\":\"60079\",\"regionName\":\"永康市\"},{\"id\":\"60077\",\"regionName\":\"义乌市\"}]";
		}
		else if("5038".equals(id))
		{
			return "[{\"id\":\"60045\",\"regionName\":\"海宁市\"},{\"id\":\"60044\",\"regionName\":\"海盐县\"},{\"id\":\"60043\",\"regionName\":\"嘉善县\"},{\"id\":\"60046\",\"regionName\":\"平湖市\"},{\"id\":\"60047\",\"regionName\":\"桐乡市\"},{\"id\":\"60042\",\"regionName\":\"秀洲区\"},{\"id\":\"60041\",\"regionName\":\"秀城区\"}]";
		}
		else if("5045".equals(id))
		{
			return "[{\"id\":\"60118\",\"regionName\":\"景宁畲族自治县\"},{\"id\":\"60113\",\"regionName\":\"缙云县\"},{\"id\":\"60119\",\"regionName\":\"龙泉市\"},{\"id\":\"60111\",\"regionName\":\"莲都区\"},{\"id\":\"60117\",\"regionName\":\"庆元县\"},{\"id\":\"60112\",\"regionName\":\"青田县\"},{\"id\":\"60115\",\"regionName\":\"松阳县\"},{\"id\":\"60114\",\"regionName\":\"遂昌县\"},{\"id\":\"60116\",\"regionName\":\"云和县\"}]";
		}
		else if("5036".equals(id))
		{
			return "[{\"id\":\"60024\",\"regionName\":\"北仑区\"},{\"id\":\"600210\",\"regionName\":\"慈溪市\"},{\"id\":\"600211\",\"regionName\":\"奉化市\"},{\"id\":\"60021\",\"regionName\":\"海曙区\"},{\"id\":\"60023\",\"regionName\":\"江北区\"},{\"id\":\"60022\",\"regionName\":\"江东区\"},{\"id\":\"60028\",\"regionName\":\"宁海县\"},{\"id\":\"60027\",\"regionName\":\"象山县\"},{\"id\":\"60029\",\"regionName\":\"余姚市\"},{\"id\":\"60026\",\"regionName\":\"鄞州区\"},{\"id\":\"60025\",\"regionName\":\"镇海区\"}]";
		}
		else if("5042".equals(id))
		{
			return "[{\"id\":\"60083\",\"regionName\":\"常山县\"},{\"id\":\"60086\",\"regionName\":\"江山市\"},{\"id\":\"60084\",\"regionName\":\"开化县\"},{\"id\":\"60081\",\"regionName\":\"柯城区\"},{\"id\":\"60085\",\"regionName\":\"龙游县\"},{\"id\":\"60082\",\"regionName\":\"衢江区\"}]";
		}
		else if("5040".equals(id))
		{
			return "[{\"id\":\"60066\",\"regionName\":\"嵊州市\"},{\"id\":\"60065\",\"regionName\":\"上虞市\"},{\"id\":\"60062\",\"regionName\":\"绍兴县\"},{\"id\":\"60063\",\"regionName\":\"新昌县\"},{\"id\":\"60061\",\"regionName\":\"越城区\"},{\"id\":\"60064\",\"regionName\":\"诸暨市\"}]";
		}
		else if("5044".equals(id))
		{
			return "[{\"id\":\"60102\",\"regionName\":\"黄岩区\"},{\"id\":\"60101\",\"regionName\":\"椒江区\"},{\"id\":\"60109\",\"regionName\":\"临海市\"},{\"id\":\"60103\",\"regionName\":\"路桥区\"},{\"id\":\"60105\",\"regionName\":\"三门县\"},{\"id\":\"60106\",\"regionName\":\"天台县\"},{\"id\":\"60108\",\"regionName\":\"温岭市\"},{\"id\":\"60107\",\"regionName\":\"仙居县\"},{\"id\":\"60104\",\"regionName\":\"玉环县\"}]";
		}
		else if("5037".equals(id))
		{
			return "[{\"id\":\"60037\",\"regionName\":\"苍南县\"},{\"id\":\"60034\",\"regionName\":\"洞头县\"},{\"id\":\"600311\",\"regionName\":\"乐清市\"},{\"id\":\"60032\",\"regionName\":\"龙湾区\"},{\"id\":\"60031\",\"regionName\":\"鹿城区\"},{\"id\":\"60033\",\"regionName\":\"瓯海区\"},{\"id\":\"60036\",\"regionName\":\"平阳县\"},{\"id\":\"600310\",\"regionName\":\"瑞安市\"},{\"id\":\"60039\",\"regionName\":\"泰顺县\"},{\"id\":\"60038\",\"regionName\":\"文成县\"},{\"id\":\"60035\",\"regionName\":\"永嘉县\"}]";
		}
		else if("5043".equals(id))
		{
			return "[{\"id\":\"60093\",\"regionName\":\"岱山县\"},{\"id\":\"60091\",\"regionName\":\"定海区\"},{\"id\":\"60092\",\"regionName\":\"普陀区\"},{\"id\":\"60094\",\"regionName\":\"嵊泗县\"}]";
		}
		return "[]";
	}*/
	@RequestMapping("/sysCity.citys.do")
	public void citys(HttpServletResponse response)
	{
		/*
		List<CityMinInfo> selectProvince = sysCityService.selectCityById("0");
		
		System.out.println("if(\"0\".equals(id))");
		System.out.println("{");
		System.out.println("	return \""+JsonUtil.listToJson(selectProvince).replaceAll("\"", "\\\\\"")+"\";");
		System.out.println("}");
		List<AreaCityInfo> citys = new ArrayList<AreaCityInfo>();
		for(CityMinInfo info:selectProvince)
		{
			AreaCityInfo pInfo = new AreaCityInfo();
			citys.add(pInfo);
			pInfo.setName(info.getRegionName());
			List<CityMinInfo> selectCitys = sysCityService.selectCityById(info.getId()+"");
			System.out.println("else if(\""+info.getId()+"\".equals(id))");
			System.out.println("{");
			System.out.println("	return \""+JsonUtil.listToJson(selectCitys).replaceAll("\"", "\\\\\"")+"\";");
			System.out.println("}");
			for(CityMinInfo city:selectCitys)
			{
				AreaCityInfo cInfo = new AreaCityInfo();
				cInfo.setName(city.getRegionName());
				pInfo.getList().add(cInfo);
				List<CityMinInfo> selectCounty= sysCityService.selectCityById(city.getId()+"");
				System.out.println("else if(\""+city.getId()+"\".equals(id))");
				System.out.println("{");
				System.out.println("	return \""+JsonUtil.listToJson(selectCounty).replaceAll("\"", "\\\\\"")+"\";");
				System.out.println("}");
				for(CityMinInfo county:selectCounty)
				{
					AreaCityInfo countyInfo = new AreaCityInfo();
					countyInfo.setName(county.getRegionName());
					cInfo.getList().add(countyInfo);
				}
			}
		}
		AjaxUtil.write(JsonUtil.listToJson(citys), response);
		*/
		AjaxUtil.write("[]", response);
		//AjaxUtil.write("[{\"list\":[{\"list\":[{\"list\":[],\"name\":\"大观区\"},{\"list\":[],\"name\":\"怀宁县\"},{\"list\":[],\"name\":\"郊　区\"},{\"list\":[],\"name\":\"潜山县\"},{\"list\":[],\"name\":\"宿松县\"},{\"list\":[],\"name\":\"桐城市\"},{\"list\":[],\"name\":\"太湖县\"},{\"list\":[],\"name\":\"望江县\"},{\"list\":[],\"name\":\"岳西县\"},{\"list\":[],\"name\":\"迎江区\"},{\"list\":[],\"name\":\"枞阳县\"}],\"name\":\"安庆市\"},{\"list\":[{\"list\":[],\"name\":\"利辛县\"},{\"list\":[],\"name\":\"蒙城县\"},{\"list\":[],\"name\":\"谯城区\"},{\"list\":[],\"name\":\"涡阳县\"}],\"name\":\"亳州市\"},{\"list\":[{\"list\":[],\"name\":\"蚌山区\"},{\"list\":[],\"name\":\"固镇县\"},{\"list\":[],\"name\":\"怀远县\"},{\"list\":[],\"name\":\"淮上区\"},{\"list\":[],\"name\":\"龙子湖区\"},{\"list\":[],\"name\":\"五河县\"},{\"list\":[],\"name\":\"禹会区\"}],\"name\":\"蚌埠市\"},{\"list\":[{\"list\":[],\"name\":\"东至县\"},{\"list\":[],\"name\":\"贵池区\"},{\"list\":[],\"name\":\"青阳县\"},{\"list\":[],\"name\":\"石台县\"}],\"name\":\"池州市\"},{\"list\":[{\"list\":[],\"name\":\"和　县\"},{\"list\":[],\"name\":\"含山县\"},{\"list\":[],\"name\":\"居巢区\"},{\"list\":[],\"name\":\"庐江县\"},{\"list\":[],\"name\":\"无为县\"}],\"name\":\"巢湖市\"},{\"list\":[{\"list\":[],\"name\":\"定远县\"},{\"list\":[],\"name\":\"凤阳县\"},{\"list\":[],\"name\":\"来安县\"},{\"list\":[],\"name\":\"琅琊区\"},{\"list\":[],\"name\":\"明光市\"},{\"list\":[],\"name\":\"南谯区\"},{\"list\":[],\"name\":\"全椒县\"},{\"list\":[],\"name\":\"天长市\"}],\"name\":\"滁州市\"},{\"list\":[{\"list\":[],\"name\":\"阜南县\"},{\"list\":[],\"name\":\"界首市\"},{\"list\":[],\"name\":\"临泉县\"},{\"list\":[],\"name\":\"太和县\"},{\"list\":[],\"name\":\"颍上县\"},{\"list\":[],\"name\":\"颍泉区\"},{\"list\":[],\"name\":\"颍东区\"},{\"list\":[],\"name\":\"颍州区\"}],\"name\":\"阜阳市\"},{\"list\":[{\"list\":[],\"name\":\"徽州区\"},{\"list\":[],\"name\":\"黄山区\"},{\"list\":[],\"name\":\"祁门县\"},{\"list\":[],\"name\":\"歙　县\"},{\"list\":[],\"name\":\"屯溪区\"},{\"list\":[],\"name\":\"休宁县\"},{\"list\":[],\"name\":\"黟　县\"}],\"name\":\"黄山市\"},{\"list\":[{\"list\":[],\"name\":\"杜集区\"},{\"list\":[],\"name\":\"烈山区\"},{\"list\":[],\"name\":\"濉溪县\"},{\"list\":[],\"name\":\"相山区\"}],\"name\":\"淮北市\"},{\"list\":[{\"list\":[],\"name\":\"八公山区\"},{\"list\":[],\"name\":\"大通区\"},{\"list\":[],\"name\":\"凤台县\"},{\"list\":[],\"name\":\"潘集区\"},{\"list\":[],\"name\":\"田家庵区\"},{\"list\":[],\"name\":\"谢家集区\"}],\"name\":\"淮南市\"},{\"list\":[{\"list\":[],\"name\":\"包河区\"},{\"list\":[],\"name\":\"肥西县\"},{\"list\":[],\"name\":\"肥东县\"},{\"list\":[],\"name\":\"庐阳区\"},{\"list\":[],\"name\":\"蜀山区\"},{\"list\":[],\"name\":\"瑶海区\"},{\"list\":[],\"name\":\"长丰县\"}],\"name\":\"合肥市\"},{\"list\":[{\"list\":[],\"name\":\"霍山县\"},{\"list\":[],\"name\":\"霍邱县\"},{\"list\":[],\"name\":\"金寨县\"},{\"list\":[],\"name\":\"金安区\"},{\"list\":[],\"name\":\"舒城县\"},{\"list\":[],\"name\":\"寿　县\"},{\"list\":[],\"name\":\"裕安区\"}],\"name\":\"六安市\"},{\"list\":[{\"list\":[],\"name\":\"当涂县\"},{\"list\":[],\"name\":\"花山区\"},{\"list\":[],\"name\":\"金家庄区\"},{\"list\":[],\"name\":\"雨山区\"}],\"name\":\"马鞍山市\"},{\"list\":[{\"list\":[],\"name\":\"砀山县\"},{\"list\":[],\"name\":\"灵璧县\"},{\"list\":[],\"name\":\"泗　县\"},{\"list\":[],\"name\":\"萧　县\"},{\"list\":[],\"name\":\"墉桥区\"}],\"name\":\"宿州市\"},{\"list\":[{\"list\":[],\"name\":\"郊　区\"},{\"list\":[],\"name\":\"狮子山区\"},{\"list\":[],\"name\":\"铜陵县\"},{\"list\":[],\"name\":\"铜官山区\"}],\"name\":\"铜陵市\"},{\"list\":[{\"list\":[],\"name\":\"繁昌县\"},{\"list\":[],\"name\":\"鸠江区\"},{\"list\":[],\"name\":\"镜湖区\"},{\"list\":[],\"name\":\"马塘区\"},{\"list\":[],\"name\":\"南陵县\"},{\"list\":[],\"name\":\"芜湖县\"},{\"list\":[],\"name\":\"新芜区\"}],\"name\":\"芜湖市\"},{\"list\":[{\"list\":[],\"name\":\"广德县\"},{\"list\":[],\"name\":\"旌德县\"},{\"list\":[],\"name\":\"绩溪县\"},{\"list\":[],\"name\":\"泾　县\"},{\"list\":[],\"name\":\"郎溪县\"},{\"list\":[],\"name\":\"宁国市\"},{\"list\":[],\"name\":\"宣州区\"}],\"name\":\"宣城市\"}],\"name\":\"安徽省\"},{\"list\":[{\"list\":[],\"name\":\"昌平区\"},{\"list\":[],\"name\":\"朝阳区\"},{\"list\":[],\"name\":\"崇文区\"},{\"list\":[],\"name\":\"大兴区\"},{\"list\":[],\"name\":\"东城区\"},{\"list\":[],\"name\":\"房山区\"},{\"list\":[],\"name\":\"丰台区\"},{\"list\":[],\"name\":\"怀柔区\"},{\"list\":[],\"name\":\"海淀区\"},{\"list\":[],\"name\":\"密云县\"},{\"list\":[],\"name\":\"门头沟区\"},{\"list\":[],\"name\":\"平谷区\"},{\"list\":[],\"name\":\"顺义区\"},{\"list\":[],\"name\":\"石景山区\"},{\"list\":[],\"name\":\"通州区\"},{\"list\":[],\"name\":\"宣武区\"},{\"list\":[],\"name\":\"西城区\"},{\"list\":[],\"name\":\"延庆县\"}],\"name\":\"北京市\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"仓山区\"},{\"list\":[],\"name\":\"福清市\"},{\"list\":[],\"name\":\"鼓楼区\"},{\"list\":[],\"name\":\"晋安区\"},{\"list\":[],\"name\":\"罗源县\"},{\"list\":[],\"name\":\"连江县\"},{\"list\":[],\"name\":\"闽清县\"},{\"list\":[],\"name\":\"闽侯县\"},{\"list\":[],\"name\":\"马尾区\"},{\"list\":[],\"name\":\"平潭县\"},{\"list\":[],\"name\":\"台江区\"},{\"list\":[],\"name\":\"永泰县\"},{\"list\":[],\"name\":\"长乐市\"}],\"name\":\"福州市\"},{\"list\":[{\"list\":[],\"name\":\"连城县\"},{\"list\":[],\"name\":\"上杭县\"},{\"list\":[],\"name\":\"武平县\"},{\"list\":[],\"name\":\"新罗区\"},{\"list\":[],\"name\":\"永定县\"},{\"list\":[],\"name\":\"漳平市\"},{\"list\":[],\"name\":\"长汀县\"}],\"name\":\"龙岩市\"},{\"list\":[{\"list\":[],\"name\":\"福鼎市\"},{\"list\":[],\"name\":\"福安市\"},{\"list\":[],\"name\":\"古田县\"},{\"list\":[],\"name\":\"蕉城区\"},{\"list\":[],\"name\":\"屏南县\"},{\"list\":[],\"name\":\"寿宁县\"},{\"list\":[],\"name\":\"霞浦县\"},{\"list\":[],\"name\":\"柘荣县\"},{\"list\":[],\"name\":\"周宁县\"}],\"name\":\"宁德市\"},{\"list\":[{\"list\":[],\"name\":\"光泽县\"},{\"list\":[],\"name\":\"建阳市\"},{\"list\":[],\"name\":\"建瓯市\"},{\"list\":[],\"name\":\"浦城县\"},{\"list\":[],\"name\":\"邵武市\"},{\"list\":[],\"name\":\"松溪县\"},{\"list\":[],\"name\":\"顺昌县\"},{\"list\":[],\"name\":\"武夷山市\"},{\"list\":[],\"name\":\"延平区\"},{\"list\":[],\"name\":\"政和县\"}],\"name\":\"南平市\"},{\"list\":[{\"list\":[],\"name\":\"城厢区\"},{\"list\":[],\"name\":\"涵江区\"},{\"list\":[],\"name\":\"荔城区\"},{\"list\":[],\"name\":\"仙游县\"},{\"list\":[],\"name\":\"秀屿区\"}],\"name\":\"莆田市\"},{\"list\":[{\"list\":[],\"name\":\"安溪县\"},{\"list\":[],\"name\":\"德化县\"},{\"list\":[],\"name\":\"丰泽区\"},{\"list\":[],\"name\":\"惠安县\"},{\"list\":[],\"name\":\"晋江市\"},{\"list\":[],\"name\":\"金门县\"},{\"list\":[],\"name\":\"洛江区\"},{\"list\":[],\"name\":\"鲤城区\"},{\"list\":[],\"name\":\"南安市\"},{\"list\":[],\"name\":\"泉港区\"},{\"list\":[],\"name\":\"石狮市\"},{\"list\":[],\"name\":\"永春县\"}],\"name\":\"泉州市\"},{\"list\":[{\"list\":[],\"name\":\"大田县\"},{\"list\":[],\"name\":\"建宁县\"},{\"list\":[],\"name\":\"将乐县\"},{\"list\":[],\"name\":\"明溪县\"},{\"list\":[],\"name\":\"梅列区\"},{\"list\":[],\"name\":\"宁化县\"},{\"list\":[],\"name\":\"清流县\"},{\"list\":[],\"name\":\"沙　县\"},{\"list\":[],\"name\":\"三元区\"},{\"list\":[],\"name\":\"泰宁县\"},{\"list\":[],\"name\":\"永安市\"},{\"list\":[],\"name\":\"尤溪县\"}],\"name\":\"三明市\"},{\"list\":[{\"list\":[],\"name\":\"湖里区\"},{\"list\":[],\"name\":\"海沧区\"},{\"list\":[],\"name\":\"集美区\"},{\"list\":[],\"name\":\"思明区\"},{\"list\":[],\"name\":\"同安区\"},{\"list\":[],\"name\":\"翔安区\"}],\"name\":\"厦门市\"},{\"list\":[{\"list\":[],\"name\":\"东山县\"},{\"list\":[],\"name\":\"华安县\"},{\"list\":[],\"name\":\"龙海市\"},{\"list\":[],\"name\":\"龙文区\"},{\"list\":[],\"name\":\"南靖县\"},{\"list\":[],\"name\":\"平和县\"},{\"list\":[],\"name\":\"芗城区\"},{\"list\":[],\"name\":\"云霄县\"},{\"list\":[],\"name\":\"长泰县\"},{\"list\":[],\"name\":\"诏安县\"},{\"list\":[],\"name\":\"漳浦县\"}],\"name\":\"漳州市\"}],\"name\":\"福建省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"白银区\"},{\"list\":[],\"name\":\"会宁县\"},{\"list\":[],\"name\":\"景泰县\"},{\"list\":[],\"name\":\"靖远县\"},{\"list\":[],\"name\":\"平川区\"}],\"name\":\"白银市\"},{\"list\":[{\"list\":[],\"name\":\"安定区\"},{\"list\":[],\"name\":\"临洮县\"},{\"list\":[],\"name\":\"陇西县\"},{\"list\":[],\"name\":\"岷　县\"},{\"list\":[],\"name\":\"通渭县\"},{\"list\":[],\"name\":\"渭源县\"},{\"list\":[],\"name\":\"漳　县\"}],\"name\":\"定西市\"},{\"list\":[{\"list\":[],\"name\":\"迭部县\"},{\"list\":[],\"name\":\"合作市\"},{\"list\":[],\"name\":\"碌曲县\"},{\"list\":[],\"name\":\"临潭县\"},{\"list\":[],\"name\":\"玛曲县\"},{\"list\":[],\"name\":\"夏河县\"},{\"list\":[],\"name\":\"舟曲县\"},{\"list\":[],\"name\":\"卓尼县\"}],\"name\":\"甘南藏族自治州\"},{\"list\":[{\"list\":[],\"name\":\"阿克塞哈萨克族自治县\"},{\"list\":[],\"name\":\"安西县\"},{\"list\":[],\"name\":\"敦煌市\"},{\"list\":[],\"name\":\"金塔县\"},{\"list\":[],\"name\":\"肃北蒙古族自治县\"},{\"list\":[],\"name\":\"肃州区\"},{\"list\":[],\"name\":\"玉门市\"}],\"name\":\"酒泉市\"},{\"list\":[{\"list\":[],\"name\":\"金川区\"},{\"list\":[],\"name\":\"永昌县\"}],\"name\":\"金昌市\"},{\"list\":[],\"name\":\"嘉峪关市\"},{\"list\":[{\"list\":[],\"name\":\"东乡族自治县\"},{\"list\":[],\"name\":\"广河县\"},{\"list\":[],\"name\":\"和政县\"},{\"list\":[],\"name\":\"积石山保安族东乡族撒拉族自治县\"},{\"list\":[],\"name\":\"康乐县\"},{\"list\":[],\"name\":\"临夏县\"},{\"list\":[],\"name\":\"临夏市\"},{\"list\":[],\"name\":\"永靖县\"}],\"name\":\"临夏回族自治州\"},{\"list\":[{\"list\":[],\"name\":\"成　县\"},{\"list\":[],\"name\":\"宕昌县\"},{\"list\":[],\"name\":\"徽　县\"},{\"list\":[],\"name\":\"康　县\"},{\"list\":[],\"name\":\"两当县\"},{\"list\":[],\"name\":\"礼　县\"},{\"list\":[],\"name\":\"文　县\"},{\"list\":[],\"name\":\"武都区\"},{\"list\":[],\"name\":\"西和县\"}],\"name\":\"陇南市\"},{\"list\":[{\"list\":[],\"name\":\"安宁区\"},{\"list\":[],\"name\":\"城关区\"},{\"list\":[],\"name\":\"皋兰县\"},{\"list\":[],\"name\":\"红古区\"},{\"list\":[],\"name\":\"七里河区\"},{\"list\":[],\"name\":\"西固区\"},{\"list\":[],\"name\":\"榆中县\"},{\"list\":[],\"name\":\"永登县\"}],\"name\":\"兰州市\"},{\"list\":[{\"list\":[],\"name\":\"崇信县\"},{\"list\":[],\"name\":\"华亭县\"},{\"list\":[],\"name\":\"静宁县\"},{\"list\":[],\"name\":\"泾川县\"},{\"list\":[],\"name\":\"崆峒区\"},{\"list\":[],\"name\":\"灵台县\"},{\"list\":[],\"name\":\"庄浪县\"}],\"name\":\"平凉市\"},{\"list\":[{\"list\":[],\"name\":\"合水县\"},{\"list\":[],\"name\":\"华池县\"},{\"list\":[],\"name\":\"环　县\"},{\"list\":[],\"name\":\"宁　县\"},{\"list\":[],\"name\":\"庆城县\"},{\"list\":[],\"name\":\"西峰区\"},{\"list\":[],\"name\":\"镇原县\"},{\"list\":[],\"name\":\"正宁县\"}],\"name\":\"庆阳市\"},{\"list\":[{\"list\":[],\"name\":\"北道区\"},{\"list\":[],\"name\":\"甘谷县\"},{\"list\":[],\"name\":\"秦安县\"},{\"list\":[],\"name\":\"清水县\"},{\"list\":[],\"name\":\"秦城区\"},{\"list\":[],\"name\":\"武山县\"},{\"list\":[],\"name\":\"张家川回族自治县\"}],\"name\":\"天水市\"},{\"list\":[{\"list\":[],\"name\":\"古浪县\"},{\"list\":[],\"name\":\"凉州区\"},{\"list\":[],\"name\":\"民勤县\"},{\"list\":[],\"name\":\"天祝藏族自治县\"}],\"name\":\"武威市\"},{\"list\":[{\"list\":[],\"name\":\"高台县\"},{\"list\":[],\"name\":\"甘州区\"},{\"list\":[],\"name\":\"临泽县\"},{\"list\":[],\"name\":\"民乐县\"},{\"list\":[],\"name\":\"山丹县\"},{\"list\":[],\"name\":\"肃南裕固族自治县\"}],\"name\":\"张掖市\"}],\"name\":\"甘肃省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"关岭布依族苗族自治县\"},{\"list\":[],\"name\":\"普定县\"},{\"list\":[],\"name\":\"平坝县\"},{\"list\":[],\"name\":\"西秀区\"},{\"list\":[],\"name\":\"紫云苗族布依族自治县\"},{\"list\":[],\"name\":\"镇宁布依族苗族自治县\"}],\"name\":\"安顺市\"},{\"list\":[{\"list\":[],\"name\":\"毕节市\"},{\"list\":[],\"name\":\"大方县\"},{\"list\":[],\"name\":\"赫章县\"},{\"list\":[],\"name\":\"金沙县\"},{\"list\":[],\"name\":\"纳雍县\"},{\"list\":[],\"name\":\"黔西县\"},{\"list\":[],\"name\":\"威宁彝族回族苗族自治县\"},{\"list\":[],\"name\":\"织金县\"}],\"name\":\"毕节地区\"},{\"list\":[{\"list\":[],\"name\":\"白云区\"},{\"list\":[],\"name\":\"花溪区\"},{\"list\":[],\"name\":\"开阳县\"},{\"list\":[],\"name\":\"南明区\"},{\"list\":[],\"name\":\"清镇市\"},{\"list\":[],\"name\":\"乌当区\"},{\"list\":[],\"name\":\"修文县\"},{\"list\":[],\"name\":\"息烽县\"},{\"list\":[],\"name\":\"小河区\"},{\"list\":[],\"name\":\"云岩区\"}],\"name\":\"贵阳市\"},{\"list\":[{\"list\":[],\"name\":\"六枝特区\"},{\"list\":[],\"name\":\"盘　县\"},{\"list\":[],\"name\":\"水城县\"},{\"list\":[],\"name\":\"钟山区\"}],\"name\":\"六盘水市\"},{\"list\":[{\"list\":[],\"name\":\"独山县\"},{\"list\":[],\"name\":\"都匀市\"},{\"list\":[],\"name\":\"福泉市\"},{\"list\":[],\"name\":\"贵定县\"},{\"list\":[],\"name\":\"惠水县\"},{\"list\":[],\"name\":\"龙里县\"},{\"list\":[],\"name\":\"罗甸县\"},{\"list\":[],\"name\":\"荔波县\"},{\"list\":[],\"name\":\"平塘县\"},{\"list\":[],\"name\":\"三都水族自治县\"},{\"list\":[],\"name\":\"瓮安县\"},{\"list\":[],\"name\":\"长顺县\"}],\"name\":\"黔南布依族苗族自治州\"},{\"list\":[{\"list\":[],\"name\":\"从江县\"},{\"list\":[],\"name\":\"岑巩县\"},{\"list\":[],\"name\":\"黄平县\"},{\"list\":[],\"name\":\"剑河县\"},{\"list\":[],\"name\":\"锦屏县\"},{\"list\":[],\"name\":\"凯里市\"},{\"list\":[],\"name\":\"雷山县\"},{\"list\":[],\"name\":\"黎平县\"},{\"list\":[],\"name\":\"麻江县\"},{\"list\":[],\"name\":\"榕江县\"},{\"list\":[],\"name\":\"三穗县\"},{\"list\":[],\"name\":\"施秉县\"},{\"list\":[],\"name\":\"台江县\"},{\"list\":[],\"name\":\"天柱县\"},{\"list\":[],\"name\":\"镇远县\"}],\"name\":\"黔东南苗族侗族自治州\"},{\"list\":[{\"list\":[],\"name\":\"安龙县\"},{\"list\":[],\"name\":\"册亨县\"},{\"list\":[],\"name\":\"普安县\"},{\"list\":[],\"name\":\"晴隆县\"},{\"list\":[],\"name\":\"望谟县\"},{\"list\":[],\"name\":\"兴仁县\"},{\"list\":[],\"name\":\"兴义市\"},{\"list\":[],\"name\":\"贞丰县\"}],\"name\":\"黔西南布依族苗族自治州\"},{\"list\":[{\"list\":[],\"name\":\"德江县\"},{\"list\":[],\"name\":\"江口县\"},{\"list\":[],\"name\":\"松桃苗族自治县\"},{\"list\":[],\"name\":\"思南县\"},{\"list\":[],\"name\":\"石阡县\"},{\"list\":[],\"name\":\"铜仁市\"},{\"list\":[],\"name\":\"万山特区\"},{\"list\":[],\"name\":\"沿河土家族自治县\"},{\"list\":[],\"name\":\"印江土家族苗族自治县\"},{\"list\":[],\"name\":\"玉屏侗族自治县\"}],\"name\":\"铜仁地区\"},{\"list\":[{\"list\":[],\"name\":\"赤水市\"},{\"list\":[],\"name\":\"道真仡佬族苗族自治县\"},{\"list\":[],\"name\":\"凤冈县\"},{\"list\":[],\"name\":\"汇川区\"},{\"list\":[],\"name\":\"红花岗区\"},{\"list\":[],\"name\":\"湄潭县\"},{\"list\":[],\"name\":\"仁怀市\"},{\"list\":[],\"name\":\"绥阳县\"},{\"list\":[],\"name\":\"桐梓县\"},{\"list\":[],\"name\":\"务川仡佬族苗族自治县\"},{\"list\":[],\"name\":\"习水县\"},{\"list\":[],\"name\":\"余庆县\"},{\"list\":[],\"name\":\"正安县\"},{\"list\":[],\"name\":\"遵义县\"}],\"name\":\"遵义市\"}],\"name\":\"贵州省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"德保县\"},{\"list\":[],\"name\":\"靖西县\"},{\"list\":[],\"name\":\"隆林各族自治县\"},{\"list\":[],\"name\":\"乐业县\"},{\"list\":[],\"name\":\"凌云县\"},{\"list\":[],\"name\":\"那坡县\"},{\"list\":[],\"name\":\"平果县\"},{\"list\":[],\"name\":\"田林县\"},{\"list\":[],\"name\":\"田东县\"},{\"list\":[],\"name\":\"田阳县\"},{\"list\":[],\"name\":\"西林县\"},{\"list\":[],\"name\":\"右江区\"}],\"name\":\"百色市\"},{\"list\":[{\"list\":[],\"name\":\"合浦县\"},{\"list\":[],\"name\":\"海城区\"},{\"list\":[],\"name\":\"铁山港区\"},{\"list\":[],\"name\":\"银海区\"}],\"name\":\"北海市\"},{\"list\":[{\"list\":[],\"name\":\"大新县\"},{\"list\":[],\"name\":\"扶绥县\"},{\"list\":[],\"name\":\"江洲区\"},{\"list\":[],\"name\":\"龙州县\"},{\"list\":[],\"name\":\"宁明县\"},{\"list\":[],\"name\":\"凭祥市\"},{\"list\":[],\"name\":\"天等县\"}],\"name\":\"崇左市\"},{\"list\":[{\"list\":[],\"name\":\"东兴市\"},{\"list\":[],\"name\":\"防城区\"},{\"list\":[],\"name\":\"港口区\"},{\"list\":[],\"name\":\"上思县\"}],\"name\":\"防城港市\"},{\"list\":[{\"list\":[],\"name\":\"桂平市\"},{\"list\":[],\"name\":\"港南区\"},{\"list\":[],\"name\":\"港北区\"},{\"list\":[],\"name\":\"平南县\"},{\"list\":[],\"name\":\"覃塘区\"}],\"name\":\"贵港市\"},{\"list\":[{\"list\":[],\"name\":\"叠彩区\"},{\"list\":[],\"name\":\"恭城瑶族自治县\"},{\"list\":[],\"name\":\"灌阳县\"},{\"list\":[],\"name\":\"荔蒲县\"},{\"list\":[],\"name\":\"龙胜各族自治县\"},{\"list\":[],\"name\":\"灵川县\"},{\"list\":[],\"name\":\"临桂县\"},{\"list\":[],\"name\":\"平乐县\"},{\"list\":[],\"name\":\"全州县\"},{\"list\":[],\"name\":\"七星区\"},{\"list\":[],\"name\":\"兴安县\"},{\"list\":[],\"name\":\"象山区\"},{\"list\":[],\"name\":\"秀峰区\"},{\"list\":[],\"name\":\"永福县\"},{\"list\":[],\"name\":\"阳朔县\"},{\"list\":[],\"name\":\"雁山区\"},{\"list\":[],\"name\":\"资源县\"}],\"name\":\"桂林市\"},{\"list\":[{\"list\":[],\"name\":\"巴马瑶族自治县\"},{\"list\":[],\"name\":\"大化瑶族自治县\"},{\"list\":[],\"name\":\"都安瑶族自治县\"},{\"list\":[],\"name\":\"东兰县\"},{\"list\":[],\"name\":\"凤山县\"},{\"list\":[],\"name\":\"环江毛南族自治县\"},{\"list\":[],\"name\":\"金城江区\"},{\"list\":[],\"name\":\"罗城仫佬族自治县\"},{\"list\":[],\"name\":\"南丹县\"},{\"list\":[],\"name\":\"天峨县\"},{\"list\":[],\"name\":\"宜州市\"}],\"name\":\"河池市\"},{\"list\":[{\"list\":[],\"name\":\"八步区\"},{\"list\":[],\"name\":\"富川瑶族自治县\"},{\"list\":[],\"name\":\"钟山县\"},{\"list\":[],\"name\":\"昭平县\"}],\"name\":\"贺州市\"},{\"list\":[{\"list\":[],\"name\":\"合山市\"},{\"list\":[],\"name\":\"金秀瑶族自治县\"},{\"list\":[],\"name\":\"武宣县\"},{\"list\":[],\"name\":\"象州县\"},{\"list\":[],\"name\":\"忻城县\"},{\"list\":[],\"name\":\"兴宾区\"}],\"name\":\"来宾市\"},{\"list\":[{\"list\":[],\"name\":\"城中区\"},{\"list\":[],\"name\":\"鹿寨县\"},{\"list\":[],\"name\":\"柳城县\"},{\"list\":[],\"name\":\"柳江县\"},{\"list\":[],\"name\":\"柳北区\"},{\"list\":[],\"name\":\"柳南区\"},{\"list\":[],\"name\":\"融水苗族自治县\"},{\"list\":[],\"name\":\"融安县\"},{\"list\":[],\"name\":\"三江侗族自治县\"},{\"list\":[],\"name\":\"鱼峰区\"}],\"name\":\"柳州市\"},{\"list\":[{\"list\":[],\"name\":\"宾阳县\"},{\"list\":[],\"name\":\"横　县\"},{\"list\":[],\"name\":\"江南区\"},{\"list\":[],\"name\":\"隆安县\"},{\"list\":[],\"name\":\"良庆区\"},{\"list\":[],\"name\":\"马山县\"},{\"list\":[],\"name\":\"青秀区\"},{\"list\":[],\"name\":\"上林县\"},{\"list\":[],\"name\":\"武鸣县\"},{\"list\":[],\"name\":\"西乡塘区\"},{\"list\":[],\"name\":\"兴宁区\"},{\"list\":[],\"name\":\"邕宁区\"}],\"name\":\"南宁市\"},{\"list\":[{\"list\":[],\"name\":\"灵山县\"},{\"list\":[],\"name\":\"浦北县\"},{\"list\":[],\"name\":\"钦北区\"},{\"list\":[],\"name\":\"钦南区\"}],\"name\":\"钦州市\"},{\"list\":[{\"list\":[],\"name\":\"岑溪市\"},{\"list\":[],\"name\":\"苍梧县\"},{\"list\":[],\"name\":\"蝶山区\"},{\"list\":[],\"name\":\"蒙山县\"},{\"list\":[],\"name\":\"藤　县\"},{\"list\":[],\"name\":\"万秀区\"},{\"list\":[],\"name\":\"长洲区\"}],\"name\":\"梧州市\"},{\"list\":[{\"list\":[],\"name\":\"北流市\"},{\"list\":[],\"name\":\"博白县\"},{\"list\":[],\"name\":\"陆川县\"},{\"list\":[],\"name\":\"容　县\"},{\"list\":[],\"name\":\"兴业县\"},{\"list\":[],\"name\":\"玉州区\"}],\"name\":\"玉林市\"}],\"name\":\"广西壮族自治区\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"潮安县\"},{\"list\":[],\"name\":\"饶平县\"}],\"name\":\"潮州市\"},{\"list\":[],\"name\":\"东莞市\"},{\"list\":[{\"list\":[],\"name\":\"高明区\"},{\"list\":[],\"name\":\"南海区\"},{\"list\":[],\"name\":\"三水区\"},{\"list\":[],\"name\":\"顺德区\"},{\"list\":[],\"name\":\"禅城区\"}],\"name\":\"佛山市\"},{\"list\":[{\"list\":[],\"name\":\"白云区\"},{\"list\":[],\"name\":\"从化市\"},{\"list\":[],\"name\":\"东山区\"},{\"list\":[],\"name\":\"番禺区\"},{\"list\":[],\"name\":\"芳村区\"},{\"list\":[],\"name\":\"花都区\"},{\"list\":[],\"name\":\"黄埔区\"},{\"list\":[],\"name\":\"海珠区\"},{\"list\":[],\"name\":\"荔湾区\"},{\"list\":[],\"name\":\"天河区\"},{\"list\":[],\"name\":\"越秀区\"},{\"list\":[],\"name\":\"增城市\"}],\"name\":\"广州市\"},{\"list\":[{\"list\":[],\"name\":\"东源县\"},{\"list\":[],\"name\":\"和平县\"},{\"list\":[],\"name\":\"连平县\"},{\"list\":[],\"name\":\"龙川县\"},{\"list\":[],\"name\":\"源城区\"},{\"list\":[],\"name\":\"紫金县\"}],\"name\":\"河源市\"},{\"list\":[{\"list\":[],\"name\":\"博罗县\"},{\"list\":[],\"name\":\"惠东县\"},{\"list\":[],\"name\":\"惠阳区\"},{\"list\":[],\"name\":\"惠城区\"},{\"list\":[],\"name\":\"龙门县\"}],\"name\":\"惠州市\"},{\"list\":[{\"list\":[],\"name\":\"惠来县\"},{\"list\":[],\"name\":\"揭西县\"},{\"list\":[],\"name\":\"揭东县\"},{\"list\":[],\"name\":\"普宁市\"},{\"list\":[],\"name\":\"榕城区\"}],\"name\":\"揭阳市\"},{\"list\":[{\"list\":[],\"name\":\"恩平市\"},{\"list\":[],\"name\":\"鹤山市\"},{\"list\":[],\"name\":\"江海区\"},{\"list\":[],\"name\":\"开平市\"},{\"list\":[],\"name\":\"蓬江区\"},{\"list\":[],\"name\":\"台山市\"},{\"list\":[],\"name\":\"新会区\"}],\"name\":\"江门市\"},{\"list\":[{\"list\":[],\"name\":\"大埔县\"},{\"list\":[],\"name\":\"丰顺县\"},{\"list\":[],\"name\":\"蕉岭县\"},{\"list\":[],\"name\":\"梅　县\"},{\"list\":[],\"name\":\"梅江区\"},{\"list\":[],\"name\":\"平远县\"},{\"list\":[],\"name\":\"五华县\"},{\"list\":[],\"name\":\"兴宁市\"}],\"name\":\"梅州市\"},{\"list\":[{\"list\":[],\"name\":\"电白县\"},{\"list\":[],\"name\":\"高州市\"},{\"list\":[],\"name\":\"化州市\"},{\"list\":[],\"name\":\"茂港区\"},{\"list\":[],\"name\":\"茂南区\"},{\"list\":[],\"name\":\"信宜市\"}],\"name\":\"茂名市\"},{\"list\":[{\"list\":[],\"name\":\"佛冈县\"},{\"list\":[],\"name\":\"连州市\"},{\"list\":[],\"name\":\"连南瑶族自治县\"},{\"list\":[],\"name\":\"连山壮族瑶族自治县\"},{\"list\":[],\"name\":\"清新县\"},{\"list\":[],\"name\":\"清城区\"},{\"list\":[],\"name\":\"英德市\"},{\"list\":[],\"name\":\"阳山县\"}],\"name\":\"清远市\"},{\"list\":[{\"list\":[],\"name\":\"城　区\"},{\"list\":[],\"name\":\"海丰县\"},{\"list\":[],\"name\":\"陆丰市\"},{\"list\":[],\"name\":\"陆河县\"}],\"name\":\"汕尾市\"},{\"list\":[{\"list\":[],\"name\":\"澄海区\"},{\"list\":[],\"name\":\"潮南区\"},{\"list\":[],\"name\":\"潮阳区\"},{\"list\":[],\"name\":\"濠江区\"},{\"list\":[],\"name\":\"金平区\"},{\"list\":[],\"name\":\"龙湖区\"},{\"list\":[],\"name\":\"南澳县\"}],\"name\":\"汕头市\"},{\"list\":[{\"list\":[],\"name\":\"宝安区\"},{\"list\":[],\"name\":\"福田区\"},{\"list\":[],\"name\":\"龙岗区\"},{\"list\":[],\"name\":\"罗湖区\"},{\"list\":[],\"name\":\"南山区\"},{\"list\":[],\"name\":\"盐田区\"}],\"name\":\"深圳市\"},{\"list\":[{\"list\":[],\"name\":\"乐昌市\"},{\"list\":[],\"name\":\"南雄市\"},{\"list\":[],\"name\":\"曲江区\"},{\"list\":[],\"name\":\"乳源瑶族自治县\"},{\"list\":[],\"name\":\"仁化县\"},{\"list\":[],\"name\":\"始兴县\"},{\"list\":[],\"name\":\"翁源县\"},{\"list\":[],\"name\":\"武江区\"},{\"list\":[],\"name\":\"新丰县\"},{\"list\":[],\"name\":\"浈江区\"}],\"name\":\"韶关市\"},{\"list\":[{\"list\":[],\"name\":\"罗定市\"},{\"list\":[],\"name\":\"新兴县\"},{\"list\":[],\"name\":\"云安县\"},{\"list\":[],\"name\":\"郁南县\"},{\"list\":[],\"name\":\"云城区\"}],\"name\":\"云浮市\"},{\"list\":[{\"list\":[],\"name\":\"江城区\"},{\"list\":[],\"name\":\"阳春市\"},{\"list\":[],\"name\":\"阳东县\"},{\"list\":[],\"name\":\"阳西县\"}],\"name\":\"阳江市\"},{\"list\":[],\"name\":\"中山市\"},{\"list\":[{\"list\":[],\"name\":\"德庆县\"},{\"list\":[],\"name\":\"鼎湖区\"},{\"list\":[],\"name\":\"端州区\"},{\"list\":[],\"name\":\"封开县\"},{\"list\":[],\"name\":\"高要市\"},{\"list\":[],\"name\":\"广宁县\"},{\"list\":[],\"name\":\"怀集县\"},{\"list\":[],\"name\":\"四会市\"}],\"name\":\"肇庆市\"},{\"list\":[{\"list\":[],\"name\":\"赤坎区\"},{\"list\":[],\"name\":\"雷州市\"},{\"list\":[],\"name\":\"廉江市\"},{\"list\":[],\"name\":\"麻章区\"},{\"list\":[],\"name\":\"坡头区\"},{\"list\":[],\"name\":\"遂溪县\"},{\"list\":[],\"name\":\"吴川市\"},{\"list\":[],\"name\":\"徐闻县\"},{\"list\":[],\"name\":\"霞山区\"}],\"name\":\"湛江市\"},{\"list\":[{\"list\":[],\"name\":\"斗门区\"},{\"list\":[],\"name\":\"金湾区\"},{\"list\":[],\"name\":\"洲区\"}],\"name\":\"珠海市\"}],\"name\":\"广东省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"龙华区\"},{\"list\":[],\"name\":\"美兰区\"},{\"list\":[],\"name\":\"琼山区\"},{\"list\":[],\"name\":\"秀英区\"}],\"name\":\"海口市\"},{\"list\":[{\"list\":[],\"name\":\"保亭黎族苗族自治县\"},{\"list\":[],\"name\":\"白沙黎族自治县\"},{\"list\":[],\"name\":\"昌江黎族自治县\"},{\"list\":[],\"name\":\"澄迈县\"},{\"list\":[],\"name\":\"定安县\"},{\"list\":[],\"name\":\"东方市\"},{\"list\":[],\"name\":\"儋州市\"},{\"list\":[],\"name\":\"陵水黎族自治县\"},{\"list\":[],\"name\":\"乐东黎族自治县\"},{\"list\":[],\"name\":\"临高县\"},{\"list\":[],\"name\":\"南沙群岛\"},{\"list\":[],\"name\":\"琼中黎族苗族自治县\"},{\"list\":[],\"name\":\"琼海市\"},{\"list\":[],\"name\":\"屯昌县\"},{\"list\":[],\"name\":\"万宁市\"},{\"list\":[],\"name\":\"文昌市\"},{\"list\":[],\"name\":\"五指山市\"},{\"list\":[],\"name\":\"西沙群岛\"},{\"list\":[],\"name\":\"中沙群岛的岛礁及其海域\"}],\"name\":\"省直辖县级行政单位\"},{\"list\":[],\"name\":\"三亚市\"}],\"name\":\"海南省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"安仁县\"},{\"list\":[],\"name\":\"北湖区\"},{\"list\":[],\"name\":\"桂东县\"},{\"list\":[],\"name\":\"桂阳县\"},{\"list\":[],\"name\":\"嘉禾县\"},{\"list\":[],\"name\":\"临武县\"},{\"list\":[],\"name\":\"汝城县\"},{\"list\":[],\"name\":\"苏仙区\"},{\"list\":[],\"name\":\"永兴县\"},{\"list\":[],\"name\":\"宜章县\"},{\"list\":[],\"name\":\"资兴市\"}],\"name\":\"郴州市\"},{\"list\":[{\"list\":[],\"name\":\"安乡县\"},{\"list\":[],\"name\":\"鼎城区\"},{\"list\":[],\"name\":\"汉寿县\"},{\"list\":[],\"name\":\"津市市\"},{\"list\":[],\"name\":\"临澧县\"},{\"list\":[],\"name\":\"澧　县\"},{\"list\":[],\"name\":\"石门县\"},{\"list\":[],\"name\":\"桃源县\"},{\"list\":[],\"name\":\"武陵区\"}],\"name\":\"常德市\"},{\"list\":[{\"list\":[],\"name\":\"辰溪县\"},{\"list\":[],\"name\":\"洪江市\"},{\"list\":[],\"name\":\"会同县\"},{\"list\":[],\"name\":\"鹤城区\"},{\"list\":[],\"name\":\"靖州苗族侗族自治县\"},{\"list\":[],\"name\":\"麻阳苗族自治县\"},{\"list\":[],\"name\":\"通道侗族自治县\"},{\"list\":[],\"name\":\"新晃侗族自治县\"},{\"list\":[],\"name\":\"溆浦县\"},{\"list\":[],\"name\":\"沅陵县\"},{\"list\":[],\"name\":\"芷江侗族自治县\"},{\"list\":[],\"name\":\"中方县\"}],\"name\":\"怀化市\"},{\"list\":[{\"list\":[],\"name\":\"常宁市\"},{\"list\":[],\"name\":\"衡东县\"},{\"list\":[],\"name\":\"衡山县\"},{\"list\":[],\"name\":\"衡南县\"},{\"list\":[],\"name\":\"衡阳县\"},{\"list\":[],\"name\":\"耒阳市\"},{\"list\":[],\"name\":\"南岳区\"},{\"list\":[],\"name\":\"祁东县\"},{\"list\":[],\"name\":\"石鼓区\"},{\"list\":[],\"name\":\"雁峰区\"},{\"list\":[],\"name\":\"蒸湘区\"},{\"list\":[],\"name\":\"珠晖区\"}],\"name\":\"衡阳市\"},{\"list\":[{\"list\":[],\"name\":\"涟源市\"},{\"list\":[],\"name\":\"冷水江市\"},{\"list\":[],\"name\":\"娄星区\"},{\"list\":[],\"name\":\"双峰县\"},{\"list\":[],\"name\":\"新化县\"}],\"name\":\"娄底市\"},{\"list\":[{\"list\":[],\"name\":\"北塔区\"},{\"list\":[],\"name\":\"城步苗族自治县\"},{\"list\":[],\"name\":\"洞口县\"},{\"list\":[],\"name\":\"大祥区\"},{\"list\":[],\"name\":\"隆回县\"},{\"list\":[],\"name\":\"绥宁县\"},{\"list\":[],\"name\":\"邵阳县\"},{\"list\":[],\"name\":\"邵东县\"},{\"list\":[],\"name\":\"双清区\"},{\"list\":[],\"name\":\"武冈市\"},{\"list\":[],\"name\":\"新宁县\"},{\"list\":[],\"name\":\"新邵县\"}],\"name\":\"邵阳市\"},{\"list\":[{\"list\":[],\"name\":\"保靖县\"},{\"list\":[],\"name\":\"凤凰县\"},{\"list\":[],\"name\":\"古丈县\"},{\"list\":[],\"name\":\"花垣县\"},{\"list\":[],\"name\":\"吉首市\"},{\"list\":[],\"name\":\"龙山县\"},{\"list\":[],\"name\":\"泸溪县\"},{\"list\":[],\"name\":\"永顺县\"}],\"name\":\"湘西土家族苗族自治州\"},{\"list\":[{\"list\":[],\"name\":\"韶山市\"},{\"list\":[],\"name\":\"湘乡市\"},{\"list\":[],\"name\":\"湘潭县\"},{\"list\":[],\"name\":\"岳塘区\"},{\"list\":[],\"name\":\"雨湖区\"}],\"name\":\"湘潭市\"},{\"list\":[{\"list\":[],\"name\":\"道　县\"},{\"list\":[],\"name\":\"东安县\"},{\"list\":[],\"name\":\"江华瑶族自治县\"},{\"list\":[],\"name\":\"江永县\"},{\"list\":[],\"name\":\"蓝山县\"},{\"list\":[],\"name\":\"冷水滩区\"},{\"list\":[],\"name\":\"宁远县\"},{\"list\":[],\"name\":\"祁阳县\"},{\"list\":[],\"name\":\"双牌县\"},{\"list\":[],\"name\":\"新田县\"},{\"list\":[],\"name\":\"芝山区\"}],\"name\":\"永州市\"},{\"list\":[{\"list\":[],\"name\":\"安化县\"},{\"list\":[],\"name\":\"赫山区\"},{\"list\":[],\"name\":\"南　县\"},{\"list\":[],\"name\":\"桃江县\"},{\"list\":[],\"name\":\"沅江市\"},{\"list\":[],\"name\":\"资阳区\"}],\"name\":\"益阳市\"},{\"list\":[{\"list\":[],\"name\":\"华容县\"},{\"list\":[],\"name\":\"君山区\"},{\"list\":[],\"name\":\"临湘市\"},{\"list\":[],\"name\":\"汨罗市\"},{\"list\":[],\"name\":\"平江县\"},{\"list\":[],\"name\":\"湘阴县\"},{\"list\":[],\"name\":\"岳阳县\"},{\"list\":[],\"name\":\"云溪区\"},{\"list\":[],\"name\":\"岳阳楼区\"}],\"name\":\"岳阳市\"},{\"list\":[{\"list\":[],\"name\":\"慈利县\"},{\"list\":[],\"name\":\"桑植县\"},{\"list\":[],\"name\":\"武陵源区\"},{\"list\":[],\"name\":\"永定区\"}],\"name\":\"张家界市\"},{\"list\":[{\"list\":[],\"name\":\"茶陵县\"},{\"list\":[],\"name\":\"荷塘区\"},{\"list\":[],\"name\":\"醴陵市\"},{\"list\":[],\"name\":\"芦淞区\"},{\"list\":[],\"name\":\"石峰区\"},{\"list\":[],\"name\":\"天元区\"},{\"list\":[],\"name\":\"炎陵县\"},{\"list\":[],\"name\":\"攸　县\"},{\"list\":[],\"name\":\"株洲县\"}],\"name\":\"株洲市\"},{\"list\":[{\"list\":[],\"name\":\"芙蓉区\"},{\"list\":[],\"name\":\"开福区\"},{\"list\":[],\"name\":\"浏阳市\"},{\"list\":[],\"name\":\"宁乡县\"},{\"list\":[],\"name\":\"天心区\"},{\"list\":[],\"name\":\"望城县\"},{\"list\":[],\"name\":\"雨花区\"},{\"list\":[],\"name\":\"岳麓区\"},{\"list\":[],\"name\":\"长沙县\"}],\"name\":\"长沙市\"}],\"name\":\"湖南省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"巴东县\"},{\"list\":[],\"name\":\"恩施市\"},{\"list\":[],\"name\":\"鹤峰县\"},{\"list\":[],\"name\":\"建始县\"},{\"list\":[],\"name\":\"来凤县\"},{\"list\":[],\"name\":\"利川市\"},{\"list\":[],\"name\":\"咸丰县\"},{\"list\":[],\"name\":\"宣恩县\"}],\"name\":\"恩施土家族苗族自治州\"},{\"list\":[{\"list\":[],\"name\":\"鄂城区\"},{\"list\":[],\"name\":\"华容区\"},{\"list\":[],\"name\":\"梁子湖区\"}],\"name\":\"鄂州市\"},{\"list\":[{\"list\":[],\"name\":\"黄梅县\"},{\"list\":[],\"name\":\"红安县\"},{\"list\":[],\"name\":\"罗田县\"},{\"list\":[],\"name\":\"麻城市\"},{\"list\":[],\"name\":\"蕲春县\"},{\"list\":[],\"name\":\"团风县\"},{\"list\":[],\"name\":\"武穴市\"},{\"list\":[],\"name\":\"浠水县\"},{\"list\":[],\"name\":\"英山县\"},{\"list\":[],\"name\":\"州区\"}],\"name\":\"黄冈市\"},{\"list\":[{\"list\":[],\"name\":\"大冶市\"},{\"list\":[],\"name\":\"黄石港区\"},{\"list\":[],\"name\":\"铁山区\"},{\"list\":[],\"name\":\"下陆区\"},{\"list\":[],\"name\":\"西塞山区\"},{\"list\":[],\"name\":\"阳新县\"}],\"name\":\"黄石市\"},{\"list\":[{\"list\":[],\"name\":\"公安县\"},{\"list\":[],\"name\":\"洪湖市\"},{\"list\":[],\"name\":\"江陵县\"},{\"list\":[],\"name\":\"监利县\"},{\"list\":[],\"name\":\"荆州区\"},{\"list\":[],\"name\":\"松滋市\"},{\"list\":[],\"name\":\"石首市\"},{\"list\":[],\"name\":\"沙市区\"}],\"name\":\"荆州市\"},{\"list\":[{\"list\":[],\"name\":\"东宝区\"},{\"list\":[],\"name\":\"掇刀区\"},{\"list\":[],\"name\":\"京山县\"},{\"list\":[],\"name\":\"沙洋县\"},{\"list\":[],\"name\":\"钟祥市\"}],\"name\":\"荆门市\"},{\"list\":[{\"list\":[],\"name\":\"潜江市\"},{\"list\":[],\"name\":\"神农架林区\"},{\"list\":[],\"name\":\"天门市\"},{\"list\":[],\"name\":\"仙桃市\"}],\"name\":\"省直辖行政单位\"},{\"list\":[{\"list\":[],\"name\":\"曾都区\"},{\"list\":[],\"name\":\"广水市\"}],\"name\":\"随州市\"},{\"list\":[{\"list\":[],\"name\":\"丹江口市\"},{\"list\":[],\"name\":\"房　县\"},{\"list\":[],\"name\":\"茅箭区\"},{\"list\":[],\"name\":\"郧西县\"},{\"list\":[],\"name\":\"郧　县\"},{\"list\":[],\"name\":\"竹溪县\"},{\"list\":[],\"name\":\"竹山县\"},{\"list\":[],\"name\":\"张湾区\"}],\"name\":\"十堰市\"},{\"list\":[{\"list\":[],\"name\":\"蔡甸区\"},{\"list\":[],\"name\":\"东西湖区\"},{\"list\":[],\"name\":\"黄陂区\"},{\"list\":[],\"name\":\"汉南区\"},{\"list\":[],\"name\":\"洪山区\"},{\"list\":[],\"name\":\"汉阳区\"},{\"list\":[],\"name\":\"江夏区\"},{\"list\":[],\"name\":\"江汉区\"},{\"list\":[],\"name\":\"江岸区\"},{\"list\":[],\"name\":\"青山区\"},{\"list\":[],\"name\":\"乔口区\"},{\"list\":[],\"name\":\"武昌区\"},{\"list\":[],\"name\":\"新洲区\"}],\"name\":\"武汉市\"},{\"list\":[{\"list\":[],\"name\":\"赤壁市\"},{\"list\":[],\"name\":\"崇阳县\"},{\"list\":[],\"name\":\"嘉鱼县\"},{\"list\":[],\"name\":\"通山县\"},{\"list\":[],\"name\":\"通城县\"},{\"list\":[],\"name\":\"咸安区\"}],\"name\":\"咸宁市\"},{\"list\":[{\"list\":[],\"name\":\"安陆市\"},{\"list\":[],\"name\":\"大悟县\"},{\"list\":[],\"name\":\"汉川市\"},{\"list\":[],\"name\":\"孝南区\"},{\"list\":[],\"name\":\"孝昌县\"},{\"list\":[],\"name\":\"云梦县\"},{\"list\":[],\"name\":\"应城市\"}],\"name\":\"孝感市\"},{\"list\":[{\"list\":[],\"name\":\"保康县\"},{\"list\":[],\"name\":\"樊城区\"},{\"list\":[],\"name\":\"谷城县\"},{\"list\":[],\"name\":\"老河口市\"},{\"list\":[],\"name\":\"南漳县\"},{\"list\":[],\"name\":\"襄阳区\"},{\"list\":[],\"name\":\"襄城区\"},{\"list\":[],\"name\":\"宜城市\"},{\"list\":[],\"name\":\"枣阳市\"}],\"name\":\"襄樊市\"},{\"list\":[{\"list\":[],\"name\":\"当阳市\"},{\"list\":[],\"name\":\"点军区\"},{\"list\":[],\"name\":\"五峰土家族自治县\"},{\"list\":[],\"name\":\"伍家岗区\"},{\"list\":[],\"name\":\"兴山县\"},{\"list\":[],\"name\":\"西陵区\"},{\"list\":[],\"name\":\"宜都市\"},{\"list\":[],\"name\":\"远安县\"},{\"list\":[],\"name\":\"夷陵区\"},{\"list\":[],\"name\":\"猇亭区\"},{\"list\":[],\"name\":\"枝江市\"},{\"list\":[],\"name\":\"长阳土家族自治县\"},{\"list\":[],\"name\":\"秭归县\"}],\"name\":\"宜昌市\"}],\"name\":\"湖北省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"安阳县\"},{\"list\":[],\"name\":\"北关区\"},{\"list\":[],\"name\":\"滑　县\"},{\"list\":[],\"name\":\"林州市\"},{\"list\":[],\"name\":\"龙安区\"},{\"list\":[],\"name\":\"内黄县\"},{\"list\":[],\"name\":\"汤阴县\"},{\"list\":[],\"name\":\"文峰区\"},{\"list\":[],\"name\":\"殷都区\"}],\"name\":\"安阳市\"},{\"list\":[{\"list\":[],\"name\":\"鹤山区\"},{\"list\":[],\"name\":\"浚　县\"},{\"list\":[],\"name\":\"淇　县\"},{\"list\":[],\"name\":\"淇滨区\"},{\"list\":[],\"name\":\"山城区\"}],\"name\":\"鹤壁市\"},{\"list\":[{\"list\":[],\"name\":\"博爱县\"},{\"list\":[],\"name\":\"济源市\"},{\"list\":[],\"name\":\"解放区\"},{\"list\":[],\"name\":\"孟州市\"},{\"list\":[],\"name\":\"马村区\"},{\"list\":[],\"name\":\"沁阳市\"},{\"list\":[],\"name\":\"山阳区\"},{\"list\":[],\"name\":\"温　县\"},{\"list\":[],\"name\":\"武陟县\"},{\"list\":[],\"name\":\"修武县\"},{\"list\":[],\"name\":\"中站区\"}],\"name\":\"焦作市\"},{\"list\":[{\"list\":[],\"name\":\"鼓楼区\"},{\"list\":[],\"name\":\"郊　区\"},{\"list\":[],\"name\":\"开封县\"},{\"list\":[],\"name\":\"兰考县\"},{\"list\":[],\"name\":\"龙亭区\"},{\"list\":[],\"name\":\"南关区\"},{\"list\":[],\"name\":\"杞　县\"},{\"list\":[],\"name\":\"顺河回族区\"},{\"list\":[],\"name\":\"通许县\"},{\"list\":[],\"name\":\"尉氏县\"}],\"name\":\"开封市\"},{\"list\":[{\"list\":[],\"name\":\"临颍县\"},{\"list\":[],\"name\":\"舞阳县\"},{\"list\":[],\"name\":\"郾城区\"},{\"list\":[],\"name\":\"源汇区\"},{\"list\":[],\"name\":\"召陵区\"}],\"name\":\"漯河市\"},{\"list\":[{\"list\":[],\"name\":\"廛河回族区\"},{\"list\":[],\"name\":\"吉利区\"},{\"list\":[],\"name\":\"涧西区\"},{\"list\":[],\"name\":\"洛宁县\"},{\"list\":[],\"name\":\"栾川县\"},{\"list\":[],\"name\":\"洛龙区\"},{\"list\":[],\"name\":\"老城区\"},{\"list\":[],\"name\":\"孟津县\"},{\"list\":[],\"name\":\"汝阳县\"},{\"list\":[],\"name\":\"嵩　县\"},{\"list\":[],\"name\":\"新安县\"},{\"list\":[],\"name\":\"西工区\"},{\"list\":[],\"name\":\"偃师市\"},{\"list\":[],\"name\":\"伊川县\"},{\"list\":[],\"name\":\"宜阳县\"}],\"name\":\"洛阳市\"},{\"list\":[{\"list\":[],\"name\":\"邓州市\"},{\"list\":[],\"name\":\"方城县\"},{\"list\":[],\"name\":\"内乡县\"},{\"list\":[],\"name\":\"南召县\"},{\"list\":[],\"name\":\"社旗县\"},{\"list\":[],\"name\":\"桐柏县\"},{\"list\":[],\"name\":\"唐河县\"},{\"list\":[],\"name\":\"卧龙区\"},{\"list\":[],\"name\":\"宛城区\"},{\"list\":[],\"name\":\"新野县\"},{\"list\":[],\"name\":\"淅川县\"},{\"list\":[],\"name\":\"西峡县\"},{\"list\":[],\"name\":\"镇平县\"}],\"name\":\"南阳市\"},{\"list\":[{\"list\":[],\"name\":\"范　县\"},{\"list\":[],\"name\":\"华龙区\"},{\"list\":[],\"name\":\"南乐县\"},{\"list\":[],\"name\":\"濮阳县\"},{\"list\":[],\"name\":\"清丰县\"},{\"list\":[],\"name\":\"台前县\"}],\"name\":\"濮阳市\"},{\"list\":[{\"list\":[],\"name\":\"宝丰县\"},{\"list\":[],\"name\":\"郏　县\"},{\"list\":[],\"name\":\"鲁山县\"},{\"list\":[],\"name\":\"汝州市\"},{\"list\":[],\"name\":\"石龙区\"},{\"list\":[],\"name\":\"舞钢市\"},{\"list\":[],\"name\":\"卫东区\"},{\"list\":[],\"name\":\"新华区\"},{\"list\":[],\"name\":\"叶　县\"},{\"list\":[],\"name\":\"湛河区\"}],\"name\":\"平顶山市\"},{\"list\":[{\"list\":[],\"name\":\"梁园区\"},{\"list\":[],\"name\":\"民权县\"},{\"list\":[],\"name\":\"宁陵县\"},{\"list\":[],\"name\":\"睢　县\"},{\"list\":[],\"name\":\"睢阳区\"},{\"list\":[],\"name\":\"夏邑县\"},{\"list\":[],\"name\":\"永城市\"},{\"list\":[],\"name\":\"虞城县\"},{\"list\":[],\"name\":\"柘城县\"}],\"name\":\"商丘市\"},{\"list\":[{\"list\":[],\"name\":\"湖滨区\"},{\"list\":[],\"name\":\"灵宝市\"},{\"list\":[],\"name\":\"卢氏县\"},{\"list\":[],\"name\":\"渑池县\"},{\"list\":[],\"name\":\"陕　县\"},{\"list\":[],\"name\":\"义马市\"}],\"name\":\"三门峡市\"},{\"list\":[{\"list\":[],\"name\":\"固始县\"},{\"list\":[],\"name\":\"光山县\"},{\"list\":[],\"name\":\"淮滨县\"},{\"list\":[],\"name\":\"潢川县\"},{\"list\":[],\"name\":\"罗山县\"},{\"list\":[],\"name\":\"平桥区\"},{\"list\":[],\"name\":\"商城县\"},{\"list\":[],\"name\":\"师河区\"},{\"list\":[],\"name\":\"息　县\"},{\"list\":[],\"name\":\"新　县\"}],\"name\":\"信阳市\"},{\"list\":[{\"list\":[],\"name\":\"魏都区\"},{\"list\":[],\"name\":\"襄城县\"},{\"list\":[],\"name\":\"许昌县\"},{\"list\":[],\"name\":\"禹州市\"},{\"list\":[],\"name\":\"鄢陵县\"},{\"list\":[],\"name\":\"长葛市\"}],\"name\":\"许昌市\"},{\"list\":[{\"list\":[],\"name\":\"封丘县\"},{\"list\":[],\"name\":\"凤泉区\"},{\"list\":[],\"name\":\"辉县市\"},{\"list\":[],\"name\":\"获嘉县\"},{\"list\":[],\"name\":\"红旗区\"},{\"list\":[],\"name\":\"牧野区\"},{\"list\":[],\"name\":\"卫辉市\"},{\"list\":[],\"name\":\"卫滨区\"},{\"list\":[],\"name\":\"新乡县\"},{\"list\":[],\"name\":\"延津县\"},{\"list\":[],\"name\":\"原阳县\"},{\"list\":[],\"name\":\"长垣县\"}],\"name\":\"新乡市\"},{\"list\":[{\"list\":[],\"name\":\"泌阳县\"},{\"list\":[],\"name\":\"平舆县\"},{\"list\":[],\"name\":\"确山县\"},{\"list\":[],\"name\":\"汝南县\"},{\"list\":[],\"name\":\"遂平县\"},{\"list\":[],\"name\":\"上蔡县\"},{\"list\":[],\"name\":\"新蔡县\"},{\"list\":[],\"name\":\"西平县\"},{\"list\":[],\"name\":\"驿城区\"},{\"list\":[],\"name\":\"正阳县\"}],\"name\":\"驻马店市\"},{\"list\":[{\"list\":[],\"name\":\"川汇区\"},{\"list\":[],\"name\":\"郸城县\"},{\"list\":[],\"name\":\"扶沟县\"},{\"list\":[],\"name\":\"淮阳县\"},{\"list\":[],\"name\":\"鹿邑县\"},{\"list\":[],\"name\":\"沈丘县\"},{\"list\":[],\"name\":\"商水县\"},{\"list\":[],\"name\":\"太康县\"},{\"list\":[],\"name\":\"项城市\"},{\"list\":[],\"name\":\"西华县\"}],\"name\":\"周口市\"},{\"list\":[{\"list\":[],\"name\":\"登封市\"},{\"list\":[],\"name\":\"二七区\"},{\"list\":[],\"name\":\"巩义市\"},{\"list\":[],\"name\":\"管城回族区\"},{\"list\":[],\"name\":\"金水区\"},{\"list\":[],\"name\":\"邙山区\"},{\"list\":[],\"name\":\"上街区\"},{\"list\":[],\"name\":\"新郑市\"},{\"list\":[],\"name\":\"新密市\"},{\"list\":[],\"name\":\"荥阳市\"},{\"list\":[],\"name\":\"中牟县\"},{\"list\":[],\"name\":\"中原区\"}],\"name\":\"郑州市\"}],\"name\":\"河南省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"呼玛县\"},{\"list\":[],\"name\":\"漠河县\"},{\"list\":[],\"name\":\"塔河县\"}],\"name\":\"大兴安岭地区\"},{\"list\":[{\"list\":[],\"name\":\"杜尔伯特蒙古族自治县\"},{\"list\":[],\"name\":\"大同区\"},{\"list\":[],\"name\":\"红岗区\"},{\"list\":[],\"name\":\"林甸县\"},{\"list\":[],\"name\":\"龙凤区\"},{\"list\":[],\"name\":\"让胡路区\"},{\"list\":[],\"name\":\"萨尔图区\"},{\"list\":[],\"name\":\"肇源县\"},{\"list\":[],\"name\":\"肇州县\"}],\"name\":\"大庆市\"},{\"list\":[{\"list\":[],\"name\":\"爱辉区\"},{\"list\":[],\"name\":\"北安市\"},{\"list\":[],\"name\":\"嫩江县\"},{\"list\":[],\"name\":\"孙吴县\"},{\"list\":[],\"name\":\"五大连池市\"},{\"list\":[],\"name\":\"逊克县\"}],\"name\":\"黑河市\"},{\"list\":[{\"list\":[],\"name\":\"东山区\"},{\"list\":[],\"name\":\"工农区\"},{\"list\":[],\"name\":\"萝北县\"},{\"list\":[],\"name\":\"南山区\"},{\"list\":[],\"name\":\"绥滨县\"},{\"list\":[],\"name\":\"兴山区\"},{\"list\":[],\"name\":\"兴安区\"},{\"list\":[],\"name\":\"向阳区\"}],\"name\":\"鹤岗市\"},{\"list\":[{\"list\":[],\"name\":\"阿城市\"},{\"list\":[],\"name\":\"巴彦县\"},{\"list\":[],\"name\":\"宾　县\"},{\"list\":[],\"name\":\"动力区\"},{\"list\":[],\"name\":\"道外区\"},{\"list\":[],\"name\":\"道里区\"},{\"list\":[],\"name\":\"方正县\"},{\"list\":[],\"name\":\"呼兰区\"},{\"list\":[],\"name\":\"木兰县\"},{\"list\":[],\"name\":\"南岗区\"},{\"list\":[],\"name\":\"平房区\"},{\"list\":[],\"name\":\"尚志市\"},{\"list\":[],\"name\":\"双城市\"},{\"list\":[],\"name\":\"松北区\"},{\"list\":[],\"name\":\"通河县\"},{\"list\":[],\"name\":\"五常市\"},{\"list\":[],\"name\":\"香坊区\"},{\"list\":[],\"name\":\"延寿县\"},{\"list\":[],\"name\":\"依兰县\"}],\"name\":\"哈尔滨市\"},{\"list\":[{\"list\":[],\"name\":\"东风区\"},{\"list\":[],\"name\":\"富锦市\"},{\"list\":[],\"name\":\"抚远县\"},{\"list\":[],\"name\":\"桦川县\"},{\"list\":[],\"name\":\"桦南县\"},{\"list\":[],\"name\":\"郊　区\"},{\"list\":[],\"name\":\"前进区\"},{\"list\":[],\"name\":\"同江市\"},{\"list\":[],\"name\":\"汤原县\"},{\"list\":[],\"name\":\"向阳区\"},{\"list\":[],\"name\":\"永红区\"}],\"name\":\"佳木斯市\"},{\"list\":[{\"list\":[],\"name\":\"城子河区\"},{\"list\":[],\"name\":\"滴道区\"},{\"list\":[],\"name\":\"虎林市\"},{\"list\":[],\"name\":\"恒山区\"},{\"list\":[],\"name\":\"鸡东县\"},{\"list\":[],\"name\":\"鸡冠区\"},{\"list\":[],\"name\":\"梨树区\"},{\"list\":[],\"name\":\"密山市\"},{\"list\":[],\"name\":\"麻山区\"}],\"name\":\"鸡西市\"},{\"list\":[{\"list\":[],\"name\":\"爱民区\"},{\"list\":[],\"name\":\"东宁县\"},{\"list\":[],\"name\":\"东安区\"},{\"list\":[],\"name\":\"海林市\"},{\"list\":[],\"name\":\"林口县\"},{\"list\":[],\"name\":\"穆棱市\"},{\"list\":[],\"name\":\"宁安市\"},{\"list\":[],\"name\":\"绥芬河市\"},{\"list\":[],\"name\":\"西安区\"},{\"list\":[],\"name\":\"阳明区\"}],\"name\":\"牡丹江市\"},{\"list\":[{\"list\":[],\"name\":\"勃利县\"},{\"list\":[],\"name\":\"茄子河区\"},{\"list\":[],\"name\":\"桃山区\"},{\"list\":[],\"name\":\"新兴区\"}],\"name\":\"七台河市\"},{\"list\":[{\"list\":[],\"name\":\"昂昂溪区\"},{\"list\":[],\"name\":\"拜泉县\"},{\"list\":[],\"name\":\"富裕县\"},{\"list\":[],\"name\":\"富拉尔基区\"},{\"list\":[],\"name\":\"甘南县\"},{\"list\":[],\"name\":\"建华区\"},{\"list\":[],\"name\":\"克东县\"},{\"list\":[],\"name\":\"克山县\"},{\"list\":[],\"name\":\"龙江县 依安县\"},{\"list\":[],\"name\":\"龙沙区\"},{\"list\":[],\"name\":\"梅里斯达斡尔族区\"},{\"list\":[],\"name\":\"讷河市\"},{\"list\":[],\"name\":\"碾子山区\"},{\"list\":[],\"name\":\"泰来县\"},{\"list\":[],\"name\":\"铁锋区\"}],\"name\":\"齐齐哈尔市\"},{\"list\":[{\"list\":[],\"name\":\"安达市\"},{\"list\":[],\"name\":\"北林区\"},{\"list\":[],\"name\":\"海伦市\"},{\"list\":[],\"name\":\"兰西县\"},{\"list\":[],\"name\":\"明水县\"},{\"list\":[],\"name\":\"庆安县\"},{\"list\":[],\"name\":\"青冈县\"},{\"list\":[],\"name\":\"绥棱县\"},{\"list\":[],\"name\":\"望奎县\"},{\"list\":[],\"name\":\"肇东市\"}],\"name\":\"绥化市\"},{\"list\":[{\"list\":[],\"name\":\"宝清县\"},{\"list\":[],\"name\":\"宝山区\"},{\"list\":[],\"name\":\"集贤县\"},{\"list\":[],\"name\":\"尖山区\"},{\"list\":[],\"name\":\"岭东区\"},{\"list\":[],\"name\":\"饶河县\"},{\"list\":[],\"name\":\"四方台区\"},{\"list\":[],\"name\":\"友谊县\"}],\"name\":\"双鸭山市\"},{\"list\":[{\"list\":[],\"name\":\"翠峦区\"},{\"list\":[],\"name\":\"带岭区\"},{\"list\":[],\"name\":\"红星区\"},{\"list\":[],\"name\":\"嘉荫县\"},{\"list\":[],\"name\":\"金山屯区\"},{\"list\":[],\"name\":\"美溪区\"},{\"list\":[],\"name\":\"南岔区\"},{\"list\":[],\"name\":\"上甘岭区\"},{\"list\":[],\"name\":\"铁力市\"},{\"list\":[],\"name\":\"汤旺河区\"},{\"list\":[],\"name\":\"乌伊岭区\"},{\"list\":[],\"name\":\"乌马河区\"},{\"list\":[],\"name\":\"五营区\"},{\"list\":[],\"name\":\"新青区\"},{\"list\":[],\"name\":\"西林区\"},{\"list\":[],\"name\":\"友好区\"},{\"list\":[],\"name\":\"伊春区\"}],\"name\":\"伊春市\"}],\"name\":\"黑龙江省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"安国市\"},{\"list\":[],\"name\":\"安新县\"},{\"list\":[],\"name\":\"博野县\"},{\"list\":[],\"name\":\"北市区\"},{\"list\":[],\"name\":\"定州市\"},{\"list\":[],\"name\":\"定兴县\"},{\"list\":[],\"name\":\"阜平县\"},{\"list\":[],\"name\":\"高碑店市\"},{\"list\":[],\"name\":\"高阳县\"},{\"list\":[],\"name\":\"蠡　县\"},{\"list\":[],\"name\":\"涞源县\"},{\"list\":[],\"name\":\"涞水县\"},{\"list\":[],\"name\":\"满城县\"},{\"list\":[],\"name\":\"南市区\"},{\"list\":[],\"name\":\"曲阳县\"},{\"list\":[],\"name\":\"清苑县\"},{\"list\":[],\"name\":\"容城县\"},{\"list\":[],\"name\":\"顺平县\"},{\"list\":[],\"name\":\"唐　县\"},{\"list\":[],\"name\":\"望都县\"},{\"list\":[],\"name\":\"雄　县\"},{\"list\":[],\"name\":\"徐水县\"},{\"list\":[],\"name\":\"新市区\"},{\"list\":[],\"name\":\"易县\"},{\"list\":[],\"name\":\"涿州市\"}],\"name\":\"保定市\"},{\"list\":[{\"list\":[],\"name\":\"泊头市\"},{\"list\":[],\"name\":\"沧　县\"},{\"list\":[],\"name\":\"东光县\"},{\"list\":[],\"name\":\"河间市\"},{\"list\":[],\"name\":\"黄骅市\"},{\"list\":[],\"name\":\"海兴县\"},{\"list\":[],\"name\":\"孟村回族自治县\"},{\"list\":[],\"name\":\"南皮县\"},{\"list\":[],\"name\":\"青　县\"},{\"list\":[],\"name\":\"任丘市\"},{\"list\":[],\"name\":\"肃宁县\"},{\"list\":[],\"name\":\"吴桥县\"},{\"list\":[],\"name\":\"献　县\"},{\"list\":[],\"name\":\"新华区\"},{\"list\":[],\"name\":\"盐山县\"},{\"list\":[],\"name\":\"运河区\"}],\"name\":\"沧州市\"},{\"list\":[{\"list\":[],\"name\":\" 围场满族蒙古族自治县\"},{\"list\":[],\"name\":\"承德县\"},{\"list\":[],\"name\":\"丰宁满族自治县\"},{\"list\":[],\"name\":\"宽城满族自治\"},{\"list\":[],\"name\":\"隆化县\"},{\"list\":[],\"name\":\"滦平县\"},{\"list\":[],\"name\":\"平泉县\"},{\"list\":[],\"name\":\"双滦区\"},{\"list\":[],\"name\":\"双桥区\"},{\"list\":[],\"name\":\"兴隆县\"},{\"list\":[],\"name\":\"鹰手营子矿区\"}],\"name\":\"承德市\"},{\"list\":[{\"list\":[],\"name\":\"安平县\"},{\"list\":[],\"name\":\"阜城县\"},{\"list\":[],\"name\":\"故城县\"},{\"list\":[],\"name\":\"冀州市\"},{\"list\":[],\"name\":\"景　县\"},{\"list\":[],\"name\":\"饶阳县\"},{\"list\":[],\"name\":\"深州市\"},{\"list\":[],\"name\":\"桃城区\"},{\"list\":[],\"name\":\"武强县\"},{\"list\":[],\"name\":\"武邑县\"},{\"list\":[],\"name\":\"枣强县\"}],\"name\":\"衡水市\"},{\"list\":[{\"list\":[],\"name\":\"磁　县\"},{\"list\":[],\"name\":\"成安县\"},{\"list\":[],\"name\":\"丛台区\"},{\"list\":[],\"name\":\"大名县\"},{\"list\":[],\"name\":\"肥乡县\"},{\"list\":[],\"name\":\"峰峰矿区\"},{\"list\":[],\"name\":\"复兴区\"},{\"list\":[],\"name\":\"馆陶县\"},{\"list\":[],\"name\":\"广平县\"},{\"list\":[],\"name\":\"邯郸县\"},{\"list\":[],\"name\":\"邯山区\"},{\"list\":[],\"name\":\"鸡泽县\"},{\"list\":[],\"name\":\"临漳县\"},{\"list\":[],\"name\":\"曲周县\"},{\"list\":[],\"name\":\"邱　县\"},{\"list\":[],\"name\":\"涉　县\"},{\"list\":[],\"name\":\"市辖区\"},{\"list\":[],\"name\":\"武安市\"},{\"list\":[],\"name\":\"魏县\"},{\"list\":[],\"name\":\"永年县\"}],\"name\":\"邯郸市\"},{\"list\":[{\"list\":[],\"name\":\"安次区\"},{\"list\":[],\"name\":\"霸州市\"},{\"list\":[],\"name\":\"大厂回族自治县\"},{\"list\":[],\"name\":\"大城县\"},{\"list\":[],\"name\":\"固安县\"},{\"list\":[],\"name\":\"广阳区\"},{\"list\":[],\"name\":\"三河市\"},{\"list\":[],\"name\":\"文安县\"},{\"list\":[],\"name\":\"香河县\"},{\"list\":[],\"name\":\"永清县\"}],\"name\":\"廊坊市\"},{\"list\":[{\"list\":[],\"name\":\"北戴河区\"},{\"list\":[],\"name\":\"昌黎县\"},{\"list\":[],\"name\":\"抚宁县\"},{\"list\":[],\"name\":\"海港区\"},{\"list\":[],\"name\":\"卢龙县\"},{\"list\":[],\"name\":\"青龙满族自治县\"},{\"list\":[],\"name\":\"山海关区\"}],\"name\":\"秦皇岛市\"},{\"list\":[{\"list\":[],\"name\":\"藁城市\"},{\"list\":[],\"name\":\"高邑县\"},{\"list\":[],\"name\":\"晋州市\"},{\"list\":[],\"name\":\"井陉县\"},{\"list\":[],\"name\":\"井陉矿区\"},{\"list\":[],\"name\":\"鹿泉市\"},{\"list\":[],\"name\":\"灵寿县\"},{\"list\":[],\"name\":\"栾城县\"},{\"list\":[],\"name\":\"平山县\"},{\"list\":[],\"name\":\"桥西区\"},{\"list\":[],\"name\":\"桥东区\"},{\"list\":[],\"name\":\"深泽县\"},{\"list\":[],\"name\":\"无极县\"},{\"list\":[],\"name\":\"新乐市\"},{\"list\":[],\"name\":\"辛集市\"},{\"list\":[],\"name\":\"行唐县\"},{\"list\":[],\"name\":\"新华区\"},{\"list\":[],\"name\":\"元氏县\"},{\"list\":[],\"name\":\"裕华区\"},{\"list\":[],\"name\":\"赵　县\"},{\"list\":[],\"name\":\"赞皇县\"},{\"list\":[],\"name\":\"正定县\"},{\"list\":[],\"name\":\"长安区\"}],\"name\":\"石家庄市\"},{\"list\":[{\"list\":[],\"name\":\"丰润区\"},{\"list\":[],\"name\":\"丰南区\"},{\"list\":[],\"name\":\"古冶区\"},{\"list\":[],\"name\":\"开平区\"},{\"list\":[],\"name\":\"乐亭县\"},{\"list\":[],\"name\":\"滦南县\"},{\"list\":[],\"name\":\"滦　县\"},{\"list\":[],\"name\":\"路北区\"},{\"list\":[],\"name\":\"路南区\"},{\"list\":[],\"name\":\"迁安市\"},{\"list\":[],\"name\":\"迁西县\"},{\"list\":[],\"name\":\"唐海县\"},{\"list\":[],\"name\":\"玉田县\"},{\"list\":[],\"name\":\"遵化市\"}],\"name\":\"唐山市\"},{\"list\":[{\"list\":[],\"name\":\"柏乡县\"},{\"list\":[],\"name\":\"广宗县\"},{\"list\":[],\"name\":\"巨鹿县\"},{\"list\":[],\"name\":\"临西县\"},{\"list\":[],\"name\":\"隆尧县\"},{\"list\":[],\"name\":\"临城县\"},{\"list\":[],\"name\":\"南宫市\"},{\"list\":[],\"name\":\"宁晋县\"},{\"list\":[],\"name\":\"南和县\"},{\"list\":[],\"name\":\"内丘县\"},{\"list\":[],\"name\":\"平乡县\"},{\"list\":[],\"name\":\"清河县\"},{\"list\":[],\"name\":\"桥西区\"},{\"list\":[],\"name\":\"桥东区\"},{\"list\":[],\"name\":\"任　县\"},{\"list\":[],\"name\":\"沙河市\"},{\"list\":[],\"name\":\"威　县\"},{\"list\":[],\"name\":\"新河县\"},{\"list\":[],\"name\":\"邢台县\"}],\"name\":\"邢台市\"},{\"list\":[{\"list\":[],\"name\":\"崇礼县\"},{\"list\":[],\"name\":\"赤城县\"},{\"list\":[],\"name\":\"沽源县\"},{\"list\":[],\"name\":\"怀来县\"},{\"list\":[],\"name\":\"怀安县\"},{\"list\":[],\"name\":\"康保县\"},{\"list\":[],\"name\":\"桥西区\"},{\"list\":[],\"name\":\"桥东区\"},{\"list\":[],\"name\":\"尚义县\"},{\"list\":[],\"name\":\"万全县\"},{\"list\":[],\"name\":\"宣化县\"},{\"list\":[],\"name\":\"下花园区\"},{\"list\":[],\"name\":\"宣化区\"},{\"list\":[],\"name\":\"阳原县\"},{\"list\":[],\"name\":\"蔚　县\"},{\"list\":[],\"name\":\"涿鹿县\"},{\"list\":[],\"name\":\"张北县\"}],\"name\":\"张家口市\"}],\"name\":\"河北省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"崇仁县\"},{\"list\":[],\"name\":\"东乡县\"},{\"list\":[],\"name\":\"广昌县\"},{\"list\":[],\"name\":\"金溪县\"},{\"list\":[],\"name\":\"乐安县\"},{\"list\":[],\"name\":\"黎川县\"},{\"list\":[],\"name\":\"临川区\"},{\"list\":[],\"name\":\"南丰县\"},{\"list\":[],\"name\":\"南城县\"},{\"list\":[],\"name\":\"宜黄县\"},{\"list\":[],\"name\":\"资溪县\"}],\"name\":\"抚州市\"},{\"list\":[{\"list\":[],\"name\":\"安远县\"},{\"list\":[],\"name\":\"崇义县\"},{\"list\":[],\"name\":\"定南县\"},{\"list\":[],\"name\":\"大余县\"},{\"list\":[],\"name\":\"赣　县\"},{\"list\":[],\"name\":\"会昌县\"},{\"list\":[],\"name\":\"龙南县\"},{\"list\":[],\"name\":\"南康市\"},{\"list\":[],\"name\":\"宁都县\"},{\"list\":[],\"name\":\"全南县\"},{\"list\":[],\"name\":\"瑞金市\"},{\"list\":[],\"name\":\"石城县\"},{\"list\":[],\"name\":\"上犹县\"},{\"list\":[],\"name\":\"寻乌县\"},{\"list\":[],\"name\":\"兴国县\"},{\"list\":[],\"name\":\"信丰县\"},{\"list\":[],\"name\":\"于都县\"},{\"list\":[],\"name\":\"章贡区\"}],\"name\":\"赣州市\"},{\"list\":[{\"list\":[],\"name\":\"安福县\"},{\"list\":[],\"name\":\"井冈山市\"},{\"list\":[],\"name\":\"吉水县\"},{\"list\":[],\"name\":\"吉安县\"},{\"list\":[],\"name\":\"吉州区\"},{\"list\":[],\"name\":\"青原区\"},{\"list\":[],\"name\":\"遂川县\"},{\"list\":[],\"name\":\"泰和县\"},{\"list\":[],\"name\":\"万安县\"},{\"list\":[],\"name\":\"新干县\"},{\"list\":[],\"name\":\"峡江县\"},{\"list\":[],\"name\":\"永新县\"},{\"list\":[],\"name\":\"永丰县\"}],\"name\":\"吉安市\"},{\"list\":[{\"list\":[],\"name\":\"都昌县\"},{\"list\":[],\"name\":\"德安县\"},{\"list\":[],\"name\":\"湖口县\"},{\"list\":[],\"name\":\"九江县\"},{\"list\":[],\"name\":\"庐山区\"},{\"list\":[],\"name\":\"彭泽县\"},{\"list\":[],\"name\":\"瑞昌市\"},{\"list\":[],\"name\":\"武宁县\"},{\"list\":[],\"name\":\"星子县\"},{\"list\":[],\"name\":\"修水县\"},{\"list\":[],\"name\":\"浔阳区\"},{\"list\":[],\"name\":\"永修县\"}],\"name\":\"九江市\"},{\"list\":[{\"list\":[],\"name\":\"昌江区\"},{\"list\":[],\"name\":\"浮梁县\"},{\"list\":[],\"name\":\"乐平市\"},{\"list\":[],\"name\":\"珠山区\"}],\"name\":\"景德镇市\"},{\"list\":[{\"list\":[],\"name\":\"安义县\"},{\"list\":[],\"name\":\"东湖区\"},{\"list\":[],\"name\":\"进贤县\"},{\"list\":[],\"name\":\"南昌县\"},{\"list\":[],\"name\":\"青山湖区\"},{\"list\":[],\"name\":\"青云谱区\"},{\"list\":[],\"name\":\"湾里区\"},{\"list\":[],\"name\":\"新建县\"},{\"list\":[],\"name\":\"西湖区\"}],\"name\":\"南昌市\"},{\"list\":[{\"list\":[],\"name\":\"安源区\"},{\"list\":[],\"name\":\"芦溪县\"},{\"list\":[],\"name\":\"莲花县\"},{\"list\":[],\"name\":\"上栗县\"},{\"list\":[],\"name\":\"湘东区\"}],\"name\":\"萍乡市\"},{\"list\":[{\"list\":[],\"name\":\"德兴市\"},{\"list\":[],\"name\":\"广丰县\"},{\"list\":[],\"name\":\"横峰县\"},{\"list\":[],\"name\":\"鄱阳县\"},{\"list\":[],\"name\":\"铅山县\"},{\"list\":[],\"name\":\"上饶县\"},{\"list\":[],\"name\":\"婺源县\"},{\"list\":[],\"name\":\"万年县\"},{\"list\":[],\"name\":\"信州区\"},{\"list\":[],\"name\":\"余干县\"},{\"list\":[],\"name\":\"弋阳县\"},{\"list\":[],\"name\":\"玉山县\"}],\"name\":\"上饶市\"},{\"list\":[{\"list\":[],\"name\":\"分宜县\"},{\"list\":[],\"name\":\"渝水区\"}],\"name\":\"新余市\"},{\"list\":[{\"list\":[],\"name\":\"丰城市\"},{\"list\":[],\"name\":\"奉新县\"},{\"list\":[],\"name\":\"高安市\"},{\"list\":[],\"name\":\"靖安县\"},{\"list\":[],\"name\":\"上高县\"},{\"list\":[],\"name\":\"铜鼓县\"},{\"list\":[],\"name\":\"万载县\"},{\"list\":[],\"name\":\"宜丰县\"},{\"list\":[],\"name\":\"袁州区\"},{\"list\":[],\"name\":\"樟树市\"}],\"name\":\"宜春市\"},{\"list\":[{\"list\":[],\"name\":\"贵溪市\"},{\"list\":[],\"name\":\"余江县\"},{\"list\":[],\"name\":\"月湖区\"}],\"name\":\"鹰潭市\"}],\"name\":\"江西省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"金坛市\"},{\"list\":[],\"name\":\"溧阳市\"},{\"list\":[],\"name\":\"戚墅堰区\"},{\"list\":[],\"name\":\"天宁区\"},{\"list\":[],\"name\":\"武进区\"},{\"list\":[],\"name\":\"新北区\"},{\"list\":[],\"name\":\"钟楼区\"}],\"name\":\"常州市\"},{\"list\":[{\"list\":[],\"name\":\"楚州区\"},{\"list\":[],\"name\":\"洪泽县\"},{\"list\":[],\"name\":\"淮阴区\"},{\"list\":[],\"name\":\"金湖县\"},{\"list\":[],\"name\":\"涟水县\"},{\"list\":[],\"name\":\"清浦区\"},{\"list\":[],\"name\":\"清河区\"},{\"list\":[],\"name\":\"盱眙县\"}],\"name\":\"淮安市\"},{\"list\":[{\"list\":[],\"name\":\"东海县\"},{\"list\":[],\"name\":\"灌南县\"},{\"list\":[],\"name\":\"灌云县\"},{\"list\":[],\"name\":\"赣榆县\"},{\"list\":[],\"name\":\"海州区\"},{\"list\":[],\"name\":\"连云区\"},{\"list\":[],\"name\":\"新浦区\"}],\"name\":\"连云港市\"},{\"list\":[{\"list\":[],\"name\":\"崇川区\"},{\"list\":[],\"name\":\"港闸区\"},{\"list\":[],\"name\":\"海门市\"},{\"list\":[],\"name\":\"海安县\"},{\"list\":[],\"name\":\"启东市\"},{\"list\":[],\"name\":\"如皋市\"},{\"list\":[],\"name\":\"如东县\"},{\"list\":[],\"name\":\"通州市\"}],\"name\":\"南通市\"},{\"list\":[{\"list\":[],\"name\":\"白下区\"},{\"list\":[],\"name\":\"高淳县\"},{\"list\":[],\"name\":\"鼓楼区\"},{\"list\":[],\"name\":\"江宁区\"},{\"list\":[],\"name\":\"建邺区\"},{\"list\":[],\"name\":\"溧水县\"},{\"list\":[],\"name\":\"六合区\"},{\"list\":[],\"name\":\"浦口区\"},{\"list\":[],\"name\":\"栖霞区\"},{\"list\":[],\"name\":\"秦淮区\"},{\"list\":[],\"name\":\"武区\"},{\"list\":[],\"name\":\"下关区\"},{\"list\":[],\"name\":\"雨花台区\"}],\"name\":\"南京市\"},{\"list\":[{\"list\":[],\"name\":\"泗洪县\"},{\"list\":[],\"name\":\"泗阳县\"},{\"list\":[],\"name\":\"沭阳县\"},{\"list\":[],\"name\":\"宿豫区\"},{\"list\":[],\"name\":\"宿城区\"}],\"name\":\"宿迁市\"},{\"list\":[{\"list\":[],\"name\":\"常熟市\"},{\"list\":[],\"name\":\"沧浪区\"},{\"list\":[],\"name\":\"虎丘区\"},{\"list\":[],\"name\":\"金阊区\"},{\"list\":[],\"name\":\"昆山市\"},{\"list\":[],\"name\":\"平江区\"},{\"list\":[],\"name\":\"太仓市\"},{\"list\":[],\"name\":\"吴江市\"},{\"list\":[],\"name\":\"吴中区\"},{\"list\":[],\"name\":\"相城区\"},{\"list\":[],\"name\":\"张家港市\"}],\"name\":\"苏州市\"},{\"list\":[{\"list\":[],\"name\":\"高港区\"},{\"list\":[],\"name\":\"海陵区\"},{\"list\":[],\"name\":\"姜堰市\"},{\"list\":[],\"name\":\"靖江市\"},{\"list\":[],\"name\":\"泰兴市\"},{\"list\":[],\"name\":\"兴化市\"}],\"name\":\"泰州市\"},{\"list\":[{\"list\":[],\"name\":\"滨湖区\"},{\"list\":[],\"name\":\"北塘区\"},{\"list\":[],\"name\":\"崇安区\"},{\"list\":[],\"name\":\"惠山区\"},{\"list\":[],\"name\":\"江阴市\"},{\"list\":[],\"name\":\"南长区\"},{\"list\":[],\"name\":\"锡山区\"},{\"list\":[],\"name\":\"宜兴市\"}],\"name\":\"无锡市\"},{\"list\":[{\"list\":[],\"name\":\"丰　县\"},{\"list\":[],\"name\":\"鼓楼区\"},{\"list\":[],\"name\":\"贾汪区\"},{\"list\":[],\"name\":\"九里区\"},{\"list\":[],\"name\":\"邳州市\"},{\"list\":[],\"name\":\"沛　县\"},{\"list\":[],\"name\":\"泉山区\"},{\"list\":[],\"name\":\"睢宁县\"},{\"list\":[],\"name\":\"铜山县\"},{\"list\":[],\"name\":\"新沂市\"},{\"list\":[],\"name\":\"云龙区\"}],\"name\":\"徐州市\"},{\"list\":[{\"list\":[],\"name\":\"宝应县\"},{\"list\":[],\"name\":\"高邮市\"},{\"list\":[],\"name\":\"广陵区\"},{\"list\":[],\"name\":\"邗江区\"},{\"list\":[],\"name\":\"江都市\"},{\"list\":[],\"name\":\"郊　区\"},{\"list\":[],\"name\":\"仪征市\"}],\"name\":\"扬州市\"},{\"list\":[{\"list\":[],\"name\":\"滨海县\"},{\"list\":[],\"name\":\"大丰市\"},{\"list\":[],\"name\":\"东台市\"},{\"list\":[],\"name\":\"阜宁县\"},{\"list\":[],\"name\":\"建湖县\"},{\"list\":[],\"name\":\"射阳县\"},{\"list\":[],\"name\":\"亭湖区\"},{\"list\":[],\"name\":\"响水县\"},{\"list\":[],\"name\":\"盐都区\"}],\"name\":\"盐城市\"},{\"list\":[{\"list\":[],\"name\":\"丹阳市\"},{\"list\":[],\"name\":\"丹徒区\"},{\"list\":[],\"name\":\"句容市\"},{\"list\":[],\"name\":\"京口区\"},{\"list\":[],\"name\":\"润州区\"},{\"list\":[],\"name\":\"扬中市\"}],\"name\":\"镇江市\"}],\"name\":\"江苏省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"大安市\"},{\"list\":[],\"name\":\"洮南市\"},{\"list\":[],\"name\":\"通榆县\"},{\"list\":[],\"name\":\"洮北区\"},{\"list\":[],\"name\":\"镇赉县\"}],\"name\":\"白城市\"},{\"list\":[{\"list\":[],\"name\":\"八道江区\"},{\"list\":[],\"name\":\"抚松县\"},{\"list\":[],\"name\":\"江源县\"},{\"list\":[],\"name\":\"靖宇县\"},{\"list\":[],\"name\":\"临江市\"},{\"list\":[],\"name\":\"长白朝鲜族自治县\"}],\"name\":\"白山市\"},{\"list\":[{\"list\":[],\"name\":\"船营区\"},{\"list\":[],\"name\":\"昌邑区\"},{\"list\":[],\"name\":\"丰满区\"},{\"list\":[],\"name\":\"桦甸市\"},{\"list\":[],\"name\":\"蛟河市\"},{\"list\":[],\"name\":\"龙潭区\"},{\"list\":[],\"name\":\"磐石市\"},{\"list\":[],\"name\":\"舒兰市\"},{\"list\":[],\"name\":\"永吉县\"}],\"name\":\"吉林市\"},{\"list\":[{\"list\":[],\"name\":\"东辽县\"},{\"list\":[],\"name\":\"东丰县\"},{\"list\":[],\"name\":\"龙山区\"},{\"list\":[],\"name\":\"西安区\"}],\"name\":\"辽源市\"},{\"list\":[{\"list\":[],\"name\":\"扶余县\"},{\"list\":[],\"name\":\"宁江区\"},{\"list\":[],\"name\":\"乾安县\"},{\"list\":[],\"name\":\"前郭尔罗斯蒙古族自治县\"},{\"list\":[],\"name\":\"长岭县\"}],\"name\":\"松原市\"},{\"list\":[{\"list\":[],\"name\":\"公主岭市\"},{\"list\":[],\"name\":\"梨树县\"},{\"list\":[],\"name\":\"双辽市\"},{\"list\":[],\"name\":\"铁东区\"},{\"list\":[],\"name\":\"铁西区\"},{\"list\":[],\"name\":\"伊通满族自治县\"}],\"name\":\"四平市\"},{\"list\":[{\"list\":[],\"name\":\"东昌区\"},{\"list\":[],\"name\":\"二道江区\"},{\"list\":[],\"name\":\"辉南县\"},{\"list\":[],\"name\":\"集安市\"},{\"list\":[],\"name\":\"柳河县\"},{\"list\":[],\"name\":\"梅河口市\"},{\"list\":[],\"name\":\"通化县\"}],\"name\":\"通化市\"},{\"list\":[{\"list\":[],\"name\":\"安图县\"},{\"list\":[],\"name\":\"敦化市\"},{\"list\":[],\"name\":\"和龙市\"},{\"list\":[],\"name\":\"珲春市\"},{\"list\":[],\"name\":\"龙井市\"},{\"list\":[],\"name\":\"图们市\"},{\"list\":[],\"name\":\"汪清县\"},{\"list\":[],\"name\":\"延吉市\"}],\"name\":\"延边朝鲜族自治州\"},{\"list\":[{\"list\":[],\"name\":\"朝阳区\"},{\"list\":[],\"name\":\"德惠市\"},{\"list\":[],\"name\":\"二道区\"},{\"list\":[],\"name\":\"九台市\"},{\"list\":[],\"name\":\"宽城区\"},{\"list\":[],\"name\":\"绿园区\"},{\"list\":[],\"name\":\"农安县\"},{\"list\":[],\"name\":\"南关区\"},{\"list\":[],\"name\":\"双阳区\"},{\"list\":[],\"name\":\"榆树市\"}],\"name\":\"长春市\"}],\"name\":\"吉林省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"海城市\"},{\"list\":[],\"name\":\"立山区\"},{\"list\":[],\"name\":\"千山区\"},{\"list\":[],\"name\":\"台安县\"},{\"list\":[],\"name\":\"铁西区\"},{\"list\":[],\"name\":\"铁东区\"},{\"list\":[],\"name\":\"岫岩满族自治县\"}],\"name\":\"鞍山市\"},{\"list\":[{\"list\":[],\"name\":\"本溪满族自治县\"},{\"list\":[],\"name\":\"桓仁满族自治县\"},{\"list\":[],\"name\":\"明山区\"},{\"list\":[],\"name\":\"南芬区\"},{\"list\":[],\"name\":\"平山区\"},{\"list\":[],\"name\":\"溪湖区\"}],\"name\":\"本溪市\"},{\"list\":[{\"list\":[],\"name\":\"北票市\"},{\"list\":[],\"name\":\"朝阳县\"},{\"list\":[],\"name\":\"建平县\"},{\"list\":[],\"name\":\"喀喇沁左翼蒙古族自治县\"},{\"list\":[],\"name\":\"凌源市\"},{\"list\":[],\"name\":\"龙城区\"},{\"list\":[],\"name\":\"双塔区\"}],\"name\":\"朝阳市\"},{\"list\":[{\"list\":[],\"name\":\"东港市\"},{\"list\":[],\"name\":\"凤城市\"},{\"list\":[],\"name\":\"宽甸满族自治县\"},{\"list\":[],\"name\":\"元宝区\"},{\"list\":[],\"name\":\"振安区\"},{\"list\":[],\"name\":\"振兴区\"}],\"name\":\"丹东市\"},{\"list\":[{\"list\":[],\"name\":\"甘井子区\"},{\"list\":[],\"name\":\"金州区\"},{\"list\":[],\"name\":\"旅顺口区\"},{\"list\":[],\"name\":\"普兰店市\"},{\"list\":[],\"name\":\"沙河口区\"},{\"list\":[],\"name\":\"瓦房店市\"},{\"list\":[],\"name\":\"西岗区\"},{\"list\":[],\"name\":\"庄河市\"},{\"list\":[],\"name\":\"长海县\"},{\"list\":[],\"name\":\"中山区\"}],\"name\":\"大连市\"},{\"list\":[{\"list\":[],\"name\":\"阜新蒙古族自治县\"},{\"list\":[],\"name\":\"海州区\"},{\"list\":[],\"name\":\"清河门区\"},{\"list\":[],\"name\":\"太平区\"},{\"list\":[],\"name\":\"细河区\"},{\"list\":[],\"name\":\"新邱区\"},{\"list\":[],\"name\":\"彰武县\"}],\"name\":\"阜新市\"},{\"list\":[{\"list\":[],\"name\":\"东洲区\"},{\"list\":[],\"name\":\"抚顺县\"},{\"list\":[],\"name\":\"清原满族自治县\"},{\"list\":[],\"name\":\"顺城区\"},{\"list\":[],\"name\":\"望花区\"},{\"list\":[],\"name\":\"新宾满族自治县\"},{\"list\":[],\"name\":\"新抚区\"}],\"name\":\"抚顺市\"},{\"list\":[{\"list\":[],\"name\":\"建昌县\"},{\"list\":[],\"name\":\"龙港区\"},{\"list\":[],\"name\":\"连山区\"},{\"list\":[],\"name\":\"南票区\"},{\"list\":[],\"name\":\"绥中县\"},{\"list\":[],\"name\":\"兴城市\"}],\"name\":\"葫芦岛市\"},{\"list\":[{\"list\":[],\"name\":\"北宁市\"},{\"list\":[],\"name\":\"古塔区\"},{\"list\":[],\"name\":\"黑山县\"},{\"list\":[],\"name\":\"凌海市\"},{\"list\":[],\"name\":\"凌河区\"},{\"list\":[],\"name\":\"太和区\"},{\"list\":[],\"name\":\"义　县\"}],\"name\":\"锦州市\"},{\"list\":[{\"list\":[],\"name\":\"白塔区\"},{\"list\":[],\"name\":\"灯塔市\"},{\"list\":[],\"name\":\"弓长岭区\"},{\"list\":[],\"name\":\"宏伟区\"},{\"list\":[],\"name\":\"辽阳县\"},{\"list\":[],\"name\":\"太子河区\"},{\"list\":[],\"name\":\"文圣区\"}],\"name\":\"辽阳市\"},{\"list\":[{\"list\":[],\"name\":\"大洼县\"},{\"list\":[],\"name\":\"盘山县\"},{\"list\":[],\"name\":\"双台子区\"},{\"list\":[],\"name\":\"兴隆台区\"}],\"name\":\"盘锦市\"},{\"list\":[{\"list\":[],\"name\":\"东陵区\"},{\"list\":[],\"name\":\"大东区\"},{\"list\":[],\"name\":\"法库县\"},{\"list\":[],\"name\":\"皇姑区\"},{\"list\":[],\"name\":\"和平区\"},{\"list\":[],\"name\":\"康平县\"},{\"list\":[],\"name\":\"辽中县\"},{\"list\":[],\"name\":\"苏家屯区\"},{\"list\":[],\"name\":\"沈河区\"},{\"list\":[],\"name\":\"铁西区\"},{\"list\":[],\"name\":\"新民市\"},{\"list\":[],\"name\":\"新城子区\"},{\"list\":[],\"name\":\"于洪区\"}],\"name\":\"沈阳市\"},{\"list\":[{\"list\":[],\"name\":\"昌图县\"},{\"list\":[],\"name\":\"调兵山市\"},{\"list\":[],\"name\":\"开原市\"},{\"list\":[],\"name\":\"清河区\"},{\"list\":[],\"name\":\"铁岭县\"},{\"list\":[],\"name\":\"西丰县\"},{\"list\":[],\"name\":\"银州区\"}],\"name\":\"铁岭市\"},{\"list\":[{\"list\":[],\"name\":\"鲅鱼圈区\"},{\"list\":[],\"name\":\"大石桥市\"},{\"list\":[],\"name\":\"盖州市\"},{\"list\":[],\"name\":\"老边区\"},{\"list\":[],\"name\":\"西市区\"},{\"list\":[],\"name\":\"站前区\"}],\"name\":\"营口市\"}],\"name\":\"辽宁省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"泾源县\"},{\"list\":[],\"name\":\"隆德县\"},{\"list\":[],\"name\":\"彭阳县\"},{\"list\":[],\"name\":\"西吉县\"},{\"list\":[],\"name\":\"原州区\"}],\"name\":\"固原市\"},{\"list\":[{\"list\":[],\"name\":\"大武口区\"},{\"list\":[],\"name\":\"惠农区\"},{\"list\":[],\"name\":\"平罗县\"}],\"name\":\"石嘴山市\"},{\"list\":[{\"list\":[],\"name\":\"利通区\"},{\"list\":[],\"name\":\"青铜峡市\"},{\"list\":[],\"name\":\"同心县\"},{\"list\":[],\"name\":\"盐池县\"}],\"name\":\"吴忠市\"},{\"list\":[{\"list\":[],\"name\":\"贺兰县\"},{\"list\":[],\"name\":\"金凤区\"},{\"list\":[],\"name\":\"灵武市\"},{\"list\":[],\"name\":\"西夏区\"},{\"list\":[],\"name\":\"兴庆区\"},{\"list\":[],\"name\":\"永宁县\"}],\"name\":\"银川市\"},{\"list\":[{\"list\":[],\"name\":\"海原县\"},{\"list\":[],\"name\":\"沙坡头区\"},{\"list\":[],\"name\":\"中宁县\"}],\"name\":\"中卫市\"}],\"name\":\"宁夏回族自治区\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"阿拉善右旗\"},{\"list\":[],\"name\":\"阿拉善左旗\"},{\"list\":[],\"name\":\"额济纳旗\"}],\"name\":\"阿拉善盟\"},{\"list\":[{\"list\":[],\"name\":\"磴口县\"},{\"list\":[],\"name\":\"杭锦后旗\"},{\"list\":[],\"name\":\"临河区\"},{\"list\":[],\"name\":\"乌拉特后旗\"},{\"list\":[],\"name\":\"乌拉特中旗\"},{\"list\":[],\"name\":\"乌拉特前旗\"},{\"list\":[],\"name\":\"五原县\"}],\"name\":\"巴彦淖尔市\"},{\"list\":[{\"list\":[],\"name\":\"白云矿区\"},{\"list\":[],\"name\":\"达尔罕茂明安联合旗\"},{\"list\":[],\"name\":\"东河区\"},{\"list\":[],\"name\":\"固阳县\"},{\"list\":[],\"name\":\"九原区\"},{\"list\":[],\"name\":\"昆都仑区\"},{\"list\":[],\"name\":\"青山区\"},{\"list\":[],\"name\":\"石拐区\"},{\"list\":[],\"name\":\"土默特右旗\"}],\"name\":\"包头市\"},{\"list\":[{\"list\":[],\"name\":\"敖汉旗\"},{\"list\":[],\"name\":\"阿鲁科尔沁旗\"},{\"list\":[],\"name\":\"巴林右旗\"},{\"list\":[],\"name\":\"巴林左旗\"},{\"list\":[],\"name\":\"红山区\"},{\"list\":[],\"name\":\"喀喇沁旗\"},{\"list\":[],\"name\":\"克什克腾旗\"},{\"list\":[],\"name\":\"林西县\"},{\"list\":[],\"name\":\"宁城县\"},{\"list\":[],\"name\":\"松山区\"},{\"list\":[],\"name\":\"翁牛特旗\"},{\"list\":[],\"name\":\"元宝山区\"}],\"name\":\"赤峰市\"},{\"list\":[{\"list\":[],\"name\":\"达拉特旗\"},{\"list\":[],\"name\":\"东胜区\"},{\"list\":[],\"name\":\"鄂托克旗\"},{\"list\":[],\"name\":\"鄂托克前旗\"},{\"list\":[],\"name\":\"杭锦旗\"},{\"list\":[],\"name\":\"乌审旗\"},{\"list\":[],\"name\":\"伊金霍洛旗\"},{\"list\":[],\"name\":\"准格尔旗\"}],\"name\":\"鄂尔多斯市\"},{\"list\":[{\"list\":[],\"name\":\"阿荣旗\"},{\"list\":[],\"name\":\"陈巴尔虎旗\"},{\"list\":[],\"name\":\"额尔古纳市\"},{\"list\":[],\"name\":\"鄂温克族自治旗\"},{\"list\":[],\"name\":\"鄂伦春自治旗\"},{\"list\":[],\"name\":\"根河市\"},{\"list\":[],\"name\":\"海拉尔区\"},{\"list\":[],\"name\":\"满洲里市\"},{\"list\":[],\"name\":\"莫力达瓦达斡尔族自治旗\"},{\"list\":[],\"name\":\"新巴尔虎右旗\"},{\"list\":[],\"name\":\"新巴尔虎左旗\"},{\"list\":[],\"name\":\"牙克石市\"},{\"list\":[],\"name\":\"扎兰屯市\"}],\"name\":\"呼伦贝尔市\"},{\"list\":[{\"list\":[],\"name\":\"和林格尔县\"},{\"list\":[],\"name\":\"回民区\"},{\"list\":[],\"name\":\"清水河县\"},{\"list\":[],\"name\":\"赛罕区\"},{\"list\":[],\"name\":\"托克托县\"},{\"list\":[],\"name\":\"土默特左旗\"},{\"list\":[],\"name\":\"武川县\"},{\"list\":[],\"name\":\"新城区\"},{\"list\":[],\"name\":\"玉泉区\"}],\"name\":\"呼和浩特市\"},{\"list\":[{\"list\":[],\"name\":\"霍林郭勒市\"},{\"list\":[],\"name\":\"库伦旗\"},{\"list\":[],\"name\":\"开鲁县\"},{\"list\":[],\"name\":\"科尔沁左翼后旗\"},{\"list\":[],\"name\":\"科尔沁左翼中旗\"},{\"list\":[],\"name\":\"科尔沁区\"},{\"list\":[],\"name\":\"奈曼旗\"},{\"list\":[],\"name\":\"扎鲁特旗\"}],\"name\":\"通辽市\"},{\"list\":[{\"list\":[],\"name\":\"察哈尔右翼后旗\"},{\"list\":[],\"name\":\"察哈尔右翼中旗\"},{\"list\":[],\"name\":\"察哈尔右翼前旗\"},{\"list\":[],\"name\":\"丰镇市\"},{\"list\":[],\"name\":\"化德县\"},{\"list\":[],\"name\":\"集宁区\"},{\"list\":[],\"name\":\"凉城县\"},{\"list\":[],\"name\":\"四子王旗\"},{\"list\":[],\"name\":\"商都县\"},{\"list\":[],\"name\":\"兴和县\"},{\"list\":[],\"name\":\"卓资县\"}],\"name\":\"乌兰察布市\"},{\"list\":[{\"list\":[],\"name\":\"海南区\"},{\"list\":[],\"name\":\"海勃湾区\"},{\"list\":[],\"name\":\"乌达区\"}],\"name\":\"乌海市\"},{\"list\":[{\"list\":[],\"name\":\"阿巴嘎旗\"},{\"list\":[],\"name\":\"多伦县\"},{\"list\":[],\"name\":\"东乌珠穆沁旗\"},{\"list\":[],\"name\":\"二连浩特市\"},{\"list\":[],\"name\":\"苏尼特右旗\"},{\"list\":[],\"name\":\"苏尼特左旗\"},{\"list\":[],\"name\":\"太仆寺旗\"},{\"list\":[],\"name\":\"镶黄旗\"},{\"list\":[],\"name\":\"西乌珠穆沁旗\"},{\"list\":[],\"name\":\"锡林浩特市\"},{\"list\":[],\"name\":\"正蓝旗\"},{\"list\":[],\"name\":\"正镶白旗\"}],\"name\":\"锡林郭勒盟\"},{\"list\":[{\"list\":[],\"name\":\"阿尔山市\"},{\"list\":[],\"name\":\"科尔沁右翼中旗\"},{\"list\":[],\"name\":\"科尔沁右翼前旗\"},{\"list\":[],\"name\":\"突泉县\"},{\"list\":[],\"name\":\"乌兰浩特市\"},{\"list\":[],\"name\":\"扎赉特旗\"}],\"name\":\"兴安盟\"}],\"name\":\"内蒙古自治区\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"班玛县\"},{\"list\":[],\"name\":\"达日县\"},{\"list\":[],\"name\":\"甘德县\"},{\"list\":[],\"name\":\"久治县\"},{\"list\":[],\"name\":\"玛多县\"},{\"list\":[],\"name\":\"玛沁县\"}],\"name\":\"果洛藏族自治州\"},{\"list\":[{\"list\":[],\"name\":\"都兰县\"},{\"list\":[],\"name\":\"德令哈市\"},{\"list\":[],\"name\":\"格尔木市\"},{\"list\":[],\"name\":\"天峻县\"},{\"list\":[],\"name\":\"乌兰县\"}],\"name\":\"海西蒙古族藏族自治州\"},{\"list\":[{\"list\":[],\"name\":\"贵南县\"},{\"list\":[],\"name\":\"贵德县\"},{\"list\":[],\"name\":\"共和县\"},{\"list\":[],\"name\":\"同德县\"},{\"list\":[],\"name\":\"兴海县\"}],\"name\":\"海南藏族自治州\"},{\"list\":[{\"list\":[],\"name\":\"河南蒙古族自治县\"},{\"list\":[],\"name\":\"尖扎县\"},{\"list\":[],\"name\":\"同仁县\"},{\"list\":[],\"name\":\"泽库县\"}],\"name\":\"黄南藏族自治州\"},{\"list\":[{\"list\":[],\"name\":\"刚察县\"},{\"list\":[],\"name\":\"海晏县\"},{\"list\":[],\"name\":\"门源回族自治县\"},{\"list\":[],\"name\":\"祁连县\"}],\"name\":\"海北藏族自治州\"},{\"list\":[{\"list\":[],\"name\":\"化隆回族自治县\"},{\"list\":[],\"name\":\"互助土族自治县\"},{\"list\":[],\"name\":\"乐都县\"},{\"list\":[],\"name\":\"民和回族土族自治县\"},{\"list\":[],\"name\":\"平安县\"},{\"list\":[],\"name\":\"循化撒拉族自治县\"}],\"name\":\"海东地区\"},{\"list\":[{\"list\":[],\"name\":\"城北区\"},{\"list\":[],\"name\":\"城西区\"},{\"list\":[],\"name\":\"城中区\"},{\"list\":[],\"name\":\"城东区\"},{\"list\":[],\"name\":\"大通回族土族自治县\"},{\"list\":[],\"name\":\"湟源县\"},{\"list\":[],\"name\":\"湟中县\"}],\"name\":\"西宁市\"},{\"list\":[{\"list\":[],\"name\":\"称多县\"},{\"list\":[],\"name\":\"囊谦县\"},{\"list\":[],\"name\":\"曲麻莱县\"},{\"list\":[],\"name\":\"玉树县\"},{\"list\":[],\"name\":\"治多县\"},{\"list\":[],\"name\":\"杂多县\"}],\"name\":\"玉树藏族自治州\"}],\"name\":\"青海省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"白河县\"},{\"list\":[],\"name\":\"汉阴县\"},{\"list\":[],\"name\":\"汉滨区\"},{\"list\":[],\"name\":\"岚皋县\"},{\"list\":[],\"name\":\"宁陕县\"},{\"list\":[],\"name\":\"平利县\"},{\"list\":[],\"name\":\"石泉县\"},{\"list\":[],\"name\":\"旬阳县\"},{\"list\":[],\"name\":\"镇坪县\"},{\"list\":[],\"name\":\"紫阳县\"}],\"name\":\"安康市\"},{\"list\":[{\"list\":[],\"name\":\"滨区\"},{\"list\":[],\"name\":\"陈仓区\"},{\"list\":[],\"name\":\"凤　县\"},{\"list\":[],\"name\":\"扶风县\"},{\"list\":[],\"name\":\"凤翔县\"},{\"list\":[],\"name\":\"金台区\"},{\"list\":[],\"name\":\"麟游县\"},{\"list\":[],\"name\":\"陇　县\"},{\"list\":[],\"name\":\"眉　县\"},{\"list\":[],\"name\":\"千阳县\"},{\"list\":[],\"name\":\"岐山县\"},{\"list\":[],\"name\":\"太白县\"}],\"name\":\"宝鸡市\"},{\"list\":[{\"list\":[],\"name\":\"城固县\"},{\"list\":[],\"name\":\"佛坪县\"},{\"list\":[],\"name\":\"汉台区\"},{\"list\":[],\"name\":\"留坝县\"},{\"list\":[],\"name\":\"略阳县\"},{\"list\":[],\"name\":\"勉　县\"},{\"list\":[],\"name\":\"宁强县\"},{\"list\":[],\"name\":\"南郑县\"},{\"list\":[],\"name\":\"西乡县\"},{\"list\":[],\"name\":\"洋　县\"},{\"list\":[],\"name\":\"镇巴县\"}],\"name\":\"汉中市\"},{\"list\":[{\"list\":[],\"name\":\"丹凤县\"},{\"list\":[],\"name\":\"洛南县\"},{\"list\":[],\"name\":\"山阳县\"},{\"list\":[],\"name\":\"商南县\"},{\"list\":[],\"name\":\"商州区\"},{\"list\":[],\"name\":\"柞水县\"},{\"list\":[],\"name\":\"镇安县\"}],\"name\":\"商洛市\"},{\"list\":[{\"list\":[],\"name\":\"王益区\"},{\"list\":[],\"name\":\"宜君县\"},{\"list\":[],\"name\":\"耀州区\"},{\"list\":[],\"name\":\"印台区\"}],\"name\":\"铜川市\"},{\"list\":[{\"list\":[],\"name\":\"白水县\"},{\"list\":[],\"name\":\"澄城县\"},{\"list\":[],\"name\":\"大荔县\"},{\"list\":[],\"name\":\"富平县\"},{\"list\":[],\"name\":\"华阴市\"},{\"list\":[],\"name\":\"韩城市\"},{\"list\":[],\"name\":\"合阳县\"},{\"list\":[],\"name\":\"华　县\"},{\"list\":[],\"name\":\"临渭区\"},{\"list\":[],\"name\":\"蒲城县\"},{\"list\":[],\"name\":\"潼关县\"}],\"name\":\"渭南市\"},{\"list\":[{\"list\":[],\"name\":\"彬　县\"},{\"list\":[],\"name\":\"淳化县\"},{\"list\":[],\"name\":\"泾阳县\"},{\"list\":[],\"name\":\"礼泉县\"},{\"list\":[],\"name\":\"乾　县\"},{\"list\":[],\"name\":\"秦都区\"},{\"list\":[],\"name\":\"三原县\"},{\"list\":[],\"name\":\"武功县\"},{\"list\":[],\"name\":\"渭城区\"},{\"list\":[],\"name\":\"兴平市\"},{\"list\":[],\"name\":\"旬邑县\"},{\"list\":[],\"name\":\"永寿县\"},{\"list\":[],\"name\":\"杨凌区\"},{\"list\":[],\"name\":\"长武县\"}],\"name\":\"咸阳市\"},{\"list\":[{\"list\":[],\"name\":\"灞桥区\"},{\"list\":[],\"name\":\"碑林区\"},{\"list\":[],\"name\":\"高陵县\"},{\"list\":[],\"name\":\"户　县\"},{\"list\":[],\"name\":\"蓝田县\"},{\"list\":[],\"name\":\"临潼区\"},{\"list\":[],\"name\":\"莲湖区\"},{\"list\":[],\"name\":\"未央区\"},{\"list\":[],\"name\":\"新城区\"},{\"list\":[],\"name\":\"阎良区\"},{\"list\":[],\"name\":\"雁塔区\"},{\"list\":[],\"name\":\"周至县\"},{\"list\":[],\"name\":\"长安区\"}],\"name\":\"西安市\"},{\"list\":[{\"list\":[],\"name\":\"定边县\"},{\"list\":[],\"name\":\"府谷县\"},{\"list\":[],\"name\":\"横山县\"},{\"list\":[],\"name\":\"佳　县\"},{\"list\":[],\"name\":\"靖边县\"},{\"list\":[],\"name\":\"米脂县\"},{\"list\":[],\"name\":\"清涧县\"},{\"list\":[],\"name\":\"绥德县\"},{\"list\":[],\"name\":\"神木县\"},{\"list\":[],\"name\":\"吴堡县\"},{\"list\":[],\"name\":\"榆阳区\"},{\"list\":[],\"name\":\"子洲县\"}],\"name\":\"榆林市\"},{\"list\":[{\"list\":[],\"name\":\"安塞县\"},{\"list\":[],\"name\":\"宝塔区\"},{\"list\":[],\"name\":\"富　县\"},{\"list\":[],\"name\":\"甘泉县\"},{\"list\":[],\"name\":\"黄陵县\"},{\"list\":[],\"name\":\"黄龙县\"},{\"list\":[],\"name\":\"洛川县\"},{\"list\":[],\"name\":\"吴旗县\"},{\"list\":[],\"name\":\"宜川县\"},{\"list\":[],\"name\":\"延川县\"},{\"list\":[],\"name\":\"延长县\"},{\"list\":[],\"name\":\"志丹县\"},{\"list\":[],\"name\":\"子长县\"}],\"name\":\"延安市\"}],\"name\":\"陕西省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"阿坝县\"},{\"list\":[],\"name\":\"红原县\"},{\"list\":[],\"name\":\"黑水县\"},{\"list\":[],\"name\":\"金川县\"},{\"list\":[],\"name\":\"九寨沟县\"},{\"list\":[],\"name\":\"理　县\"},{\"list\":[],\"name\":\"马尔康县\"},{\"list\":[],\"name\":\"茂　县\"},{\"list\":[],\"name\":\"若尔盖县\"},{\"list\":[],\"name\":\"壤塘县\"},{\"list\":[],\"name\":\"松潘县\"},{\"list\":[],\"name\":\"汶川县\"},{\"list\":[],\"name\":\"小金县\"}],\"name\":\"阿坝藏族羌族自治州\"},{\"list\":[{\"list\":[],\"name\":\"巴州区\"},{\"list\":[],\"name\":\"南江县\"},{\"list\":[],\"name\":\"平昌县\"},{\"list\":[],\"name\":\"通江县\"}],\"name\":\"巴中市\"},{\"list\":[{\"list\":[],\"name\":\"崇州市\"},{\"list\":[],\"name\":\"成华区\"},{\"list\":[],\"name\":\"都江堰市\"},{\"list\":[],\"name\":\"大邑县\"},{\"list\":[],\"name\":\"金堂县\"},{\"list\":[],\"name\":\"金牛区\"},{\"list\":[],\"name\":\"锦江区\"},{\"list\":[],\"name\":\"龙泉驿区\"},{\"list\":[],\"name\":\"彭州市\"},{\"list\":[],\"name\":\"蒲江县\"},{\"list\":[],\"name\":\"郫　县\"},{\"list\":[],\"name\":\"邛崃市\"},{\"list\":[],\"name\":\"青白江区\"},{\"list\":[],\"name\":\"青羊区\"},{\"list\":[],\"name\":\"双流县\"},{\"list\":[],\"name\":\"温江区\"},{\"list\":[],\"name\":\"武侯区\"},{\"list\":[],\"name\":\"新津县\"},{\"list\":[],\"name\":\"新都区\"}],\"name\":\"成都市\"},{\"list\":[{\"list\":[],\"name\":\"大竹县\"},{\"list\":[],\"name\":\"达　县\"},{\"list\":[],\"name\":\"开江县\"},{\"list\":[],\"name\":\"渠　县\"},{\"list\":[],\"name\":\"通川区\"},{\"list\":[],\"name\":\"万源市\"},{\"list\":[],\"name\":\"宣汉县\"}],\"name\":\"达州市\"},{\"list\":[{\"list\":[],\"name\":\"广汉市\"},{\"list\":[],\"name\":\"旌阳区\"},{\"list\":[],\"name\":\"罗江县\"},{\"list\":[],\"name\":\"绵竹市\"},{\"list\":[],\"name\":\"什邡市\"},{\"list\":[],\"name\":\"中江县\"}],\"name\":\"德阳市\"},{\"list\":[{\"list\":[],\"name\":\"巴塘县\"},{\"list\":[],\"name\":\"白玉县\"},{\"list\":[],\"name\":\"得荣县\"},{\"list\":[],\"name\":\"稻城县\"},{\"list\":[],\"name\":\"德格县\"},{\"list\":[],\"name\":\"道孚县\"},{\"list\":[],\"name\":\"丹巴县\"},{\"list\":[],\"name\":\"甘孜县\"},{\"list\":[],\"name\":\"九龙县\"},{\"list\":[],\"name\":\"康定县\"},{\"list\":[],\"name\":\"理塘县\"},{\"list\":[],\"name\":\"炉霍县\"},{\"list\":[],\"name\":\"泸定县\"},{\"list\":[],\"name\":\"色达县\"},{\"list\":[],\"name\":\"石渠县\"},{\"list\":[],\"name\":\"乡城县\"},{\"list\":[],\"name\":\"新龙县\"},{\"list\":[],\"name\":\"雅江县\"}],\"name\":\"甘孜藏族自治州\"},{\"list\":[{\"list\":[],\"name\":\"广安区\"},{\"list\":[],\"name\":\"华莹市\"},{\"list\":[],\"name\":\"邻水县\"},{\"list\":[],\"name\":\"武胜县\"},{\"list\":[],\"name\":\"岳池县\"}],\"name\":\"广安市\"},{\"list\":[{\"list\":[],\"name\":\"苍溪县\"},{\"list\":[],\"name\":\"朝天区\"},{\"list\":[],\"name\":\"剑阁县\"},{\"list\":[],\"name\":\"青川县\"},{\"list\":[],\"name\":\"市中区\"},{\"list\":[],\"name\":\"旺苍县\"},{\"list\":[],\"name\":\"元坝区\"}],\"name\":\"广元市\"},{\"list\":[{\"list\":[],\"name\":\"布拖县\"},{\"list\":[],\"name\":\"德昌县\"},{\"list\":[],\"name\":\"甘洛县\"},{\"list\":[],\"name\":\"会东县\"},{\"list\":[],\"name\":\"会理县\"},{\"list\":[],\"name\":\"金阳县\"},{\"list\":[],\"name\":\"雷波县\"},{\"list\":[],\"name\":\"美姑县\"},{\"list\":[],\"name\":\"冕宁县\"},{\"list\":[],\"name\":\"木里藏族自治县\"},{\"list\":[],\"name\":\"宁南县\"},{\"list\":[],\"name\":\"普格县\"},{\"list\":[],\"name\":\"喜德县\"},{\"list\":[],\"name\":\"西昌市\"},{\"list\":[],\"name\":\"越西县\"},{\"list\":[],\"name\":\"盐源县\"},{\"list\":[],\"name\":\"昭觉县\"}],\"name\":\"凉山彝族自治州\"},{\"list\":[{\"list\":[],\"name\":\"峨眉山市\"},{\"list\":[],\"name\":\"峨边彝族自治县\"},{\"list\":[],\"name\":\"夹江县\"},{\"list\":[],\"name\":\"井研县\"},{\"list\":[],\"name\":\"犍为县\"},{\"list\":[],\"name\":\"金口河区\"},{\"list\":[],\"name\":\"马边彝族自治县\"},{\"list\":[],\"name\":\"沐川县\"},{\"list\":[],\"name\":\"沙湾区\"},{\"list\":[],\"name\":\"市中区\"},{\"list\":[],\"name\":\"五通桥区\"}],\"name\":\"乐山市\"},{\"list\":[{\"list\":[],\"name\":\"古蔺县\"},{\"list\":[],\"name\":\"合江县\"},{\"list\":[],\"name\":\"江阳区\"},{\"list\":[],\"name\":\"泸　县\"},{\"list\":[],\"name\":\"龙马潭区\"},{\"list\":[],\"name\":\"纳溪区\"},{\"list\":[],\"name\":\"叙永县\"}],\"name\":\"泸州市\"},{\"list\":[{\"list\":[],\"name\":\"丹棱县\"},{\"list\":[],\"name\":\"东坡区\"},{\"list\":[],\"name\":\"洪雅县\"},{\"list\":[],\"name\":\"彭山县\"},{\"list\":[],\"name\":\"青神县\"},{\"list\":[],\"name\":\"仁寿县\"}],\"name\":\"眉山市\"},{\"list\":[{\"list\":[],\"name\":\"安　县\"},{\"list\":[],\"name\":\"北川羌族自治县\"},{\"list\":[],\"name\":\"涪城区\"},{\"list\":[],\"name\":\"江油市\"},{\"list\":[],\"name\":\"平武县\"},{\"list\":[],\"name\":\"三台县\"},{\"list\":[],\"name\":\"盐亭县\"},{\"list\":[],\"name\":\"游仙区\"},{\"list\":[],\"name\":\"梓潼县\"}],\"name\":\"绵阳市\"},{\"list\":[{\"list\":[],\"name\":\"高坪区\"},{\"list\":[],\"name\":\"嘉陵区\"},{\"list\":[],\"name\":\"阆中市\"},{\"list\":[],\"name\":\"南部县\"},{\"list\":[],\"name\":\"蓬安县\"},{\"list\":[],\"name\":\"顺庆区\"},{\"list\":[],\"name\":\"西充县\"},{\"list\":[],\"name\":\"仪陇县\"},{\"list\":[],\"name\":\"营山县\"}],\"name\":\"南充市\"},{\"list\":[{\"list\":[],\"name\":\"东兴区\"},{\"list\":[],\"name\":\"隆昌县\"},{\"list\":[],\"name\":\"市中区\"},{\"list\":[],\"name\":\"威远县\"},{\"list\":[],\"name\":\"资中县\"}],\"name\":\"内江市\"},{\"list\":[{\"list\":[],\"name\":\"东　区\"},{\"list\":[],\"name\":\"米易县\"},{\"list\":[],\"name\":\"仁和区\"},{\"list\":[],\"name\":\"西　区\"},{\"list\":[],\"name\":\"盐边县\"}],\"name\":\"攀枝花市\"},{\"list\":[{\"list\":[],\"name\":\"安居区\"},{\"list\":[],\"name\":\"船山区\"},{\"list\":[],\"name\":\"大英县\"},{\"list\":[],\"name\":\"蓬溪县\"},{\"list\":[],\"name\":\"射洪县\"}],\"name\":\"遂宁市\"},{\"list\":[{\"list\":[],\"name\":\"宝兴县\"},{\"list\":[],\"name\":\"汉源县\"},{\"list\":[],\"name\":\"芦山县\"},{\"list\":[],\"name\":\"名山县\"},{\"list\":[],\"name\":\"石棉县\"},{\"list\":[],\"name\":\"天全县\"},{\"list\":[],\"name\":\"荥经县\"},{\"list\":[],\"name\":\"雨城区\"}],\"name\":\"雅安市\"},{\"list\":[{\"list\":[],\"name\":\"翠屏区\"},{\"list\":[],\"name\":\"珙　县\"},{\"list\":[],\"name\":\"高　县\"},{\"list\":[],\"name\":\"江安县\"},{\"list\":[],\"name\":\"南溪县\"},{\"list\":[],\"name\":\"屏山县\"},{\"list\":[],\"name\":\"兴文县\"},{\"list\":[],\"name\":\"筠连县\"},{\"list\":[],\"name\":\"宜宾县\"},{\"list\":[],\"name\":\"长宁县\"}],\"name\":\"宜宾市\"},{\"list\":[{\"list\":[],\"name\":\"安岳县\"},{\"list\":[],\"name\":\"简阳市\"},{\"list\":[],\"name\":\"乐至县\"},{\"list\":[],\"name\":\"雁江区\"}],\"name\":\"资阳市\"},{\"list\":[{\"list\":[],\"name\":\"大安区\"},{\"list\":[],\"name\":\"富顺县\"},{\"list\":[],\"name\":\"贡井区\"},{\"list\":[],\"name\":\"荣　县\"},{\"list\":[],\"name\":\"沿滩区\"},{\"list\":[],\"name\":\"自流井区\"}],\"name\":\"自贡市\"}],\"name\":\"四川省\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"博兴县\"},{\"list\":[],\"name\":\"滨城区\"},{\"list\":[],\"name\":\"惠民县\"},{\"list\":[],\"name\":\"无棣县\"},{\"list\":[],\"name\":\"阳信县\"},{\"list\":[],\"name\":\"邹平县\"},{\"list\":[],\"name\":\"沾化县\"}],\"name\":\"滨州市\"},{\"list\":[{\"list\":[],\"name\":\"德城区\"},{\"list\":[],\"name\":\"乐陵市\"},{\"list\":[],\"name\":\"临邑县\"},{\"list\":[],\"name\":\"陵　县\"},{\"list\":[],\"name\":\"宁津县\"},{\"list\":[],\"name\":\"平原县\"},{\"list\":[],\"name\":\"齐河县\"},{\"list\":[],\"name\":\"庆云县\"},{\"list\":[],\"name\":\"武城县\"},{\"list\":[],\"name\":\"夏津县\"},{\"list\":[],\"name\":\"禹城市\"}],\"name\":\"德州市\"},{\"list\":[{\"list\":[],\"name\":\"成武县\"},{\"list\":[],\"name\":\"曹　县\"},{\"list\":[],\"name\":\"东明县\"},{\"list\":[],\"name\":\"定陶县\"},{\"list\":[],\"name\":\"单　县\"},{\"list\":[],\"name\":\"鄄城县\"},{\"list\":[],\"name\":\"巨野县\"},{\"list\":[],\"name\":\"牡丹区\"},{\"list\":[],\"name\":\"郓城县\"}],\"name\":\"荷泽市\"},{\"list\":[{\"list\":[],\"name\":\"嘉祥县\"},{\"list\":[],\"name\":\"金乡县\"},{\"list\":[],\"name\":\"梁山县\"},{\"list\":[],\"name\":\"曲阜市\"},{\"list\":[],\"name\":\"任城区\"},{\"list\":[],\"name\":\"泗水县\"},{\"list\":[],\"name\":\"市中区\"},{\"list\":[],\"name\":\"汶上县\"},{\"list\":[],\"name\":\"微山县\"},{\"list\":[],\"name\":\"兖州市\"},{\"list\":[],\"name\":\"鱼台县\"},{\"list\":[],\"name\":\"邹城市\"}],\"name\":\"济宁市\"},{\"list\":[{\"list\":[],\"name\":\"槐荫区\"},{\"list\":[],\"name\":\"济阳县\"},{\"list\":[],\"name\":\"历城区\"},{\"list\":[],\"name\":\"历下区\"},{\"list\":[],\"name\":\"平阴县\"},{\"list\":[],\"name\":\"商河县\"},{\"list\":[],\"name\":\"市中区\"},{\"list\":[],\"name\":\"天桥区\"},{\"list\":[],\"name\":\"章丘市\"},{\"list\":[],\"name\":\"长清区\"}],\"name\":\"济南市\"},{\"list\":[{\"list\":[],\"name\":\"茌平县\"},{\"list\":[],\"name\":\"东阿县\"},{\"list\":[],\"name\":\"东昌府区\"},{\"list\":[],\"name\":\"高唐县\"},{\"list\":[],\"name\":\"冠　县\"},{\"list\":[],\"name\":\"临清市\"},{\"list\":[],\"name\":\"莘　县\"},{\"list\":[],\"name\":\"阳谷县\"}],\"name\":\"聊城市\"},{\"list\":[{\"list\":[],\"name\":\"苍山县\"},{\"list\":[],\"name\":\"费　县\"},{\"list\":[],\"name\":\"河东区\"},{\"list\":[],\"name\":\"莒南县\"},{\"list\":[],\"name\":\"临沭县\"},{\"list\":[],\"name\":\"罗庄区\"},{\"list\":[],\"name\":\"兰山区\"},{\"list\":[],\"name\":\"蒙阴县\"},{\"list\":[],\"name\":\"平邑县\"},{\"list\":[],\"name\":\"郯城县\"},{\"list\":[],\"name\":\"沂水县\"},{\"list\":[],\"name\":\"沂南县\"}],\"name\":\"临沂市\"},{\"list\":[{\"list\":[],\"name\":\"钢城区\"},{\"list\":[],\"name\":\"莱城区\"}],\"name\":\"莱芜市\"},{\"list\":[{\"list\":[],\"name\":\"城阳区\"},{\"list\":[],\"name\":\"黄岛区\"},{\"list\":[],\"name\":\"胶南市\"},{\"list\":[],\"name\":\"即墨市\"},{\"list\":[],\"name\":\"胶州市\"},{\"list\":[],\"name\":\"莱西市\"},{\"list\":[],\"name\":\"李沧区\"},{\"list\":[],\"name\":\"崂山区\"},{\"list\":[],\"name\":\"平度市\"},{\"list\":[],\"name\":\"四方区\"},{\"list\":[],\"name\":\"市北区\"},{\"list\":[],\"name\":\"市南区\"}],\"name\":\"青岛市\"},{\"list\":[{\"list\":[],\"name\":\"东港区\"},{\"list\":[],\"name\":\"莒　县\"},{\"list\":[],\"name\":\"岚山区\"},{\"list\":[],\"name\":\"五莲县\"}],\"name\":\"日照市\"},{\"list\":[{\"list\":[],\"name\":\"东平县\"},{\"list\":[],\"name\":\"岱岳区\"},{\"list\":[],\"name\":\"肥城市\"},{\"list\":[],\"name\":\"宁阳县\"},{\"list\":[],\"name\":\"泰山区\"},{\"list\":[],\"name\":\"新泰市\"}],\"name\":\"泰安市\"},{\"list\":[{\"list\":[],\"name\":\"环翠区\"},{\"list\":[],\"name\":\"乳山市\"},{\"list\":[],\"name\":\"荣成市\"},{\"list\":[],\"name\":\"文登市\"}],\"name\":\"威海市\"},{\"list\":[{\"list\":[],\"name\":\"安丘市\"},{\"list\":[],\"name\":\"昌邑市\"},{\"list\":[],\"name\":\"昌乐县\"},{\"list\":[],\"name\":\"坊子区\"},{\"list\":[],\"name\":\"高密市\"},{\"list\":[],\"name\":\"寒亭区\"},{\"list\":[],\"name\":\"奎文区\"},{\"list\":[],\"name\":\"临朐县\"},{\"list\":[],\"name\":\"青州市\"},{\"list\":[],\"name\":\"寿光市\"},{\"list\":[],\"name\":\"潍城区\"},{\"list\":[],\"name\":\"诸城市\"}],\"name\":\"潍坊市\"},{\"list\":[{\"list\":[],\"name\":\"福山区\"},{\"list\":[],\"name\":\"海阳市\"},{\"list\":[],\"name\":\"莱州市\"},{\"list\":[],\"name\":\"莱阳市\"},{\"list\":[],\"name\":\"龙口市\"},{\"list\":[],\"name\":\"莱山区\"},{\"list\":[],\"name\":\"牟平区\"},{\"list\":[],\"name\":\"蓬莱市\"},{\"list\":[],\"name\":\"栖霞市\"},{\"list\":[],\"name\":\"招远市\"},{\"list\":[],\"name\":\"长岛县\"},{\"list\":[],\"name\":\"芝罘区\"}],\"name\":\"烟台市\"},{\"list\":[{\"list\":[],\"name\":\"山亭区\"},{\"list\":[],\"name\":\"市中区\"},{\"list\":[],\"name\":\"滕州市\"},{\"list\":[],\"name\":\"台儿庄区\"},{\"list\":[],\"name\":\"薛城区\"},{\"list\":[],\"name\":\"峄城区\"}],\"name\":\"枣庄市\"},{\"list\":[{\"list\":[],\"name\":\"博山区\"},{\"list\":[],\"name\":\"高青县\"},{\"list\":[],\"name\":\"桓台县\"},{\"list\":[],\"name\":\"临淄区\"},{\"list\":[],\"name\":\"沂源县\"},{\"list\":[],\"name\":\"周村区\"},{\"list\":[],\"name\":\"张店区\"},{\"list\":[],\"name\":\"淄川区\"}],\"name\":\"淄博市\"}],\"name\":\"山东省\"},{\"list\":[{\"list\":[],\"name\":\"宝山区\"},{\"list\":[],\"name\":\"崇明县\"},{\"list\":[],\"name\":\"奉贤区\"},{\"list\":[],\"name\":\"虹口区\"},{\"list\":[],\"name\":\"黄浦区\"},{\"list\":[],\"name\":\"金山区\"},{\"list\":[],\"name\":\"嘉定区\"},{\"list\":[],\"name\":\"静安区\"},{\"list\":[],\"name\":\"卢湾区\"},{\"list\":[],\"name\":\"闵行区\"},{\"list\":[],\"name\":\"南汇区\"},{\"list\":[],\"name\":\"浦东新区\"},{\"list\":[],\"name\":\"普陀区\"},{\"list\":[],\"name\":\"青浦区\"},{\"list\":[],\"name\":\"松江区\"},{\"list\":[],\"name\":\"徐汇区\"},{\"list\":[],\"name\":\"杨浦区\"},{\"list\":[],\"name\":\"闸北区\"},{\"list\":[],\"name\":\"长宁区\"}],\"name\":\"上海市\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"城　区\"},{\"list\":[],\"name\":\"大同县\"},{\"list\":[],\"name\":\"广灵县\"},{\"list\":[],\"name\":\"浑源县\"},{\"list\":[],\"name\":\"矿　区\"},{\"list\":[],\"name\":\"灵丘县\"},{\"list\":[],\"name\":\"南郊区\"},{\"list\":[],\"name\":\"南郊区\"},{\"list\":[],\"name\":\"天镇县\"},{\"list\":[],\"name\":\"新荣区\"},{\"list\":[],\"name\":\"阳高县\"},{\"list\":[],\"name\":\"左云县\"}],\"name\":\"大同市\"},{\"list\":[{\"list\":[],\"name\":\"和顺县\"},{\"list\":[],\"name\":\"介休市\"},{\"list\":[],\"name\":\"灵石县\"},{\"list\":[],\"name\":\"平遥县\"},{\"list\":[],\"name\":\"祁　县\"},{\"list\":[],\"name\":\"寿阳县\"},{\"list\":[],\"name\":\"太谷县\"},{\"list\":[],\"name\":\"昔阳县\"},{\"list\":[],\"name\":\"榆社县\"},{\"list\":[],\"name\":\"榆次区\"},{\"list\":[],\"name\":\"左权县\"}],\"name\":\"晋中市\"},{\"list\":[{\"list\":[],\"name\":\"城　区\"},{\"list\":[],\"name\":\"高平市\"},{\"list\":[],\"name\":\"陵川县\"},{\"list\":[],\"name\":\"沁水县\"},{\"list\":[],\"name\":\"阳城县\"},{\"list\":[],\"name\":\"泽州县\"}],\"name\":\"晋城市\"},{\"list\":[{\"list\":[],\"name\":\"汾阳市\"},{\"list\":[],\"name\":\"方山县\"},{\"list\":[],\"name\":\"交口县\"},{\"list\":[],\"name\":\"交城县\"},{\"list\":[],\"name\":\"岚　县\"},{\"list\":[],\"name\":\"柳林县\"},{\"list\":[],\"name\":\"临　县\"},{\"list\":[],\"name\":\"离石区\"},{\"list\":[],\"name\":\"石楼县\"},{\"list\":[],\"name\":\"文水县\"},{\"list\":[],\"name\":\"孝义市\"},{\"list\":[],\"name\":\"兴　县\"},{\"list\":[],\"name\":\"中阳县\"}],\"name\":\"吕梁市\"},{\"list\":[{\"list\":[],\"name\":\"安泽县\"},{\"list\":[],\"name\":\"大宁县\"},{\"list\":[],\"name\":\"汾西县\"},{\"list\":[],\"name\":\"浮山县\"},{\"list\":[],\"name\":\"古　县\"},{\"list\":[],\"name\":\"霍州市\"},{\"list\":[],\"name\":\"侯马市\"},{\"list\":[],\"name\":\"洪洞县\"},{\"list\":[],\"name\":\"吉　县\"},{\"list\":[],\"name\":\"蒲　县\"},{\"list\":[],\"name\":\"曲沃县\"},{\"list\":[],\"name\":\"隰　县\"},{\"list\":[],\"name\":\"乡宁县\"},{\"list\":[],\"name\":\"襄汾县\"},{\"list\":[],\"name\":\"永和县\"},{\"list\":[],\"name\":\"翼城县\"},{\"list\":[],\"name\":\"尧都区\"}],\"name\":\"临汾市\"},{\"list\":[{\"list\":[],\"name\":\"怀仁县\"},{\"list\":[],\"name\":\"平鲁区\"},{\"list\":[],\"name\":\"山阴县\"},{\"list\":[],\"name\":\"朔城区\"},{\"list\":[],\"name\":\"右玉县\"},{\"list\":[],\"name\":\"应　县\"}],\"name\":\"朔州市\"},{\"list\":[{\"list\":[],\"name\":\"古交市\"},{\"list\":[],\"name\":\"晋源区\"},{\"list\":[],\"name\":\"尖草坪区\"},{\"list\":[],\"name\":\"娄烦县\"},{\"list\":[],\"name\":\"清徐县\"},{\"list\":[],\"name\":\"万柏林区\"},{\"list\":[],\"name\":\"杏花岭区\"},{\"list\":[],\"name\":\"小店区\"},{\"list\":[],\"name\":\"阳曲县\"},{\"list\":[],\"name\":\"迎泽区\"}],\"name\":\"太原市\"},{\"list\":[{\"list\":[],\"name\":\"保德县\"},{\"list\":[],\"name\":\"代　县\"},{\"list\":[],\"name\":\"定襄县\"},{\"list\":[],\"name\":\"繁峙县\"},{\"list\":[],\"name\":\"河曲县\"},{\"list\":[],\"name\":\"静乐县\"},{\"list\":[],\"name\":\"岢岚县\"},{\"list\":[],\"name\":\"宁武县\"},{\"list\":[],\"name\":\"偏关县\"},{\"list\":[],\"name\":\"神池县\"},{\"list\":[],\"name\":\"五寨县\"},{\"list\":[],\"name\":\"五台县\"},{\"list\":[],\"name\":\"忻府区\"},{\"list\":[],\"name\":\"原平市\"}],\"name\":\"忻州市\"},{\"list\":[{\"list\":[],\"name\":\"河津市\"},{\"list\":[],\"name\":\"绛　县\"},{\"list\":[],\"name\":\"稷山县\"},{\"list\":[],\"name\":\"临猗县\"},{\"list\":[],\"name\":\"平陆县\"},{\"list\":[],\"name\":\"芮城县\"},{\"list\":[],\"name\":\"闻喜县\"},{\"list\":[],\"name\":\"万荣县\"},{\"list\":[],\"name\":\"夏　县\"},{\"list\":[],\"name\":\"新绛县\"},{\"list\":[],\"name\":\"永济市\"},{\"list\":[],\"name\":\"垣曲县\"},{\"list\":[],\"name\":\"盐湖区\"}],\"name\":\"运城市\"},{\"list\":[{\"list\":[],\"name\":\"城　区\"},{\"list\":[],\"name\":\"郊　区\"},{\"list\":[],\"name\":\"矿　区\"},{\"list\":[],\"name\":\"平定县\"},{\"list\":[],\"name\":\"盂　县\"}],\"name\":\"阳泉市\"},{\"list\":[{\"list\":[],\"name\":\"城　区\"},{\"list\":[],\"name\":\"壶关县\"},{\"list\":[],\"name\":\"郊　区\"},{\"list\":[],\"name\":\"潞城市\"},{\"list\":[],\"name\":\"黎城县\"},{\"list\":[],\"name\":\"平顺县\"},{\"list\":[],\"name\":\"沁源县\"},{\"list\":[],\"name\":\"沁　县\"},{\"list\":[],\"name\":\"屯留县\"},{\"list\":[],\"name\":\"武乡县\"},{\"list\":[],\"name\":\"襄垣县\"},{\"list\":[],\"name\":\"长子县\"},{\"list\":[],\"name\":\"长治县\"}],\"name\":\"长治市\"}],\"name\":\"山西省\"},{\"list\":[],\"name\":\"台湾省\"},{\"list\":[{\"list\":[],\"name\":\"宝坻区\"},{\"list\":[],\"name\":\"北辰区\"},{\"list\":[],\"name\":\"东丽区\"},{\"list\":[],\"name\":\"大港区\"},{\"list\":[],\"name\":\"汉沽区\"},{\"list\":[],\"name\":\"红桥区\"},{\"list\":[],\"name\":\"河北区\"},{\"list\":[],\"name\":\"河西区\"},{\"list\":[],\"name\":\"河东区\"},{\"list\":[],\"name\":\"和平区\"},{\"list\":[],\"name\":\"蓟　县\"},{\"list\":[],\"name\":\"静海县\"},{\"list\":[],\"name\":\"津南区\"},{\"list\":[],\"name\":\"宁河县\"},{\"list\":[],\"name\":\"南开区\"},{\"list\":[],\"name\":\"塘沽区\"},{\"list\":[],\"name\":\"武清区\"},{\"list\":[],\"name\":\"西青区\"}],\"name\":\"天津市\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"阿勒泰市\"},{\"list\":[],\"name\":\"布尔津县\"},{\"list\":[],\"name\":\"福海县\"},{\"list\":[],\"name\":\"富蕴县\"},{\"list\":[],\"name\":\"哈巴河县\"},{\"list\":[],\"name\":\"吉木乃县\"},{\"list\":[],\"name\":\"青河县\"}],\"name\":\"阿勒泰地区\"},{\"list\":[{\"list\":[],\"name\":\"阿瓦提县\"},{\"list\":[],\"name\":\"阿克苏市\"},{\"list\":[],\"name\":\"拜城县\"},{\"list\":[],\"name\":\"柯坪县\"},{\"list\":[],\"name\":\"库车县\"},{\"list\":[],\"name\":\"沙雅县\"},{\"list\":[],\"name\":\"乌什县\"},{\"list\":[],\"name\":\"温宿县\"},{\"list\":[],\"name\":\"新和县\"}],\"name\":\"阿克苏地区\"},{\"list\":[{\"list\":[],\"name\":\"博湖县\"},{\"list\":[],\"name\":\"和硕县\"},{\"list\":[],\"name\":\"和静县\"},{\"list\":[],\"name\":\"库尔勒市\"},{\"list\":[],\"name\":\"轮台县\"},{\"list\":[],\"name\":\"且末县\"},{\"list\":[],\"name\":\"若羌县\"},{\"list\":[],\"name\":\"尉犁县\"},{\"list\":[],\"name\":\"焉耆回族自治县\"}],\"name\":\"巴音郭楞蒙古自治州\"},{\"list\":[{\"list\":[],\"name\":\"博乐市\"},{\"list\":[],\"name\":\"精河县\"},{\"list\":[],\"name\":\"温泉县\"}],\"name\":\"博尔塔拉蒙古自治州\"},{\"list\":[{\"list\":[],\"name\":\"昌吉市\"},{\"list\":[],\"name\":\"阜康市\"},{\"list\":[],\"name\":\"呼图壁县\"},{\"list\":[],\"name\":\"吉木萨尔县\"},{\"list\":[],\"name\":\"木垒哈萨克自治县\"},{\"list\":[],\"name\":\"玛纳斯县\"},{\"list\":[],\"name\":\"米泉市\"},{\"list\":[],\"name\":\"奇台县\"}],\"name\":\"昌吉回族自治州\"},{\"list\":[{\"list\":[],\"name\":\"策勒县\"},{\"list\":[],\"name\":\"和田县\"},{\"list\":[],\"name\":\"和田市\"},{\"list\":[],\"name\":\"洛浦县\"},{\"list\":[],\"name\":\"民丰县\"},{\"list\":[],\"name\":\"墨玉县\"},{\"list\":[],\"name\":\"皮山县\"},{\"list\":[],\"name\":\"于田县\"}],\"name\":\"和田地区\"},{\"list\":[{\"list\":[],\"name\":\"巴里坤哈萨克自治县\"},{\"list\":[],\"name\":\"哈密市\"},{\"list\":[],\"name\":\"伊吾县\"}],\"name\":\"哈密地区\"},{\"list\":[{\"list\":[],\"name\":\"巴楚县\"},{\"list\":[],\"name\":\"伽师县\"},{\"list\":[],\"name\":\"喀什市\"},{\"list\":[],\"name\":\"麦盖提县\"},{\"list\":[],\"name\":\"莎车县\"},{\"list\":[],\"name\":\"疏勒县\"},{\"list\":[],\"name\":\"疏附县\"},{\"list\":[],\"name\":\"塔什库尔干塔吉克自治县\"},{\"list\":[],\"name\":\"岳普湖县\"},{\"list\":[],\"name\":\"叶城县\"},{\"list\":[],\"name\":\"英吉沙县\"},{\"list\":[],\"name\":\"泽普县\"}],\"name\":\"喀什地区\"},{\"list\":[{\"list\":[],\"name\":\"阿合奇县\"},{\"list\":[],\"name\":\"阿克陶县\"},{\"list\":[],\"name\":\"阿图什市\"},{\"list\":[],\"name\":\"乌恰县\"}],\"name\":\"克孜勒苏柯尔克孜自治州\"},{\"list\":[{\"list\":[],\"name\":\"白碱滩区\"},{\"list\":[],\"name\":\"独山子区\"},{\"list\":[],\"name\":\"克拉玛依区\"},{\"list\":[],\"name\":\"乌尔禾区\"}],\"name\":\"克拉玛依市\"},{\"list\":[{\"list\":[],\"name\":\"阿拉尔市\"},{\"list\":[],\"name\":\"石河子市\"},{\"list\":[],\"name\":\"图木舒克市\"}],\"name\":\"省直辖行政单位\"},{\"list\":[{\"list\":[],\"name\":\"额敏县\"},{\"list\":[],\"name\":\"和布克赛尔蒙古自治县\"},{\"list\":[],\"name\":\"沙湾县\"},{\"list\":[],\"name\":\"托里县\"},{\"list\":[],\"name\":\"塔城市\"},{\"list\":[],\"name\":\"乌苏市\"},{\"list\":[],\"name\":\"裕民县\"}],\"name\":\"塔城地区\"},{\"list\":[{\"list\":[],\"name\":\"鄯善县\"},{\"list\":[],\"name\":\"托克逊县\"},{\"list\":[],\"name\":\"吐鲁番市\"}],\"name\":\"吐鲁番地区\"},{\"list\":[{\"list\":[],\"name\":\"东山区\"},{\"list\":[],\"name\":\"达坂城区\"},{\"list\":[],\"name\":\"水磨沟区\"},{\"list\":[],\"name\":\"沙依巴克区\"},{\"list\":[],\"name\":\"头屯河区\"},{\"list\":[],\"name\":\"天山区\"},{\"list\":[],\"name\":\"乌鲁木齐县\"},{\"list\":[],\"name\":\"新市区\"}],\"name\":\"乌鲁木齐市\"},{\"list\":[{\"list\":[],\"name\":\"察布查尔锡伯自治县\"},{\"list\":[],\"name\":\"巩留县\"},{\"list\":[],\"name\":\"霍城县\"},{\"list\":[],\"name\":\"奎屯市\"},{\"list\":[],\"name\":\"尼勒克县\"},{\"list\":[],\"name\":\"特克斯县\"},{\"list\":[],\"name\":\"新源县\"},{\"list\":[],\"name\":\"伊宁县\"},{\"list\":[],\"name\":\"伊宁市\"},{\"list\":[],\"name\":\"昭苏县\"}],\"name\":\"伊犁哈萨克自治州\"}],\"name\":\"新疆维吾尔自治区\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"措勤县\"},{\"list\":[],\"name\":\"改则县\"},{\"list\":[],\"name\":\"革吉县\"},{\"list\":[],\"name\":\"噶尔县\"},{\"list\":[],\"name\":\"普兰县\"},{\"list\":[],\"name\":\"日土县\"},{\"list\":[],\"name\":\"札达县\"}],\"name\":\"阿里地区\"},{\"list\":[{\"list\":[],\"name\":\"边坝县\"},{\"list\":[],\"name\":\"八宿县\"},{\"list\":[],\"name\":\"察雅县\"},{\"list\":[],\"name\":\"昌都县\"},{\"list\":[],\"name\":\"丁青县\"},{\"list\":[],\"name\":\"贡觉县\"},{\"list\":[],\"name\":\"江达县\"},{\"list\":[],\"name\":\"洛隆县\"},{\"list\":[],\"name\":\"类乌齐县\"},{\"list\":[],\"name\":\"芒康县\"},{\"list\":[],\"name\":\"左贡县\"}],\"name\":\"昌都地区\"},{\"list\":[{\"list\":[],\"name\":\"波密县\"},{\"list\":[],\"name\":\"察隅县\"},{\"list\":[],\"name\":\"工布江达县\"},{\"list\":[],\"name\":\"朗　县\"},{\"list\":[],\"name\":\"林芝县\"},{\"list\":[],\"name\":\"墨脱县\"},{\"list\":[],\"name\":\"米林县\"}],\"name\":\"林芝地区\"},{\"list\":[{\"list\":[],\"name\":\"城关区\"},{\"list\":[],\"name\":\"达孜县\"},{\"list\":[],\"name\":\"堆龙德庆县\"},{\"list\":[],\"name\":\"当雄县\"},{\"list\":[],\"name\":\"林周县\"},{\"list\":[],\"name\":\"墨竹工卡县\"},{\"list\":[],\"name\":\"尼木县\"},{\"list\":[],\"name\":\"曲水县\"}],\"name\":\"拉萨市\"},{\"list\":[{\"list\":[],\"name\":\"安多县\"},{\"list\":[],\"name\":\"巴青县\"},{\"list\":[],\"name\":\"班戈县\"},{\"list\":[],\"name\":\"比如县\"},{\"list\":[],\"name\":\"嘉黎县\"},{\"list\":[],\"name\":\"尼玛县\"},{\"list\":[],\"name\":\"聂荣县\"},{\"list\":[],\"name\":\"那曲县\"},{\"list\":[],\"name\":\"索　县\"},{\"list\":[],\"name\":\"申扎县\"}],\"name\":\"那曲地区\"},{\"list\":[{\"list\":[],\"name\":\"昂仁县\"},{\"list\":[],\"name\":\"白朗县\"},{\"list\":[],\"name\":\"定结县\"},{\"list\":[],\"name\":\"定日县\"},{\"list\":[],\"name\":\"岗巴县\"},{\"list\":[],\"name\":\"吉隆县\"},{\"list\":[],\"name\":\"江孜县\"},{\"list\":[],\"name\":\"康马县\"},{\"list\":[],\"name\":\"拉孜县\"},{\"list\":[],\"name\":\"聂拉木县\"},{\"list\":[],\"name\":\"南木林县\"},{\"list\":[],\"name\":\"仁布县\"},{\"list\":[],\"name\":\"日喀则市\"},{\"list\":[],\"name\":\"萨嘎县\"},{\"list\":[],\"name\":\"萨迦县\"},{\"list\":[],\"name\":\"谢通门县\"},{\"list\":[],\"name\":\"亚东县\"},{\"list\":[],\"name\":\"仲巴县\"}],\"name\":\"日喀则地区\"},{\"list\":[{\"list\":[],\"name\":\"错那县\"},{\"list\":[],\"name\":\"措美县\"},{\"list\":[],\"name\":\"贡嘎县\"},{\"list\":[],\"name\":\"加查县\"},{\"list\":[],\"name\":\"浪卡子县\"},{\"list\":[],\"name\":\"隆子县\"},{\"list\":[],\"name\":\"洛扎县\"},{\"list\":[],\"name\":\"乃东县\"},{\"list\":[],\"name\":\"曲松县\"},{\"list\":[],\"name\":\"琼结县\"},{\"list\":[],\"name\":\"桑日县\"},{\"list\":[],\"name\":\"扎囊县\"}],\"name\":\"山南地区\"}],\"name\":\"西藏自治区\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"昌宁县\"},{\"list\":[],\"name\":\"龙陵县\"},{\"list\":[],\"name\":\"隆阳区\"},{\"list\":[],\"name\":\"施甸县\"},{\"list\":[],\"name\":\"腾冲县\"}],\"name\":\"保山市\"},{\"list\":[{\"list\":[],\"name\":\"楚雄市\"},{\"list\":[],\"name\":\"大姚县\"},{\"list\":[],\"name\":\"禄丰县\"},{\"list\":[],\"name\":\"牟定县\"},{\"list\":[],\"name\":\"南华县\"},{\"list\":[],\"name\":\"双柏县\"},{\"list\":[],\"name\":\"武定县\"},{\"list\":[],\"name\":\"元谋县\"},{\"list\":[],\"name\":\"永仁县\"},{\"list\":[],\"name\":\"姚安县\"}],\"name\":\"楚雄彝族自治州\"},{\"list\":[{\"list\":[],\"name\":\"德钦县\"},{\"list\":[],\"name\":\"维西傈僳族自治县\"},{\"list\":[],\"name\":\"香格里拉县\"}],\"name\":\"迪庆藏族自治州\"},{\"list\":[{\"list\":[],\"name\":\"陇川县\"},{\"list\":[],\"name\":\"梁河县\"},{\"list\":[],\"name\":\"潞西市\"},{\"list\":[],\"name\":\"瑞丽市\"},{\"list\":[],\"name\":\"盈江县\"}],\"name\":\"德宏傣族景颇族自治州\"},{\"list\":[{\"list\":[],\"name\":\"宾川县\"},{\"list\":[],\"name\":\"大理市\"},{\"list\":[],\"name\":\"洱源县\"},{\"list\":[],\"name\":\"鹤庆县\"},{\"list\":[],\"name\":\"剑川县\"},{\"list\":[],\"name\":\"弥渡县\"},{\"list\":[],\"name\":\"南涧彝族自治县\"},{\"list\":[],\"name\":\"巍山彝族回族自治县\"},{\"list\":[],\"name\":\"祥云县\"},{\"list\":[],\"name\":\"云龙县\"},{\"list\":[],\"name\":\"永平县\"},{\"list\":[],\"name\":\"漾濞彝族自治县\"}],\"name\":\"大理白族自治州\"},{\"list\":[{\"list\":[],\"name\":\"个旧市\"},{\"list\":[],\"name\":\"河口瑶族自治县\"},{\"list\":[],\"name\":\"金平苗族瑶族傣族自治县\"},{\"list\":[],\"name\":\"建水县\"},{\"list\":[],\"name\":\"开远市\"},{\"list\":[],\"name\":\"绿春县\"},{\"list\":[],\"name\":\"泸西县\"},{\"list\":[],\"name\":\"弥勒县\"},{\"list\":[],\"name\":\"蒙自县\"},{\"list\":[],\"name\":\"屏边苗族自治县\"},{\"list\":[],\"name\":\"石屏县\"},{\"list\":[],\"name\":\"元阳县\"}],\"name\":\"红河哈尼族彝族自治州\"},{\"list\":[{\"list\":[],\"name\":\"安宁市\"},{\"list\":[],\"name\":\"呈贡县\"},{\"list\":[],\"name\":\"东川区\"},{\"list\":[],\"name\":\"富民县\"},{\"list\":[],\"name\":\"官渡区\"},{\"list\":[],\"name\":\"晋宁县\"},{\"list\":[],\"name\":\"禄劝彝族苗族自治县\"},{\"list\":[],\"name\":\"盘龙区\"},{\"list\":[],\"name\":\"嵩明县\"},{\"list\":[],\"name\":\"石林彝族自治县\"},{\"list\":[],\"name\":\"五华区\"},{\"list\":[],\"name\":\"寻甸回族彝族自治县\"},{\"list\":[],\"name\":\"西山区\"},{\"list\":[],\"name\":\"宜良县\"}],\"name\":\"昆明市\"},{\"list\":[{\"list\":[],\"name\":\"沧源佤族自治县\"},{\"list\":[],\"name\":\"凤庆县\"},{\"list\":[],\"name\":\"耿马傣族佤族自治县\"},{\"list\":[],\"name\":\"临翔区\"},{\"list\":[],\"name\":\"双江拉祜族佤族布朗族傣族自治县\"},{\"list\":[],\"name\":\"永德县\"},{\"list\":[],\"name\":\"云　县\"},{\"list\":[],\"name\":\"镇康县\"}],\"name\":\"临沧市\"},{\"list\":[{\"list\":[],\"name\":\"古城区\"},{\"list\":[],\"name\":\"华坪县\"},{\"list\":[],\"name\":\"宁蒗彝族自治县\"},{\"list\":[],\"name\":\"永胜县\"},{\"list\":[],\"name\":\"玉龙纳西族自治县\"}],\"name\":\"丽江市\"},{\"list\":[{\"list\":[],\"name\":\"福贡县\"},{\"list\":[],\"name\":\"贡山独龙族怒族自治县\"},{\"list\":[],\"name\":\"兰坪白族普米族自治县\"},{\"list\":[],\"name\":\"泸水县\"}],\"name\":\"怒江傈僳族自治州\"},{\"list\":[{\"list\":[],\"name\":\"富源县\"},{\"list\":[],\"name\":\"会泽县\"},{\"list\":[],\"name\":\"罗平县\"},{\"list\":[],\"name\":\"陆良县\"},{\"list\":[],\"name\":\"马龙县\"},{\"list\":[],\"name\":\"麒麟区\"},{\"list\":[],\"name\":\"师宗县\"},{\"list\":[],\"name\":\"宣威市\"},{\"list\":[],\"name\":\"沾益县\"}],\"name\":\"曲靖市\"},{\"list\":[{\"list\":[],\"name\":\"翠云区\"},{\"list\":[],\"name\":\"江城哈尼族彝族自治县\"},{\"list\":[],\"name\":\"景谷傣族彝族自治县\"},{\"list\":[],\"name\":\"景东彝族自治县\"},{\"list\":[],\"name\":\"澜沧拉祜族自治县\"},{\"list\":[],\"name\":\"孟连傣族拉祜族佤族自治县\"},{\"list\":[],\"name\":\"墨江哈尼族自治县\"},{\"list\":[],\"name\":\"普洱哈尼族彝族自治县\"},{\"list\":[],\"name\":\"西盟佤族自治县\"},{\"list\":[],\"name\":\"镇沅彝族哈尼族拉祜族自治县\"}],\"name\":\"思茅市\"},{\"list\":[{\"list\":[],\"name\":\"富宁县\"},{\"list\":[],\"name\":\"广南县\"},{\"list\":[],\"name\":\"马关县\"},{\"list\":[],\"name\":\"麻栗坡县\"},{\"list\":[],\"name\":\"丘北县\"},{\"list\":[],\"name\":\"文山县\"},{\"list\":[],\"name\":\"西畴县\"},{\"list\":[],\"name\":\"砚山县\"}],\"name\":\"文山壮族苗族自治州\"},{\"list\":[{\"list\":[],\"name\":\"景洪市\"},{\"list\":[],\"name\":\"勐腊县\"},{\"list\":[],\"name\":\"勐海县\"}],\"name\":\"西双版纳傣族自治州\"},{\"list\":[{\"list\":[],\"name\":\"澄江县\"},{\"list\":[],\"name\":\"峨山彝族自治县\"},{\"list\":[],\"name\":\"华宁县\"},{\"list\":[],\"name\":\"红塔区\"},{\"list\":[],\"name\":\"江川县\"},{\"list\":[],\"name\":\"通海县\"},{\"list\":[],\"name\":\"新平彝族傣族自治县\"},{\"list\":[],\"name\":\"元江哈尼族彝族傣族自治县\"},{\"list\":[],\"name\":\"易门县\"}],\"name\":\"玉溪市\"},{\"list\":[{\"list\":[],\"name\":\"大关县\"},{\"list\":[],\"name\":\"鲁甸县\"},{\"list\":[],\"name\":\"巧家县\"},{\"list\":[],\"name\":\"水富县\"},{\"list\":[],\"name\":\"绥江县\"},{\"list\":[],\"name\":\"威信县\"},{\"list\":[],\"name\":\"彝良县\"},{\"list\":[],\"name\":\"永善县\"},{\"list\":[],\"name\":\"盐津县\"},{\"list\":[],\"name\":\"镇雄县\"},{\"list\":[],\"name\":\"昭阳区\"}],\"name\":\"昭通市\"}],\"name\":\"云南省\"},{\"list\":[{\"list\":[],\"name\":\"璧山县\"},{\"list\":[],\"name\":\"巴南区\"},{\"list\":[],\"name\":\"北碚区\"},{\"list\":[],\"name\":\"城口县\"},{\"list\":[],\"name\":\"垫江县\"},{\"list\":[],\"name\":\"大足县\"},{\"list\":[],\"name\":\"大渡口区\"},{\"list\":[],\"name\":\"奉节县\"},{\"list\":[],\"name\":\"丰都县\"},{\"list\":[],\"name\":\"涪陵区\"},{\"list\":[],\"name\":\"合川市\"},{\"list\":[],\"name\":\"江津市\"},{\"list\":[],\"name\":\"九龙坡区\"},{\"list\":[],\"name\":\"江北区\"},{\"list\":[],\"name\":\"开　县\"},{\"list\":[],\"name\":\"梁平县\"},{\"list\":[],\"name\":\"南川市\"},{\"list\":[],\"name\":\"南岸区\"},{\"list\":[],\"name\":\"彭水苗族土家族自治县\"},{\"list\":[],\"name\":\"綦江县\"},{\"list\":[],\"name\":\"黔江区\"},{\"list\":[],\"name\":\"荣昌县\"},{\"list\":[],\"name\":\"石柱土家族自治县\"},{\"list\":[],\"name\":\"双桥区\"},{\"list\":[],\"name\":\"沙坪坝区\"},{\"list\":[],\"name\":\"铜梁县\"},{\"list\":[],\"name\":\"潼南县\"},{\"list\":[],\"name\":\"巫溪县\"},{\"list\":[],\"name\":\"巫山县\"},{\"list\":[],\"name\":\"武隆县\"},{\"list\":[],\"name\":\"万盛区\"},{\"list\":[],\"name\":\"万州区\"},{\"list\":[],\"name\":\"秀山土家族苗族自治县\"},{\"list\":[],\"name\":\"永川市\"},{\"list\":[],\"name\":\"酉阳土家族苗族自治县\"},{\"list\":[],\"name\":\"云阳县\"},{\"list\":[],\"name\":\"渝北区\"},{\"list\":[],\"name\":\"渝中区\"},{\"list\":[],\"name\":\"忠　县\"},{\"list\":[],\"name\":\"长寿区\"}],\"name\":\"重庆市\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"安吉县\"},{\"list\":[],\"name\":\"德清县\"},{\"list\":[],\"name\":\"南浔区\"},{\"list\":[],\"name\":\"吴兴区\"},{\"list\":[],\"name\":\"长兴县\"}],\"name\":\"湖州市\"},{\"list\":[{\"list\":[],\"name\":\"滨江区\"},{\"list\":[],\"name\":\"淳安县\"},{\"list\":[],\"name\":\"富阳市\"},{\"list\":[],\"name\":\"拱墅区\"},{\"list\":[],\"name\":\"建德市\"},{\"list\":[],\"name\":\"江干区\"},{\"list\":[],\"name\":\"临安市\"},{\"list\":[],\"name\":\"上城区\"},{\"list\":[],\"name\":\"桐庐县\"},{\"list\":[],\"name\":\"萧山区\"},{\"list\":[],\"name\":\"西湖区\"},{\"list\":[],\"name\":\"下城区\"},{\"list\":[],\"name\":\"余杭区\"}],\"name\":\"杭州市\"},{\"list\":[{\"list\":[],\"name\":\"东阳市\"},{\"list\":[],\"name\":\"金东区\"},{\"list\":[],\"name\":\"兰溪市\"},{\"list\":[],\"name\":\"磐安县\"},{\"list\":[],\"name\":\"浦江县\"},{\"list\":[],\"name\":\"武义县\"},{\"list\":[],\"name\":\"婺城区\"},{\"list\":[],\"name\":\"永康市\"},{\"list\":[],\"name\":\"义乌市\"}],\"name\":\"金华市\"},{\"list\":[{\"list\":[],\"name\":\"海宁市\"},{\"list\":[],\"name\":\"海盐县\"},{\"list\":[],\"name\":\"嘉善县\"},{\"list\":[],\"name\":\"平湖市\"},{\"list\":[],\"name\":\"桐乡市\"},{\"list\":[],\"name\":\"秀洲区\"},{\"list\":[],\"name\":\"秀城区\"}],\"name\":\"嘉兴市\"},{\"list\":[{\"list\":[],\"name\":\"景宁畲族自治县\"},{\"list\":[],\"name\":\"缙云县\"},{\"list\":[],\"name\":\"龙泉市\"},{\"list\":[],\"name\":\"莲都区\"},{\"list\":[],\"name\":\"庆元县\"},{\"list\":[],\"name\":\"青田县\"},{\"list\":[],\"name\":\"松阳县\"},{\"list\":[],\"name\":\"遂昌县\"},{\"list\":[],\"name\":\"云和县\"}],\"name\":\"丽水市\"},{\"list\":[{\"list\":[],\"name\":\"北仑区\"},{\"list\":[],\"name\":\"慈溪市\"},{\"list\":[],\"name\":\"奉化市\"},{\"list\":[],\"name\":\"海曙区\"},{\"list\":[],\"name\":\"江北区\"},{\"list\":[],\"name\":\"江东区\"},{\"list\":[],\"name\":\"宁海县\"},{\"list\":[],\"name\":\"象山县\"},{\"list\":[],\"name\":\"余姚市\"},{\"list\":[],\"name\":\"鄞州区\"},{\"list\":[],\"name\":\"镇海区\"}],\"name\":\"宁波市\"},{\"list\":[{\"list\":[],\"name\":\"常山县\"},{\"list\":[],\"name\":\"江山市\"},{\"list\":[],\"name\":\"开化县\"},{\"list\":[],\"name\":\"柯城区\"},{\"list\":[],\"name\":\"龙游县\"},{\"list\":[],\"name\":\"衢江区\"}],\"name\":\"衢州市\"},{\"list\":[{\"list\":[],\"name\":\"嵊州市\"},{\"list\":[],\"name\":\"上虞市\"},{\"list\":[],\"name\":\"绍兴县\"},{\"list\":[],\"name\":\"新昌县\"},{\"list\":[],\"name\":\"越城区\"},{\"list\":[],\"name\":\"诸暨市\"}],\"name\":\"绍兴市\"},{\"list\":[{\"list\":[],\"name\":\"黄岩区\"},{\"list\":[],\"name\":\"椒江区\"},{\"list\":[],\"name\":\"临海市\"},{\"list\":[],\"name\":\"路桥区\"},{\"list\":[],\"name\":\"三门县\"},{\"list\":[],\"name\":\"天台县\"},{\"list\":[],\"name\":\"温岭市\"},{\"list\":[],\"name\":\"仙居县\"},{\"list\":[],\"name\":\"玉环县\"}],\"name\":\"台州市\"},{\"list\":[{\"list\":[],\"name\":\"苍南县\"},{\"list\":[],\"name\":\"洞头县\"},{\"list\":[],\"name\":\"乐清市\"},{\"list\":[],\"name\":\"龙湾区\"},{\"list\":[],\"name\":\"鹿城区\"},{\"list\":[],\"name\":\"瓯海区\"},{\"list\":[],\"name\":\"平阳县\"},{\"list\":[],\"name\":\"瑞安市\"},{\"list\":[],\"name\":\"泰顺县\"},{\"list\":[],\"name\":\"文成县\"},{\"list\":[],\"name\":\"永嘉县\"}],\"name\":\"温州市\"},{\"list\":[{\"list\":[],\"name\":\"岱山县\"},{\"list\":[],\"name\":\"定海区\"},{\"list\":[],\"name\":\"普陀区\"},{\"list\":[],\"name\":\"嵊泗县\"}],\"name\":\"舟山市\"}],\"name\":\"浙江省\"}]", response);
	}
	@RequestMapping("/sysCity.areaCity.do")
	public void areaCity(HttpServletResponse response)
	{
		/*
		Map<String,List<String>> map = new LinkedHashMap<String, List<String>>();
		map.put("华北",new ArrayList<String>() {{add("北京市:1:0");add("天津市:2:0");add("山西省:4:1");add("内蒙古自治区:5:1");add("河北省:3:1");}});
		map.put("东北",new ArrayList<String>() {{add("辽宁省:6:1");add("吉林省:7:1");add("黑龙江省:8:1");}});
		map.put("华东",new ArrayList<String>() {{add("上海市:9:0");add("江苏省:10:1");add("浙江省:11:1");add("安徽省:12:1");add("福建省:13:1");add("江西省:14:1");;add("山东省:15:1");}});
		map.put("华中",new ArrayList<String>() {{add("湖南省:18:1");add("湖北省:17:1");}});
		map.put("华南",new ArrayList<String>() {{add("广东省:19:1");add("广西壮族自治区:20:1");add("海南省:21:1");}});
		map.put("西北",new ArrayList<String>() {{add("陕西省:27:1");add("甘肃省:28:1");add("青海省:29:1");add("宁夏回族自治区:30:1");add("新疆维吾尔自治区:31:1");}});
		map.put("西南",new ArrayList<String>() {{add("重庆市:22:0");add("四川省:23:1");add("贵州省:24:1");add("云南省:25:1");add("西藏自治区:26:1");}});


		List<AreaCityInfo> list = new ArrayList<AreaCityInfo>();
		Set<String> keySet = map.keySet();
		Iterator<String> it = keySet.iterator();
		while (it.hasNext())
		{
			AreaCityInfo areaInfo = new AreaCityInfo();
			list.add(areaInfo);
			String key = it.next();
			areaInfo.setName(key);
			List<String> list2 = map.get(key);
			for(String item :list2)
			{
				String[] strings = item.split(":");
				AreaCityInfo pInfo = new AreaCityInfo();
				pInfo.setName(strings[0]);
				areaInfo.getList().add(pInfo);
				if("1".equals(strings[2]))
				{
					List<CityMinInfo> selectProvince = sysCityService.selectCityById(strings[1]);
					for(CityMinInfo info:selectProvince)
					{
						AreaCityInfo cInfo = new AreaCityInfo();
						cInfo.setName(info.getRegionName());
						pInfo.getList().add(cInfo);
					}
				}
			}
		}
		AjaxUtil.write(JsonUtil.listToJson(list), response);*/
		AjaxUtil.write("[{\"list\":[{\"list\":[],\"name\":\"北京市\"},{\"list\":[],\"name\":\"天津市\"},{\"list\":[{\"list\":[],\"name\":\"大同市\"},{\"list\":[],\"name\":\"晋中市\"},{\"list\":[],\"name\":\"晋城市\"},{\"list\":[],\"name\":\"吕梁市\"},{\"list\":[],\"name\":\"临汾市\"},{\"list\":[],\"name\":\"朔州市\"},{\"list\":[],\"name\":\"太原市\"},{\"list\":[],\"name\":\"忻州市\"},{\"list\":[],\"name\":\"运城市\"},{\"list\":[],\"name\":\"阳泉市\"},{\"list\":[],\"name\":\"长治市\"}],\"name\":\"山西省\"},{\"list\":[{\"list\":[],\"name\":\"阿拉善盟\"},{\"list\":[],\"name\":\"巴彦淖尔市\"},{\"list\":[],\"name\":\"包头市\"},{\"list\":[],\"name\":\"赤峰市\"},{\"list\":[],\"name\":\"鄂尔多斯市\"},{\"list\":[],\"name\":\"呼伦贝尔市\"},{\"list\":[],\"name\":\"呼和浩特市\"},{\"list\":[],\"name\":\"通辽市\"},{\"list\":[],\"name\":\"乌兰察布市\"},{\"list\":[],\"name\":\"乌海市\"},{\"list\":[],\"name\":\"锡林郭勒盟\"},{\"list\":[],\"name\":\"兴安盟\"}],\"name\":\"内蒙古自治区\"},{\"list\":[{\"list\":[],\"name\":\"保定市\"},{\"list\":[],\"name\":\"沧州市\"},{\"list\":[],\"name\":\"承德市\"},{\"list\":[],\"name\":\"衡水市\"},{\"list\":[],\"name\":\"邯郸市\"},{\"list\":[],\"name\":\"廊坊市\"},{\"list\":[],\"name\":\"秦皇岛市\"},{\"list\":[],\"name\":\"石家庄市\"},{\"list\":[],\"name\":\"唐山市\"},{\"list\":[],\"name\":\"邢台市\"},{\"list\":[],\"name\":\"张家口市\"}],\"name\":\"河北省\"}],\"name\":\"华北\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"鞍山市\"},{\"list\":[],\"name\":\"本溪市\"},{\"list\":[],\"name\":\"朝阳市\"},{\"list\":[],\"name\":\"丹东市\"},{\"list\":[],\"name\":\"大连市\"},{\"list\":[],\"name\":\"阜新市\"},{\"list\":[],\"name\":\"抚顺市\"},{\"list\":[],\"name\":\"葫芦岛市\"},{\"list\":[],\"name\":\"锦州市\"},{\"list\":[],\"name\":\"辽阳市\"},{\"list\":[],\"name\":\"盘锦市\"},{\"list\":[],\"name\":\"沈阳市\"},{\"list\":[],\"name\":\"铁岭市\"},{\"list\":[],\"name\":\"营口市\"}],\"name\":\"辽宁省\"},{\"list\":[{\"list\":[],\"name\":\"白城市\"},{\"list\":[],\"name\":\"白山市\"},{\"list\":[],\"name\":\"吉林市\"},{\"list\":[],\"name\":\"辽源市\"},{\"list\":[],\"name\":\"松原市\"},{\"list\":[],\"name\":\"四平市\"},{\"list\":[],\"name\":\"通化市\"},{\"list\":[],\"name\":\"延边朝鲜族自治州\"},{\"list\":[],\"name\":\"长春市\"}],\"name\":\"吉林省\"},{\"list\":[{\"list\":[],\"name\":\"大兴安岭地区\"},{\"list\":[],\"name\":\"大庆市\"},{\"list\":[],\"name\":\"黑河市\"},{\"list\":[],\"name\":\"鹤岗市\"},{\"list\":[],\"name\":\"哈尔滨市\"},{\"list\":[],\"name\":\"佳木斯市\"},{\"list\":[],\"name\":\"鸡西市\"},{\"list\":[],\"name\":\"牡丹江市\"},{\"list\":[],\"name\":\"七台河市\"},{\"list\":[],\"name\":\"齐齐哈尔市\"},{\"list\":[],\"name\":\"绥化市\"},{\"list\":[],\"name\":\"双鸭山市\"},{\"list\":[],\"name\":\"伊春市\"}],\"name\":\"黑龙江省\"}],\"name\":\"东北\"},{\"list\":[{\"list\":[],\"name\":\"上海市\"},{\"list\":[{\"list\":[],\"name\":\"常州市\"},{\"list\":[],\"name\":\"淮安市\"},{\"list\":[],\"name\":\"连云港市\"},{\"list\":[],\"name\":\"南通市\"},{\"list\":[],\"name\":\"南京市\"},{\"list\":[],\"name\":\"宿迁市\"},{\"list\":[],\"name\":\"苏州市\"},{\"list\":[],\"name\":\"泰州市\"},{\"list\":[],\"name\":\"无锡市\"},{\"list\":[],\"name\":\"徐州市\"},{\"list\":[],\"name\":\"扬州市\"},{\"list\":[],\"name\":\"盐城市\"},{\"list\":[],\"name\":\"镇江市\"}],\"name\":\"江苏省\"},{\"list\":[{\"list\":[],\"name\":\"湖州市\"},{\"list\":[],\"name\":\"杭州市\"},{\"list\":[],\"name\":\"金华市\"},{\"list\":[],\"name\":\"嘉兴市\"},{\"list\":[],\"name\":\"丽水市\"},{\"list\":[],\"name\":\"宁波市\"},{\"list\":[],\"name\":\"衢州市\"},{\"list\":[],\"name\":\"绍兴市\"},{\"list\":[],\"name\":\"台州市\"},{\"list\":[],\"name\":\"温州市\"},{\"list\":[],\"name\":\"舟山市\"}],\"name\":\"浙江省\"},{\"list\":[{\"list\":[],\"name\":\"安庆市\"},{\"list\":[],\"name\":\"亳州市\"},{\"list\":[],\"name\":\"蚌埠市\"},{\"list\":[],\"name\":\"池州市\"},{\"list\":[],\"name\":\"巢湖市\"},{\"list\":[],\"name\":\"滁州市\"},{\"list\":[],\"name\":\"阜阳市\"},{\"list\":[],\"name\":\"黄山市\"},{\"list\":[],\"name\":\"淮北市\"},{\"list\":[],\"name\":\"淮南市\"},{\"list\":[],\"name\":\"合肥市\"},{\"list\":[],\"name\":\"六安市\"},{\"list\":[],\"name\":\"马鞍山市\"},{\"list\":[],\"name\":\"宿州市\"},{\"list\":[],\"name\":\"铜陵市\"},{\"list\":[],\"name\":\"芜湖市\"},{\"list\":[],\"name\":\"宣城市\"}],\"name\":\"安徽省\"},{\"list\":[{\"list\":[],\"name\":\"福州市\"},{\"list\":[],\"name\":\"龙岩市\"},{\"list\":[],\"name\":\"宁德市\"},{\"list\":[],\"name\":\"南平市\"},{\"list\":[],\"name\":\"莆田市\"},{\"list\":[],\"name\":\"泉州市\"},{\"list\":[],\"name\":\"三明市\"},{\"list\":[],\"name\":\"厦门市\"},{\"list\":[],\"name\":\"漳州市\"}],\"name\":\"福建省\"},{\"list\":[{\"list\":[],\"name\":\"抚州市\"},{\"list\":[],\"name\":\"赣州市\"},{\"list\":[],\"name\":\"吉安市\"},{\"list\":[],\"name\":\"九江市\"},{\"list\":[],\"name\":\"景德镇市\"},{\"list\":[],\"name\":\"南昌市\"},{\"list\":[],\"name\":\"萍乡市\"},{\"list\":[],\"name\":\"上饶市\"},{\"list\":[],\"name\":\"新余市\"},{\"list\":[],\"name\":\"宜春市\"},{\"list\":[],\"name\":\"鹰潭市\"}],\"name\":\"江西省\"},{\"list\":[{\"list\":[],\"name\":\"滨州市\"},{\"list\":[],\"name\":\"德州市\"},{\"list\":[],\"name\":\"荷泽市\"},{\"list\":[],\"name\":\"济宁市\"},{\"list\":[],\"name\":\"济南市\"},{\"list\":[],\"name\":\"聊城市\"},{\"list\":[],\"name\":\"临沂市\"},{\"list\":[],\"name\":\"莱芜市\"},{\"list\":[],\"name\":\"青岛市\"},{\"list\":[],\"name\":\"日照市\"},{\"list\":[],\"name\":\"泰安市\"},{\"list\":[],\"name\":\"威海市\"},{\"list\":[],\"name\":\"潍坊市\"},{\"list\":[],\"name\":\"烟台市\"},{\"list\":[],\"name\":\"枣庄市\"},{\"list\":[],\"name\":\"淄博市\"}],\"name\":\"山东省\"}],\"name\":\"华东\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"郴州市\"},{\"list\":[],\"name\":\"常德市\"},{\"list\":[],\"name\":\"怀化市\"},{\"list\":[],\"name\":\"衡阳市\"},{\"list\":[],\"name\":\"娄底市\"},{\"list\":[],\"name\":\"邵阳市\"},{\"list\":[],\"name\":\"湘西土家族苗族自治州\"},{\"list\":[],\"name\":\"湘潭市\"},{\"list\":[],\"name\":\"永州市\"},{\"list\":[],\"name\":\"益阳市\"},{\"list\":[],\"name\":\"岳阳市\"},{\"list\":[],\"name\":\"张家界市\"},{\"list\":[],\"name\":\"株洲市\"},{\"list\":[],\"name\":\"长沙市\"}],\"name\":\"湖南省\"},{\"list\":[{\"list\":[],\"name\":\"恩施土家族苗族自治州\"},{\"list\":[],\"name\":\"鄂州市\"},{\"list\":[],\"name\":\"黄冈市\"},{\"list\":[],\"name\":\"黄石市\"},{\"list\":[],\"name\":\"荆州市\"},{\"list\":[],\"name\":\"荆门市\"},{\"list\":[],\"name\":\"省直辖行政单位\"},{\"list\":[],\"name\":\"随州市\"},{\"list\":[],\"name\":\"十堰市\"},{\"list\":[],\"name\":\"武汉市\"},{\"list\":[],\"name\":\"咸宁市\"},{\"list\":[],\"name\":\"孝感市\"},{\"list\":[],\"name\":\"襄樊市\"},{\"list\":[],\"name\":\"宜昌市\"}],\"name\":\"湖北省\"}],\"name\":\"华中\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"潮州市\"},{\"list\":[],\"name\":\"东莞市\"},{\"list\":[],\"name\":\"佛山市\"},{\"list\":[],\"name\":\"广州市\"},{\"list\":[],\"name\":\"河源市\"},{\"list\":[],\"name\":\"惠州市\"},{\"list\":[],\"name\":\"揭阳市\"},{\"list\":[],\"name\":\"江门市\"},{\"list\":[],\"name\":\"梅州市\"},{\"list\":[],\"name\":\"茂名市\"},{\"list\":[],\"name\":\"清远市\"},{\"list\":[],\"name\":\"汕尾市\"},{\"list\":[],\"name\":\"汕头市\"},{\"list\":[],\"name\":\"深圳市\"},{\"list\":[],\"name\":\"韶关市\"},{\"list\":[],\"name\":\"云浮市\"},{\"list\":[],\"name\":\"阳江市\"},{\"list\":[],\"name\":\"中山市\"},{\"list\":[],\"name\":\"肇庆市\"},{\"list\":[],\"name\":\"湛江市\"},{\"list\":[],\"name\":\"珠海市\"}],\"name\":\"广东省\"},{\"list\":[{\"list\":[],\"name\":\"百色市\"},{\"list\":[],\"name\":\"北海市\"},{\"list\":[],\"name\":\"崇左市\"},{\"list\":[],\"name\":\"防城港市\"},{\"list\":[],\"name\":\"贵港市\"},{\"list\":[],\"name\":\"桂林市\"},{\"list\":[],\"name\":\"河池市\"},{\"list\":[],\"name\":\"贺州市\"},{\"list\":[],\"name\":\"来宾市\"},{\"list\":[],\"name\":\"柳州市\"},{\"list\":[],\"name\":\"南宁市\"},{\"list\":[],\"name\":\"钦州市\"},{\"list\":[],\"name\":\"梧州市\"},{\"list\":[],\"name\":\"玉林市\"}],\"name\":\"广西壮族自治区\"},{\"list\":[{\"list\":[],\"name\":\"海口市\"},{\"list\":[],\"name\":\"省直辖县级行政单位\"},{\"list\":[],\"name\":\"三亚市\"}],\"name\":\"海南省\"}],\"name\":\"华南\"},{\"list\":[{\"list\":[{\"list\":[],\"name\":\"安康市\"},{\"list\":[],\"name\":\"宝鸡市\"},{\"list\":[],\"name\":\"汉中市\"},{\"list\":[],\"name\":\"商洛市\"},{\"list\":[],\"name\":\"铜川市\"},{\"list\":[],\"name\":\"渭南市\"},{\"list\":[],\"name\":\"咸阳市\"},{\"list\":[],\"name\":\"西安市\"},{\"list\":[],\"name\":\"榆林市\"},{\"list\":[],\"name\":\"延安市\"}],\"name\":\"陕西省\"},{\"list\":[{\"list\":[],\"name\":\"白银市\"},{\"list\":[],\"name\":\"定西市\"},{\"list\":[],\"name\":\"甘南藏族自治州\"},{\"list\":[],\"name\":\"酒泉市\"},{\"list\":[],\"name\":\"金昌市\"},{\"list\":[],\"name\":\"嘉峪关市\"},{\"list\":[],\"name\":\"临夏回族自治州\"},{\"list\":[],\"name\":\"陇南市\"},{\"list\":[],\"name\":\"兰州市\"},{\"list\":[],\"name\":\"平凉市\"},{\"list\":[],\"name\":\"庆阳市\"},{\"list\":[],\"name\":\"天水市\"},{\"list\":[],\"name\":\"武威市\"},{\"list\":[],\"name\":\"张掖市\"}],\"name\":\"甘肃省\"},{\"list\":[{\"list\":[],\"name\":\"果洛藏族自治州\"},{\"list\":[],\"name\":\"海西蒙古族藏族自治州\"},{\"list\":[],\"name\":\"海南藏族自治州\"},{\"list\":[],\"name\":\"黄南藏族自治州\"},{\"list\":[],\"name\":\"海北藏族自治州\"},{\"list\":[],\"name\":\"海东地区\"},{\"list\":[],\"name\":\"西宁市\"},{\"list\":[],\"name\":\"玉树藏族自治州\"}],\"name\":\"青海省\"},{\"list\":[{\"list\":[],\"name\":\"固原市\"},{\"list\":[],\"name\":\"石嘴山市\"},{\"list\":[],\"name\":\"吴忠市\"},{\"list\":[],\"name\":\"银川市\"},{\"list\":[],\"name\":\"中卫市\"}],\"name\":\"宁夏回族自治区\"},{\"list\":[{\"list\":[],\"name\":\"阿勒泰地区\"},{\"list\":[],\"name\":\"阿克苏地区\"},{\"list\":[],\"name\":\"巴音郭楞蒙古自治州\"},{\"list\":[],\"name\":\"博尔塔拉蒙古自治州\"},{\"list\":[],\"name\":\"昌吉回族自治州\"},{\"list\":[],\"name\":\"和田地区\"},{\"list\":[],\"name\":\"哈密地区\"},{\"list\":[],\"name\":\"喀什地区\"},{\"list\":[],\"name\":\"克孜勒苏柯尔克孜自治州\"},{\"list\":[],\"name\":\"克拉玛依市\"},{\"list\":[],\"name\":\"省直辖行政单位\"},{\"list\":[],\"name\":\"塔城地区\"},{\"list\":[],\"name\":\"吐鲁番地区\"},{\"list\":[],\"name\":\"乌鲁木齐市\"},{\"list\":[],\"name\":\"伊犁哈萨克自治州\"}],\"name\":\"新疆维吾尔自治区\"}],\"name\":\"西北\"},{\"list\":[{\"list\":[],\"name\":\"重庆市\"},{\"list\":[{\"list\":[],\"name\":\"阿坝藏族羌族自治州\"},{\"list\":[],\"name\":\"巴中市\"},{\"list\":[],\"name\":\"成都市\"},{\"list\":[],\"name\":\"达州市\"},{\"list\":[],\"name\":\"德阳市\"},{\"list\":[],\"name\":\"甘孜藏族自治州\"},{\"list\":[],\"name\":\"广安市\"},{\"list\":[],\"name\":\"广元市\"},{\"list\":[],\"name\":\"凉山彝族自治州\"},{\"list\":[],\"name\":\"乐山市\"},{\"list\":[],\"name\":\"泸州市\"},{\"list\":[],\"name\":\"眉山市\"},{\"list\":[],\"name\":\"绵阳市\"},{\"list\":[],\"name\":\"南充市\"},{\"list\":[],\"name\":\"内江市\"},{\"list\":[],\"name\":\"攀枝花市\"},{\"list\":[],\"name\":\"遂宁市\"},{\"list\":[],\"name\":\"雅安市\"},{\"list\":[],\"name\":\"宜宾市\"},{\"list\":[],\"name\":\"资阳市\"},{\"list\":[],\"name\":\"自贡市\"}],\"name\":\"四川省\"},{\"list\":[{\"list\":[],\"name\":\"安顺市\"},{\"list\":[],\"name\":\"毕节地区\"},{\"list\":[],\"name\":\"贵阳市\"},{\"list\":[],\"name\":\"六盘水市\"},{\"list\":[],\"name\":\"黔南布依族苗族自治州\"},{\"list\":[],\"name\":\"黔东南苗族侗族自治州\"},{\"list\":[],\"name\":\"黔西南布依族苗族自治州\"},{\"list\":[],\"name\":\"铜仁地区\"},{\"list\":[],\"name\":\"遵义市\"}],\"name\":\"贵州省\"},{\"list\":[{\"list\":[],\"name\":\"保山市\"},{\"list\":[],\"name\":\"楚雄彝族自治州\"},{\"list\":[],\"name\":\"迪庆藏族自治州\"},{\"list\":[],\"name\":\"德宏傣族景颇族自治州\"},{\"list\":[],\"name\":\"大理白族自治州\"},{\"list\":[],\"name\":\"红河哈尼族彝族自治州\"},{\"list\":[],\"name\":\"昆明市\"},{\"list\":[],\"name\":\"临沧市\"},{\"list\":[],\"name\":\"丽江市\"},{\"list\":[],\"name\":\"怒江傈僳族自治州\"},{\"list\":[],\"name\":\"曲靖市\"},{\"list\":[],\"name\":\"思茅市\"},{\"list\":[],\"name\":\"文山壮族苗族自治州\"},{\"list\":[],\"name\":\"西双版纳傣族自治州\"},{\"list\":[],\"name\":\"玉溪市\"},{\"list\":[],\"name\":\"昭通市\"}],\"name\":\"云南省\"},{\"list\":[{\"list\":[],\"name\":\"阿里地区\"},{\"list\":[],\"name\":\"昌都地区\"},{\"list\":[],\"name\":\"林芝地区\"},{\"list\":[],\"name\":\"拉萨市\"},{\"list\":[],\"name\":\"那曲地区\"},{\"list\":[],\"name\":\"日喀则地区\"},{\"list\":[],\"name\":\"山南地区\"}],\"name\":\"西藏自治区\"}],\"name\":\"西南\"}]", response);
		
	}
}
