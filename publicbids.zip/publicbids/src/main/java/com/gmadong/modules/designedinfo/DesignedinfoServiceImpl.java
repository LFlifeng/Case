package com.gmadong.modules.designedinfo;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.designedinfo.DesignedinfoExample.Criteria;
import com.gmadong.modules.projectDesigneds.ProjectDesignedsExample;
import com.gmadong.modules.staff.SysStaff;
import com.gmadong.modules.staff.SysStaffExample;

@Service("designedinfoService")
public class DesignedinfoServiceImpl implements DesignedinfoService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private DesignedinfoMapper designedinfoMapper;
	
	@Override
	public Page page(String id,Integer page, Integer rows)
	{
		DesignedinfoExample designedinfoExample = new DesignedinfoExample();
		Criteria createCriteria = designedinfoExample.createCriteria();
		if (!StringUtil.isEmpty(id)) {
			createCriteria.andProjectIdEqualTo(id);
		}
		
		designedinfoExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<Designedinfo> list = designedinfoMapper.selectByExample(designedinfoExample);
		PageInfo<Designedinfo> pageInfo = new PageInfo<Designedinfo>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public Designedinfo getProjectId(String projectId)
	{
		return designedinfoMapper.selectByPrimaryKey(projectId);
	}

	@Override
	public Designedinfo getDesignedinfo(String designedinfo)
	{
		if(StringUtil.isEmpty(designedinfo))
		{
			return null;
		}
		DesignedinfoExample designedinfoExample = new DesignedinfoExample();
		Criteria criteria = designedinfoExample.createCriteria();
		criteria.andDesignedinfoEqualTo(designedinfo.trim());
		designedinfoExample.or(criteria);
		List<Designedinfo> selectByExample = designedinfoMapper.selectByExample(designedinfoExample);
		if (selectByExample.size()>0)
		{
			return selectByExample.get(0);
		}
		return null;
	}

	@Override
	public boolean save(Designedinfo designedinfo)
	{
		designedinfo.setId(UUIDUtil.getUUID());
		designedinfo.setCtime(DateUtil.getCurrentDate());
		boolean flag = designedinfoMapper.insert(designedinfo) > 0;
		return flag;
	}

	@Override
	public boolean deleteById(String ids)
	{
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			DesignedinfoExample designedinfoExample = new DesignedinfoExample();
			Criteria createCriteria = designedinfoExample.createCriteria();
			createCriteria.andprojectIdIn(Arrays.asList(ids.split(",")));
			return designedinfoMapper.deleteByExample(designedinfoExample) > 0;
		}
		return false;
	}

}
