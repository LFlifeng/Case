package com.gmadong.modules.organize;

import java.util.List;

import com.gmadong.common.Page;

public interface SysOrganizeService
{
	public String getActionByOrganizeIds(String roleIds);
	public Page page(String OrganizeName,String remark,Integer page,Integer rows);
	public List<SysOrganize> getAll();
	public SysOrganize getRow(String organizeId);
	public List<SysOrganize> getChlidOrganize(String organizeId);
	public Page staffPage(String organizeId, String staffName,String createTime, Integer page, Integer rows);
	public boolean save(SysOrganize sysOrganize);
	public boolean deleteByOrganizeIds(String ids);
	public boolean hasChildOrganize(String ids);
	public boolean update(SysOrganize organize);
}
