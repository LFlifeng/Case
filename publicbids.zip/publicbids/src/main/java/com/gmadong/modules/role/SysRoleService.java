package com.gmadong.modules.role;

import java.util.List;

import com.gmadong.common.Page;

public interface SysRoleService 
{
	public String getActionByRoleIds(String roleIds);
	public Page page(String roleName,String remark,Integer page,Integer rows);
	public SysRole selectByRoleId(String roleId);
	public boolean saveRold(SysRole role);
	public boolean updateRold(SysRole role);
	public boolean deleteByRoleIds(String ids);
	public List<SysRole> getAll();
}
