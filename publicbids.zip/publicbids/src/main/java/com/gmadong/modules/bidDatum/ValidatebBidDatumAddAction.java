package com.gmadong.modules.bidDatum;

public interface ValidatebBidDatumAddAction
{

}
