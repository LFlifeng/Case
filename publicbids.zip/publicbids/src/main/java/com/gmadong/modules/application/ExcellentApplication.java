package com.gmadong.modules.application;

import com.gmadong.common.utils.FileUtil;
import com.gmadong.common.utils.StringUtil;

/**
 * 优秀供应商
 * 
 * @author Administrator
 *
 */
public class ExcellentApplication {
	/** 企业id */
	private String id;
	/** 头像 */
	private String portrait;
	/** 头像路径 */
	private String portraitUrl;
	/** 企业名称 */
	private String enterpriseName;
	/** 详情地址 */
	private String address;
	/** 所属 */
	private String industryOne;
	/** 主营产品 */
	private String product;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPortrait() {
		return portrait;
	}

	public void setPortrait(String portrait) {
		if (StringUtil.isNotEmpty(portrait)) {
			this.portraitUrl = "/upload/attach" + FileUtil.getPath(portrait) + portrait + ".png";
		} else {
			this.portraitUrl = "/skin/default/front/img/head_placeholder.png";
		}
		this.portrait = portrait == null ? null : portrait.trim();
	}

	public String getPortraitUrl() {
		if (StringUtil.isEmpty(portraitUrl)) {
			return "/skin/default/front/img/head_placeholder.png";
		}
		return portraitUrl;
	}

	public void setPortraitUrl(String portraitUrl) {
		this.portraitUrl = portraitUrl;
	}

	public String getEnterpriseName() {
		return enterpriseName;
	}

	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getIndustryOne() {
		return industryOne;
	}

	public void setIndustryOne(String industryOne) {
		this.industryOne = industryOne;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

}
