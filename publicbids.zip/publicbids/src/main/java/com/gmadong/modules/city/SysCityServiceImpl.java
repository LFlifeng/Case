package com.gmadong.modules.city;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gmadong.modules.city.SysCityExample.Criteria;

@Service("sysCityService")
public class SysCityServiceImpl implements SysCityService
{
	@Autowired
	private SysCityMapper sysCityMapper;
	
	@Override
	public List<CityMinInfo> selectProvince()
	{
		SysCityExample example = new SysCityExample();
		Criteria criteria = example.createCriteria();
		criteria.andParentIdEqualTo(0);
		example.setOrderByClause("first_letter ASC");
		
		List<CityMinInfo> selectByExample = sysCityMapper.selectIdOrNamesByExample(example);
		
		return selectByExample;
	}

	@Override
	public List<CityMinInfo> selectCityById(String id)
	{
		SysCityExample example = new SysCityExample();
		Criteria criteria = example.createCriteria();
		criteria.andParentIdEqualTo(Integer.valueOf(id));
		example.setOrderByClause("first_letter ASC");
	
		List<CityMinInfo> selectByExample = sysCityMapper.selectIdOrNamesByExample(example);
		
		return selectByExample;
	}

	@Override
	public SysCity selectById(String id) {
		return sysCityMapper.selectByPrimaryKey(id);
	}

}
