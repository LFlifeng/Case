package com.gmadong.modules.billinginfo;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gmadong.common.Common;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.biddinginfo.Biddinginfo;
import com.gmadong.modules.company.Company;
import com.gmadong.modules.user.User;

@Controller
public class BillingInfoQdController
{

	@Autowired
	BillingInfoQdService billingInfoQdService;
	@Autowired
	JedisClientSingle jedisClientSingle;
	public static String key = "billinginfo.selectInvoiceById.do";

	/**
	 * 跳转到用户申请发票
	 * 
	 * @param biddingInfo
	 */
	@RequestMapping("/billinginfo.selectApplyinvoice.do")
	public String applyinvoice(HttpServletResponse response)
	{
 		User user = (User) Session.get("user");
 		
		Billinginfo invoice=null;
		try
		{
			String string = jedisClientSingle.hget(key,user.getId());
			if (StringUtil.isNotEmpty(string))
			{

				ObjectMapper mapper = new ObjectMapper();
				invoice = mapper.readValue(string, Billinginfo.class);
				Request.set("invoice", invoice);
				return "/front/billinginfo/p-applyinvoice";
			}
		} catch (Exception e)
		{
		}
		invoice = billingInfoQdService.selectInvoiceById(user.getId());
		if(invoice == null) 
		{
			Request.set("invoice", new Billinginfo(user.getId()));
		}
		else
		{
			try
			{
				jedisClientSingle.hset(key,user.getId(),JsonUtil.bean2json(invoice), Common.REDIS_48_HOUR_EXPIRE);
			} catch (Exception e)
			{
			}
			Request.set("invoice", invoice);
		}
		return "/front/billinginfo/p-applyinvoice";
	}

	/**
	 * 用户申请发票修改填写开票信息
	 * 
	 * @param biddingInfo
	 */
	@RequestMapping("billinginfo.updateApplyinvoice.do")
	public void updateApplyinvoice(HttpServletResponse response, @Validated Billinginfo billinginfo,
			BindingResult bindingResult)
	{
		
		if (bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(), response);
			return;
		}
		User user=(User)Session.get("user");
		//判断是否用户userId为空，为空则说明是新用户第一次申请发票，需要调用add方法否则是修改方法
		if(StringUtil.isEmpty(billinginfo.getId())) 
		{
			boolean ismodification=billingInfoQdService.saveBillingInfo(billinginfo);
			try
			{
				
				if(ismodification) 
				{
					jedisClientSingle.hset(key,user.getId(),JsonUtil.bean2json(billinginfo), Common.REDIS_48_HOUR_EXPIRE);
				}
				
			} catch (Exception e)
			{}
			if(ismodification)
			{
				try
				{
					jedisClientSingle.del("billinginfo.list.action");
					
				} catch (Exception e)
				{}
				AjaxUtil.write("succ", response);
				return;
			}
			else
			{
				AjaxUtil.write("fail", response);
				return;
			}
		}
		else
		{
			try
			{
				boolean ismodification = billingInfoQdService.updateByPrimaryKey(billinginfo);
				if (ismodification)
				{
					try
					{
						jedisClientSingle.hset(key,user.getId(),JsonUtil.bean2json(billinginfo), Common.REDIS_48_HOUR_EXPIRE);
						jedisClientSingle.del("billinginfo.list.action");
						
					} catch (Exception e)
					{}
					AjaxUtil.write("succ", response);
					return;
				} else
				{
					AjaxUtil.write("fail", response);
					return;
				}
			} catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		
		AjaxUtil.write("fail", response);
		
	}

	/**
	 * 跳转到申请发票列表
	 * 
	 * @return
	 */
	@RequestMapping("billinginfo.publishedList.do")
	public String publishedList()
	{
		return "/front/billinginfo/p-invoicelists";
	}

}
