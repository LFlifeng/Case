package com.gmadong.modules.browsingHistory;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;

import com.gmadong.common.jedis.JedisClientSingle;

import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.browsingHistory.BrowsingHistoryExample.Criteria;
import com.gmadong.modules.usercollection.UserCollection;
import com.gmadong.modules.usercollection.UserCollectionExample;

@Service("browsingHistoryService")
public class BrowsingHistoryServiceImpl implements BrowsingHistoryService {

	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private BrowsingHistoryMapper browsingHistoryMapper;

	@Override
	public Page page(String userId, Integer page, Integer rows) {
		// TODO Auto-generated method stub
		BrowsingHistoryExample browsingHistoryExample = new BrowsingHistoryExample();
		Criteria createCriteria = browsingHistoryExample.createCriteria();
		if (!StringUtil.isEmpty(userId)) {
			createCriteria.andUserIdEqualTo(userId);
		}
		browsingHistoryExample.setOrderByClause("ctime desc");
		PageHelper.startPage(page, rows);
		List<BrowsingHistory> list = browsingHistoryMapper.selectByExample(browsingHistoryExample);
		PageInfo<BrowsingHistory> pageInfo = new PageInfo<BrowsingHistory>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean deleteById(String id) {
		if (browsingHistoryMapper.deleteByPrimaryKey(id) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean save(BrowsingHistory browsingHistory) {
		boolean flag = false;
		try {
			if(browsingHistoryMapper.insert(browsingHistory)> 0) {
				flag = true;
			}
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}

	@Override
	public BrowsingHistory selectByBiddingInfoId(String userId,String titleId) {
		BrowsingHistoryExample browsingHistoryExample = new BrowsingHistoryExample();
		Criteria createCriteria = browsingHistoryExample.createCriteria();
		if (!StringUtil.isEmpty(userId)) {
			createCriteria.andUserIdEqualTo(userId);
		}
		if (!StringUtil.isEmpty(titleId)) {
			createCriteria.andBiddinginfoIdEqualTo(userId);
		}
		List<BrowsingHistory> list = browsingHistoryMapper.selectByExample(browsingHistoryExample);
		if(list.size() > 0) {
			return list.get(0);
		}
			return null;
	}

}