package com.gmadong.modules.manageCondition;

import com.gmadong.common.Page;

public interface ManageConditionQdService
{

	Page page(String id, Integer page, Integer rows);

	boolean deleteByPrimaryKey(String id);

	boolean save(ManageCondition manageCondition);
	
     
}
