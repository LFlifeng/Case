package com.gmadong.modules.browsingHistory;

import com.gmadong.modules.browsingHistory.BrowsingHistory;
import com.gmadong.modules.browsingHistory.BrowsingHistoryExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BrowsingHistoryMapper {
    int countByExample(BrowsingHistoryExample example);

    int deleteByExample(BrowsingHistoryExample example);

    int deleteByPrimaryKey(String id);

    int insert(BrowsingHistory record);

    int insertSelective(BrowsingHistory record);

    List<BrowsingHistory> selectByExample(BrowsingHistoryExample example);

    BrowsingHistory selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") BrowsingHistory record, @Param("example") BrowsingHistoryExample example);

    int updateByExample(@Param("record") BrowsingHistory record, @Param("example") BrowsingHistoryExample example);

    int updateByPrimaryKeySelective(BrowsingHistory record);

    int updateByPrimaryKey(BrowsingHistory record);
}