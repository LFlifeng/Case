package com.gmadong.modules.biddinginfo;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.formula.udf.UDFFinder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.Md5Util;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.bids.BidsFrontService;
import com.gmadong.modules.tracker.Tracker;
import com.gmadong.modules.tracker.TrackerFrontService;
import com.gmadong.modules.user.User;

/**
 * 项目中心
 * @author caodongdong
 *
 */
@Controller
public class BiddinginfoFrontController
{
	@Autowired
	private TrackerFrontService trackerFrontService;
	@Autowired
	private BiddinginfoFrontService biddinginfoFrontService; 
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private BidsFrontService bidsFrontService;
	
	private String key = "biddinginfoFront.list.do";
	
	@RequestMapping("/biddinginfoFront.list.do")
	public void list(HttpServletResponse response,String id,@RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "10") Integer rows)
	{
		if(StringUtil.isEmpty(id) || id.length() != 32)
		{
			AjaxUtil.write(Page.pageToJson(Page.getEmptyPage()), response);
			return ;
		}
		User user = (User) Session.get("user");
		if(user==null)
		{
			AjaxUtil.write(Page.pageToJson(Page.getEmptyPage()), response);
			return ;
		}
		Tracker tracker = trackerFrontService.getTrackerById(id);
		if(tracker==null || tracker.getKeys().size()==0 || tracker.getInfoType().length()==0 || tracker.getRegionList().size()==0)
		{
			AjaxUtil.write(Page.pageToJson(Page.getEmptyPage()), response);
			return ;
		}
		searchOtherBibs(response,user.getId(), new BidsParamsInfo(tracker,false), page, rows);
		/*
		if("0".equals(user.getGrade()))
		{
			searchOtherBibs(response, new BidsParamsInfo(tracker,false), page, rows);
		}
		else
		{
			searchLocalBibs(response, new BidsParamsInfo(tracker,true), page, rows);
		}*/
	}
	/**
	 * 搜索客户填写的招标信息
	 * @param response
	 * @param tracker
	 * @param page
	 * @param rows
	 */
	private void searchLocalBibs(HttpServletResponse response,String uid,BidsParamsInfo info,Integer page,Integer rows)
	{
		String field = Md5Util.md5("local_"+info.getTrackerId()+"_"+page+"_"+rows);
		try
		{
			String list = jedisClientSingle.hget(key+"_"+uid, field);
			if(StringUtil.isNotEmpty(list))
			{
				AjaxUtil.write(list, response);
				return;
			}
			
		}catch (Exception e) 
		{}
		Page page2 = biddinginfoFrontService.page(info, page, rows);
		String list = Page.pageToJson(page2);
		try
		{
			jedisClientSingle.hset(key, field, list, Common.REDIS_30_MINUTE_EXPIRE);
			
		} catch (Exception e)
		{}
		AjaxUtil.write(list, response);
	}
	/**
	 * 搜索爬虫爬出来的招标信息
	 * @param response
	 * @param tracker
	 * @param page
	 * @param rows
	 */
	private void searchOtherBibs(HttpServletResponse response,String uid,BidsParamsInfo info,Integer page,Integer rows)
	{
		String field = Md5Util.md5("other_"+info.getTrackerId()+"_"+page+"_"+rows);
		try
		{
			String list = jedisClientSingle.hget(key+"_"+uid, field);
			if(StringUtil.isNotEmpty(list))
			{
				AjaxUtil.write(list, response);
				return;
			}
			
		}catch (Exception e) 
		{}
		Page page2 = bidsFrontService.page(info, page, rows);
		String list = Page.pageToJson(page2);
		try
		{
			jedisClientSingle.hset(key, field, list, Common.REDIS_30_MINUTE_EXPIRE);
			
		} catch (Exception e)
		{}
		AjaxUtil.write(list, response);
	}
}
