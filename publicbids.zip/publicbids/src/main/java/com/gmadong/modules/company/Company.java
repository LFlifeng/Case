package com.gmadong.modules.company;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.gmadong.common.utils.FileUtil;
import com.gmadong.common.utils.StringUtil;

public class Company {
	/** 公司id */
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyEditAction.class} )
    private String id;

    /** 用户 */
    private String staffId;

    
    /** 企业名称 */
   	@NotBlank(message="企业名称不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    @Size (min=1,max=50,message="请输入正确的企业名称!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String title;



    /** 法定代表人 */
   	@NotBlank(message="法定代表人不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    @Size (min=1,max=50,message="请输入正确的法定代表人!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String legalPerson;

    /** 统一信用代码 */
   	@NotBlank(message="统一信用代码不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    @Size (min=15,max=18,message="请输入正确的统一信用代码!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String creditCode;

    /** 法人身份证号 */
   	@NotBlank(message="法人身份证号不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
	@Size (min=15,max=18,message="请输入正确的法人身份证号!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String idCard;

    /** 所在省 */
   	@NotBlank(message="所在省不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
	@Size (min=1,max=20,message="请输入正确的所在省!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String province;

    /** 所在市 */
   	@NotBlank(message="所在市不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
	@Size (min=1,max=20,message="请输入正确的所在市!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String city;

    /** 所在县 */
   private String county;

    /** 公司类型 1有限责任公司 2股份有限公司 3合伙企业 */
   	@NotBlank(message="公司类型不能为空!" ,groups = {ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String companytype;

    /** 详情地址 */
   	@NotBlank(message="详情地址不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
	@Size (min=1,max=50,message="请输入正确的详情地址!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String address;

    /** 行业一级 */
   	@NotBlank(message="行业一级不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    @Size (min=1,max=50,message="请输入正确的行业一级!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String industryOne;

    /** 行业二级 */
	@NotBlank(message="行业二级不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    @Size (min=1,max=50,message="请输入正确的行业二级!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String industryTwo;

    /** 行业三级 */
    private String industryThree;

    /** 联系人 */
	@NotBlank(message="联系人不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    @Size (min=1,max=10,message="请输入正确的联系人!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String contacts;

    /** 邮箱地址 */
	@NotBlank(message="邮箱地址不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    @Size (min=1,max=50,message="请输入正确的邮箱地址!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String emailAddress;

    /** 邮政编码 */
	@NotBlank(message="邮政编码不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
	@Size (min=6,max=6,message="请输入正确的邮政编码!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String postalCode;

    /** 手机号码 */
	@NotBlank(message="手机号码不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
	@Size (min=11,max=11,message="请输入正确的手机号码!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String number;

    /** 注册资本 */
    private String registeredcapital;

    /** 公司网站 */
    private String corporatewebsite;

    /** 注册时间 */
    private String registerctime;

    /** 上传营业执照 */
    @NotBlank(message="上传营业执照不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    @Size (min=0,max=32,message="请输入正确的上传营业执照!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String businessLicense;

    /** 上传法人手持身份证正面照 */
    @NotBlank(message="上传法人手持身份证正面照不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
	@Size (min=0,max=32,message="请输入正确的上传法人手持身份证正面照!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String frontCard;

    /** 上传法人手持身份证背面照 */
    @NotBlank(message="上传法人手持身份证背面照不能为空!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    @Size (min=0,max=32,message="请输入正确的上传法人手持身份证背面照!" ,groups = {ValidatebCompanyUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String backCard;

    /** 审核状态 0 正常 1 审核通过 2审核未通过 */
    @NotBlank(message="审核状态不能为空!" ,groups = {ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String state;

    private String ctime;
    
  //后加的属性
    private String businessLicenseUrl;
    private String frontCardUrl;
    private String backCardUrl;
    
    public String getBusinessLicenseUrl()
	{
		return businessLicenseUrl;
	}

	public void setBusinessLicenseUrl(String businessLicenseUrl)
	{
		this.businessLicenseUrl = businessLicenseUrl;
	}

	public String getFrontCardUrl()
	{
		return frontCardUrl;
	}

	public void setFrontCardUrl(String frontCardUrl)
	{
		this.frontCardUrl = frontCardUrl;
	}

	public String getBackCardUrl()
	{
		return backCardUrl;
	}

	public void setBackCardUrl(String backCardUrl)
	{
		this.backCardUrl = backCardUrl;
	}

	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 用户
     * @return staffId
     */
    public String getStaffId() {
        return staffId;
    }

    /**
     * 用户
     * @param staffId
     */
    public void setStaffId(String staffId) {
        this.staffId = staffId == null ? null : staffId.trim();
    }

    /**
     * 企业名称
     * @return title
     */
    public String getTitle() {
        return title;
    }

    /**
     * 企业名称
     * @param title
     */
    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }


    /**
     * 法定代表人
     * @return legalPerson
     */
    public String getLegalPerson() {
        return legalPerson;
    }

    /**
     * 法定代表人
     * @param legalPerson
     */
    public void setLegalPerson(String legalPerson) {
        this.legalPerson = legalPerson == null ? null : legalPerson.trim();
    }

    /**
     * 统一信用代码
     * @return creditCode
     */
    public String getCreditCode() {
        return creditCode;
    }

    /**
     * 统一信用代码
     * @param creditCode
     */
    public void setCreditCode(String creditCode) {
        this.creditCode = creditCode == null ? null : creditCode.trim();
    }

    /**
     * 法人身份证号
     * @return idCard
     */
    public String getIdCard() {
        return idCard;
    }

    /**
     * 法人身份证号
     * @param idCard
     */
    public void setIdCard(String idCard) {
        this.idCard = idCard == null ? null : idCard.trim();
    }

    /**
     * 所在省
     * @return province
     */
    public String getProvince() {
        return province;
    }

    /**
     * 所在省
     * @param province
     */
    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    /**
     * 所在市
     * @return city
     */
    public String getCity() {
        return city;
    }

    /**
     * 所在市
     * @param city
     */
    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    /**
     * 所在县
     * @return county
     */
    public String getCounty() {
        return county;
    }

    /**
     * 所在县
     * @param county
     */
    public void setCounty(String county) {
        this.county = county == null ? null : county.trim();
    }

    /**
     * 公司类型 1有限责任公司 2股份有限公司 3合伙企业
     * @return companytype
     */
    public String getCompanytype() {
        return companytype;
    }

    /**
     * 公司类型 1有限责任公司 2股份有限公司 3合伙企业
     * @param companytype
     */
    public void setCompanytype(String companytype) {
        this.companytype = companytype == null ? null : companytype.trim();
    }

    /**
     * 详情地址
     * @return address
     */
    public String getAddress() {
        return address;
    }

    /**
     * 详情地址
     * @param address
     */
    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    /**
     * 行业一级
     * @return industryOne
     */
    public String getIndustryOne() {
        return industryOne;
    }

    /**
     * 行业一级
     * @param industryOne
     */
    public void setIndustryOne(String industryOne) {
        this.industryOne = industryOne == null ? null : industryOne.trim();
    }

    /**
     * 行业二级
     * @return industryTwo
     */
    public String getIndustryTwo() {
        return industryTwo;
    }

    /**
     * 行业二级
     * @param industryTwo
     */
    public void setIndustryTwo(String industryTwo) {
        this.industryTwo = industryTwo == null ? null : industryTwo.trim();
    }

    /**
     * 行业三级
     * @return industryThree
     */
    public String getIndustryThree() {
        return industryThree;
    }

    /**
     * 行业三级
     * @param industryThree
     */
    public void setIndustryThree(String industryThree) {
        this.industryThree = industryThree == null ? null : industryThree.trim();
    }

    /**
     * 联系人
     * @return contacts
     */
    public String getContacts() {
        return contacts;
    }

    /**
     * 联系人
     * @param contacts
     */
    public void setContacts(String contacts) {
        this.contacts = contacts == null ? null : contacts.trim();
    }

    /**
     * 邮箱地址
     * @return emailAddress
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * 邮箱地址
     * @param emailAddress
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress == null ? null : emailAddress.trim();
    }

    /**
     * 邮政编码
     * @return postalCode
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * 邮政编码
     * @param postalCode
     */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode == null ? null : postalCode.trim();
    }

    /**
     * 手机号码
     * @return number
     */
    public String getNumber() {
        return number;
    }

    /**
     * 手机号码
     * @param number
     */
    public void setNumber(String number) {
        this.number = number == null ? null : number.trim();
    }

    /**
     * 注册资本
     * @return registeredcapital
     */
    public String getRegisteredcapital() {
        return registeredcapital;
    }

    /**
     * 注册资本
     * @param registeredcapital
     */
    public void setRegisteredcapital(String registeredcapital) {
        this.registeredcapital = registeredcapital == null ? null : registeredcapital.trim();
    }

    /**
     * 公司网站
     * @return corporatewebsite
     */
    public String getCorporatewebsite() {
        return corporatewebsite;
    }

    /**
     * 公司网站
     * @param corporatewebsite
     */
    public void setCorporatewebsite(String corporatewebsite) {
        this.corporatewebsite = corporatewebsite == null ? null : corporatewebsite.trim();
    }

    /**
     * 注册时间
     * @return registerctime
     */
    public String getRegisterctime() {
        return registerctime;
    }

    /**
     * 注册时间
     * @param registerctime
     */
    public void setRegisterctime(String registerctime) {
        this.registerctime = registerctime == null ? null : registerctime.trim();
    }

    /**
     * 上传营业执照
     * @return businessLicense
     */
    public String getBusinessLicense() {
        return businessLicense;
    }

    /**
     * 上传营业执照
     * @param businessLicense
     */
    public void setBusinessLicense(String businessLicense) {
    	if(StringUtil.isNotEmpty(businessLicense))
    	{
    		this.businessLicenseUrl = "/upload/attach"+FileUtil.getPath(businessLicense)+businessLicense +".png";
    	}
        this.businessLicense = businessLicense == null ? null : businessLicense.trim();
    }

    /**
     * 上传法人手持身份证正面照
     * @return frontCard
     */
    public String getFrontCard() {
        return frontCard;
    }

    /**
     * 上传法人手持身份证正面照
     * @param frontCard
     */
    public void setFrontCard(String frontCard) {
    	if(StringUtil.isNotEmpty(frontCard))
    	{
    		this.frontCardUrl = "/upload/attach"+FileUtil.getPath(frontCard)+frontCard +".png";
    	}
        this.frontCard = frontCard == null ? null : frontCard.trim();
    }

    /**
     * 上传法人手持身份证背面照
     * @return backCard
     */
    public String getBackCard() {
        return backCard;
    }

    /**
     * 上传法人手持身份证背面照
     * @param backCard
     */
    public void setBackCard(String backCard) {
    	if(StringUtil.isNotEmpty(backCard))
    	{
    		this.backCardUrl = "/upload/attach"+FileUtil.getPath(backCard)+backCard +".png";
    	}
        this.backCard = backCard == null ? null : backCard.trim();
    }

    /**
     * 审核状态 0 正常 1 审核通过 2审核未通过
     * @return state
     */
    public String getState() {
        return state;
    }

    /**
     * 审核状态 0 正常 1 审核通过 2审核未通过
     * @param state
     */
    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }

	@Override
	public String toString()
	{
		return "Company [id=" + id + ", staffId=" + staffId + ", title=" + title + ", legalPerson=" + legalPerson
				+ ", creditCode=" + creditCode + ", idCard=" + idCard + ", province=" + province + ", city=" + city
				+ ", county=" + county + ", companytype=" + companytype + ", address=" + address + ", industryOne="
				+ industryOne + ", industryTwo=" + industryTwo + ", industryThree=" + industryThree + ", contacts="
				+ contacts + ", emailAddress=" + emailAddress + ", postalCode=" + postalCode + ", number=" + number
				+ ", registeredcapital=" + registeredcapital + ", corporatewebsite=" + corporatewebsite
				+ ", registerctime=" + registerctime + ", businessLicense=" + businessLicense + ", frontCard="
				+ frontCard + ", backCard=" + backCard + ", state=" + state + ", ctime=" + ctime
				+ ", businessLicenseUrl=" + businessLicenseUrl + ", frontCardUrl=" + frontCardUrl + ", backCardUrl="
				+ backCardUrl + "]";
	}
    
}