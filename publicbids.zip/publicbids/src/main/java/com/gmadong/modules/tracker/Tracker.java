package com.gmadong.modules.tracker;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gmadong.common.utils.StringUtil;



public class Tracker {
	/** 跟踪器id */
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebTrackerEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebTrackerEditAction.class} )
    private String id;
	
    private String userId;

    /** 跟踪器名称 */
   	@NotBlank(message="跟踪器名称不能为空!" ,groups = {ValidatebTrackerAddAction.class,ValidatebTrackerEditAction.class})
    @Size (min=1,max=50,message="请输入正确的跟踪器名称!" ,groups = {ValidatebTrackerAddAction.class,ValidatebTrackerEditAction.class})
    private String trackerName;

    /** 关键字 */
    private String keywords;

    /** 地区 */
    private String regions;

    /** 信息类型 1招标公告 2招标预告 3招标变更 4中标结果 5拟在建项目 6vip独家项目 7政府采购 8企业采购 9业主委托项目 */
    private String infoType;

    /** 搜索模式 1模糊搜索 2精确搜索 */
    private String searchType;

    /** 订阅 */
    private String subscribe;

    private String ctime;
    
    
    
    
    //自己加
    
    private List<String> provinces = new ArrayList<>();
    private List<String> citys = new ArrayList<>();
    private List<String> keys ;
    private List<CityInfo> regionList = new ArrayList<>();
    private String searchTypeStr;
    private String regionStr;

    
	@Override
	public String toString()
	{
		return "Tracker [id=" + id + ", userId=" + userId + ", trackerName=" + trackerName + ", keywords=" + keywords
				+ ", regions=" + regions + ", infoType=" + infoType + ", searchType=" + searchType + ", subscribe="
				+ subscribe + ", ctime=" + ctime + "]";
	}
	public String getId() {
        return id;
    }
	public List<String> getKeys()
	{
		return keys;
	}
	
	public List<CityInfo> getRegionList()
	{
		return regionList;
	}
	public void setRegionList(List<CityInfo> regionList)
	{
		this.regionList = regionList;
	}
	public List<String> getProvinces()
	{
		return provinces;
	}

	public void setProvinces(List<String> provinces)
	{
		this.provinces = provinces;
	}

	public List<String> getCitys()
	{
		return citys;
	}

	public void setCitys(List<String> citys)
	{
		this.citys = citys;
	}

	public void setKeys(List<String> keys)
	{
		this.keys = keys;
	}

	public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }
    /**
     * 跟踪器名称
     * @return trackerName
     */
    public String getTrackerName() {
        return trackerName;
    }

    /**
     * 跟踪器名称
     * @param trackerName
     */
    public void setTrackerName(String trackerName) {
        this.trackerName = trackerName == null ? null : trackerName.trim();
    }

    /**
     * 关键字
     * @return keywords
     */
    public String getKeywords() {
        return keywords;
    }

    /**
     * 关键字
     * @param keywords
     */
    public void setKeywords(String keywords) 
    {
    	if(StringUtil.isNotEmpty(keywords))
    	{
    		keys = Arrays.asList(keywords.split(","));
    	}
        this.keywords = keywords == null ? null : keywords.trim();
    }

    /**
     * 地区
     * @return regions
     */
    public String getRegions() {
        return regions;
    }

    /**
     * 地区
     * @param regions
     */
    public void setRegions(String regions) 
    {
    	if(StringUtil.isNotEmpty(regions))
    	{
    		ObjectMapper mapper = new ObjectMapper();
    		try
			{
				this.regionList = mapper.readValue(regions, new TypeReference<List<CityInfo>>() {});
				String p = "";
				for(CityInfo info:regionList)
				{
					p = p + info.getP()+",";
				}
				if(p.length() > 0)
				{
					p = p.substring(0, p.length() -1);
				}
				this.regionStr = p;
				
			} catch (Exception e)
			{
				e.printStackTrace();
			}
    		
    	}
        this.regions = regions == null ? null : regions.trim();
    }

    /**
     * 信息类型 1招标公告 2招标预告 3招标变更 4中标结果 5拟在建项目 6vip独家项目 7政府采购 8企业采购 9业主委托项目
     * @return infoType
     */
    public String getInfoType() {
        return infoType;
    }

    /**
     * 信息类型 1招标公告 2招标预告 3招标变更 4中标结果 5拟在建项目 6vip独家项目 7政府采购 8企业采购 9业主委托项目
     * @param infoType
     */
    public void setInfoType(String infoType) {
        this.infoType = infoType == null ? null : infoType.trim();
    }

    /**
     * 搜索模式 1模糊搜索 2精确搜索
     * @return searchType
     */
    public String getSearchType() {
        return searchType;
    }

    /**
     * 搜索模式 1模糊搜索 2精确搜索
     * @param searchType
     */
    public void setSearchType(String searchType)
    {
    	if(StringUtil.isNotEmpty(searchType))
    	{
    		if("1".equals(searchType))
    		{
    			this.searchTypeStr = "模糊搜索";
    		}
    		else
    		{
    			this.searchTypeStr = "精确搜索";
    		}
    	}
        this.searchType = searchType == null ? null : searchType.trim();
    }

    /**
     * 订阅
     * @return subscribe
     */
    public String getSubscribe() {
        return subscribe;
    }

    /**
     * 订阅
     * @param subscribe
     */
    public void setSubscribe(String subscribe) {
        this.subscribe = subscribe == null ? null : subscribe.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }
    
	public String getSearchTypeStr()
	{
		return searchTypeStr;
	}
	public void setSearchTypeStr(String searchTypeStr)
	{
		this.searchTypeStr = searchTypeStr;
	}
	public String getRegionStr()
	{
		return regionStr;
	}
	public void setRegionStr(String regionStr)
	{
		this.regionStr = regionStr;
	}
	
    
    
}