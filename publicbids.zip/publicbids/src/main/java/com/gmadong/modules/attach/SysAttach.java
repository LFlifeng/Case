package com.gmadong.modules.attach;

public class SysAttach {
    /** 附件ID */
    private String attachId;

    /** 文件名称 */
    private String fileName;

    /** 文件类型 */
    private String mineType;

    /** 文件大小 */
    private String fileSize;

    /** 存放路径，相对upload路径 */
    private String url;

    /** 员工 */
    private String staff;

    /** 当前记录状态:0-删除 1-正常 */
    private String status;

    /** 当前记录创建时间 */
    private String ctime;

    /**
     * 附件ID
     * @return attachId
     */
    public String getAttachId() {
        return attachId;
    }

    /**
     * 附件ID
     * @param attachId
     */
    public void setAttachId(String attachId) {
        this.attachId = attachId == null ? null : attachId.trim();
    }

    /**
     * 文件名称
     * @return fileName
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * 文件名称
     * @param fileName
     */
    public void setFileName(String fileName) {
        this.fileName = fileName == null ? null : fileName.trim();
    }

    /**
     * 文件类型
     * @return mineType
     */
    public String getMineType() {
        return mineType;
    }

    /**
     * 文件类型
     * @param mineType
     */
    public void setMineType(String mineType) {
        this.mineType = mineType == null ? null : mineType.trim();
    }

    /**
     * 文件大小
     * @return fileSize
     */
    public String getFileSize() {
        return fileSize;
    }

    /**
     * 文件大小
     * @param fileSize
     */
    public void setFileSize(String fileSize) {
        this.fileSize = fileSize == null ? null : fileSize.trim();
    }

    /**
     * 存放路径，相对upload路径
     * @return url
     */
    public String getUrl() {
        return url;
    }

    /**
     * 存放路径，相对upload路径
     * @param url
     */
    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    /**
     * 员工
     * @return staff
     */
    public String getStaff() {
        return staff;
    }

    /**
     * 员工
     * @param staff
     */
    public void setStaff(String staff) {
        this.staff = staff == null ? null : staff.trim();
    }

    /**
     * 当前记录状态:0-删除 1-正常
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     * 当前记录状态:0-删除 1-正常
     * @param status
     */
    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    /**
     * 当前记录创建时间
     * @return ctime
     */
    public String getCtime() {
        return ctime;
    }

    /**
     * 当前记录创建时间
     * @param ctime
     */
    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }
}