package com.gmadong.modules.bids;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.gmadong.common.utils.DateUtil;

public class Bids {
    private Integer id;

    /** 公告名称 */
    private String name;

    /** 省 */
    private String province;

    /** 市 */
    private String city;

    /** 公告发布时间 */
    private String time;

    /** 公告链接 */
    private String url;

    /** 附件链接 */
    private String attachmentUrl;

    /** 行业分类 */
    private String industry;

    /** 公告类型 */
    private String type;
    
    /** 公告内容 */
    private String content;

    /** 公告内容(带html标签) */
    private String contentHtml;

    /** 附件名称 */
    private String attachmentName;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 公告名称
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * 公告名称
     * @param name
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * 省
     * @return province
     */
    public String getProvince() {
        return province;
    }

    /**
     * 省
     * @param province
     */
    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    /**
     * 市
     * @return city
     */
    public String getCity() {
        return city;
    }

    /**
     * 市
     * @param city
     */
    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    /**
     * 公告发布时间
     * @return time
     */
    public String getTime() {
        return time;
    }

    /**
     * 公告发布时间
     * @param time
     */
    public void setTime(String time) {
    	if(time.contains("月")) {
    		time = dataFormat(time);
    	}
        this.time = time == null ? null : time.trim();
    }

    /**
     * 公告链接
     * @return url
     */
    public String getUrl() {
        return url;
    }

    /**
     * 公告链接
     * @param url
     */
    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    /**
     * 附件链接
     * @return attachmentUrl
     */
    public String getAttachmentUrl() {
        return attachmentUrl;
    }

    /**
     * 附件链接
     * @param attachmentUrl
     */
    public void setAttachmentUrl(String attachmentUrl) {
        this.attachmentUrl = attachmentUrl == null ? null : attachmentUrl.trim();
    }

    /**
     * 行业分类
     * @return industry
     */
    public String getIndustry() {
        return industry;
    }

    /**
     * 行业分类
     * @param industry
     */
    public void setIndustry(String industry) {
        this.industry = industry == null ? null : industry.trim();
    }

    /**
     * 公告类型
     * @return type
     */
    public String getType() {
        return type;
    }

    /**
     * 公告类型
     * @param type
     */
    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }
    
    public String dataFormat(String time) {
    	Date date = null;
    	SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy年MM月dd日 ");
        //必须捕获异常
		try {
			date = simpleDateFormat.parse(time);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		time = DateUtil.dateToString(date, "yyyy-MM-dd");
    	return time;
    }
    
}