package com.gmadong.modules.city;

import com.gmadong.modules.city.SysCity;
import com.gmadong.modules.city.SysCityExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SysCityMapper {
    int countByExample(SysCityExample example);

    int deleteByExample(SysCityExample example);

    int insert(SysCity record);

    int insertSelective(SysCity record);

    List<SysCity> selectByExample(SysCityExample example);
    
    SysCity selectByPrimaryKey(String id);
    
    int updateByExampleSelective(@Param("record") SysCity record, @Param("example") SysCityExample example);

    int updateByExample(@Param("record") SysCity record, @Param("example") SysCityExample example);
    
    /**
     * 自定义
     */
    List<CityMinInfo> selectIdOrNamesByExample(SysCityExample example);
    
}