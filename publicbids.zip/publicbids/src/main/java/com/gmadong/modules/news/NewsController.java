package com.gmadong.modules.news;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.category.Category;
import com.gmadong.modules.category.CategoryService;
import com.gmadong.modules.category.ValidatebCategoryAddAction;
import com.gmadong.modules.category.ValidatebCategoryEditAction;
import com.gmadong.modules.staff.SysStaff;

/**
 * 新闻管理
 * @author Administrator
 *
 */
@Controller
public class NewsController 
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private NewsService newsService;
	private String listkey = "news.list.action";
	@Autowired
	private CategoryService categoryService;
	
	/**
	 * 显示页面
	 * @return
	 */
	@RequestMapping("/news.page.action")
	public String page()
	{
		return "/back/news/page";
	}
	
	/**
	 * 页面条件查询
	 * @return
	 */
	@RequestMapping("/news.list.action")
	public void list(HttpServletResponse response, String category, String title, String ctime,@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows) 
	{
		String field = category + "_" + title + "_" + ctime + "_" + page + "_" + rows;
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = newsService.page(category, title, ctime, page, rows);
		String list = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, list, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(Page.pageToJson(toPage), response);
	}
	/**
	 * 删除
	 * * @return
	 */
	@RequestMapping("/news.doDelete.action")
	public void doDelete(HttpServletResponse response, String ids) {
		if (newsService.deleteById(ids)) {
			try {
				jedisClientSingle.del("news.list.action");
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("fail", response);
		}
	}
	/**
	 * 添加页面
	 * @return
	 */
	@RequestMapping("/news.preAdd.action")
	public String preAdd() 
	{
		List<Category> categorys = categoryService.getCategorys("1");
		Request.set("list", categorys);
		return "/back/news/add";
	}
	/**
	 * 页面操作
	 * @return
	 */
	@RequestMapping("/news.doAdd.action")
	public void doAdd(HttpServletResponse response, @Validated({ ValidatebCategoryAddAction.class }) News news,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		if (StringUtil.isNotEmpty(news)) 
		{
			SysStaff staff = (SysStaff) Session.get("staff");
			news.setStaffId(staff.getId());
			news.setStaffName(staff.getNickname());
			newsService.save(news);
			try {
				jedisClientSingle.del(listkey);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("保存失败", response);
		}
	}
	/**
	 * 修改页面
	 * @return
	 */
	@RequestMapping("/news.preEdit.action")
	public String preEdit(String id) {
		News newsById = newsService.getNewsById(id);
		if (newsById == null) {
			return "/common/500";
		}
		Request.set("info", newsById);
		List<Category> categorys = categoryService.getCategorys("1");
		Request.set("list", categorys);
		return "/back/news/edit";
	}
	/**
	 * 修改操作
	 */
	@RequestMapping("/news.doEdit.action")
	public void doEdit(HttpServletResponse response,
			@Validated({ ValidatebCategoryEditAction.class }) News news, BindingResult bindingResult) 
	{
		if (bindingResult.hasErrors()) {
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(), response);
			return;
		}
		SysStaff staff = (SysStaff) Session.get("staff");
		news.setStaffId(staff.getId());
		news.setStaffName(staff.getNickname());
		if(newsService.update(news))
		{
			try
			{
				jedisClientSingle.del(listkey);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("修改失败！",response);
		}
	}
}
