package com.gmadong.modules.bids;

import com.gmadong.modules.biddinginfo.Biddinginfo;
import com.gmadong.modules.biddinginfo.BidsInfo;
import com.gmadong.modules.biddinginfo.BidsParamsInfo;
import com.gmadong.modules.bids.Bids;
import com.gmadong.modules.bids.BidsExample;
import com.gmadong.modules.bids.BidsWithBLOBs;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BidsMapper {
    int countByExample(BidsExample example);

    int deleteByExample(BidsExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BidsWithBLOBs record);

    int insertSelective(BidsWithBLOBs record);

    List<BidsWithBLOBs> selectByExampleWithBLOBs(BidsExample example);

    List<Bids> selectByExample(BidsExample example);

    BidsWithBLOBs selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BidsWithBLOBs record, @Param("example") BidsExample example);

    int updateByExampleWithBLOBs(@Param("record") BidsWithBLOBs record, @Param("example") BidsExample example);

    int updateByExample(@Param("record") Bids record, @Param("example") BidsExample example);

    int updateByPrimaryKeySelective(BidsWithBLOBs record);

    int updateByPrimaryKeyWithBLOBs(BidsWithBLOBs record);

    int updateByPrimaryKey(Bids record);
    
    //个人新增
    List<Bids> selectTodayBids();

	List<Bids> selectTypeBids(@Param(value="type")String type);

	List<Bids> selectBidsConsultation();

	List<Bids> selectFreeAndWinBids(@Param(value="type")String type);
	
	List<Bids> selectExclusiveBids();
	
	List<BidsInfo> selectBidingByParamsInfo(BidsParamsInfo record);

	List<Biddinginfo> selectLatestRelease();

	List<BidListInfo> selectBidsList(BidsMinInfo info);
	
	List<Bids> selectWechatBids();
	
	List<BidsInfo> selectBidingByMobileParamsInfo(BidMobileParamsInfo record);
	
}