package com.gmadong.modules.qualification;

public interface ValidatebQualificationAddAction
{

}
