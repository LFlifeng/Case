package com.gmadong.modules.manageCondition;

public interface ValidatebManageConditionAddAction
{

}
