package com.gmadong.modules.designedinfo;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.projectDesigneds.ProjectDesigneds;
import com.gmadong.modules.projectDesigneds.ProjectDesignedsService;
import com.gmadong.modules.staff.SysStaff;

/**
 * 专盯下的跟进
 * @author Administrator
 *
 */
@Controller
public class DesignedinfoController
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private DesignedinfoService designedinfoService;
	private String listkey = "designedinfo.list.action";
	@Autowired
	private ProjectDesignedsService projectDesignedsService;
	/**
	 * 列表页面
	 * @return
	 */
	@RequestMapping("/designedinfo.page.action")
	public String page()
	{
		return "/back/designedinfo/page";
	}
	/**
	 * 页面条件搜索
	 * @return
	 */
	@RequestMapping("/designedinfo.list.action")
	public void list(HttpServletResponse response,String id,@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows) 
	{
		String field = id + "_" + page + "_" + rows;
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = designedinfoService.page(id,page, rows);
		String list = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, list, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(Page.pageToJson(toPage), response);
	}
	@RequestMapping("/designedinfo.preAdd.action")
	public String preAdd() 
	{
		return "/back/projectDesigneds/add";
	}
	/**添加操作
	 * @return
	 */
	@RequestMapping("/designedinfo.doAdd.action")
	public void doAdd(HttpServletResponse response, @Validated({ ValidatebDesignedinfoAddAction.class }) Designedinfo designedinfo,String uid,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		SysStaff staff = (SysStaff) Session.get("staff");
		designedinfo.setStaffId(staff.getId());
		designedinfo.setPeople(staff.getNickname());
		if(designedinfoService.save(designedinfo))
		{
			try {
				jedisClientSingle.del(listkey);
				jedisClientSingle.del("designedinfo.list_"+uid);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		}
		else {
			AjaxUtil.write("添加失败", response);
		}
	}
	//查询专盯详情
	@RequestMapping("/designedinfo.seachUser.action")
	public void seachUser(HttpServletResponse response,String name)
	{
		ProjectDesigneds projectDesigneds = projectDesignedsService.getProjectDesigneds(name);
		if(projectDesigneds == null)
		{
			AjaxUtil.write("fail",response);
			return ;
		}
		AjaxUtil.write("{\"name\":\""+projectDesigneds.getProjectsName()+"\",\"id\":\""+projectDesigneds.getId()+"\"}",response);
	}
}
