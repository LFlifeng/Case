package com.gmadong.modules.biddinginfo;

import java.util.List;

import com.gmadong.common.Page;

public interface BiddinginfoQdService
{

	Page page(String name, String type, String ctime, String province, String industry, Integer page, Integer rows);

	Biddinginfo details(String id);

	List<Biddinginfo> findBidingInfoByType(String proType);

	boolean save(Biddinginfo biddinginfo);

	boolean deleteById(String id);

	Page pageUser(String userId, Integer page, Integer rows);

	Page pageCompany(String applicationId, Integer page, Integer rows);



}
