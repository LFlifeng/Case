package com.gmadong.modules.industry;

import java.util.List;

public interface IndustryService
{
	public List<IndustryMinInfo> getChildren(int pId);
	
	Industry selectById(Integer id);
}
