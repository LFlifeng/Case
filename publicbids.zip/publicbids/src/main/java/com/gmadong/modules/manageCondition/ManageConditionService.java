package com.gmadong.modules.manageCondition;

import com.gmadong.common.Page;

public interface ManageConditionService
{
	public Page page(String operations,String product,String ctime,Integer page,Integer rows);
	public boolean save(ManageCondition manageCondition);
	public boolean update(ManageCondition manageCondition);
	public ManageCondition getManageConditionById(String id);
	public boolean deleteById(String ids);
}
