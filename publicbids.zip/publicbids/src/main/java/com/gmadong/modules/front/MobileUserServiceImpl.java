package com.gmadong.modules.front;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.PasswordUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.common.utils.PasswordUtil.PasswordUtilType;
import com.gmadong.modules.application.Application;
import com.gmadong.modules.application.ApplicationMapper;
import com.gmadong.modules.company.Company;
import com.gmadong.modules.company.CompanyMapper;
import com.gmadong.modules.user.User;
import com.gmadong.modules.user.UserExample;
import com.gmadong.modules.user.UserExample.Criteria;
import com.gmadong.modules.user.UserMapper;
import com.gmadong.modules.user.UserQdRegister;

@Service("mobileUserService")
public class MobileUserServiceImpl implements MobileUserService
{
	@Autowired
    UserMapper userMapper;
	@Autowired
	CompanyMapper companyMapper;
	@Autowired
	ApplicationMapper applicationMapper;
	@Override
	public User selectUserByPhone(String phone)
	{
		return userMapper.selectUserByPhone(phone);
	}

	@Override
	public int updateByltime(String phone, String currentDate)
	{
		// 修改登录时间
		return userMapper.updateByltime(phone, currentDate);	
	}

	@Override
	public Boolean saveUserRegister(MobileRegister reg)
	{
        User user = new User();
		Company company = new Company();
		String phone = reg.getPhone();
		user.setPhone(phone);
		user.setId(UUIDUtil.getUUID());
		user.setPassword(PasswordUtil.encrypt("123456", PasswordUtilType.NORMAL));
		user.setCtime(DateUtil.getCurrentDate());
		boolean users = userMapper.insertUserQdUregister(user) > 0;
		company.setNumber(phone);
		company.setStaffId(user.getId());
		company.setId(UUIDUtil.getUUID());
		company.setCtime(DateUtil.getCurrentDate());
		company.setState("0");
		boolean companys = companyMapper.insert(company) > 0;
		
		//注册成功新增关联申请入驻的用户信息
		Application application=new Application();
		application.setId(UUIDUtil.getUUID());
		application.setCtime(DateUtil.getCurrentDate());
		application.setUserId(user.getId());
		application.setState("0");
		boolean app=applicationMapper.insertSelective(application) > 0;
		
		if (users && companys && app) {
			return true;
		}
		return false;
	}

	@Override
	public boolean updatePwd(String newPwd, String useId)
	{
		return userMapper.updateByPassword(useId, newPwd) > 0;
	}

}
