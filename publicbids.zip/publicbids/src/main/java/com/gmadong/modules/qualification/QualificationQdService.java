package com.gmadong.modules.qualification;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gmadong.common.Page;

public interface QualificationQdService
{

	Page page(String id, Integer page, Integer rows);

	boolean deleteByPrimaryKey(String id);

	boolean save(Qualification qualification);

	List<Qualification> selectByApplicationId(String applicationId);



}
