package com.gmadong.modules.systemMsg;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.systemMsg.SystemMsgExample.Criteria;


@Service("systemMsgService")
public class SystemMsgServiceImpl implements SystemMsgService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private SystemMsgMapper systemMsgMapper;
	
	@Override
	public Page page(String msg, String type, String ctime, Integer page, Integer rows)
	{
		SystemMsgExample systemMsgExample = new SystemMsgExample();
		Criteria createCriteria = systemMsgExample.createCriteria();
		if (!StringUtil.isEmpty(msg)) {
			createCriteria.andMsgLike(msg + "%");
			
		}
		if (!StringUtil.isEmpty(type)) {
			createCriteria.andTypeLike(type + "%");
		}
		if (!StringUtil.isEmpty(ctime)) {
			createCriteria.andCtimeLike(ctime + "%");
		}
		systemMsgExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<SystemMsg> list = systemMsgMapper.selectByExample(systemMsgExample);
		PageInfo<SystemMsg> pageInfo = new PageInfo<SystemMsg>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean save(SystemMsg systemMsg)
	{
		systemMsg.setId(UUIDUtil.getUUID());
		systemMsg.setCtime(DateUtil.getCurrentDate());
		boolean flag = systemMsgMapper.insert(systemMsg) > 0;
		return flag;
	}

	@Override
	public boolean update(SystemMsg systemMsg)
	{
		systemMsg.setCtime(null);
		return systemMsgMapper.updateByPrimaryKeySelective(systemMsg) > 0;
	}

	@Override
	public SystemMsg getSystemMsgById(String id)
	{
		return systemMsgMapper.selectByPrimaryKey(id);
	}

	@Override
	public boolean deleteById(String ids)
	{
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			SystemMsgExample systemMsgExample = new SystemMsgExample();
			Criteria createCriteria = systemMsgExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			return systemMsgMapper.deleteByExample(systemMsgExample) > 0;
		}
		return false;
	}

}
