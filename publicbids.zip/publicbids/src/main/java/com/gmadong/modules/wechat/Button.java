package com.gmadong.modules.wechat;

/**
 * 按钮的基类
 * 
 * @author Administrator
 */
public class Button {
	private String name;
 
	public String getName() {
		return name;
	}
 
	public void setName(String name) {
		this.name = name;
	}

}