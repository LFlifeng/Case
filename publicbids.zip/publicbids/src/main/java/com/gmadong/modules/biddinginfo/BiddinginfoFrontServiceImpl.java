package com.gmadong.modules.biddinginfo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;

@Service("biddinginfoFrontService")
public class BiddinginfoFrontServiceImpl implements BiddinginfoFrontService
{
	@Autowired
	private BiddinginfoMapper biddinginfoMapper;
	@Override
	public Page page(BidsParamsInfo info, Integer page, Integer rows)
	{
		PageHelper.startPage(page, rows);
		List<BidsInfo> list = biddinginfoMapper.selectBidingByParamsInfo(info);
		PageInfo<BidsInfo> pageInfo = new PageInfo<BidsInfo>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

}
