package com.gmadong.modules.industry;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("industryService")
public class IndustryServiceImpl implements IndustryService
{

	@Autowired
	private IndustryMapper  industryMapper;
	
	
	@Override
	public List<IndustryMinInfo> getChildren(int pId)
	{
		return industryMapper.selectByParentId(pId);
	}


	@Override
	public Industry selectById(Integer id) {
		// TODO Auto-generated method stub
		return industryMapper.selectByPrimaryKey(id);
	}

	
}
