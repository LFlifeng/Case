package com.gmadong.modules.bids;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.datasource.CustomerContextHolder;
import com.gmadong.modules.biddinginfo.BidsInfo;
import com.gmadong.modules.biddinginfo.BidsParamsInfo;

@Service("bidsFrontService")
public class BidsFrontServiceImpl implements BidsFrontService
{

	@Autowired
	private BidsMapper bidsMapper;
	@Override
	public Page page(BidsParamsInfo info, Integer page, Integer rows)
	{
		PageHelper.startPage(page, rows);
		CustomerContextHolder.setCustomerType(CustomerContextHolder.BIDS_DATA_SOURCE_MSSQL);
		List<BidsInfo> list = bidsMapper.selectBidingByParamsInfo(info);
		CustomerContextHolder.clearCustomerType();
		PageInfo<BidsInfo> pageInfo = new PageInfo<BidsInfo>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

}
