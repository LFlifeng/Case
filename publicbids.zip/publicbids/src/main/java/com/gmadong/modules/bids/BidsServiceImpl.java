package com.gmadong.modules.bids;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.datasource.CustomerContextHolder;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.modules.biddinginfo.Biddinginfo;

@Service("bidsService")
public class BidsServiceImpl implements BidsService {

	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private BidsMapper bidsMapper;

	@Override
	public Page page(String type, String title, String date, String province, String industry, Integer page,
			Integer rows) {

		BidsMinInfo info = new BidsMinInfo(type, title, date, province, industry);
		
		PageHelper.startPage(page, rows);
		CustomerContextHolder.setCustomerType(CustomerContextHolder.BIDS_DATA_SOURCE_MSSQL);
		List<BidListInfo> list = bidsMapper.selectBidsList(info);
		CustomerContextHolder.clearCustomerType();
		PageInfo<BidListInfo> pageInfo = new PageInfo<BidListInfo>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public BidsWithBLOBs details(Integer id) {
		CustomerContextHolder.setCustomerType(CustomerContextHolder.BIDS_DATA_SOURCE_MSSQL);
		BidsWithBLOBs bid = bidsMapper.selectByPrimaryKey(id);
		CustomerContextHolder.clearCustomerType();
		return bid;

	}

	@Override
	public List<Bids> findTodayBids() {
		CustomerContextHolder.setCustomerType(CustomerContextHolder.BIDS_DATA_SOURCE_MSSQL);
		List<Bids> list = bidsMapper.selectTodayBids();
		CustomerContextHolder.clearCustomerType();
		return list;
	}

	@Override
	public List<Bids> findTypeBids(String type) {
		CustomerContextHolder.setCustomerType(CustomerContextHolder.BIDS_DATA_SOURCE_MSSQL);
		List<Bids> list = bidsMapper.selectTypeBids(type);
		CustomerContextHolder.clearCustomerType();
		return list;
	}

	@Override
	public List<Bids> findBidsConsultation() {
		CustomerContextHolder.setCustomerType(CustomerContextHolder.BIDS_DATA_SOURCE_MSSQL);
		List<Bids> list = bidsMapper.selectBidsConsultation();
		CustomerContextHolder.clearCustomerType();
		return list;
	}

	@Override
	public List<Bids> findFreeAndWinBids(String type) {
		CustomerContextHolder.setCustomerType(CustomerContextHolder.BIDS_DATA_SOURCE_MSSQL);
		List<Bids> list = bidsMapper.selectFreeAndWinBids(type);
		CustomerContextHolder.clearCustomerType();
		return list;
	}

	@Override
	public List<Bids> findExclusiveBids() {
		CustomerContextHolder.setCustomerType(CustomerContextHolder.BIDS_DATA_SOURCE_MSSQL);
		List<Bids> list = bidsMapper.selectExclusiveBids();
		CustomerContextHolder.clearCustomerType();
		return list;
	}

	@Override
	public List<Biddinginfo> findLatestRelease() {
		CustomerContextHolder.setCustomerType(CustomerContextHolder.BIDS_DATA_SOURCE_MSSQL);
		List<Biddinginfo> list = bidsMapper.selectLatestRelease();
		CustomerContextHolder.clearCustomerType();
		if(list.size() > 0) {
			return list;
		}
		return null;
	}

}