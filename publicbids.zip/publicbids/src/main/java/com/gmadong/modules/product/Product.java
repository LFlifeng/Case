package com.gmadong.modules.product;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.gmadong.common.utils.FileUtil;
import com.gmadong.common.utils.StringUtil;


public class Product {
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebProductEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebProductEditAction.class} )
    private String id;

    private String userId;

    /** 产品名称 */
    @NotBlank(message="产品名称不能为空!" ,groups = {ValidatebProductAddAction.class,ValidatebProductEditAction.class})
    @Size (min=1,max=50,message="请输入正确的产品名称!" ,groups = {ValidatebProductAddAction.class,ValidatebProductEditAction.class})
    private String productName;

    /** 产品描述 */
    @NotBlank(message="产品描述不能为空!" ,groups = {ValidatebProductAddAction.class,ValidatebProductEditAction.class})
    @Size (min=1,max=100,message="请输入正确的产品描述 !" ,groups = {ValidatebProductAddAction.class,ValidatebProductEditAction.class})
    private String productDescribe;

    /** 图片 */
    private String picture;

    private String ctime;
    
    //后加的属性
    private String pictureUrl;
    
    public String getPictureUrl()
	{
		return pictureUrl;
	}

	public void setPictureUrl(String pictureUrl)
	{
		this.pictureUrl = pictureUrl;
	}

	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    /**
     * 产品名称
     * @return productName
     */
    public String getProductName() {
        return productName;
    }

    /**
     * 产品名称
     * @param productName
     */
    public void setProductName(String productName) {
        this.productName = productName == null ? null : productName.trim();
    }

    /**
     * 产品描述
     * @return productDescribe
     */
    public String getProductDescribe() {
        return productDescribe;
    }

    /**
     * 产品描述
     * @param productDescribe
     */
    public void setProductDescribe(String productDescribe) {
        this.productDescribe = productDescribe == null ? null : productDescribe.trim();
    }

    /**
     * 图片
     * @return picture
     */
    public String getPicture() {
        return picture;
    }

    /**
     * 图片
     * @param picture
     */
    public void setPicture(String picture) {
    	if(StringUtil.isNotEmpty(picture))
    	{
    		this.pictureUrl = "/upload/attach"+FileUtil.getPath(picture)+picture +".png";
    	}
        this.picture = picture == null ? null : picture.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }
}