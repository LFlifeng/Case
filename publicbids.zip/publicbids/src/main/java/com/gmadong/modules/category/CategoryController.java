package com.gmadong.modules.category;




import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.XSSUtils;

/**
 * 类型管理
 * @author Administrator
 *
 */
@Controller
public class CategoryController {
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private CategoryService categoryService;
	
	private String listkey = "category.list.action";
	/**
	 * 显示页面
	 * @return
	 */
	@RequestMapping("/category.page.action")
	public String page()
	{
		return "/back/category/page";
	}
	/**
	 * 页面操作
	 * @return
	 */
	@RequestMapping("/category.list.action")
	public void list(HttpServletResponse response, String type, String title, String ctime,
			@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows)
	{
		String field = type + "_" + title + "_" + ctime + "_" + page + "_" + rows;
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = categoryService.page(type, title, ctime, page, rows);
		String list = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, list, Common.REDIS_30_MINUTE_EXPIRE);

		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(Page.pageToJson(toPage), response);
	}
	/**
	 * 添加页面
	 * @return
	 */
	@RequestMapping("/category.preAdd.action")
	public String preAdd() {

		return "/back/category/add";
	}
	/**
	 * 添加操作
	 * @return
	 */
	@RequestMapping("/category.doAdd.action")
	public void doAdd(HttpServletResponse response, @Validated({ ValidatebCategoryAddAction.class }) Category category,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		XSSUtils.clearXss(Category.class, category);
		if (StringUtil.isNotEmpty(category)) {
			categoryService.save(category);
			try {
				jedisClientSingle.del(listkey);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("保存失败", response);
		}
	}
	/**
	 * 删除
	 * @return
	 */
	@RequestMapping("/category.doDelete.action")
	public void doDelete(HttpServletResponse response, String ids) {

		if (categoryService.deleteById(ids)) {
			try {
				jedisClientSingle.del(listkey);

			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("fail", response);
		}
	}
	/**
	 * 修改页面
	 * 
	 * @return
	 */
	@RequestMapping("/category.preEdit.action")
	public String preEdit(String id) {
		Category columnCategoryById = categoryService.getColumnCategoryById(id);
		
		if (columnCategoryById == null) {
			return "/common/500";
		}
		Request.set("info", columnCategoryById);
		return "/back/category/edit";
	}
	/**
	 * 修改操作
	 */
	@RequestMapping("/category.doEdit.action")
	public void doEdit(HttpServletResponse response,
			@Validated({ ValidatebCategoryEditAction.class }) Category category, BindingResult bindingResult) 
	{
		if (bindingResult.hasErrors()) {
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(), response);
			return;
		}
		XSSUtils.clearXss(Category.class, category);
		if(categoryService.update(category))
		{
			try
			{
				jedisClientSingle.del(listkey);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("修改失败！",response);
		}
	}
}
