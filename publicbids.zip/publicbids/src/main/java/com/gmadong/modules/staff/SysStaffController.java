package com.gmadong.modules.staff;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.PasswordUtil;
import com.gmadong.common.utils.PasswordUtil.PasswordUtilType;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.organize.SysOrganize;
import com.gmadong.modules.organize.SysOrganizeService;
import com.gmadong.modules.role.SysRole;
import com.gmadong.modules.role.SysRoleService;

@Controller
public class SysStaffController
{
	@Resource(name="staffService")
	private SysStaffService staffService;
	@Resource(name="sysOrganizeService")
    private SysOrganizeService organizeService;
	@Resource(name="sysRoleService")
	private SysRoleService sysRoleService;
	@Autowired
	private JedisClientSingle jedisClientSingle;
	/**
	 * 列表页
	 */
	@RequestMapping("/staff.page.action")
	public String page(HttpServletResponse response)
	{
		List<SysOrganize> list = null;
//		if("402888e432a9db5a0132a9e007400001".equals(staff.getOrganizeId()))
//		{
//			list = organizeService.getAll();
//		}else
//		{
//			list = organizeService.getChlidOrganize(staff.getOrganizeId());
//		}
		String key = "organizesJsonString";
		try
		{
			String organizesJson  = jedisClientSingle.get(key);
			if(StringUtil.isNotEmpty(organizesJson))
			{
				Request.set("organizesJsonString", organizesJson);
				return "/back/staff/page";
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		list = organizeService.getAll();
		String organizesJsonString = JsonUtil.listToJson(list).replaceAll("organizeId", "id").replaceAll("organizeName", "name").replaceAll("parentId", "pId");
		Request.set("organizesJsonString", organizesJsonString);
		try
		{
			jedisClientSingle.set(key, organizesJsonString, Common.REDIS_48_HOUR_EXPIRE);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return "/back/staff/page";
	}
	/**
	 * 用户列表
	 */
	@RequestMapping("/staff.list.action")
	public void list(HttpServletResponse response,String staffName,String loginName,String createTime,String jobNumber,String orgId,@RequestParam(defaultValue="1") Integer page,@RequestParam(defaultValue="10") Integer rows)
	{
		String key = "staff.list";
		String field = staffName+"-"+loginName+"-"+createTime+"-"+jobNumber+"-"+orgId+"-"+page+"-"+rows;
		try
		{
			String list = jedisClientSingle.hget(key, field);
			if(StringUtil.isNotEmpty(list))
			{
				AjaxUtil.write(list,response);
				return;
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		Page toPage = staffService.page(staffName, loginName, createTime,jobNumber,orgId,page, rows);
		String listStr = Page.pageToJson(toPage);
		try
		{
		   jedisClientSingle.hset(key, field, listStr,Common.REDIS_48_HOUR_EXPIRE);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		AjaxUtil.write(listStr,response);
	}
	/**
	 * 添加页面
	 * @return
	 */
	@RequestMapping("/staff.preAdd.action")
	public String preAdd()
	{
		String organizesJsonString = "";
		String rolesJsonString = "";
		String organizesJson = "organizesJsonString";
		String rolesJson = "rolesJsonString";
		try
		{
			organizesJsonString  = jedisClientSingle.get(organizesJson);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		try
		{
			rolesJsonString = jedisClientSingle.get(rolesJson);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(StringUtil.isEmpty(organizesJsonString))
		{
			List<SysOrganize> list = organizeService.getAll();
			organizesJsonString = JsonUtil.listToJson(list).replaceAll("organizeId", "id").replaceAll("organizeName", "name").replaceAll("parentId", "pId");
			try
			{
				jedisClientSingle.set(organizesJson, organizesJsonString, Common.REDIS_48_HOUR_EXPIRE);
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		Request.set("organizesJsonString", organizesJsonString);
		if(StringUtil.isEmpty(rolesJsonString))
		{
			List<SysRole> roles = sysRoleService.getAll();
			rolesJsonString = JsonUtil.listToJson(roles).replaceAll("id", "roleId");
			try
			{
				jedisClientSingle.set(rolesJson, rolesJsonString, Common.REDIS_48_HOUR_EXPIRE);
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		Request.set("rolesJsonString", rolesJsonString);
		
		return "/back/staff/add";
	}
	/**
	 * 检查登录名是否合法
	 * @param response
	 * @param loginName
	 */
	@RequestMapping("/staff.loginNameCheck.action")
	public void loginNameCheck(HttpServletResponse response,String loginName)
	{
		if(!StringUtil.isEmpty(loginName)&&loginName.length()>=5&&loginName.length()<=11)
		{
			SysStaff staff = staffService.getStaffByLoginName(loginName);
			AjaxUtil.write((staff==null?"true":"false"),response);
		}
		else
		{
			AjaxUtil.write("false",response);
		}
	}
	/**
	 * 添加操作
	 * @param response
	 * @param staff
	 * @param bindingResult
	 */
	@RequestMapping("/staff.doAdd.action")
	public void doAdd(HttpServletResponse response,@Validated({ ValidateSysStaffSaveAction.class }) SysStaff staff,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		staff.setId(UUIDUtil.getUUID());
		staff.setStatus(1);
		staff.setCtime(DateUtil.getCurrentDate());
		staff.setPwd(PasswordUtil.encrypt(staff.getPwd(), PasswordUtilType.BACK));
		if(staffService.save(staff))
		{
			try
			{
				jedisClientSingle.del("staff.list");
				jedisClientSingle.del("organize.staffList");
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("未知错误",response);
		}
	}
	/**
	 * 修改页面
	 * @return
	 */
	@RequestMapping("/staff.preEdit.action")
	public String preEdit(String id)
	{
		SysStaff staff =  staffService.getStaffById(id);
		// 获取角色列表
		List<SysRole> roles = sysRoleService.getAll();
		String rolesJsonString = "[";
		for(SysRole role:roles)
		{
			rolesJsonString += "{\"roleId\":\""+role.getId()+"\",\"roleName\":\""+role.getRoleName()+"\""+(staff.getRoleId().indexOf(role.getId())!=-1 ? ",\"selected\":\"true\"" : "")+"},";
		}
		if(rolesJsonString.endsWith(","))
		{
			rolesJsonString = rolesJsonString.substring(0, rolesJsonString.length()-1);
		}
		rolesJsonString += "]";
		Request.set("rolesJsonString", rolesJsonString);
		staff.setRoleId("");
		// 部门
		List<SysOrganize> organizes = organizeService.getAll();
		String organizesJsonString = "[";
		for(SysOrganize organize:organizes)
		{
			organizesJsonString += "{\"id\":\""+organize.getOrganizeId()+"\",\"name\":\""+organize.getOrganizeName()+"\",\"pId\":\""+organize.getParentId()+"\"";
			if(StringUtil.isNotEmpty(staff.getOrganizeId()) && staff.getOrganizeId().indexOf(organize.getOrganizeId())!=-1){
				organizesJsonString += ",\"checked\":\"true\"";
			}
			organizesJsonString += "},";
		}
		if(organizesJsonString.endsWith(","))
		{
			organizesJsonString = organizesJsonString.substring(0, organizesJsonString.length()-1);
		}
		organizesJsonString += "]";
		Request.set("organizesJsonString", organizesJsonString);
		Request.set("staff", staff);
		return "/back/staff/edit";
	}
	/**
	 * 修改操作
	 * @param response
	 * @param staff
	 * @param bindingResult
	 */
	@RequestMapping("/staff.doEdit.action")
	public void doEdit(HttpServletResponse response,@Validated({ ValidateSysStaffUpdateAction.class }) SysStaff staff,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		SysStaff localStaff =  staffService.getStaffById(staff.getId());
		localStaff.setNickname(staff.getNickname());
		localStaff.setJobNumber(staff.getJobNumber());
		localStaff.setPhone(staff.getPhone());
		localStaff.setRoleId(staff.getRoleId());
		localStaff.setOrganizeId(staff.getOrganizeId());
        if( staffService.update(localStaff))
        {
        	try
			{
				jedisClientSingle.del("staff.list");
				jedisClientSingle.del("organize.staffList");
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
    	    AjaxUtil.write("succ",response);
        }
        else
        {
    	    AjaxUtil.write("未知错误",response);
        }
		
	}
	/**
	 * 删除操作
	 * @param id
	 */
	@RequestMapping("/staff.delete.action")
	public void delete(HttpServletResponse response,String ids)
	{
		if(staffService.deleteByRoleIds(ids))
		{
			try
			{
				jedisClientSingle.del("staff.list");
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("fail",response);
		}
	}
	/**
	 * 修改密码页面
	 * @return
	 */
	@RequestMapping("/staff.prePwd.action")
	public String prePwd()
	{
		return "/back/staff/pwd";
	}
	/**
	 * 修改密码操作
	 * @param response
	 * @param oldPwd
	 * @param newPwd
	 * @param rePwd
	 */
	@RequestMapping("/staff.doPwd.action")
	public void doPwd(HttpServletResponse response,String oldPwd,String newPwd,String rePwd)
	{
		String flag = "fail";
		SysStaff staff = (SysStaff) Session.get("staff");
		
		if(staff.getPwd().equals(PasswordUtil.encrypt(oldPwd, PasswordUtilType.BACK)))
		{
			if(newPwd.equals(rePwd)&&newPwd.length()>=6&&newPwd.length()<=12)
			{
				staff.setPwd(PasswordUtil.encrypt(newPwd, PasswordUtilType.BACK));
				staffService.update(staff);
				Session.set("staff", staff);
				flag = "succ";
			}
			else
			{
				flag = "newPwd";
			}
		}
		else
		{
			flag = "oldPwd";
		}
		AjaxUtil.write(flag,response);
	}
	/**
	 * 重置密码页面
	 * @return
	 */
	@RequestMapping("/staff.preResetPwd.action")
	public String preResetPwd(String id)
	{
		Request.set("id", id);
		return "/back/staff/resetPwd";
	}
	/**
	 * 修改密码操作
	 * @param response
	 * @param oldPwd
	 * @param newPwd
	 * @param rePwd
	 */
	@RequestMapping("/staff.doResetPwd.action")
	public void doResetPwd(HttpServletResponse response,String id,String newPwd,String rePwd)
	{
		String flag = "未知错误";
		if(StringUtil.isEmpty(id)||StringUtil.isEmpty(newPwd)||StringUtil.isEmpty(rePwd))
		{
			AjaxUtil.write(flag,response);
			return;
		}
		SysStaff staff = staffService.getStaffById(id);
		if(newPwd.equals(rePwd)&&newPwd.length()>=6&&newPwd.length()<=12)
		{
			staff.setPwd(PasswordUtil.encrypt(newPwd, PasswordUtilType.BACK));
			staffService.update(staff);
			Session.set("staff", staff);
			flag = "succ";
		}
		else
		{
			flag = "请输入有效的密码";
		}
		AjaxUtil.write(flag,response);
	}
	
}

