package com.gmadong.modules.systemMsg;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.gmadong.common.utils.StringUtil;


public class SystemMsg {
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebSystemMsgEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebSystemMsgEditAction.class} )
    private String id;

    private String userId;
    
    /**信息标题*/
    @NotBlank(message="信息标题不能为空!" ,groups = {ValidatebSystemMsgAddAction.class,ValidatebSystemMsgEditAction.class})
    @Size (min=1,max=200,message="请输入正确的信息标题!" ,groups = {ValidatebSystemMsgAddAction.class,ValidatebSystemMsgEditAction.class})
    private String msg;

    private String url;

    /** 状态 默认0所有用户 1单独客户 */
    private String state;

    /** 消息类型 1系统消息 2通知消息 */
    private String type;

    private String ctime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
    	if(StringUtil.isNotEmpty(userId))
    	{
    		state="1";
    	}else {
    		state="0";
		}
        this.userId = userId == null ? null : userId.trim();
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg == null ? null : msg.trim();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    /**
     * 状态 默认0所有用户 1单独客户
     * @return state
     */
    public String getState() {
        return state;
    }

    /**
     * 状态 默认0所有用户 1单独客户
     * @param state
     */
    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    /**
     * 消息类型 1系统消息 2通知消息
     * @return type
     */
    public String getType() {
        return type;
    }

    /**
     * 消息类型 1系统消息 2通知消息
     * @param type
     */
    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }
}