package com.gmadong.modules.application;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.application.ApplicationExample.Criteria;
import com.gmadong.modules.billinginfo.BillinginfoExample;

@Service("applicationService")
public class ApplicationServiceImpl implements ApplicationService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private ApplicationMapper applicationMapper;
	
	@Override
	public Page page(String enterpriseName, String representative, String code, String phone,
			String state,String showType,String ctime,Integer page, Integer rows)
	{
		ApplicationExample applicationExample = new ApplicationExample();
		Criteria createCriteria = applicationExample.createCriteria();
		 
		if (!StringUtil.isEmpty(enterpriseName)) {
			createCriteria.andEnterpriseNameLike(enterpriseName + "%");
		}
		if (!StringUtil.isEmpty(representative)) {
			createCriteria.andRepresentativeLike(representative + "%");
		}
		if (!StringUtil.isEmpty(code)) {
			createCriteria.andCodeLike(code + "%");
		}
		if (!StringUtil.isEmpty(phone)) {
			createCriteria.andPhoneLike(phone + "%");
		}
		if (!StringUtil.isEmpty(state)){
			createCriteria.andStateLike(state + "%");
		}
		if (!StringUtil.isEmpty(showType)){
			createCriteria.andShowTypeLike(showType + "%");
		}
		if (!StringUtil.isEmpty(ctime)) {
			createCriteria.andCtimeLike(ctime + "%");
		}
		applicationExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<Application> list = applicationMapper.selectByExample(applicationExample);
		PageInfo<Application> pageInfo = new PageInfo<Application>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean save(Application application)
	{
		application.setId(UUIDUtil.getUUID());
		application.setCtime(DateUtil.getCurrentDate());
		boolean flag = applicationMapper.insert(application) > 0;
		return flag;
	}

	@Override
	public boolean update(Application application)
	{
		application.setCtime(null);
		return applicationMapper.updateByPrimaryKeySelective(application) > 0;
	}

	@Override
	public Application getApplicationById(String id)
	{
		return applicationMapper.selectByPrimaryKey(id);
	}

	@Override
	public boolean deleteById(String ids)
	{
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			ApplicationExample applicationExample = new ApplicationExample();
			Criteria createCriteria = applicationExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			return applicationMapper.deleteByExample(applicationExample) > 0;
		}
		return false;
	}
	
	
}
