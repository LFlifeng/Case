package com.gmadong.modules.columnCategory;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.XSSUtils;
import com.gmadong.modules.staff.ValidateSysStaffUpdateAction;
/**
 * 栏目功能
 * @author Administrator
 *
 */
@Controller
public class ColumnCategoryController
{	
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private ColumnCategoryService columnCategoryService;
	private String key = "columnCategory.list.action";

	@RequestMapping("/columnCategory.page.action")
	public String page() {
		return "/back/columnCategory/page";
	}

	@RequestMapping("/columnCategory.list.action")
	public void list(HttpServletResponse response, String columnName, String url, String ctime,
			@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows) {

		String field = columnName + "_" + url + "_" + ctime + "_" + page + "_" + rows;
		try {
			String list = jedisClientSingle.hget(key, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = columnCategoryService.page(columnName, url, ctime, page, rows);
		String list = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(key, field, list, Common.REDIS_48_HOUR_EXPIRE);

		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(Page.pageToJson(toPage), response);
	}
	@RequestMapping("/columnCategory.preAdd.action")
	public String preAdd() {

		List<ColumnCategory> parent = columnCategoryService.getParent();

		Request.set("list", parent);

		return "/back/columnCategory/add";
	}

	@RequestMapping("/columnCategory.doAdd.action")
	public void doAdd(HttpServletResponse response, String columnName, String url, String pId, String sortIndex) {

		if (StringUtil.isNotEmpty(columnName) && sortIndex.length() > 0 && sortIndex.length() < 3) {
			columnCategoryService.save(columnName, url, pId, sortIndex);
			try 
			{
				jedisClientSingle.del(key);
				jedisClientSingle.del(ColumnCategoryFrontController.key);
				
			} catch (Exception e) 
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("保存失败", response);
		}
	}

	/**
	 * 修改页面
	 * 
	 * @return
	 */
	@RequestMapping("/columnCategory.preEdit.action")
	public String preEdit(String id) {

		ColumnCategory columnCategoryById = columnCategoryService.getColumnCategoryById(id);
		if (columnCategoryById == null) {
			return "/common/500";
		}
		Request.set("columnCategoryById", columnCategoryById);
		List<ColumnCategory> parent = columnCategoryService.getParent();
		Request.set("parent", parent);
		return "/back/columnCategory/edit";
	}

	/**
	 * 修改操作
	 */
	@RequestMapping("/columnCategory.doEdit.action")
	public void doEdit(HttpServletResponse response,
			@Validated({ ValidateSysStaffUpdateAction.class }) ColumnCategory category, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(), response);
			return;
		}
		XSSUtils.clearXss(ColumnCategory.class, category);
		ColumnCategory columnCategoryById = columnCategoryService.getColumnCategoryById(category.getId());
		columnCategoryById.setColumnName(category.getColumnName());
		columnCategoryById.setUrl(category.getUrl());
		if (columnCategoryService.update(columnCategoryById)) 
		{
			try 
			{
				jedisClientSingle.del(key);
				jedisClientSingle.del(ColumnCategoryFrontController.key);

			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("未知错误", response);
		}

	}

	@RequestMapping("/columnCategory.doDelete.action")
	public void doEelete(HttpServletResponse response, String ids) {
		if (columnCategoryService.deleteById(ids)) {
			try {
				jedisClientSingle.del("columnCategory.list.action");

			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("fail", response);
		}
	}
}
