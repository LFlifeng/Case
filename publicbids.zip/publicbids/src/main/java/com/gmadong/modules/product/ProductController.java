package com.gmadong.modules.product;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.user.UserService;
/**
 * 产品管理
 * @author Administrator
 *
 */
@Controller
public class ProductController
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private ProductService productService;
	private String listkey = "product.list.action";
	@Autowired
	private UserService userService;
	
	/**
	 * 列表页面
	 * @return
	 */
	@RequestMapping("/product.page.action")
	public String page()
	{
		return "/back/product/page";
	}
	/**
	 * 页面条件搜索
	 * @return
	 */
	@RequestMapping("/product.list.action")
	public void list(HttpServletResponse response,String productName, String productDescribe, String ctime,@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows) 
	{
		String field = productName + "_" + productDescribe + "_" + ctime + "_" + page + "_" + rows;
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = productService.page(productName,productDescribe,ctime,page, rows);
		String list = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, list, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(Page.pageToJson(toPage), response);
	}
	/**
	 * 添加页面
	 * @return
	 */
	@RequestMapping("/product.preAdd.action")
	public String preAdd() 
	{
		return "/back/product/add";
	}
	/**
	 * 添加操作
	 * @return
	 */
	@RequestMapping("/product.doAdd.action")
	public void doAdd(HttpServletResponse response, @Validated({ ValidatebProductAddAction.class }) Product product,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		if(productService.save(product))
		{
			try {
				jedisClientSingle.del(listkey);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		}
		else {
			AjaxUtil.write("添加失败", response);
		}
	}
	/**
	 * 修改页面
	 * @return
	 */
	@RequestMapping("/product.preEdit.action")
	public String preEdit(String id) {
		Product productById = productService.getProductById(id);
		if (productById == null) {
			return "/common/500";
		}
		Request.set("info", productById);
		if(StringUtil.isNotEmpty(productById.getUserId()))
		{
			Request.set("nickname", userService.getPhoneById(productById.getUserId()));
		}
		else
		{
			Request.set("nickname", "");
		}
		return "/back/product/edit";
	}
	/**
	 * 修改操作
	 */
	@RequestMapping("/product.doEdit.action")
	public void doEdit(HttpServletResponse response,
			@Validated({ ValidatebProductEditAction.class })  Product product, BindingResult bindingResult) 
	{
		if (bindingResult.hasErrors()) 
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(), response);
			return;
		}
		if(productService.update(product))
		{
			try
			{
				jedisClientSingle.del(listkey);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("修改失败！",response);
		}
	}
	/**
	 * 删除
	 * @return
	 */
	@RequestMapping("/product.doDelete.action")
	public void doDelete(HttpServletResponse response, String ids) {
		if (productService.deleteById(ids)) {
			try {
				jedisClientSingle.del(listkey);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("fail", response);
		}
	}
}
