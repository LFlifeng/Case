package com.gmadong.modules.front;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MobileController
{

	/**
	 * 首页
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/m.index.do")
	public String index() throws Exception
	{
		 return "/mobile/common/index";
	}
	/**
	 * 订阅
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/m.subscribe.do")
	public String subscribe() throws Exception
	{
		 return "/mobile/subscribe/subscribe";
	}
	/**
	 *   服务大厅页面
	 */
	@RequestMapping("/m.serviceHall.do")
	public String serviceHallIndex() throws Exception
	{
		 return "/mobile/server/productService";
	}
	/**
	 * 用户中心
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/m.profile.do")
	public String profile() throws Exception
	{
		 return "/mobile/profile/profile";
	}
	
	/**
	 * 用户注册协议
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/m.agreement.do")
	public String agreement() throws Exception
	{
		 return "/mobile/common/agreement";
	}
	
	/**
	 * 筛选
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/m.search.do")
	public String search() throws Exception
	{
		 return "/mobile/search/search";
	}
	/**
	 * 热门推荐详情
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/m.detail.do")
	public String detail() throws Exception
	{
		 return "/mobile/detail/detail";
	}
	
	
	/**
	 * 关于我们
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/m.about.do")
	public String about() throws Exception
	{
		 return "/mobile/user/about";
	}
	/**
	 * 我的购买
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/m.buy.do")
	public String buy() throws Exception
	{
		 return "/mobile/user/buy";
	}
	/**
	 * 我的收藏
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/m.collection.do")
	public String collection() throws Exception
	{
		 return "/mobile/user/collection";
	}
	/**
	 * 帮助与反馈
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/m.help.do")
	public String help() throws Exception
	{
		 return "/mobile/user/help";
	}
	/**
	 * 客服中心
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/m.service.do")
	public String service() throws Exception
	{
		 return "/mobile/user/service";
	}
	/**
	 * 设置
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/m.set.do")
	public String set() throws Exception
	{
		 return "/mobile/user/set";
	}
	
}















