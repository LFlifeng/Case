package com.gmadong.modules.back;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gmadong.common.Common;
import com.gmadong.common.MenuConfig;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.PasswordUtil;
import com.gmadong.common.utils.PasswordUtil.PasswordUtilType;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.log.StaffLogService;
import com.gmadong.modules.role.SysRoleService;
import com.gmadong.modules.staff.SysStaff;
import com.gmadong.modules.staff.SysStaffService;
import com.gmadong.modules.staff.ValidateSysStaffLoginAction;
/**
 * 后台首页
 * @ClassName: BackController
 * @Description: 
 * @author caodong
 * @date 2016年9月8日 上午11:14:21
 *
 */
@Controller
public class BackController 
{
	@Resource(name = "staffService")
	private SysStaffService staffService;
	@Resource(name = "staffLogService")
	private StaffLogService staffLogService;
	@Resource(name = "sysRoleService")
	private SysRoleService roleService;
	@Autowired
	private JedisClientSingle jedisClientSingle;
	
	/**
	 * 回到登录页面
	 */
	@RequestMapping("/back.login.action")
	public String login() throws Exception
	{
		return "/back/common/login";
	}
	/**
	 * 登录成功后首页
	 */
	@RequestMapping("/back.index.action")
	public String index() throws Exception
	{
		 return "/back/common/index";
	}
	/**
	 * 选项卡首页
	 */
	@RequestMapping("/back.main.action")
	public String main() throws Exception
	{
		return "/back/common/main";
	}
	/**
	 * 退出
	 */
	@RequestMapping("/back.logout.action")
	public String logout(HttpServletRequest request)
	{
		String staffId = Session.getString("staffId");
		if(staffId != null)
		{
			Session.set("staff", null);
			Session.set("staffId", null);
			Session.set("loginName", null);
			Session.set("staffName", null);
			Session.set("userActionString", null);
			Session.set("menuJson", null);
			request.getSession().invalidate();
		}
		return "redirect:/back.index.action";
	}
	/**
	 * 显示提示消息
	 */
	@RequestMapping("/back.message.action")
	public String message(HttpServletResponse response,String message) throws Exception
	{
		String param = new String(message.getBytes("ISO8859-1"), "UTF-8");
		Request.set("message", param);
		return "/back/common/message";
	}
	/***
	 * 登录操作
	 */
	@RequestMapping("/back.check.action")
	public void check(HttpServletRequest request,HttpServletResponse response,@Validated({ ValidateSysStaffLoginAction.class }) SysStaff staff,BindingResult bindingResult) throws Exception
	{
		boolean isExist = false;
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		String key = "staff-"+staff.getLoginname();
		SysStaff  realstaff = null;
		try
		{
			String list = jedisClientSingle.get(key);
			if(StringUtil.isNotEmpty(list))
			{
				ObjectMapper mapper = new ObjectMapper();
				realstaff = mapper.readValue(list, SysStaff.class);
				isExist = true;
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		if(realstaff == null)
		{
			realstaff = staffService.getStaffByLoginName(staff.getLoginname());
		}
		if(realstaff != null&&realstaff.getPwd().equals(PasswordUtil.encrypt(staff.getPwd(), PasswordUtilType.BACK)))
		{
			try
			{
				if(!isExist)
				{
					jedisClientSingle.set(key, JsonUtil.bean2json(realstaff), Common.REDIS_48_HOUR_EXPIRE);
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			request.getSession().invalidate();
			request.getSession(true);
			String actions = "";
			actions = roleService.getActionByRoleIds(realstaff.getRoleId());
			Session.set("staff", realstaff);
			Session.set("staffId", realstaff.getId());
			Session.set("staffName", realstaff.getNickname());
			Session.set("userActionString", actions);
			// 菜单
			String menuJson = "[";
			String allMenuString = MenuConfig.getAllMenuString();
			Pattern pattern = Pattern.compile("\\{name:\"([^{]*?)\",parent:\"([^{]*?)\",url:\"(.*?)\",authority:\"([a-zA-Z,\\.]*)\"\\}");
			Matcher matcher = pattern.matcher(allMenuString);
			String name = "";
			String parent = "";
			String url = "";
			String authority = "";
			while(matcher.find())
			{
				name = matcher.group(1);
				parent = matcher.group(2);
				url = matcher.group(3);
				authority = matcher.group(4);
				boolean hasRight = false;
				if(actions.equals("all"))
				{
					hasRight = true;
					
				}else
				{
					String[] authorityArray = authority.split(",");
					for(int i=0; i<authorityArray.length; i++)
					{
						if(actions.contains(authorityArray[i]))
						{
							hasRight = true;
							break;
						}
					}
				}
				if(hasRight){
					menuJson += "{id:\""+name+"\",name:\""+name+"\",pId:\""+parent+"\",menuUrl:\""+url+"\",isParent:\""+(url.equals("#") ? true : false)+"\"},";
				}
			}
			if(menuJson.endsWith(","))
			{
				menuJson = menuJson.substring(0, menuJson.length()-1);
			}
			menuJson += "]";
			Session.set("menuJson", menuJson);
			staffLogService.log(realstaff.getId(),realstaff.getId(), realstaff.getNickname()+"—登入系统",JsonUtil.bean2json(realstaff));
			realstaff.setLtime(DateUtil.getCurrentDate());
			staffService.update(realstaff);
			AjaxUtil.write("success",response);
			return;
		}
		AjaxUtil.write("fail",response);
	}
	
	/**
	 * 错误页面
	 */
	/**
	 * 403
	 */
	@RequestMapping("/common.403.action")
	public String jump403() throws Exception
	{
		return "/common/403";
	}
	/**
	 * 404
	 */
	@RequestMapping("/common.404.action")
	public String jump404() throws Exception
	{
		return "/common/404";
	}
	/**
	 * 500
	 */
	@RequestMapping("/common.500.action")
	public String jump500() throws Exception
	{
		return "/common/500";
	}
	
}
