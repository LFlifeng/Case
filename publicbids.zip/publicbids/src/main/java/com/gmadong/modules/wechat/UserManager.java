package com.gmadong.modules.wechat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sf.json.JSONObject;

/**
 * 用户管理器
 * 
 * @author Administrator
 *
 */
public class UserManager {

	private static Logger log = LoggerFactory.getLogger(UserManager.class);

	// 创建标签的接口
	public static final String TAGS_CREATE_URL = "https://api.weixin.qq.com/cgi-bin/tags/create?access_token=ACCESS_TOKEN";

	// 获取标签的接口
	public static final String TAGS_GET_URL = "https://api.weixin.qq.com/cgi-bin/tags/get?access_token=ACCESS_TOKEN";

	// 删除标签的接口
	public static final String TAGS_DELETE_URL = "https://api.weixin.qq.com/cgi-bin/tags/delete?access_token=ACCESS_TOKEN";

	// 批量为用户打标签
	public static final String BATCH_TAGGING_URL = "https://api.weixin.qq.com/cgi-bin/tags/members/batchtagging?access_token=ACCESS_TOKEN";

	// 获取用户列表
	public static final String USERLIST_GET_URL = "https://api.weixin.qq.com/cgi-bin/user/get?access_token=ACCESS_TOKEN&next_openid=NEXT_OPENID";

	// 根据标签群发消息
	public static final String SEND_ALL_URL = "https://api.weixin.qq.com/cgi-bin/message/mass/sendall?access_token=ACCESS_TOKEN";

	// 获取用户信息的接口
	public static final String GET_USERINFO_URL = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=ACCESS_TOKEN&openid=OPENID";

	/**
	 * 创建标签
	 * 
	 * @param tags
	 * @param accessToken
	 * @return
	 */
	public static int createTags(String name, String accessToken) {
		int result = 0;
		// 拼装创建菜单的url
		String url = TAGS_CREATE_URL.replace("ACCESS_TOKEN", accessToken);
		// 将标签对象转换成json字符串
		String jsonTags = "{   \"tag\" : {     \"name\" : \"" + name + "\"   } }";
		// 调用接口创建标签
		JSONObject jsonObject = WeChatUtil.httpRequest(url, "POST", jsonTags);

		if (null != jsonObject) {
			try {
				result = jsonObject.getInt("errcode");
				System.out.println("标签创建失败，错误码：" + result);
			} catch (Exception e) {
				System.out.println("标签创建成功");
			}

		}
		return result;
	}

	/**
	 * 获取标签
	 * 
	 * @param accessToken
	 * @return
	 */
	public static List<Tag> getTags(String accessToken) {
		int result = 0;
		List<Tag> list = null;
		Gson gson = new Gson();
		// 拼装获取标签的url
		String url = TAGS_GET_URL.replace("ACCESS_TOKEN", accessToken);

		// 调用接口获取标签
		JSONObject jsonObject = WeChatUtil.httpRequest(url, "GET", null);
		if (null != jsonObject) {
			try {
				result = jsonObject.getInt("errcode");
				System.out.println("标签创建失败，错误码：" + result);
			} catch (Exception e) {
				String s = jsonObject.toString();
				// 先转JsonObject
				JsonObject jsonObj = new JsonParser().parse(s).getAsJsonObject();
				// 再转JsonArray 加上数据头
				JsonArray jsonArray = jsonObj.getAsJsonArray("tags");
				list = new ArrayList<Tag>();
				for (JsonElement tags : jsonArray) {
					Tag tag = gson.fromJson(tags, Tag.class);
					list.add(tag);
				}
				System.out.println("标签获取成功");
			}

		}
		return list;
	}

	/**
	 * 删除标签
	 * 
	 * @param accessToken
	 * @param id
	 * @return
	 */
	public static int deleteTags(String accessToken, int id) {
		int result = 0;
		// 拼装删除标签的url
		String url = TAGS_DELETE_URL.replace("ACCESS_TOKEN", accessToken);
		String jsonTag = "{   \"tag\":{        \"id\" : " + id + "   } }";
		// 调用接口删除标签
		JSONObject jsonObject = WeChatUtil.httpRequest(url, "POST", jsonTag);
		if (null != jsonObject) {
			result = jsonObject.getInt("errcode");
			if (0 != result) {
				System.out.println("删除标签失败，错误码：" + result);
			} else {
				System.out.println("删除成功");
			}
		}
		return result;
	}

	/**
	 * 批量为用户设置标签
	 * 
	 * @param accessToken
	 * @param tagId       标签id
	 * @param openIdList  openId列表
	 * @return
	 */
	public static int batchTagging(String accessToken, int tagId, List<String> openIdList) {
		int result = 0;
		Gson gson = new Gson();
		// 拼装设置标签的url
		String url = BATCH_TAGGING_URL.replace("ACCESS_TOKEN", accessToken);

		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("openid_list", openIdList);
		filterParams.put("tagid", tagId);
		String data = gson.toJson(filterParams);

		// 调用接口删除标签
		JSONObject jsonObject = WeChatUtil.httpRequest(url, "POST", data);
		if (null != jsonObject) {
			result = jsonObject.getInt("errcode");
			if (0 != result) {
				System.out.println("设置标签失败，错误码：" + result);
			} else {
				System.out.println("设置标签成功");
			}
		}
		return result;
	}

	/**
	 * 获取用户列表
	 * 
	 * @param accessToken
	 * @return
	 */
	public static List<String> getUserList(String accessToken) {
		List<String> openIdList = new ArrayList<String>();
		int result = 0;
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		// 拼装查询用户列表的url
		String url = USERLIST_GET_URL.replace("ACCESS_TOKEN", accessToken).replace("NEXT_OPENID", "");
		// 调用接口删除标签
		JSONObject jsonObject = WeChatUtil.httpRequest(url, "GET", "");
		if (null != jsonObject) {
			try {
				result = jsonObject.getInt("errcode");
				System.out.println("获取列表失败，错误码：" + result);
			} catch (Exception e) {
				String s = jsonObject.toString();
				System.out.println(s);
				WeChatUserList weChatUserList = gson.fromJson(s, WeChatUserList.class);
				Data data = weChatUserList.getData();
				openIdList = data.getOpenid();

				System.out.println("获取列表成功");
			}
		}
		return openIdList;
	}

	/**
	 * 根据标签群发文本消息
	 * 
	 * @param accessToken
	 * @param tagId
	 * @param content
	 * @return
	 */
	public static MassMsgResult sendTextToTag(String accessToken, int tagId, String content) {
		MassMsgResult result = null;
		int errorCode = 0;

		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		// 拼装根据标签群发的url
		String url = SEND_ALL_URL.replace("ACCESS_TOKEN", accessToken);

		TreeMap<String, String> params = new TreeMap<>();
		// post 提交的参数
		Map<String, Object> filterParams = new HashMap<>();
		filterParams.put("is_to_all", false);
		filterParams.put("tag_id", tagId);
		Map<String, Object> textParams = new HashMap<>();
		textParams.put("content", content);
		TreeMap<String, Object> dataParams = new TreeMap<>();
		dataParams.put("filter", filterParams);
		dataParams.put("text", textParams);
		dataParams.put("msgtype", "text");
		String data = gson.toJson(dataParams);

		JSONObject jsonObject = WeChatUtil.httpRequest(url, "POST", data);
		if (null != jsonObject) {
			errorCode = jsonObject.getInt("errcode");
			if (0 != errorCode) {
				System.out.println("群发消息失败，错误码为：" + errorCode);
			} else {
				System.out.println("群发消息成功");
			}
			try {
				result = (MassMsgResult) JSONObject.toBean(jsonObject, MassMsgResult.class);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	/**
	 * 获取用户信息
	 * 
	 * @param accessToken 接口访问凭证
	 * @param openId      用户标识
	 * @return weChatUser
	 */
	public static WeChatUser getUserInfo(String accessToken, String openId) {
		WeChatUser weChatUser = null;
		String url = GET_USERINFO_URL.replace("ACCESS_TOKEN", accessToken).replace("OPENID", openId);
		// 获取用户信息
		JSONObject jsonObject = WeChatUtil.httpRequest(url, "GET", null);

		if (null != jsonObject) {
			try {
				weChatUser = new WeChatUser();
				// 用户的标识
				weChatUser.setOpenId(jsonObject.getString("openid"));
				// 关注状态（1是关注，0是未关注），未关注时获取不到其余信息
				weChatUser.setSubscribe(jsonObject.getInt("subscribe"));
				// 用户关注时间
				weChatUser.setSubscribeTime(jsonObject.getString("subscribe_time"));
				// 昵称
				weChatUser.setNickname(jsonObject.getString("nickname"));
				// 用户的性别（1是男性，2是女性，0是未知）
				weChatUser.setSex(jsonObject.getInt("sex"));
				// 用户所在国家
				weChatUser.setCountry(jsonObject.getString("country"));
				// 用户所在省份
				weChatUser.setProvince(jsonObject.getString("province"));
				// 用户所在城市
				weChatUser.setCity(jsonObject.getString("city"));
				// 用户的语言，简体中文为zh_CN
				weChatUser.setLanguage(jsonObject.getString("language"));
				// 用户头像
				weChatUser.setHeadImgUrl(jsonObject.getString("headimgurl"));
			} catch (Exception e) {
				if (0 == weChatUser.getSubscribe()) {
					log.error("用户{}已取消关注", weChatUser.getOpenId());
				} else {
					int errorCode = jsonObject.getInt("errcode");
					String errorMsg = jsonObject.getString("errmsg");
					log.error("获取用户信息失败 errcode:{} errmsg:{}", errorCode, errorMsg);
				}
			}
		}
		return weChatUser;
	}

	public static void main(String[] args) {

		// 获取accesstoken
		AccessToken accessToken = WeChatUtil.getAccessToken();
		// 获取用户列表

		/*
		 * List<String> userList = getUserList(accessToken.getAccess_token());
		 * System.out.println(userList.toString());
		 */

		// 获取标签
		 List<Tag> list= getTags(accessToken.getAccess_token());
		 for(Tag t:list) {
			 System.out.println(t.toString());
		 }
		// deleteTags(accessToken.getAccess_token(), 101);
		// 群发消息
		/* sendTextToTag(accessToken.getAccess_token(), 2, "测试群发"); */

		// 给用户批量设置标签
		/*
		 * List<String> openIdList = new ArrayList<String>();
		 * openIdList.add("oQ2Sx55il7rTVLamPJQ1PbzB1vrM");
		 * openIdList.add("oQ2Sx50Cvb2Pglnh8nj9tb70R5Jg");
		 * batchTagging(accessToken.getAccess_token(),2,openIdList);
		 */

	}

}
