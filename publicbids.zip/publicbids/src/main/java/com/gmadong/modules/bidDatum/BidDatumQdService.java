package com.gmadong.modules.bidDatum;

import java.util.List;

import com.gmadong.common.Page;

public interface BidDatumQdService
{

	BidDatum details(String id);

	Page page(Integer page, Integer rows);

	List<BidDatum> fidnbidDatumList();
	

}
