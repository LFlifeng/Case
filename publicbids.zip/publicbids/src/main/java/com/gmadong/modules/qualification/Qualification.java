package com.gmadong.modules.qualification;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.gmadong.common.utils.FileUtil;
import com.gmadong.common.utils.StringUtil;


public class Qualification {
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebQualificationEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebQualificationEditAction.class} )
    private String id;

    private String userId;

    /** 企业资质名称 */
    @NotBlank(message="企业资质名称不能为空!" ,groups = {ValidatebQualificationAddAction.class,ValidatebQualificationEditAction.class})
    @Size (min=1,max=200,message="请输入正确的企业资质名称!" ,groups = {ValidatebQualificationAddAction.class,ValidatebQualificationEditAction.class})
    private String aptitudeName;

    /** 图片 */
    @NotBlank(message="图片不能为空!" ,groups = {ValidatebQualificationAddAction.class,ValidatebQualificationEditAction.class})
    @Size (min=0,max=32,message="请上传正确的图片!" ,groups = {ValidatebQualificationAddAction.class,ValidatebQualificationEditAction.class})
    private String picture;

    private String ctime;
    
    //后加的属性
    private String pictureUrl;
    
    public String getPictureUrl()
	{
		return pictureUrl;
	}

	public void setPictureUrl(String pictureUrl)
	{
		this.pictureUrl = pictureUrl;
	}

	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    /**
     * 企业资质名称
     * @return aptitudeName
     */
    public String getAptitudeName() {
        return aptitudeName;
    }

    /**
     * 企业资质名称
     * @param aptitudeName
     */
    public void setAptitudeName(String aptitudeName) {
        this.aptitudeName = aptitudeName == null ? null : aptitudeName.trim();
    }

    /**
     * 图片
     * @return picture
     */
    public String getPicture() {
        return picture;
    }

    /**
     * 图片
     * @param picture
     */
    public void setPicture(String picture) {
    	if(StringUtil.isNotEmpty(picture))
    	{
    		this.pictureUrl = "/upload/attach"+FileUtil.getPath(picture)+picture +".png";
    	}
        this.picture = picture == null ? null : picture.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }
}