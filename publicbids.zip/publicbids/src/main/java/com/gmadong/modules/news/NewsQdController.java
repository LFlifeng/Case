package com.gmadong.modules.news;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.bids.Bids;
import com.gmadong.modules.bids.BidsService;

import net.sf.json.JSONObject;
import sun.swing.StringUIClientPropertyKey;

/**
 * 首页行业资讯控制层
 * 
 * @author Administrator
 *
 */
@Controller
public class NewsQdController {
	@Resource(name = "newsQdService")
	private NewsQdService newsQdService;

	@Autowired
	private JedisClientSingle jedisClientSingle;

	/**
	 * 新闻资讯列表跳转
	 * 
	 * @return
	 */
	@RequestMapping("/news.listIndex.do")
	public String page() {
		return "/front/news/news";
	}

	/**
	 * 行业资讯列表查询
	 * 
	 * @param response
	 * @param page
	 * @param rows
	 */
	@RequestMapping("/news.list.do")
	public void list(HttpServletResponse response, String category, String title,
			@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows) {
		if (StringUtil.isEmpty(category)) {
			category = null;
		}
		if (StringUtil.isEmpty(title)) {
			title = null;
		}
		String key = "news.list_" + category + "_" + title;
		String field = page + "-" + rows + "-" + title;
		try {
			String list = jedisClientSingle.hget(key, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = newsQdService.page(page, rows, category, title);
		String listStr = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(key, field, listStr, Common.REDIS_6_HOUR_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
	}

	/**
	 * 新闻资讯详情查询
	 * 
	 * @param response
	 * @param id       新闻id
	 */
	@RequestMapping("/news.details.do")
	public String details(HttpServletResponse response, String id) {
		News news = null;
		String key = "news.details-" + id;
		try {

			String detail = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(detail)) {
				JSONObject jsonObject = JSONObject.fromObject(detail);
				news = (News) JSONObject.toBean(jsonObject, News.class);
				Request.set("detail", news);
				return "/front/news/detail";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		news = newsQdService.details(id);
		String detail = JsonUtil.bean2json(news);
		try {
			jedisClientSingle.set(key, detail, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Request.set("detail", news);
		return "/front/news/detail";
	}

	/**
	 * 首页新闻资讯模块查询
	 * 
	 * @param response
	 */
	@RequestMapping("/news.findByCategory.do")
	public void findByCategory(HttpServletResponse response, String category) {
		String key = "news.findByCategory.list-" + category;
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		List<News> list = newsQdService.findByCategory(category);
		String listStr = JsonUtil.listToJson(list);
		try {
			jedisClientSingle.set(key, listStr, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
		return;
	}

	/**
	 * 首页实时新闻查询
	 * 
	 * @param response
	 */
	@RequestMapping("/news.todayNews.do")
	public void todayBids(HttpServletResponse response) {

		String key = "news.todayNews";
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		List<News> list = newsQdService.findTodayNews();
		String listStr = JsonUtil.listToJson(list);
		try {
			jedisClientSingle.set(key, listStr, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}

		AjaxUtil.write(listStr, response);
		return;
	}

	
	/**
	 * 首页热门新闻查询
	 * 
	 * @param response
	 */
	@RequestMapping("/news.hotNews.do")
	public void findHotNews(HttpServletResponse response) {

		String key = "news.hotNews";
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		List<News> list = newsQdService.findHotNews();
		String listStr = JsonUtil.listToJson(list);
		try {
			jedisClientSingle.set(key, listStr, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}

		AjaxUtil.write(listStr, response);
		return;
	}
}
