package com.gmadong.modules.bidsCategory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;

@Controller
public class BidsCategoryQdController {
	@Autowired
	BidsCategoryService bidsCategoryService;
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	public static final String key = "BidsCategoryQd.list.do";
	/**
	 * 获取分类数据
	 * @return list
	 */
	@ResponseBody
	@RequestMapping("/bidsCategoryQd.list.do")
	public void querylist(HttpServletResponse response) 
	{
		try 
		{
			String list = jedisClientSingle.get(key);
			if(StringUtil.isNotEmpty(list))
			{
				AjaxUtil.write(list,response);
				return;
			}

		} catch (Exception e) 
		{
			e.printStackTrace();
		}
		List<BidsCategoryQd> li=bidsCategoryService.querylist();
		String list = JsonUtil.listToJson(li);
		try
		{
			jedisClientSingle.set(key, list);

		}catch (Exception e) 
		{
			e.printStackTrace();
		}
		AjaxUtil.write(list,response);
	}
	@RequestMapping("/industry.detail.do")
    public String industry(String url){
		return "/front/industry/industry";
    }
}
