package com.gmadong.modules.staff;

public class SysStaffApp
{
	 /** ID */
    private String id;

    /** 登录名 */
    private String loginname;

    /** 工号 */
    private String jobNumber;

    /** 电话号 */
    private String phone;

    /** 昵称 */
    private String nickname;

    /** 密码 */
    private String pwd;
    
    /** 最后登录时间 */
    private String ltime;
    /**
     * 部门
     */
    private String organizeId;
    
	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getLoginname()
	{
		return loginname;
	}

	public void setLoginname(String loginname)
	{
		this.loginname = loginname;
	}

	public String getJobNumber()
	{
		return jobNumber;
	}

	public void setJobNumber(String jobNumber)
	{
		this.jobNumber = jobNumber;
	}

	public String getPhone()
	{
		return phone;
	}

	public void setPhone(String phone)
	{
		this.phone = phone;
	}

	public String getNickname()
	{
		return nickname;
	}

	public void setNickname(String nickname)
	{
		this.nickname = nickname;
	}

	public String getPwd()
	{
		return pwd;
	}

	public void setPwd(String pwd)
	{
		this.pwd = pwd;
	}

	public String getLtime()
	{
		return ltime;
	}

	public void setLtime(String ltime)
	{
		this.ltime = ltime;
	}

	public String getOrganizeId()
	{
		return organizeId;
	}

	public void setOrganizeId(String organizeId)
	{
		this.organizeId = organizeId;
	}
    
}
