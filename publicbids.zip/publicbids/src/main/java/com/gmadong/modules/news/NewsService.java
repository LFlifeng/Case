package com.gmadong.modules.news;

import java.util.List;

import com.gmadong.common.Page;
import com.gmadong.modules.category.Category;


public interface NewsService {
	public Page page(String category,String title,String ctime,Integer page,Integer rows);
	public List<News> getParent();
	public boolean deleteById(String ids);
	public boolean save(News news);
	public boolean update(News news);
	public News getNewsById(String id);
}
