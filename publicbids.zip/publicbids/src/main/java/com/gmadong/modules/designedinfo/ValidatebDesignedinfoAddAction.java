package com.gmadong.modules.designedinfo;

public interface ValidatebDesignedinfoAddAction
{

}
