package com.gmadong.modules.biddinginfo;

import com.gmadong.common.Page;

public interface BiddinginfoService
{
	public Page page(String projectName,String issuer,String issuerPhone,String projectType,String state,String ctime,Integer page,Integer rows);
	public boolean save(Biddinginfo biddinginfo);
	public boolean update(Biddinginfo biddinginfo);
	public Biddinginfo getBiddinginfoById(String id);
	public boolean deleteById(String ids);
	public String getprojectNameById(String id);
	/**
	 * 根据登录名查找用户信息
	 * @param loginName 登录名
	 * @return
	 */
	public Biddinginfo getBiddinginfoprojectName(String projectName);
}
