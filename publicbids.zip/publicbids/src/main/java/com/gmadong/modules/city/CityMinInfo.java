package com.gmadong.modules.city;

public class CityMinInfo
{
	private Integer id;
	private String regionName;
	
	public String getRegionName()
	{
		return regionName;
	}
	public void setRegionName(String regionName)
	{
		this.regionName = regionName;
	}
	public Integer getId()
	{
		return id;
	}
	public void setId(Integer id)
	{
		this.id = id;
	}
	public CityMinInfo(Integer id, String regionName)
	{
		super();
		this.id = id;
		this.regionName = regionName;
	}
	public CityMinInfo()
	{
		super();
	}
	 
}
