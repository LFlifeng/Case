package com.gmadong.modules.tracker;

import com.gmadong.common.Page;


public interface TrackerService
{
	public Page page(String trackerName,String searchType,String ctime,Integer page,Integer rows);
	public boolean save(Tracker tracker);
	public boolean update(Tracker tracker);
	public Tracker getTrackerById(String id);
	public boolean deleteById(String ids);
}
