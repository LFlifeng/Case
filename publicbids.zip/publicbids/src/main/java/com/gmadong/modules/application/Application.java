package com.gmadong.modules.application;


import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.gmadong.common.utils.FileUtil;
import com.gmadong.common.utils.StringUtil;



public class Application {
	/**申请入驻id*/
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationEditAction.class} )
    private String id;

    private String userId;

    /** 企业名称 */
    @NotBlank(message="企业名称不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
    @Size (min=1,max=50,message="请输入正确的企业名称!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String enterpriseName;

    /** 法定代表人 */
    @NotBlank(message="法定代表人不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
    @Size (min=1,max=50,message="请输入正确的法定代表人!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String representative;

    /** 统一信用代码 */
    @NotBlank(message="统一信用代码不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
    @Size (min=15,max=18,message="请输入正确的统一信用代码!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String code;

    /** 法人身份证号 */
    @NotBlank(message="法人身份证号不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
	@Size (min=15,max=18,message="请输入正确的法人身份证号!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String identity;

    /** 所在省 */
    @NotBlank(message="所在省不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
	@Size (min=1,max=20,message="请输入正确的所在省!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String province;

    /** 所在市 */
	@NotBlank(message="所在市不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
	@Size (min=1,max=20,message="请输入正确的所在市!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String city;

    private String county;

    /** 行业一级 */
	@NotBlank(message="行业一级不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
    @Size (min=1,max=50,message="请输入正确的行业一级!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String industryOne;

    /** 行业二级 */
	@NotBlank(message="行业二级不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
    @Size (min=1,max=50,message="请输入正确的行业二级!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String industryTwo;

    /** 行业三级 */
	@NotBlank(message="行业三级不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
    @Size (min=1,max=50,message="请输入正确的行业三级!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String industryThree;

    /** 上传营业执照 */
	@NotBlank(message="上传营业执照不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
    @Size (min=0,max=32,message="请输入正确的上传营业执照!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String businessLicense;

    /** 公司类型 */
	@NotBlank(message="公司类型不能为空!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String companytype;

    /** 详情地址 */
	@NotBlank(message="详情地址不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
	@Size (min=1,max=50,message="请输入正确的详情地址!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String address;

    /** 邮政编码 */
	@NotBlank(message="邮政编码不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
	@Size (min=6,max=6,message="请输入正确的邮政编码!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String postalCode;

    /** 联系人 */
	@NotBlank(message="联系人不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
    @Size (min=1,max=15,message="请输入正确的联系人!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String contacts;

    /** 手机号码 */
	@NotBlank(message="手机号码不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
	@Size (min=11,max=11,message="请输入正确的手机号码!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String phone;

    /** 注册资本 */
	@NotBlank(message="注册资本不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
    @Size (min=1,max=20,message="请输入正确的注册资本!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String registeredcapital;

    /** 注册时间 */
    private String registerctime;

    /** 公司网站 */
    @NotBlank(message="公司网站不能为空!" ,groups = {ValidatebApplicationUpdateAction.class})
    @Size (min=0,max=100,message="请输入正确的公司网站!" ,groups = {ValidatebApplicationUpdateAction.class,ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String corporatewebsite;

    /** 审核状态 0 正常 1 审核通过 2审核未通过 3审核中 */
    @NotBlank(message="审核状态不能为空!" ,groups = {ValidatebApplicationAddAction.class,ValidatebApplicationEditAction.class})
    private String state;
    
    /** 公司简介 */
    private String introduction;

    /** 显示类型  0不显示  1中间显示  2右侧显示 */
    private String showType;
    
    private String ctime;
    
    //后加的属性
    private String businessLicenseUrl;
    
    public String getId() {
        return id;
    }

    public String getBusinessLicenseUrl()
	{
		return businessLicenseUrl;
	}

	public void setBusinessLicenseUrl(String businessLicenseUrl)
	{
		this.businessLicenseUrl = businessLicenseUrl;
	}

	public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    /**
     * 企业名称
     * @return enterpriseName
     */
    public String getEnterpriseName() {
        return enterpriseName;
    }

    /**
     * 企业名称
     * @param enterpriseName
     */
    public void setEnterpriseName(String enterpriseName) {
        this.enterpriseName = enterpriseName == null ? null : enterpriseName.trim();
    }

    /**
     * 法定代表人
     * @return representative
     */
    public String getRepresentative() {
        return representative;
    }

    /**
     * 法定代表人
     * @param representative
     */
    public void setRepresentative(String representative) {
        this.representative = representative == null ? null : representative.trim();
    }

    /**
     * 统一信用代码
     * @return code
     */
    public String getCode() {
        return code;
    }

    /**
     * 统一信用代码
     * @param code
     */
    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    /**
     * 法人身份证号
     * @return identity
     */
    public String getIdentity() {
        return identity;
    }

    /**
     * 法人身份证号
     * @param identity
     */
    public void setIdentity(String identity) {
        this.identity = identity == null ? null : identity.trim();
    }

    /**
     * 所在省
     * @return province
     */
    public String getProvince() {
        return province;
    }

    /**
     * 所在省
     * @param province
     */
    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    /**
     * 所在市
     * @return city
     */
    public String getCity() {
        return city;
    }

    /**
     * 所在市
     * @param city
     */
    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    /**
     * 所在县
     * @return county
     */
    public String getCounty() {
        return county;
    }

    /**
     * 所在县
     * @param county
     */
    public void setCounty(String county) {
        this.county = county == null ? null : county.trim();
    }

    /**
     * 行业一级
     * @return industryOne
     */
    public String getIndustryOne() {
        return industryOne;
    }

    /**
     * 行业一级
     * @param industryOne
     */
    public void setIndustryOne(String industryOne) {
        this.industryOne = industryOne == null ? null : industryOne.trim();
    }

    /**
     * 行业二级
     * @return industryTwo
     */
    public String getIndustryTwo() {
        return industryTwo;
    }

    /**
     * 行业二级
     * @param industryTwo
     */
    public void setIndustryTwo(String industryTwo) {
        this.industryTwo = industryTwo == null ? null : industryTwo.trim();
    }

    /**
     * 行业三级
     * @return industryThree
     */
    public String getIndustryThree() {
        return industryThree;
    }

    /**
     * 行业三级
     * @param industryThree
     */
    public void setIndustryThree(String industryThree) {
        this.industryThree = industryThree == null ? null : industryThree.trim();
    }

    /**
     * 上传营业执照
     * @return businessLicense
     */
    public String getBusinessLicense() {
        return businessLicense;
    }

    /**
     * 上传营业执照
     * @param businessLicense
     */
    public void setBusinessLicense(String businessLicense) {
    	if(StringUtil.isNotEmpty(businessLicense))
    	{
    		this.businessLicenseUrl = "/upload/attach"+FileUtil.getPath(businessLicense)+businessLicense +".png";
    	}
        this.businessLicense = businessLicense == null ? null : businessLicense.trim();
    }

    /**
     * 公司类型
     * @return companytype
     */
    public String getCompanytype() {
        return companytype;
    }

    /**
     * 公司类型
     * @param companytype
     */
    public void setCompanytype(String companytype) {
        this.companytype = companytype == null ? null : companytype.trim();
    }

    /**
     * 详情地址
     * @return address
     */
    public String getAddress() {
        return address;
    }

    /**
     * 详情地址
     * @param address
     */
    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    /**
     * 邮政编码
     * @return postalCode
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * 邮政编码
     * @param postalCode
     */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode == null ? null : postalCode.trim();
    }

    /**
     * 联系人
     * @return contacts
     */
    public String getContacts() {
        return contacts;
    }

    /**
     * 联系人
     * @param contacts
     */
    public void setContacts(String contacts) {
        this.contacts = contacts == null ? null : contacts.trim();
    }

    /**
     * 手机号码
     * @return phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * 手机号码
     * @param phone
     */
    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    /**
     * 注册资本
     * @return registeredcapital
     */
    public String getRegisteredcapital() {
        return registeredcapital;
    }

    /**
     * 注册资本
     * @param registeredcapital
     */
    public void setRegisteredcapital(String registeredcapital) {
        this.registeredcapital = registeredcapital == null ? null : registeredcapital.trim();
    }

    /**
     * 注册时间
     * @return registerctime
     */
    public String getRegisterctime() {
        return registerctime;
    }

    /**
     * 注册时间
     * @param registerctime
     */
    public void setRegisterctime(String registerctime) {
        this.registerctime = registerctime == null ? null : registerctime.trim();
    }

    /**
     * 公司网站
     * @return corporatewebsite
     */
    public String getCorporatewebsite() {
        return corporatewebsite;
    }

    /**
     * 公司网站
     * @param corporatewebsite
     */
    public void setCorporatewebsite(String corporatewebsite) {
        this.corporatewebsite = corporatewebsite == null ? null : corporatewebsite.trim();
    }

    /**
     * 审核状态 0 正常 1 审核通过 2审核未通过 3审核中
     * @return state
     */
    public String getState() {
        return state;
    }

    /**
     * 审核状态 0 正常 1 审核通过 2审核未通过 3审核中
     * @param state
     */
    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }

	public String getIntroduction()
	{
		return introduction;
	}

	public void setIntroduction(String introduction)
	{
		this.introduction = introduction;
	}

	public String getShowType()
	{
		return showType;
	}

	public void setShowType(String showType)
	{
		this.showType = showType;
	}
}