package com.gmadong.modules.attach;

public interface SysAttachService
{

	public void save(SysAttach attach);

	public SysAttach getRow(String id);

}
