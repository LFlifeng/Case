package com.gmadong.modules.city;

import java.util.List;

public interface SysCityService
{
	public List<CityMinInfo> selectProvince();
	public List<CityMinInfo> selectCityById(String id);
	
	public SysCity selectById(String id);
}
