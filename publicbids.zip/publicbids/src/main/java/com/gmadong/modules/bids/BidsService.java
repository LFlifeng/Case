package com.gmadong.modules.bids;

import java.util.Date;
import java.util.List;

import com.gmadong.common.Page;
import com.gmadong.modules.biddinginfo.Biddinginfo;
import com.gmadong.modules.city.CityMinInfo;

public interface BidsService {

	public Page page(String type, String title, String date, String province, String industry, Integer page,
			Integer rows);

	public BidsWithBLOBs details(Integer id);

	public List<Bids> findTodayBids();

	public List<Bids> findTypeBids(String type);

	public List<Bids> findBidsConsultation();

	public List<Bids> findFreeAndWinBids(String type);

	public List<Bids> findExclusiveBids();

	public List<Biddinginfo> findLatestRelease();

}
