package com.gmadong.modules.billinginfo;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.StringUtil;

import com.gmadong.modules.user.UserService;
/**
 * 发票管理
 * @author Administrator
 *
 */
@Controller
public class BillinginfoController
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private BillinginfoService billinginfoService;
	private String listkey = "billinginfo.list.action";
	@Autowired
	private UserService userService;
	
	/**
	 * 列表页面
	 * @return
	 */
	@RequestMapping("/billinginfo.page.action")
	public String page()
	{
		return "/back/billinginfo/page";
	}
	/**
	 * 页面条件搜索
	 * @return
	 */
	@RequestMapping("/billinginfo.list.action")
	public void list(HttpServletResponse response,String invoice,String accountName,String invoiceType,String ctime,@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows) 
	{
		String field = invoice + "_" + accountName + "_" +invoiceType + "_" + ctime + "_"  + "_" + page + "_" + rows;
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = billinginfoService.page(invoice,accountName,invoiceType, ctime,page, rows);
		String list = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, list, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(Page.pageToJson(toPage), response);
	}
	/**
	 * 添加页面
	 * @return
	 */
	@RequestMapping("/billinginfo.preAdd.action")
	public String preAdd() 
	{
		return "/back/billinginfo/add";
	}
	/**
	 * 添加操作
	 * @return
	 */
	@RequestMapping("/billinginfo.doAdd.action")
	public void doAdd(HttpServletResponse response, @Validated({ ValidatebBillinginfoAddAction.class }) Billinginfo billinginfo,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		if(billinginfoService.save(billinginfo))
		{
			try {
				jedisClientSingle.del(listkey);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		}
		else {
			AjaxUtil.write("添加失败", response);
		}
	}
	/**
	 * 修改页面
	 * @return
	 */
	@RequestMapping("/billinginfo.preEdit.action")
	public String preEdit(String id) {
		Billinginfo billinginfoById = billinginfoService.getBillinginfoById(id);
		if (billinginfoById == null) {
			return "/common/500";
		}
		
		Request.set("info", billinginfoById);
		if(StringUtil.isNotEmpty(billinginfoById.getUserId()))
		{
			Request.set("nickname", userService.getPhoneById(billinginfoById.getUserId()));
		}
		else
		{
			Request.set("nickname", "");
		}
		return "/back/billinginfo/edit";
	}
	/**
	 * 修改操作
	 */
	@RequestMapping("/billinginfo.doEdit.action")
	public void doEdit(HttpServletResponse response,
			@Validated({ ValidatebBillinginfoEditAction.class }) Billinginfo billinginfo, BindingResult bindingResult) 
	{
		if (bindingResult.hasErrors()) 
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(), response);
			return;
		}
		if(billinginfoService.update(billinginfo))
		{
			try
			{
				jedisClientSingle.del(listkey);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("修改失败！",response);
		}
	}
	/**
	 * 删除
	 * @return
	 */
	@RequestMapping("/billinginfo.doDelete.action")
	public void doDelete(HttpServletResponse response, String ids) {
		if (billinginfoService.deleteById(ids)) {
			try {
				jedisClientSingle.del(listkey);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("fail", response);
		}
	}
}
