package com.gmadong.modules.bidsCategory;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class BidsCategory 
{
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebBidCategoryEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebBidCategoryEditAction.class} )
    private String id;

    private String pId;

    /** 1 一级 2 二级 3 三级 4 */
    private String level;

    /** 栏目名 */
    @NotBlank(message="招标分类不能为空!" ,groups = {ValidatebBidCategoryAddAction.class,ValidatebBidCategoryEditAction.class})
    @Size (min=1,max=20,message="请输入正确的招标分类名!" ,groups = {ValidatebBidCategoryAddAction.class,ValidatebBidCategoryEditAction.class})
    private String bidsName;

    /** 排序序号 */
    @Min(value=0,message="排序序号必须大于等于0!" ,groups = {ValidatebBidCategoryAddAction.class,ValidatebBidCategoryEditAction.class})
    @Max(value=99,message="排序序号必须小于等于99!" ,groups = {ValidatebBidCategoryAddAction.class,ValidatebBidCategoryEditAction.class})
    private Integer sortIndex;

    /** 添加时间 */
    private String ctime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getpId() {
        return pId;
    }

    public void setpId(String pId) {
        this.pId = pId == null ? null : pId.trim();
    }

    /**
     * 1 一级 2 二级 3 三级 4
     * @return level
     */
    public String getLevel() {
        return level;
    }

    /**
     * 1 一级 2 二级 3 三级 4
     * @param level
     */
    public void setLevel(String level) {
        this.level = level == null ? null : level.trim();
    }

    /**
     * 栏目名
     * @return bidsName
     */
    public String getBidsName() {
        return bidsName;
    }

    /**
     * 栏目名
     * @param bidsName
     */
    public void setBidsName(String bidsName) {
        this.bidsName = bidsName == null ? null : bidsName.trim();
    }

    /**
     * 排序序号
     * @return sortIndex
     */
    public Integer getSortIndex() {
        return sortIndex;
    }

    /**
     * 排序序号
     * @param sortIndex
     */
    public void setSortIndex(Integer sortIndex) {
        this.sortIndex = sortIndex;
    }

    /**
     * 添加时间
     * @return ctime
     */
    public String getCtime() {
        return ctime;
    }

    /**
     * 添加时间
     * @param ctime
     */
    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }

	@Override
	public String toString() {
		return "BidsCategory [id=" + id + ", pId=" + pId + ", level=" + level + ", bidsName=" + bidsName
				+ ", sortIndex=" + sortIndex + ", ctime=" + ctime + "]";
	}
    
    
}