package com.gmadong.modules.tracker;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.tracker.TrackerExample.Criteria;

@Service("trackerFrontService")
public class TrackerFrontServiceImpl implements TrackerFrontService
{

	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private TrackerMapper trackerMapper;

	private String key = "trackerFront.editTracker.do";

	@Override
	public boolean save(Tracker tracker)
	{
		tracker.setId(UUIDUtil.getUUID());
		tracker.setCtime(DateUtil.getCurrentDate());
		
		return trackerMapper.insert(tracker) > 0;
	}

	@Override
	public Page page(String staffId, Integer page, Integer rows)
	{
		TrackerExample example = new TrackerExample();
		Criteria criteria = example.createCriteria();
		if(StringUtil.isEmpty(staffId) || staffId.length() != 32)
		{
			return Page.getEmptyPage();
		}
		else
		{
			criteria.andUserIdEqualTo(staffId);
		}
		example.setOrderByClause("ctime DESC");
		
		PageHelper.startPage(page, rows);
		List<Tracker> list = trackerMapper.selectByExample(example);
		PageInfo<Tracker> pageInfo = new PageInfo<Tracker>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean update(Tracker tracker)
	{
		tracker.setCtime(null);
		tracker.setUserId(null);
		
		return trackerMapper.updateByPrimaryKeySelective(tracker) > 0;
	}

	@Override
	public Tracker getTrackerById(String id)
	{
		
		String field  = id;
		try
		{
			String string = jedisClientSingle.hget(key, field);
			if(StringUtil.isNotEmpty(string))
			{
				ObjectMapper mapper = new ObjectMapper();
				Tracker tracker =  mapper.readValue(string, new TypeReference<Tracker>() {});
				return tracker;
			}
			
		}catch(Exception e)
		{}
		Tracker selectByPrimaryKey = trackerMapper.selectByPrimaryKey(id);
		try
		{
			String string = JsonUtil.bean2json(selectByPrimaryKey);
			jedisClientSingle.hset(key, field, string,Common.REDIS_30_MINUTE_EXPIRE);
			
		} catch (Exception e)
		{}
		
		return selectByPrimaryKey;
	}
}
