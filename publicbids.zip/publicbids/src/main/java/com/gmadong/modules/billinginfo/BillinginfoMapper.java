package com.gmadong.modules.billinginfo;

import com.gmadong.modules.billinginfo.Billinginfo;
import com.gmadong.modules.billinginfo.BillinginfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BillinginfoMapper {
    int countByExample(BillinginfoExample example);

    int deleteByExample(BillinginfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(Billinginfo record);

    int insertSelective(Billinginfo record);

    List<Billinginfo> selectByExample(BillinginfoExample example);

    Billinginfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") Billinginfo record, @Param("example") BillinginfoExample example);

    int updateByExample(@Param("record") Billinginfo record, @Param("example") BillinginfoExample example);

    int updateByPrimaryKeySelective(Billinginfo record);

    int updateByPrimaryKey(Billinginfo record);
	 /**
     * 根据user_id查询发票信息
     */
	Billinginfo selectInvoiceById(String id);
}