package com.gmadong.modules.designedinfo;

public interface ValidatebDesignedinfoEditAction
{

}
