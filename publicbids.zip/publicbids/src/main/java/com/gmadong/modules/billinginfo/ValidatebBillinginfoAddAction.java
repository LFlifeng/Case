package com.gmadong.modules.billinginfo;

public interface ValidatebBillinginfoAddAction
{

}
