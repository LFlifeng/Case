package com.gmadong.modules.columnCategory;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;



public class ColumnCategory {
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebColumnCategoryEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebColumnCategoryEditAction.class} )
    private String id;

    private String pId;

    /** 跳转的地址 */
    @Size (min=1,max=40,message="请输入正确的跳转的地址!" ,groups = {ValidatebColumnCategoryAddAction.class,ValidatebColumnCategoryEditAction.class})
    private String url;

    /** 栏目名 */
    @NotBlank(message="栏目名不能为空!" ,groups = {ValidatebColumnCategoryAddAction.class,ValidatebColumnCategoryEditAction.class})
    @Size (min=1,max=20,message="请输入正确的栏目名!" ,groups = {ValidatebColumnCategoryAddAction.class,ValidatebColumnCategoryEditAction.class})
    private String columnName;

    /** 排序序号 */
    @Min(value=0,message="排序序号必须大于等于0!" ,groups = {ValidatebColumnCategoryAddAction.class,ValidatebColumnCategoryEditAction.class})
    @Max(value=99,message="排序序号必须小于等于99!" ,groups = {ValidatebColumnCategoryAddAction.class,ValidatebColumnCategoryEditAction.class})
    private Integer sortIndex;

    /** 添加时间 */
    private String ctime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getpId() {
        return pId;
    }

    public void setpId(String pId) {
        this.pId = pId == null ? null : pId.trim();
    }

    /**
     * 跳转的地址
     * @return url
     */
    public String getUrl() {
        return url;
    }

    /**
     * 跳转的地址
     * @param url
     */
    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    /**
     * 栏目名
     * @return columnName
     */
    public String getColumnName() {
        return columnName;
    }

    /**
     * 栏目名
     * @param columnName
     */
    public void setColumnName(String columnName) {
        this.columnName = columnName == null ? null : columnName.trim();
    }

    /**
     * 排序序号
     * @return sortIndex
     */
    public Integer getSortIndex() {
        return sortIndex;
    }

    /**
     * 排序序号
     * @param sortIndex
     */
    public void setSortIndex(Integer sortIndex) {
        this.sortIndex = sortIndex;
    }

    /**
     * 添加时间
     * @return ctime
     */
    public String getCtime() {
        return ctime;
    }

    /**
     * 添加时间
     * @param ctime
     */
    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }

	public ColumnCategory(String url, String columnName,String pId)
	{
		super();
		this.url = url;
		this.columnName = columnName;
		this.pId = pId;
	}

	public ColumnCategory() {
		super();
	}
    
    
    
}