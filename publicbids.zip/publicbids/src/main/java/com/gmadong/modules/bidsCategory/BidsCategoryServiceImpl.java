package com.gmadong.modules.bidsCategory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.bidsCategory.BidsCategoryExample.Criteria;

@Service("bidsCategoryService")
public class BidsCategoryServiceImpl implements BidsCategoryService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private BidsCategoryMapper bidsCategoryMapper;
	
	private static final String parentCategorysKey = "BidsCategoryServiceImpl.ParentCategorys";

	@Override
	public List<BidsCategory> getParentCategorys() 
	{
		try
		{//从缓存中得到数据
			String list = jedisClientSingle.get(parentCategorysKey);
			if(StringUtil.isNotEmpty(list))
			{
				ObjectMapper mapper = new ObjectMapper();
				List<BidsCategory> keys = mapper.readValue(list, new TypeReference<List<BidsCategory>>() {});
				return keys;
			}
			
		}catch (Exception e) 
		{
			e.printStackTrace();
		}
		BidsCategoryExample example = new BidsCategoryExample();
		Criteria criteria = example.createCriteria();
		criteria.andLevelEqualTo("1");
		List<BidsCategory> list =  bidsCategoryMapper.selectByExample(example);
		try
		{//添加缓存 
			jedisClientSingle.set(parentCategorysKey, JsonUtil.listToJson(list));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}
	@Override
	public boolean save(BidsCategory category)
	{
		if(StringUtil.isEmpty(category.getpId()))
		{
			category.setLevel("1");
		}
		else
		{
			category.setLevel("2");
		}
		category.setId(UUIDUtil.getUUID());
		category.setCtime(DateUtil.getCurrentDate());
		
		boolean flag = bidsCategoryMapper.insert(category) > 0;
		if(flag && "1".equals(category.getLevel()))
		{//删除缓存 
			try 
			{
				jedisClientSingle.del(parentCategorysKey);
				
			} catch (Exception e) 
			{
				e.printStackTrace();
			}
		}
		return  flag;
	}
	
	@Override
	public Page list(String name, String ctime, String level, Integer page, Integer rows) 
	{
		BidsCategoryExample example = new BidsCategoryExample();
		Criteria criteria = example.createCriteria();
		if(StringUtil.isNotEmpty(name))
		{
			criteria.andBidsNameLike(name+"%");
		}
		if(StringUtil.isNotEmpty(ctime))
		{
			criteria.andCtimeLike(ctime+"%");
		}
		if(StringUtil.isNotEmpty(level))
		{
			criteria.andLevelEqualTo(level);
		}
		example.setOrderByClause(" `level`,p_ID,sort_index ");
		
		PageHelper.startPage(page,rows);
		List<BidsCategory> list = bidsCategoryMapper.selectByExample(example);
		PageInfo<BidsCategory> pageInfo = new PageInfo<BidsCategory>(list);
		long total = pageInfo.getTotal();
        Page toPage = new Page(total, page, list);
		return toPage;
	}
	@Override
	public BidsCategory getInfoById(String id)
	{
		if(StringUtil.isEmpty(id))
		{
			return null;
		}
		return bidsCategoryMapper.selectByPrimaryKey(id);
	}

	@Override
	public boolean edit(BidsCategory category) 
	{
		category.setCtime(null);
		if(StringUtil.isEmpty(category.getpId()))
		{
			category.setLevel("1");
		}
		else
		{
			category.setLevel("2");
		}
		boolean flag = bidsCategoryMapper.updateByPrimaryKeySelective(category) > 0;
		if(flag)
		{//删除缓存 
			try 
			{
				jedisClientSingle.del(parentCategorysKey);
				
			} catch (Exception e) 
			{
				e.printStackTrace();
			}
		}
		return flag;
	}

	@Override
	public boolean deleteByIds(String ids) 
	{
		if (!StringUtil.isEmpty(ids))
		{
			if (ids.startsWith(","))
			{
				ids = ids.substring(1);
			}
			if(ids.endsWith(","))
			{
				ids = ids.substring(ids.length()-1);
			}
			ids = ids.replaceAll("'", "");
			
			BidsCategoryExample example = new BidsCategoryExample();
			Criteria criteria = example.createCriteria();
			
			criteria.andIdIn(Arrays.asList(ids.split(",")));
			return bidsCategoryMapper.deleteByExample(example) > 0;
		}		
		return false;
	}
	//新增返回前端列表功能需要的list
	@Override
	public List<BidsCategoryQd> querylist() 
	{
	    //封装例如{name: '工程机械',list:[{name:'过滤设备'},{name:'化工设备'},{name:'过净水设备'}}格式的map
	     List<BidsCategoryQd> li=new ArrayList<BidsCategoryQd>();
	     //查询所有
	     List<BidsCategory> querylist=bidsCategoryMapper.querylist();
	     HashMap<String, Integer> map = new HashMap<String, Integer>();
	     for (BidsCategory  pl : querylist)
	     {
	         if(StringUtil.isEmpty(pl.getpId()))
	         {
	        	 map.put(pl.getId(), li.size());
	        	 li.add(new BidsCategoryQd(pl.getBidsName()));
	         }
	         else
	         {
	        	 int position = map.get(pl.getpId());
	        	 li.get(position).getList().add(pl.getBidsName());
	         }
		 }
	     
		return li;
	}
}
