package com.gmadong.modules.qualification;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.user.User;

@Controller
public class QualificationQdController
{

@Autowired
QualificationQdService qualificationQdService;
@Autowired
JedisClientSingle jedisClientSingle;
private String listkey = "qualification.list.do";

/**
 * 跳转到新建企业资质
 * @return
 */

@RequestMapping("qualification.buildQyzz.do")
public String buildJyzz() 
{
	
	  return "/front/application/buildQyzz";
}
@RequestMapping("/qualification.list.do")
public void list(HttpServletRequest req,HttpServletResponse response,@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows) throws Exception 
{
	User user = (User)Session.get("user");
	if(user == null)
	{
		AjaxUtil.write(Page.pageToJson(Page.getEmptyPage()), response);
		return;
	}
	
	String field =user.getId();
	try {
		String list = jedisClientSingle.hget(listkey, field);
		if (StringUtil.isNotEmpty(list)) {
			AjaxUtil.write(list, response);
			return;
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	Page toPage = qualificationQdService.page(user.getId(),page, rows);
	String list = Page.pageToJson(toPage);
	try {
		jedisClientSingle.hset(listkey, field, list, Common.REDIS_30_MINUTE_EXPIRE);
	} catch (Exception e) {
		e.printStackTrace();
	}
	AjaxUtil.write(Page.pageToJson(toPage), response);
}
@RequestMapping("qualification.deletelist.do")
public void deleteApplicationById(HttpServletResponse res,String id) 
{
	User user=(User)Session.get("user");
	if(user == null)
	{
		AjaxUtil.write("fail",res);
		return;
	}
	boolean  stat=qualificationQdService.deleteByPrimaryKey(id);
	if(stat)
	{
		try
		{
			jedisClientSingle.hdel(listkey,user.getId());
			jedisClientSingle.del("qualification.list.action");
		} catch (Exception e)
		{
		}
		AjaxUtil.write("succ",res);
	}
	else {
		AjaxUtil.write("fail",res);
	}
}
@RequestMapping("/qualification.doAdd.do")
public void doAdd(HttpServletResponse response, @Validated({ ValidatebQualificationAddAction.class }) Qualification qualification,BindingResult bindingResult)
{
	User user=(User)Session.get("user");
	if(user == null)
	{
		AjaxUtil.write("fail",response);
		return;
	}
	if(bindingResult.hasErrors())
	{
		ObjectError error = bindingResult.getAllErrors().get(0);
		AjaxUtil.write(error.getDefaultMessage(),response);
		return;
	}
	qualification.setUserId(user.getId());
	if(qualificationQdService.save(qualification))
	{
		try {
			jedisClientSingle.hdel(listkey,user.getId());
			jedisClientSingle.del("qualification.list.action");
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write("succ", response);
	}
	else {
		AjaxUtil.write("fail", response);
	}
}

@RequestMapping("/qualification.companyQualificationList.do")
public void companyQualification(HttpServletResponse response,String applicationId)
{
	String field = applicationId;
	try {
		String list = jedisClientSingle.hget(listkey, field);
		if (StringUtil.isNotEmpty(list)) {
			AjaxUtil.write(list, response);
			return;
		}

	} catch (Exception e) {
		e.printStackTrace();
	}
	List<Qualification> list =  qualificationQdService.selectByApplicationId(applicationId);
	String listStr = JsonUtil.listToJson(list);
	try {
		jedisClientSingle.hset(listkey, field, listStr, Common.REDIS_24_HOUR_EXPIRE);
	} catch (Exception e) {
		e.printStackTrace();
	}
	AjaxUtil.write(listStr, response);
	
}

	
}













