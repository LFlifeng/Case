package com.gmadong.modules.product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.application.Application;
import com.gmadong.modules.application.ApplicationMapper;
import com.gmadong.modules.manageCondition.ManageCondition;
import com.gmadong.modules.product.ProductExample.Criteria;

@Service("productQdService")
public class ProductQdServiceImpl implements ProductQdService
{
 
	@Autowired
	ProductMapper productMapper;
	@Autowired
	private ApplicationMapper applicationMapper;
	
	@Override
	public Page page(String id, Integer page, Integer rows)
	{
		ProductExample example = new ProductExample();
		Criteria criteria = example.createCriteria();
		criteria.andUserIdEqualTo(id);
		
		example.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<Product> list = productMapper.selectByExample(example);
		PageInfo<Product> pageInfo = new PageInfo<Product>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean deleteByPrimaryKey(String id)
	{
		return productMapper.deleteByPrimaryKey(id) > 0;
	}

	@Override
	public boolean save(Product product)
	{
		product.setId(UUIDUtil.getUUID());
		product.setCtime(DateUtil.getCurrentDate());
		boolean flag = productMapper.insert(product) > 0;
		return flag;
	}

	@Override
	public Page pageCompany(String applicationId, Integer page, Integer rows) {
		ProductExample example = new ProductExample();
		Criteria criteria = example.createCriteria();
		if (!StringUtil.isEmpty(applicationId)) {
			Application application = applicationMapper.selectByPrimaryKey(applicationId);
			String userId =application.getUserId();
			if(!StringUtil.isEmpty(userId)) {
				criteria.andUserIdEqualTo(userId);
			}else {
				return null;
			}
		}
		example.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<Product> list = productMapper.selectByExample(example);
		PageInfo<Product> pageInfo = new PageInfo<Product>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}
	
	
}
