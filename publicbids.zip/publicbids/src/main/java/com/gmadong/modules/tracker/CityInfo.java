package com.gmadong.modules.tracker;

public class CityInfo
{
	private String p;
	private String c;
	public String getP()
	{
		return p;
	}
	public void setP(String p)
	{
		this.p = p;
	}
	public String getC()
	{
		return c;
	}
	public void setC(String c)
	{
		this.c = c;
	}
	public CityInfo(String p, String c)
	{
		super();
		this.p = p;
		this.c = c;
	}
	public CityInfo()
	{
		super();
	}
	
	
}
