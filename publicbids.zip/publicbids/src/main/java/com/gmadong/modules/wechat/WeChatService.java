package com.gmadong.modules.wechat;

import javax.servlet.http.HttpServletRequest;

public interface WeChatService {

	String processRequest(HttpServletRequest request);

	String getTxtMessage();
}
