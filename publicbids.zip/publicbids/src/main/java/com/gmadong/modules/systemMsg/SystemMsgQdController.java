package com.gmadong.modules.systemMsg;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.user.User;

@Controller
public class SystemMsgQdController
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private SystemMsgQdService systemMsgQdService;  
	/**
     * 跳转到会员中心消息提示
     * @return
     */
	@RequestMapping("/systemQd.paymentInstruction.do")
	public String messagePrompt()
	{
		return "/front/usercenter/p-message";
	}
	/**
     * 跳转到会员系统消息提示
     * @return
     */
	@RequestMapping("/systemQd.systeminformation.do")
	public String systemMessage()
	{
		return "/front/usercenter/p-systeminformation";
	}
	@RequestMapping("/systemQd.list.do")
	public void selectMsgByUserId(HttpServletRequest req,HttpServletResponse response,String type,@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows)
	{
		User user=(User)Session.get("user");
		String day =DateUtil.getFormatDateTime(DateUtil.getDateBeforeOrAfter(new Date(), -5), "yyyy-MM-dd");
		if(user == null)
		{
			AjaxUtil.write(Page.pageToJson(Page.getEmptyPage()), response);
			return;
		}
		String key = "systemQd.list.do_"+user.getId();
		String field = day+"_"+type+"_"+page+"_"+rows;
		try {
			String list = jedisClientSingle.hget(key, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = systemMsgQdService.page(user.getId(),type,day,page, rows);
		String list = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(key, field, list, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(Page.pageToJson(toPage), response);
	}
	@RequestMapping("/systemQd.deleteSystemById.do")
    public void deleteSystemById(HttpServletRequest req,HttpServletResponse res,String id) {
		User user=(User)Session.get("user");
		//判断用户是否      session   过期
		if(user == null)
		{
			AjaxUtil.write("fail", res);
			return;
		}
		String field =user.getId();
    	boolean flag=systemMsgQdService.deleteSystemById(id);
    	if(flag)
    	{
    		try
			{
    			//删除  redis 缓存
    			String key = "systemQd.list.do_"+user.getId();
    			jedisClientSingle.del("jesystemMsg.list.action");
    			jedisClientSingle.del(key);
			} catch (Exception e)
			{}
    	   AjaxUtil.write("succ", res);
    	}else {
    		AjaxUtil.write("fail", res);
    	}
    }
	
	
}







