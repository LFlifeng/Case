package com.gmadong.modules.category;

import java.util.List;

import com.gmadong.common.Page;


public interface CategoryService 
{
	public Page page(String type,String title,String ctime,Integer page,Integer rows);
	public boolean save(Category category);
	public List<Category> getParent();
	public boolean deleteById(String ids);
	public boolean update(Category category);
	public Category getColumnCategoryById(String id);
	public List<Category> getCategorys(String type);
}
