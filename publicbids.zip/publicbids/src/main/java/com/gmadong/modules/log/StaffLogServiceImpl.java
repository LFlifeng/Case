package com.gmadong.modules.log;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gmadong.common.Request;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.UUIDUtil;

@Service("staffLogService")
public class StaffLogServiceImpl implements StaffLogService 
{
    @Autowired
	private SysStaffLogMapper sysStaffLogMapper;
	
	@Override
	public void log(String staffId,String recordId, String keyword, String content)
	{
//		SysStaffLog staffLog = new SysStaffLog();
//		staffLog.setStaffLogId(UUIDUtil.getUUID());
//		staffLog.setStaff(staffId);
//	    staffLog.setRecordId(recordId);
//	    staffLog.setKeyword(keyword);
//		staffLog.setContent(content);
//		staffLog.setLogType("1");
//		staffLog.setIp(Request.getIp());
//		staffLog.setStatus(1);
//		staffLog.setCreateTime(DateUtil.getCurrentDate());
//		sysStaffLogMapper.insert(staffLog);
		
	}

}
