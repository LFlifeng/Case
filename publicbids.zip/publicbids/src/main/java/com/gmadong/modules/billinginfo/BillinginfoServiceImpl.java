package com.gmadong.modules.billinginfo;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.billinginfo.BillinginfoExample.Criteria;


@Service("billinginfoService")
public class BillinginfoServiceImpl implements BillinginfoService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private BillinginfoMapper billinginfoMapper;
	@Override
	public Page page(String invoice, String accountName,String invoiceType,String ctime, Integer page, Integer rows)
	{
		BillinginfoExample billinginfoExample = new BillinginfoExample();
		Criteria createCriteria = billinginfoExample.createCriteria();
		if (!StringUtil.isEmpty(invoice)) {
			createCriteria.andInvoiceLike(invoice + "%");
		}
		if (!StringUtil.isEmpty(accountName)) {
			createCriteria.andAccountNameLike(accountName + "%");
		}
		if (!StringUtil.isEmpty(invoiceType)) {
			createCriteria.andInvoiceTypeLike(invoiceType + "%");
		}
		if (!StringUtil.isEmpty(ctime)) {
			createCriteria.andCtimeLike(ctime + "%");
		}
		billinginfoExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<Billinginfo> list = billinginfoMapper.selectByExample(billinginfoExample);
		PageInfo<Billinginfo> pageInfo = new PageInfo<Billinginfo>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}
	@Override
	public boolean save(Billinginfo billinginfo)
	{
		billinginfo.setId(UUIDUtil.getUUID());
		billinginfo.setCtime(DateUtil.getCurrentDate());
		boolean flag = billinginfoMapper.insert(billinginfo) > 0;
		return flag;
	}
	@Override
	public boolean update(Billinginfo billinginfo)
	{
		billinginfo.setCtime(null);
		return billinginfoMapper.updateByPrimaryKeySelective(billinginfo) > 0;
	}
	@Override
	public Billinginfo getBillinginfoById(String id)
	{
		return billinginfoMapper.selectByPrimaryKey(id);
	}
	@Override
	public boolean deleteById(String ids)
	{
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			BillinginfoExample billinginfoExample = new BillinginfoExample();
			Criteria createCriteria = billinginfoExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			return billinginfoMapper.deleteByExample(billinginfoExample) > 0;
		}
		return false;
	}
}
