package com.gmadong.modules.city;

import java.util.ArrayList;
import java.util.List;

public class AreaCityInfo
{
	private String name;
	private List<AreaCityInfo> list = new ArrayList<AreaCityInfo>();
	
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public List<AreaCityInfo> getList()
	{
		return list;
	}
	public void setList(List<AreaCityInfo> list)
	{
		this.list = list;
	}
	
	
	
}
