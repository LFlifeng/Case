package com.gmadong.modules.systemInfo;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.application.Application;
import com.gmadong.modules.replacePicture.ReplacePictureExample;
import com.gmadong.modules.systemInfo.SystemInfoExample.Criteria;



@Service("systemInfoService")
public class SystemInfoServiceImpl implements SystemInfoService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private SystemInfoMapper systemInfoMapper;
	
	@Override
	public Page page(String companyName, String companyPhone, String companySite, String ctime, Integer page,
			Integer rows)
	{
		SystemInfoExample systemInfoExample = new SystemInfoExample();
		Criteria createCriteria = systemInfoExample.createCriteria();
		if(!StringUtil.isEmpty(companyName)) {
			createCriteria.andCompanyNameLike(companyName + "%");
		}
		if(!StringUtil.isEmpty(companyPhone)) {
			createCriteria.andCompanyPhoneLike(companyPhone + "%");
		}
		if(!StringUtil.isEmpty(companySite)) {
			createCriteria.andCompanySiteLike(companySite + "%");
		}
		if(!StringUtil.isEmpty(ctime)) {
			createCriteria.andCtimeLike(ctime + "%");
		}
		systemInfoExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<SystemInfo> list = systemInfoMapper.selectByExample(systemInfoExample);
		PageInfo<SystemInfo> pageInfo = new PageInfo<SystemInfo>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean save(SystemInfo systemInfo)
	{
		systemInfo.setId(UUIDUtil.getUUID());
		systemInfo.setCtime(DateUtil.getCurrentDate());
		boolean flag = systemInfoMapper.insert(systemInfo) > 0;
		return flag;
	}

	@Override
	public boolean update(SystemInfo systemInfo)
	{
		systemInfo.setCtime(null);
		return systemInfoMapper.updateByPrimaryKeySelective(systemInfo) > 0;
	}

	@Override
	public SystemInfo getSystemInfoById(String id)
	{
		return systemInfoMapper.selectByPrimaryKey(id);
	}
	@Override
	public SystemInfo getSystemInfo()
	{
		return systemInfoMapper.selectByPrimaryKey("A89FF817C38106D0C1AC22EAEB68FAD7");
	}


	@Override
	public boolean deleteById(String ids)
	{
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			SystemInfoExample systemInfoExample = new SystemInfoExample();
			Criteria createCriteria = systemInfoExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			return systemInfoMapper.deleteByExample(systemInfoExample) > 0;
		}
		return false;
	}

}
