package com.gmadong.modules.role;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.role.SysRoleExample.Criteria;

@Service("sysRoleService")
public class SysRoleServiceImpl implements SysRoleService 
{
    @Autowired
	private SysRoleMapper sysRoleMapper;
	@Override
	public String getActionByRoleIds(String roleIds)
	{
		if(StringUtil.isEmpty(roleIds))
		{
			return "";
		}
		String roleNames = "";
		SysRoleExample example = new SysRoleExample();
		Criteria criteria = example.createCriteria();
		criteria.andIdIn(Arrays.asList(roleIds.split(",")));
		criteria.andStatusEqualTo(1);
		
		List<SysRole> list = sysRoleMapper.selectByExampleWithBLOBs(example);
		for(SysRole role:list)
		{
			String roleName = role.getActions();
			if(StringUtil.isNotEmpty(roleName) && roleNames.indexOf(roleName)==-1)
			{
				roleNames += roleName + ",";
			}
		}
		if(roleNames.endsWith(","))
		{
			roleNames = roleNames.substring(0, roleNames.length()-1);
		}
		return roleNames;
	}

	@Override
	public Page page(String roleName, String remark, Integer page, Integer rows)
	{
		SysRoleExample example = new SysRoleExample();
		Criteria criteria = example.createCriteria();
		criteria.andStatusEqualTo(1);
		criteria.andActionsNotEqualTo("all");
		if(!StringUtil.isEmpty(roleName))
		{
			criteria.andRoleNameLike("%"+roleName+"%");
		}
		if(!StringUtil.isEmpty(remark))
		{
			criteria.andRemarkLike("%"+remark+"%");
		}
		example.setOrderByClause("create_time ASC");
		
		PageHelper.startPage(page,rows);
		List<SysRole> list = sysRoleMapper.selectByExample(example);
		PageInfo<SysRole> pageInfo = new PageInfo<SysRole>(list);
		long total = pageInfo.getTotal();
        Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public SysRole selectByRoleId(String roleId)
	{
		if(StringUtil.isEmpty(roleId))
		{
			return null;
		}
		SysRoleExample example = new SysRoleExample();
		Criteria criteria = example.createCriteria();
		criteria.andStatusEqualTo(1);
		criteria.andIdEqualTo(roleId);
		List<SysRole> list = sysRoleMapper.selectByExampleWithBLOBs(example);
		if(list.size()>0)
		{
		   return list.get(0);
		}
		return null;
	}

	@Override
	public boolean saveRold(SysRole role) 
	{
		role.setId(UUIDUtil.getUUID());
		role.setCreateTime(DateUtil.getCurrentDate());
		role.setStatus(1);
		int insert = sysRoleMapper.insert(role);
		if(insert==1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	@Override
	public boolean updateRold(SysRole role)
	{
		role.setCreateTime(DateUtil.getCurrentDate());
		role.setStatus(1);
		SysRoleExample example = new SysRoleExample();
		Criteria criteria = example.createCriteria();
		criteria.andIdEqualTo(role.getId());
		int insert = sysRoleMapper.updateByExampleWithBLOBs(role, example);
		if(insert==1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public boolean deleteByRoleIds(String ids)
	{
		if (!StringUtil.isEmpty(ids))
		{
			if (ids.startsWith(","))
			{
				ids = ids.substring(1);
			}
			if(ids.endsWith(","))
			{
				ids = ids.substring(ids.length()-1);
			}
			ids = ids.replaceAll("'", "");
		}
		SysRoleExample example = new SysRoleExample();
		Criteria criteria = example.createCriteria();
		
		criteria.andIdIn(Arrays.asList(ids.split(",")));
		int deleteByExample = sysRoleMapper.deleteByExample(example);
		if(deleteByExample>0)
		{
			return true;
		}
		return false;
	}

	@Override
	public List<SysRole> getAll()
	{
		SysRoleExample example = new SysRoleExample();
		Criteria criteria = example.createCriteria();
		criteria.andStatusNotEqualTo(0);
	    criteria.andActionsNotEqualTo("all");
	    List<SysRole> list = sysRoleMapper.selectByExampleWithBLOBs(example);
		return list;
	}

}
