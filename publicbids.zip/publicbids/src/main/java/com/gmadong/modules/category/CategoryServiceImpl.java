package com.gmadong.modules.category;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.common.utils.XSSUtils;
import com.gmadong.modules.category.CategoryExample.Criteria;
import com.gmadong.modules.columnCategory.ColumnCategory;

@Service("categoryService")
public class CategoryServiceImpl implements CategoryService
{

	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private CategoryMapper categoryMapper;
	private static final String parentCategorysKey = "categoryMapper.ParentCategorys";
	private static final String getCategoryssKey = "categoryMapper.getCategorys";

	@Override
	public Page page(String type, String title, String ctime, Integer page, Integer rows) {
		CategoryExample categoryExample = new CategoryExample();
		Criteria createCriteria = categoryExample.createCriteria();
		if (!StringUtil.isEmpty(type)) {
			createCriteria.andTypeEqualTo(type);
		}
		if (!StringUtil.isEmpty(title)) {
			createCriteria.andTitleLike(title + "%");
		}
		if (!StringUtil.isEmpty(ctime)) {

			createCriteria.andCtimeLike(ctime + "%");
		}
		categoryExample.setOrderByClause("type,sort_index");

		PageHelper.startPage(page, rows);
		List<Category> selectByExample = categoryMapper.selectByExample(categoryExample);
		PageInfo<Category> pageInfo = new PageInfo<Category>(selectByExample);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, selectByExample);
		return toPage;

	}

	@Override
	public boolean save(Category category) {
		category.setId(UUIDUtil.getUUID());
		category.setCtime(DateUtil.getCurrentDate());
		XSSUtils.clearXss(Category.class, category);
		boolean flag = categoryMapper.insert(category) > 0;
		if(flag)
		{
			try
			{
				jedisClientSingle.del("getCategoryssKey");
				
			} catch (Exception e)
			{
			}
		}
			
		return flag;
	}

	@Override
	public List<Category> getParent() {

		try {// 从缓存中得到数据
			String list = jedisClientSingle.get(parentCategorysKey);
			if (StringUtil.isNotEmpty(list)) {
				ObjectMapper mapper = new ObjectMapper();
				List<Category> keys = mapper.readValue(list, new TypeReference<List<Category>>() {
				});
				return keys;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		CategoryExample categoryExample = new CategoryExample();

		Criteria createCriteria = categoryExample.createCriteria();
		categoryExample.setOrderByClause("type,sort_index");
		List<Category> selectByExample = categoryMapper.selectByExample(categoryExample);

		try {// 添加缓存
			jedisClientSingle.set(parentCategorysKey, JsonUtil.listToJson(selectByExample));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return selectByExample;
	}

	@Override
	public boolean deleteById(String ids) {
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			CategoryExample categoryExample = new CategoryExample();
			Criteria createCriteria = categoryExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			boolean flag = categoryMapper.deleteByExample(categoryExample) > 0;
			if(flag) 
			{
				try
				{
					jedisClientSingle.del("getCategoryssKey");
					
				} catch (Exception e)
				{
				}
			}
			
			return flag;
		}
		return false;
	}

	@Override
	public boolean update(Category category) 
	{
		category.setCtime(null);
		boolean flag =  categoryMapper.updateByPrimaryKeySelective(category) > 0;
		if(flag)
		{
			try
			{
				jedisClientSingle.del("getCategoryssKey");
				
			} catch (Exception e)
			
			{
			}
		}
		return flag;
	}
	@Override
	public Category getColumnCategoryById(String id) {
		return categoryMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<Category> getCategorys(String type)
	{
		String field = type;
		try
		{
			String json = jedisClientSingle.hget(getCategoryssKey, field);
			if(StringUtil.isNotEmpty(json))
			{
				ObjectMapper mapper = new ObjectMapper();
				List<Category> keys = mapper.readValue(json, new TypeReference<List<Category>>() {
				});
				return keys;
			}
		} catch (Exception e)
		{}
		CategoryExample categoryExample = new CategoryExample();
		Criteria createCriteria = categoryExample.createCriteria();
		createCriteria.andTypeEqualTo(type);
		categoryExample.setOrderByClause("sort_index");
		List<Category> list = categoryMapper.selectByExample(categoryExample);
		try
		{
			jedisClientSingle.hset(getCategoryssKey, field, JsonUtil.listToJson(list));
		}
		catch (Exception e) 
		{}
		return list;
	}
}
