package com.gmadong.modules.bidsCategory;

public interface ValidatebBidCategoryEditAction {

}
