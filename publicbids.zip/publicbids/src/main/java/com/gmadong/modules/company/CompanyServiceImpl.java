package com.gmadong.modules.company;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.category.Category;
import com.gmadong.modules.category.CategoryExample;
import com.gmadong.modules.company.CompanyExample.Criteria;
import com.gmadong.modules.news.NewsExample;




@Service("companyService")
public class CompanyServiceImpl implements CompanyService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private CompanyMapper companyMapper;
	private static final String parentCategorysKey = "companyMapper.ParentCategorys";
	@Override
	public Page page(String title,String state,String legalPerson,String creditCode,String number,String ctime,Integer page, Integer rows)
	{
		CompanyExample companyExample = new CompanyExample();
		Criteria createCriteria = companyExample.createCriteria();
		if (!StringUtil.isEmpty(title)) {
			createCriteria.andTitleLike(title + "%");
		}
		if (!StringUtil.isEmpty(state)) {
			createCriteria.andStateLike(state + "%");
		}
		if (!StringUtil.isEmpty(legalPerson)) {
			createCriteria.andLegalPersonLike(legalPerson + "%");
		}
		if (!StringUtil.isEmpty(creditCode)) {
			createCriteria.andCreditCodeLike(creditCode + "%");
		}
		if (!StringUtil.isEmpty(number)) {
			createCriteria.andNumberLike(number + "%");
		}
		if (!StringUtil.isEmpty(ctime)) { 
			createCriteria.andCtimeLike(ctime + "%");
		}
		companyExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<Company> list = companyMapper.selectByExample(companyExample);
		PageInfo<Company> pageInfo = new PageInfo<Company>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}
	@Override
	public List<Company> getParent()
	{
		try {// 从缓存中得到数据
			String list = jedisClientSingle.get(parentCategorysKey);
			if (StringUtil.isNotEmpty(list)) {
				ObjectMapper mapper = new ObjectMapper();
				List<Company> keys = mapper.readValue(list, new TypeReference<List<Company>>() {
				});
				return keys;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		CompanyExample companyExample = new CompanyExample();
		Criteria createCriteria = companyExample.createCriteria();
		companyExample.setOrderByClause("ctime DESC");
		List<Company> selectByExample = companyMapper.selectByExample(companyExample);
		try {// 添加缓存
			jedisClientSingle.set(parentCategorysKey, JsonUtil.listToJson(selectByExample));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return selectByExample;
	}
	@Override
	public boolean deleteById(String ids)
	{
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			CompanyExample companyExample = new CompanyExample();
			Criteria createCriteria = companyExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			return companyMapper.deleteByExample(companyExample) > 0;
		}
		return false;
	}
	@Override
	public boolean save(Company company)
	{
		company.setId(UUIDUtil.getUUID());
		company.setCtime(DateUtil.getCurrentDate());
		boolean flag = companyMapper.insert(company) > 0;
		return flag;
	}
	@Override
	public boolean update(Company company)
	{
		company.setCtime(null);
		return companyMapper.updateByPrimaryKeySelective(company) > 0;
	}
	@Override
	public Company getCompanyById(String id)
	{
		return companyMapper.selectByPrimaryKey(id);
	}
	@Override
	public Company getCompanyByStaffId(String id)
	{
		if(StringUtil.isEmpty(id))
		{
			return null;
		}
		CompanyExample companyExample = new CompanyExample();
		Criteria createCriteria = companyExample.createCriteria();
		createCriteria.andStaffIdEqualTo(id);
		
		List<Company> list = companyMapper.selectByExample(companyExample);
		if(list.size() > 0)
		{
			return list.get(0);
		}
		return null;
	}
	/**
	 * 根据id查询公司信息
	 */
	@Override
	public Company selectByStaffIdKey(String id)
	{
		return companyMapper.selectByStaffIdKey(id);
	}
	@Override
	public List<Company> findFamousCompany() {
		/*
		 * CompanyExample companyExample = new CompanyExample(); Criteria createCriteria
		 * = companyExample.createCriteria();
		 * companyExample.setOrderByClause("ctime DESC");
		 */
		List<Company> list = companyMapper.selectFamousCompany();
		if(list.size() > 0) {
			return list;
		}
		return null;
	}
}
