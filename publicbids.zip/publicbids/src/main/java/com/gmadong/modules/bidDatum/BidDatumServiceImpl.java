package com.gmadong.modules.bidDatum;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.application.ApplicationExample;
import com.gmadong.modules.bidDatum.BidDatumExample.Criteria;



@Service("bidDatumService")
public class BidDatumServiceImpl implements BidDatumService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private BidDatumMapper bidDatumMapper;
	@Override
	public Page page(String tltle, String source, String ctime, Integer page, Integer rows)
	{
		BidDatumExample bidDatumExample = new BidDatumExample();
		Criteria createCriteria = bidDatumExample.createCriteria();
		if (!StringUtil.isEmpty(tltle)) {
			createCriteria.andTltleLike(tltle + "%");
		}
		if (!StringUtil.isEmpty(source)) {
			createCriteria.andSourceLike(source + "%");
		}
		if (!StringUtil.isEmpty(ctime)) {
			createCriteria.andCtimeLike(ctime + "%");
		}
		bidDatumExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<BidDatum> list = bidDatumMapper.selectByExample(bidDatumExample);
		PageInfo<BidDatum> pageInfo = new PageInfo<BidDatum>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}
	@Override
	public boolean save(BidDatum bidDatum)
	{
		bidDatum.setId(UUIDUtil.getUUID());
		bidDatum.setCtime(DateUtil.getCurrentDate());
		boolean flag = bidDatumMapper.insert(bidDatum) > 0;
		return flag;
	}
	@Override
	public boolean update(BidDatum bidDatum)
	{
		bidDatum.setCtime(null);
		return bidDatumMapper.updateByPrimaryKeySelective(bidDatum) > 0;
	}
	@Override
	public BidDatum getBidDatumById(String id)
	{
		return bidDatumMapper.selectByPrimaryKey(id);
	}
	@Override
	public boolean deleteById(String ids)
	{
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			BidDatumExample bidDatumExample = new BidDatumExample();
			Criteria createCriteria = bidDatumExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			return bidDatumMapper.deleteByExample(bidDatumExample) > 0;
		}
		return false;
	}
}
