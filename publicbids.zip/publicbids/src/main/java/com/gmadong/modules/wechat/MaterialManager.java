package com.gmadong.modules.wechat;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.http.client.ClientProtocolException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.sf.json.JSONObject;

/**
 * 素材管理器
 * 
 * @author Administrator
 *
 */
public class MaterialManager {

	private static Logger log = LoggerFactory.getLogger(MaterialManager.class);

	// 新增临时素材
	public static final String UPLOAD_TEMPORARY_URL = "https://api.weixin.qq.com/cgi-bin/media/upload?access_token=ACCESS_TOKEN&type=TYPE";

	// 获取临时素材
	public static final String GET_TEMPORARY_URL = "https://api.weixin.qq.com/cgi-bin/media/get?access_token=ACCESS_TOKEN&media_id=MEDIA_ID";

	// 新增永久图文素材
	public static final String UPLOAD_NEWS_URL = "https://api.weixin.qq.com/cgi-bin/material/add_news?access_token=ACCESS_TOKEN";

	// 上传图文消息内的图片获取URL
	public static final String UPLOAD_IMG_URL = "https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token=ACCESS_TOKEN";

	// 上传其他类型的永久素材
	public static final String ADD_MATERIAL_URL = "https://api.weixin.qq.com/cgi-bin/material/add_material?access_token=ACCESS_TOKEN&type=TYPE";

	// 获取永久素材
	public static final String GET_MATERIAL_URL = "https://api.weixin.qq.com/cgi-bin/material/get_material?access_token=ACCESS_TOKEN";

	// 删除永久素材
	public static final String DELETE_MATERIAL_URL = "https://api.weixin.qq.com/cgi-bin/material/del_material?access_token=ACCESS_TOKEN";
	
	// 修改永久图文素材
	public static final String UPDATE_NEWS_URL = "https://api.weixin.qq.com/cgi-bin/material/update_news?access_token=ACCESS_TOKEN";
	
	// 获取素材总数
	public static final String GET_MATERIALCOUNT_URL = "https://api.weixin.qq.com/cgi-bin/material/get_materialcount?access_token=ACCESS_TOKEN";
	
	// 获取素材列表
	public static final String BATCHGET_MATERIAL_URL = "https://api.weixin.qq.com/cgi-bin/material/get_materialcount?access_token=ACCESS_TOKEN";
	
	/**
	 * 上传图文消息内的图片获取URL
	 * 
	 * @param accessToken
	 * @param media
	 * @return
	 */
	public static String uploadImg(String accessToken, String fileUrl) {
		String imgUrl = "";
		String result = "";
		// 判断文件是否存在
		File file = new File(fileUrl);
		if (!file.exists()) {
			return null;
		}
		// 拼装创建菜单的url
		String url = UPLOAD_IMG_URL.replace("ACCESS_TOKEN", accessToken);

		try {
			URL url1 = new URL(url);
			HttpURLConnection conn = (HttpURLConnection) url1.openConnection();
			conn.setConnectTimeout(5000);
			conn.setReadTimeout(30000);
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setUseCaches(false);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Connection", "Keep-Alive");
			conn.setRequestProperty("Cache-Control", "no-cache");
			String boundary = "-----------------------------" + System.currentTimeMillis();
			conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

			OutputStream output = conn.getOutputStream();
			output.write(("--" + boundary + "\r\n").getBytes());
			output.write(
					String.format("Content-Disposition: form-data; name=\"media\"; filename=\"%s\"\r\n", file.getName())
							.getBytes());
			output.write("Content-Type: image/jpeg \r\n\r\n".getBytes());
			byte[] data = new byte[1024];
			int len = 0;
			FileInputStream input = new FileInputStream(file);
			while ((len = input.read(data)) > -1) {
				output.write(data, 0, len);
			}
			output.write(("\r\n--" + boundary + "\r\n\r\n").getBytes());
			output.flush();
			output.close();
			input.close();
			InputStream resp = conn.getInputStream();
			StringBuffer sb = new StringBuffer();
			while ((len = resp.read(data)) > -1)
				sb.append(new String(data, 0, len, "utf-8"));
			resp.close();
			result = sb.toString();
			JSONObject jsonObject = JSONObject.fromObject(result);
			imgUrl = jsonObject.getString("url");
		} catch (ClientProtocolException e) {
			log.error("postFile，不支持http协议", e);
		} catch (IOException e) {
			log.error("postFile数据传输失败", e);
		}
		return imgUrl;
	}
}
