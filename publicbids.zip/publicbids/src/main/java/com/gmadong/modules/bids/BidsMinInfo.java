package com.gmadong.modules.bids;

import com.gmadong.common.utils.StringUtil;

public class BidsMinInfo {
	private String type = null;
	private String title = null;
	private String date = null;
	private String province = null;
	private String industry = null;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public BidsMinInfo(String type, String title, String date, String province, String industry) {
		super();
		
		if(!StringUtil.isEmpty(type))
		{
			this.type = type;
		}
		if(!StringUtil.isEmpty(title))
		{
			this.title = title;
		}
		if(!StringUtil.isEmpty(date))
		{
			this.date = date;
		}
		if(!StringUtil.isEmpty(province))
		{
			this.province = province;
		}
		if(!StringUtil.isEmpty(industry))
		{
			this.industry = industry;
		}
		
		
		
		
	}
	
	
	
}
