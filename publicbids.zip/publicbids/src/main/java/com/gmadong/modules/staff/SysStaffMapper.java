package com.gmadong.modules.staff;

import com.gmadong.modules.staff.SysStaff;
import com.gmadong.modules.staff.SysStaffExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SysStaffMapper {
    int countByExample(SysStaffExample example);

    int deleteByExample(SysStaffExample example);

    int deleteByPrimaryKey(String id);

    int insert(SysStaff record);

    int insertSelective(SysStaff record);

    List<SysStaff> selectByExample(SysStaffExample example);

    SysStaff selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") SysStaff record, @Param("example") SysStaffExample example);

    int updateByExample(@Param("record") SysStaff record, @Param("example") SysStaffExample example);

    int updateByPrimaryKeySelective(SysStaff record);

    int updateByPrimaryKey(SysStaff record);
    
    int copyUseReport(@Param(value="day") String day);
    int copyMsg(@Param(value="day") String day);
    int copyDayReport(@Param(value="year") String year);
    //自己加的方法
    String getNicknameByPrimaryKey(String id);
}