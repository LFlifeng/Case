package com.gmadong.modules.application;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.modules.application.ApplicationExample.Criteria;
import com.gmadong.modules.bids.Bids;

@Service("applicationQdService")
public class ApplicationQdServiceImpl implements ApplicationQdService
{
	@Autowired
	ApplicationMapper applicationMapper;

	@Override
	public Application selectByUserId(String userId)
	{
		ApplicationExample example = new ApplicationExample();
		Criteria criteria = example.createCriteria();
		criteria.andUserIdEqualTo(userId);
		
		List<Application> list = applicationMapper.selectByExampleWithBLOBs(example);
		
		
		if(list.size()>0)
		{
			return list.get(0);
		}
		return null;
	}

	@Override
	public boolean updateUploadAudit(Application application)
	{
		return applicationMapper.updateByPrimaryKeySelective(application) > 0;
	}
	@Override
	public List<ExcellentApplication> findFamousCompany() {
		/*
		 * ApplicationExample applicationExample = new ApplicationExample(); Criteria
		 * createCriteria = applicationExample.createCriteria();
		 */
		List<ExcellentApplication> list = applicationMapper.selectFamousCompany();
		if(list.size() > 0) {
			return list;
		}
		return null;
	}

	@Override
	public List<ExcellentApplication> findTopFamousCompany() {
		/*
		 * ApplicationExample applicationExample = new ApplicationExample(); Criteria
		 * createCriteria = applicationExample.createCriteria();
		 */
		List<ExcellentApplication> list = applicationMapper.selectTopFamousCompany();
		if(list.size() > 0) {
			return list;
		}
		return null;
	}
	
	@Override
	public List<ExcellentApplication> findExcellentApplication() {
		List<ExcellentApplication> list = applicationMapper.selectExcellentApplication();
		if(list.size() > 0) {
			return list;
		}
		return null;
	}

	@Override
	public Page page(Integer page, Integer rows) {
		PageHelper.startPage(page, rows);
		List<ExcellentApplication> list = applicationMapper.selectExcellentApplication();
		PageInfo<ExcellentApplication> pageInfo = new PageInfo<ExcellentApplication>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public Application selectCompanyById(String applicationId) {
		Application application = applicationMapper.selectByPrimaryKey(applicationId);
		if(application == null) {
			return new Application();
		}
		return application;
	}

	@Override
	public List<ExcellentApplication> findFamousCompanyWall() {
		// TODO Auto-generated method stub
		List<ExcellentApplication> list = applicationMapper.selectFamousCompanyWall();
		if(list.size() > 0) {
			return list;
		}
		return null;
	}
}
