package com.gmadong.modules.staff;


public interface ValidateSysStaffSaveAction 
{
   
}