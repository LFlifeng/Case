package com.gmadong.modules.billinginfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gmadong.common.datasource.CustomerContextHolder;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.UUIDUtil;

@Service("billingInfoQdService")
public class BillingInfoQdServiceImpl implements BillingInfoQdService
{

	@Autowired
	BillinginfoMapper billinginfoMapper;
	@Override
	public Billinginfo selectInvoiceById(String id)
	{ 
		Billinginfo billing=billinginfoMapper.selectInvoiceById(id);
		return billing;
	}
	@Override
	public boolean updateByPrimaryKey(Billinginfo billinginfo)
	{
		return billinginfoMapper.updateByPrimaryKeySelective(billinginfo)>0;
	}
	@Override
	public boolean saveBillingInfo(Billinginfo billinginfo)
	{
		billinginfo.setId(UUIDUtil.getUUID());
		billinginfo.setCtime(DateUtil.getCurrentDate());
		return  billinginfoMapper.insert(billinginfo) > 0;
	}
	
}
