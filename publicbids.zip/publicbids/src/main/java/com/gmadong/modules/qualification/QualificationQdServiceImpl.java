package com.gmadong.modules.qualification;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.application.Application;
import com.gmadong.modules.application.ApplicationMapper;
import com.gmadong.modules.qualification.QualificationExample.Criteria;

@Service("qualificationQdService")
public class QualificationQdServiceImpl implements QualificationQdService {
	@Autowired
	QualificationMapper qualificationMapper;

	@Autowired
	private ApplicationMapper applicationMapper;

	
	@Override
	public Page page(String id, Integer page, Integer rows) {
		QualificationExample qualificationExample = new QualificationExample();
		Criteria createCriteria = qualificationExample.createCriteria();
		createCriteria.andUserIdEqualTo(id);
		PageHelper.startPage(page, rows);
		List<Qualification> list = qualificationMapper.selectByExample(qualificationExample);
		PageInfo<Qualification> pageInfo = new PageInfo<Qualification>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean deleteByPrimaryKey(String id) {
		return qualificationMapper.deleteByPrimaryKey(id) > 0;
	}

	@Override
	public boolean save(Qualification qualification) {
		qualification.setId(UUIDUtil.getUUID());
		qualification.setCtime(DateUtil.getCurrentDate());
		boolean flag = qualificationMapper.insert(qualification) > 0;
		return flag;
	}

	@Override
	public List<Qualification> selectByApplicationId(String applicationId) {
		Application application = applicationMapper.selectByPrimaryKey(applicationId);
		if(application == null) {
			return null;
		}
		QualificationExample qualificationExample = new QualificationExample();
		Criteria createCriteria = qualificationExample.createCriteria();
		createCriteria.andUserIdEqualTo(application.getUserId());
		List<Qualification> list = qualificationMapper.selectByExample(qualificationExample);
		return list;
	}



}
