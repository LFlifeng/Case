package com.gmadong.modules.usercollection;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.datasource.CustomerContextHolder;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.usercollection.UserCollectionExample.Criteria;



@Service("userCollectionService")
public class UserCollectionServiceImpl implements UserCollectionService {

	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private UserCollectionMapper userCollectionMapper;
	
	@Override
	public Page page(String userId, Integer page, Integer rows) {
		// TODO Auto-generated method stub
		UserCollectionExample userCollectionExample = new UserCollectionExample();
		Criteria createCriteria = userCollectionExample.createCriteria();
		if (!StringUtil.isEmpty(userId)) {
			createCriteria.andUserIdEqualTo(userId);
		}
		PageHelper.startPage(page, rows);
		userCollectionExample.setOrderByClause("ctime desc");
		List<UserCollection> list = userCollectionMapper.selectByExample(userCollectionExample);
		PageInfo<UserCollection> pageInfo = new PageInfo<UserCollection>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean deleteById(String id) {
		if(userCollectionMapper.deleteByPrimaryKey(id) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean save(UserCollection userCollection) {
		boolean flag = userCollectionMapper.insert(userCollection) > 0;
		return flag;
	}

	@Override
	public UserCollection selectByBiddingInfoId(String biddingInfoId) {
		UserCollectionExample userCollectionExample = new UserCollectionExample();
		Criteria createCriteria = userCollectionExample.createCriteria();
		if (!StringUtil.isEmpty(biddingInfoId)) {
			createCriteria.andBiddinginfoIdEqualTo(biddingInfoId);
		}
		List<UserCollection> list = userCollectionMapper.selectByExample(userCollectionExample);
		if(list.size() > 0) {
			return list.get(0);
		}
			return null;
	}


}