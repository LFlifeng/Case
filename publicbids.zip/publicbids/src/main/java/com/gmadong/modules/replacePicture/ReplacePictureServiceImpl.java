package com.gmadong.modules.replacePicture;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.projectDesigneds.ProjectDesignedsExample;
import com.gmadong.modules.replacePicture.ReplacePictureExample.Criteria;


@Service("replacePictureService")
public class ReplacePictureServiceImpl implements ReplacePictureService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private ReplacePictureMapper replacePictureMapper;

	@Override
	public Page page(String number,String url,String ctime, Integer page, Integer rows)
	{
		ReplacePictureExample replacePictureExample = new ReplacePictureExample();
		Criteria createCriteria = replacePictureExample.createCriteria();
		if(!StringUtil.isEmpty(number)) {
			createCriteria.andNumberLike(number + "%");
		}
		if(!StringUtil.isEmpty(url)) {
			createCriteria.andUrlLike(url + "%");
		}
		if (!StringUtil.isEmpty(ctime)) {
			createCriteria.andCtimeLike(ctime + "%");
		}
		replacePictureExample.setOrderByClause("number,position");
		PageHelper.startPage(page, rows);
		List<ReplacePicture> list = replacePictureMapper.selectByExample(replacePictureExample);
		PageInfo<ReplacePicture> pageInfo = new PageInfo<ReplacePicture>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean save(ReplacePicture replacePicture)
	{
		replacePicture.setId(UUIDUtil.getUUID());
		replacePicture.setCtime(DateUtil.getCurrentDate());
		boolean flag = replacePictureMapper.insert(replacePicture) > 0;
		return flag;
	}

	@Override
	public boolean update(ReplacePicture replacePicture)
	{
		replacePicture.setCtime(null);
		return replacePictureMapper.updateByPrimaryKeySelective(replacePicture) > 0;
	}

	@Override
	public ReplacePicture getReplacePictureById(String id)
	{
		return replacePictureMapper.selectByPrimaryKey(id);
	}

	@Override
	public boolean deleteById(String ids)
	{
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			ReplacePictureExample replacePictureExample = new ReplacePictureExample();
			Criteria createCriteria = replacePictureExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			return replacePictureMapper.deleteByExample(replacePictureExample) > 0;
		}
		return false;
	}
	
}
