package com.gmadong.modules.bidDatum;

import com.gmadong.modules.bidDatum.BidDatum;
import com.gmadong.modules.bidDatum.BidDatumExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BidDatumMapper {
    int countByExample(BidDatumExample example);

    int deleteByExample(BidDatumExample example);

    int deleteByPrimaryKey(String id);

    int insert(BidDatum record);

    int insertSelective(BidDatum record);

    List<BidDatum> selectByExample(BidDatumExample example);

    BidDatum selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") BidDatum record, @Param("example") BidDatumExample example);

    int updateByExample(@Param("record") BidDatum record, @Param("example") BidDatumExample example);

    int updateByPrimaryKeySelective(BidDatum record);

    int updateByPrimaryKey(BidDatum record);


    /**
     * 个人新增
     * @return
     */
	List<BidDatum> selectbidDatumList();

}