package com.gmadong.modules.projectDesigneds;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.product.ProductExample;
import com.gmadong.modules.projectDesigneds.ProjectDesignedsExample.Criteria;
import com.gmadong.modules.user.User;
import com.gmadong.modules.usercollection.UserCollection;
import com.gmadong.modules.usercollection.UserCollectionExample;

@Service("projectDesignedsQdService")
public class ProjectDesignedsQdServiceImpl implements ProjectDesignedsQdService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private ProjectDesignedsMapper projectDesignedsMapper;
	

	@Override
	public boolean save(ProjectDesigneds projectDesigneds)
	{
		boolean flag = projectDesignedsMapper.insert(projectDesigneds) > 0;
		return flag;
	}


	@Override
	public Page page(String userId, Integer page, Integer rows) {
		ProjectDesignedsExample projectDesignedsExample = new ProjectDesignedsExample();
		Criteria createCriteria = projectDesignedsExample.createCriteria();
		if (!StringUtil.isEmpty(userId)) {
			createCriteria.andUserIdEqualTo(userId);
		}
		projectDesignedsExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<ProjectDesigneds> list = projectDesignedsMapper.selectByExample(projectDesignedsExample);
		PageInfo<ProjectDesigneds> pageInfo = new PageInfo<ProjectDesigneds>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}


	@Override
	public ProjectDesigneds selectByBiddingInfoId(String userId,String biddingInfoId) {
		ProjectDesignedsExample projectDesignedsExample = new ProjectDesignedsExample();
		Criteria createCriteria = projectDesignedsExample.createCriteria();
		if (!StringUtil.isEmpty(userId)) {
			createCriteria.andUserIdEqualTo(userId);
		}
		if (!StringUtil.isEmpty(biddingInfoId)) {
			createCriteria.andBiddinginfoIdEqualTo(biddingInfoId);
		}
		projectDesignedsExample.setOrderByClause("ctime DESC");
		List<ProjectDesigneds> list = projectDesignedsMapper.selectByExample(projectDesignedsExample);
		if(list.size() > 0) {
			return list.get(0);
		}
			return null;
	}


	@Override
	public Integer selectDesignedsCountByUserId(String userId) {
		// TODO Auto-generated method stub
		return projectDesignedsMapper.selectDesignedsCountByUserId(userId);
	}


}

