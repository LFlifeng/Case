package com.gmadong.modules.systemInfo;

import com.gmadong.common.Page;

public interface SystemInfoService
{
	public Page page(String companyName,String companyPhone,String companySite,String ctime,Integer page,Integer rows);
	public boolean save(SystemInfo systemInfo);
	public boolean update(SystemInfo systemInfo);
	public SystemInfo getSystemInfoById(String id);
	public boolean deleteById(String ids);
	public SystemInfo getSystemInfo();
}
