package com.gmadong.modules.user;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;
/**
 * 账号信息实体类
 * @author Administrator
 *
 */
public class Account {
	@NotBlank(message = "头像不能为空!", groups = { ValidatebAccountEditAction.class })
	@Size(min = 0, max = 100, message = "请输入上传正确的头像!", groups = { ValidatebAccountEditAction.class })
	private String portrait;
	
	@NotBlank(message = "头像路径不能为空!", groups = { ValidatebAccountEditAction.class })
	private String portraitUrl;
	
	@NotBlank(message = "昵称不能为空!", groups = { ValidatebAccountEditAction.class })
	@Size (min=1,max=50,message="请输入正确的昵称!" ,groups = { ValidatebAccountEditAction.class })
	private String nickName;
	
	@NotBlank(message = "年份不能为空!", groups = { ValidatebAccountEditAction.class })
	@Size(min = 4, max = 4, message = "请输入正确的年份!", groups = { ValidatebAccountEditAction.class })
	private String year;
	
	@NotBlank(message = "月份不能为空!", groups = { ValidatebAccountEditAction.class })
	@Size(min = 2, max = 2, message = "请输入正确的月份!", groups = { ValidatebAccountEditAction.class })
	private String month;
	
	@NotBlank(message = "日期不能为空!", groups = { ValidatebAccountEditAction.class })
	@Size(min = 2, max = 2, message = "请输入正确的日期!", groups = { ValidatebAccountEditAction.class })
	private String date;
	
	@NotBlank(message = "性别不能为空!", groups = { ValidatebAccountEditAction.class })
	@Size(min = 0, max = 1, message = "请输入正确的性别!", groups = { ValidatebAccountEditAction.class })
	private String sex;

	public String getPortrait() {
		return portrait;
	}

	public void setPortrait(String portrait) {
		this.portrait = portrait;
	}

	public String getPortraitUrl() {
		return portraitUrl;
	}

	public void setPortraitUrl(String portraitUrl) {
		this.portraitUrl = portraitUrl;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

}
