package com.gmadong.modules.designedinfo;

import com.gmadong.modules.designedinfo.Designedinfo;
import com.gmadong.modules.designedinfo.DesignedinfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DesignedinfoMapper {
    int countByExample(DesignedinfoExample example);

    int deleteByExample(DesignedinfoExample example);

    int deleteByPrimaryKey(String id);

    int insert(Designedinfo record);

    int insertSelective(Designedinfo record);

    List<Designedinfo> selectByExample(DesignedinfoExample example);

    Designedinfo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") Designedinfo record, @Param("example") DesignedinfoExample example);

    int updateByExample(@Param("record") Designedinfo record, @Param("example") DesignedinfoExample example);

    int updateByPrimaryKeySelective(Designedinfo record);

    int updateByPrimaryKey(Designedinfo record);
    
    //个人新增
	List<DesignedInfoVO> selectByUserId(@Param("id") String userId);
    
    
}