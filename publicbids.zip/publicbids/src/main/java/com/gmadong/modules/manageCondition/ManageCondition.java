package com.gmadong.modules.manageCondition;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class ManageCondition {
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebManageConditionEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebManageConditionEditAction.class} )
    private String id;

    private String userId;

    /** 经营年限 */
    @NotBlank(message="经营年限不能为空!" ,groups = {ValidatebManageConditionAddAction.class,ValidatebManageConditionEditAction.class})
    @Size (min=4,max=19,message="请输入正确的经营年限!" ,groups = {ValidatebManageConditionAddAction.class,ValidatebManageConditionEditAction.class})
    private String operations;

    /** 主营产品 */
    @NotBlank(message="主营产品不能为空!" ,groups = {ValidatebManageConditionAddAction.class,ValidatebManageConditionEditAction.class})
    @Size (min=1,max=200,message="请输入正确的主营产品!" ,groups = {ValidatebManageConditionAddAction.class,ValidatebManageConditionEditAction.class})
    private String product;

    /** 所属行业 */
    @NotBlank(message="所属行业不能为空!" ,groups = {ValidatebManageConditionAddAction.class,ValidatebManageConditionEditAction.class})
    @Size (min=1,max=100,message="请输入正确的所属行业!" ,groups = {ValidatebManageConditionAddAction.class,ValidatebManageConditionEditAction.class})
    private String industry;

    /** 销售额 */
    @NotBlank(message="销售额不能为空!" ,groups = {ValidatebManageConditionAddAction.class,ValidatebManageConditionEditAction.class})
    @Size (min=1,max=10,message="请输入正确的销售额!" ,groups = {ValidatebManageConditionAddAction.class,ValidatebManageConditionEditAction.class})
    private String sale;
    private String ctime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    /**
     * 经营年限
     * @return operations
     */
    public String getOperations() {
        return operations;
    }

    /**
     * 经营年限
     * @param operations
     */
    public void setOperations(String operations) {
        this.operations = operations == null ? null : operations.trim();
    }

    /**
     * 主营产品
     * @return product
     */
    public String getProduct() {
        return product;
    }

    /**
     * 主营产品
     * @param product
     */
    public void setProduct(String product) {
        this.product = product == null ? null : product.trim();
    }

    /**
     * 所属行业
     * @return industry
     */
    public String getIndustry() {
        return industry;
    }

    /**
     * 所属行业
     * @param industry
     */
    public void setIndustry(String industry) {
        this.industry = industry == null ? null : industry.trim();
    }

    /**
     * 销售额
     * @return sale
     */
    public String getSale() {
        return sale;
    }

    /**
     * 销售额
     * @param sale
     */
    public void setSale(String sale) {
        this.sale = sale == null ? null : sale.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }
}