package com.gmadong.modules.log;

import com.gmadong.modules.log.SysStaffLog;
import com.gmadong.modules.log.SysStaffLogExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SysStaffLogMapper {
    int countByExample(SysStaffLogExample example);

    int deleteByExample(SysStaffLogExample example);

    int deleteByPrimaryKey(String staffLogId);

    int insert(SysStaffLog record);

    int insertSelective(SysStaffLog record);

    List<SysStaffLog> selectByExample(SysStaffLogExample example);

    SysStaffLog selectByPrimaryKey(String staffLogId);

    int updateByExampleSelective(@Param("record") SysStaffLog record, @Param("example") SysStaffLogExample example);

    int updateByExample(@Param("record") SysStaffLog record, @Param("example") SysStaffLogExample example);

    int updateByPrimaryKeySelective(SysStaffLog record);

    int updateByPrimaryKey(SysStaffLog record);
}