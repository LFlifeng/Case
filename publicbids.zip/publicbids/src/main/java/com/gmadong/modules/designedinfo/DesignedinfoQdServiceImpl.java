package com.gmadong.modules.designedinfo;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.designedinfo.DesignedinfoExample.Criteria;
import com.gmadong.modules.product.ProductExample;
import com.gmadong.modules.user.User;
import com.gmadong.modules.usercollection.UserCollection;
import com.gmadong.modules.usercollection.UserCollectionExample;

@Service("designedinfoQdService")
public class DesignedinfoQdServiceImpl implements DesignedinfoQdService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private DesignedinfoMapper designedinfoMapper;

	@Override
	public Page page(String userId, Integer page, Integer rows) {
		PageHelper.startPage(page, rows);
		List<DesignedInfoVO> list = designedinfoMapper.selectByUserId(userId);
		PageInfo<DesignedInfoVO> pageInfo = new PageInfo<DesignedInfoVO>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean addDesignedinfo(Designedinfo designedinfo) {
		boolean flag = designedinfoMapper.insert(designedinfo) > 0;
		return flag;
	}

}

