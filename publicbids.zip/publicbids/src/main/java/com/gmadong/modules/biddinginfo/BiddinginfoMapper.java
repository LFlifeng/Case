package com.gmadong.modules.biddinginfo;

import com.gmadong.modules.biddinginfo.Biddinginfo;
import com.gmadong.modules.biddinginfo.BiddinginfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BiddinginfoMapper {
	int countByExample(BiddinginfoExample example);

	int deleteByExample(BiddinginfoExample example);

	int deleteByPrimaryKey(String id);

	int insert(Biddinginfo record);

	int insertSelective(Biddinginfo record);

	List<Biddinginfo> selectByExampleWithBLOBs(BiddinginfoExample example);

	List<Biddinginfo> selectByExample(BiddinginfoExample example);

	Biddinginfo selectByPrimaryKey(String id);

	int updateByExampleSelective(@Param("record") Biddinginfo record, @Param("example") BiddinginfoExample example);

	int updateByExampleWithBLOBs(@Param("record") Biddinginfo record, @Param("example") BiddinginfoExample example);

	int updateByExample(@Param("record") Biddinginfo record, @Param("example") BiddinginfoExample example);

	int updateByPrimaryKeySelective(Biddinginfo record);

	int updateByPrimaryKeyWithBLOBs(Biddinginfo record);

	int updateByPrimaryKey(Biddinginfo record);

	// 自己添加的
	List<Biddinginfo> selectBidingInfoByType(@Param("projectType") String projectType);

	List<BidsInfo> selectBidingByParamsInfo(BidsParamsInfo record);


}