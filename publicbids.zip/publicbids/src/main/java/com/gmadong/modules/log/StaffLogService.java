package com.gmadong.modules.log;

public interface StaffLogService 
{
	/**
	 * 添加日志
	 * @param recordId
	 * @param keyword
	 * @param content
	 */
	public void log(String staffId,String recordId, String keyword, String content);
}
