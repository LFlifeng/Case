package com.gmadong.modules.designedinfo;

import com.gmadong.common.Page;


public interface DesignedinfoService
{
	public Page page(String id,Integer page,Integer rows);
	//id找专盯
	public Designedinfo getProjectId(String projectId);
	/**
	 * 根据专盯情况查找专盯
	 * @param designedinfo 专盯情况
	 * @return
	 */
	public Designedinfo getDesignedinfo(String designedinfo);
	
	public boolean save(Designedinfo designedinfo);
	public boolean deleteById(String ids);
}
