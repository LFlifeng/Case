package com.gmadong.modules.company;

import java.util.List;

import com.gmadong.common.Page;

public interface CompanyService {
	public Page page(String title,String state,String legalPerson,String creditCode,String number,String ctime,Integer page, Integer rows);

	public List<Company> getParent();

	public boolean deleteById(String ids);

	public boolean save(Company company);

	public boolean update(Company company);

	public Company getCompanyById(String id);

	public Company getCompanyByStaffId(String id);

	public Company selectByStaffIdKey(String id);

	public List<Company> findFamousCompany();

}
