package com.gmadong.modules.designedinfo;

import com.gmadong.common.Page;


public interface DesignedinfoQdService
{

	Page page(String userId, Integer page, Integer rows);

	boolean addDesignedinfo(Designedinfo designedinfo);

}
