package com.gmadong.modules.columnCategory;

import java.util.List;

import com.gmadong.common.Page;
import com.gmadong.modules.staff.SysStaff;

public interface ColumnCategoryService {
	
	public boolean save(String columnName, String url, String pId,String sortIndex);
	public Page page(String columnName,String url,String ctime,Integer page,Integer rows);
	public List<ColumnCategory> getParent();
	public boolean deleteById(String ids);
	public boolean update(ColumnCategory category);
	public ColumnCategory getColumnCategoryById(String id);
	
	public List<ColumnCategoryMiniInfo> getMiniInfo();
}
