package com.gmadong.modules.company;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gmadong.common.Common;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.bids.Bids;
import com.gmadong.modules.category.CategoryService;
import com.gmadong.modules.city.SysCityService;
import com.gmadong.modules.industry.IndustryService;
import com.gmadong.modules.user.LoginUserInfo;
import com.gmadong.modules.user.User;
import com.gmadong.modules.user.UserCenterController;
import com.gmadong.modules.user.UserService;

@Controller
public class CompanyQdController {

	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private CompanyService companyService;
	@Autowired
	private IndustryService industryService;
	@Autowired
	private SysCityService sysCityService;
	private String listkey = "company.list.action";

	// 修改用户公司属性
	@RequestMapping("/company.auditing.do")
	public void updateByCompany(HttpServletResponse response, HttpServletRequest req,@Validated({ValidatebCompanyUpdateAction.class})Company company,BindingResult bindingResult) {
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		try {
			User user = (User) Session.get("user");	
			company.setStaffId(user.getId());
			company.setState("3");
			boolean a = companyService.update(company);
			if (a) {
				try {
					jedisClientSingle.hdel(UserCenterController.key,user.getId());
					jedisClientSingle.del("company.list.action");
				} catch (Exception e) {
				}
				AjaxUtil.write("succ", response);

			} else {
				AjaxUtil.write("fail", response);
			}

		} catch (Exception e) {
		}

	}
	
	/**
	 * 查询名企
	 * @param response
	 */
	@RequestMapping("/company.famousCompany.do")
	public void findFamousCompany(HttpServletResponse response) {
		String key = "company.famousCompany.list";
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Company> list = companyService.findFamousCompany();
		String listStr = JsonUtil.listToJson(list);
		try {
			jedisClientSingle.set(key, listStr, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
		return;
	}
	

}
