package com.gmadong.modules.tracker;

import com.gmadong.modules.tracker.Tracker;
import com.gmadong.modules.tracker.TrackerExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TrackerMapper {
    int countByExample(TrackerExample example);

    int deleteByExample(TrackerExample example);

    int deleteByPrimaryKey(String id);

    int insert(Tracker record);

    int insertSelective(Tracker record);

    List<Tracker> selectByExample(TrackerExample example);

    Tracker selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") Tracker record, @Param("example") TrackerExample example);

    int updateByExample(@Param("record") Tracker record, @Param("example") TrackerExample example);

    int updateByPrimaryKeySelective(Tracker record);

    int updateByPrimaryKey(Tracker record);
}