package com.gmadong.modules.attach;

import com.gmadong.modules.attach.SysAttach;
import com.gmadong.modules.attach.SysAttachExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SysAttachMapper {
    int countByExample(SysAttachExample example);

    int deleteByExample(SysAttachExample example);

    int deleteByPrimaryKey(String attachId);

    int insert(SysAttach record);

    int insertSelective(SysAttach record);

    List<SysAttach> selectByExample(SysAttachExample example);

    SysAttach selectByPrimaryKey(String attachId);

    int updateByExampleSelective(@Param("record") SysAttach record, @Param("example") SysAttachExample example);

    int updateByExample(@Param("record") SysAttach record, @Param("example") SysAttachExample example);

    int updateByPrimaryKeySelective(SysAttach record);

    int updateByPrimaryKey(SysAttach record);
}