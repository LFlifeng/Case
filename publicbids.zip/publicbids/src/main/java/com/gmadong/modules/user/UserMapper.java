package com.gmadong.modules.user;

import com.gmadong.modules.company.Company;
import com.gmadong.modules.user.User;
import com.gmadong.modules.user.UserExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserMapper {
    int countByExample(UserExample example);

    int deleteByExample(UserExample example);

    int deleteByPrimaryKey(String id);

    int insert(User record);

    int insertSelective(User record);

    List<User> selectByExample(UserExample example);

    User selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") User record, @Param("example") UserExample example);

    int updateByExample(@Param("record") User record, @Param("example") UserExample example);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);
    
  //自己加的方法
    String getNicknameByPrimaryKey(String id);
    
    //自己加的方法
    String getPhoneByPrimaryKey(String id);
    
    int updateByPassword(@Param("id")String id,@Param("password")String password);
    
    //根据用户名查询用户
    User selectUserByName(String name);
    //修改登录时间
    int updateByltime(@Param("phone")String phone,@Param("dtime")String dtime);
    //注册功能:根据用户手机号查询用户
    User selectUserByPhone(String phone);
    //注册用户添加用户信息用户表
	int insertUserQdUregister(User user);
	//注册功能添加用户关联的公司company表
	int insertUserQdMregister(Company company);

	int updateByPhone(@Param("phone")String phone, @Param("id")String id);

	int updateByEmail(@Param("emailAddress")String email, @Param("id")String id);

	User selectUserByEmail(@Param("emailAddress")String email);
	
	List<UserInfo> getNotificationList();
}