package com.gmadong.modules.designedinfo;

import com.gmadong.common.utils.FileUtil;

/**
 * 项目专盯-专项信息关联查询模型
 * @author Administrator
 *
 */
public class DesignedInfoVO {

	private String id;

	/** 项目名称 */
	private String projectsName;
	
	/** 专盯情况 */
	private String designedinfo;

	/** 跟进人 */
	private String people;

	/** 备注 */
	private String remark;

	/**附件 */
	private String uploadAttachment;
	
	/**附件地址 */
	private String uploadAttachmentUrl;
	
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProjectsName() {
		return projectsName;
	}

	public void setProjectsName(String projectsName) {
		this.projectsName = projectsName;
	}

	public String getDesignedinfo() {
		return designedinfo;
	}

	public void setDesignedinfo(String designedinfo) {
		this.designedinfo = designedinfo;
	}

	public String getPeople() {
		return people;
	}

	public void setPeople(String people) {
		this.people = people;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getUploadAttachment() {
		return uploadAttachment;
	}

	public void setUploadAttachment(String uploadAttachment) {
		this.uploadAttachmentUrl = "/upload/attach"+FileUtil.getPath(uploadAttachment)+uploadAttachment;
		this.uploadAttachment = uploadAttachment;
	}
	
	
}
