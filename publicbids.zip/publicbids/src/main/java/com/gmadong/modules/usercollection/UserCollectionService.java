package com.gmadong.modules.usercollection;


import com.gmadong.common.Page;

public interface UserCollectionService {

	Page page(String userId, Integer page, Integer rows);

	boolean deleteById(String id);

	boolean save(UserCollection userCollection);

	UserCollection selectByBiddingInfoId(String biddingInfoId);





}
