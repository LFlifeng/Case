package com.gmadong.modules.systemMsg;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.systemMsg.SystemMsgExample.Criteria;

@Service("systemMsgQdService")
public class SystemMsgQdServiceImpl implements SystemMsgQdService
{

	@Autowired
	SystemMsgMapper systemMsgMapper;
	
	public Page page(String id,String type ,String day,Integer page, Integer rows)
	{
		
		if(StringUtil.isEmpty(type) || StringUtil.isEmpty(id))
		{
			return Page.getEmptyPage();
		}
		SystemMsgExample systemMsgExample = new SystemMsgExample(); 
		Criteria criteria = systemMsgExample.createCriteria();
		criteria.andUserIdEqualTo(id);
		criteria.andTypeEqualTo(type);
		Criteria criteria1 = systemMsgExample.createCriteria();
		criteria1.andStateEqualTo("0");
		criteria1.andTypeEqualTo(type);
		criteria1.andCtimeGreaterThan(day);
		systemMsgExample.or(criteria1);
		PageHelper.startPage(page, rows);
		List<SystemMsg> list=systemMsgMapper.selectByExample(systemMsgExample);
		PageInfo<SystemMsg> pageInfo = new PageInfo<SystemMsg>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}
	
	public boolean deleteSystemById(String id) 
	{
		if(StringUtil.isEmpty(id)) {
			return false;
		}
		SystemMsgExample systemMsgExample = new SystemMsgExample(); 
		Criteria criteria = systemMsgExample.createCriteria();
		criteria.andIdEqualTo(id);
		criteria.andStateNotEqualTo("0");
		return systemMsgMapper.deleteByExample(systemMsgExample) >0;
	}
	
}









