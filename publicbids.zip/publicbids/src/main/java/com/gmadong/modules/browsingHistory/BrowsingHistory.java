package com.gmadong.modules.browsingHistory;

public class BrowsingHistory {
    private String id;

    private String userId;

    private String biddinginfoId;

    private String biddinginfoTitle;

    private String ctime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public String getBiddinginfoId() {
        return biddinginfoId;
    }

    public void setBiddinginfoId(String biddinginfoId) {
        this.biddinginfoId = biddinginfoId == null ? null : biddinginfoId.trim();
    }

    public String getBiddinginfoTitle() {
        return biddinginfoTitle;
    }

    public void setBiddinginfoTitle(String biddinginfoTitle) {
        this.biddinginfoTitle = biddinginfoTitle == null ? null : biddinginfoTitle.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }
}