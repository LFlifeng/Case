package com.gmadong.modules.application;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.city.SysCityService;
import com.gmadong.modules.company.Company;
import com.gmadong.modules.industry.IndustryService;
import com.gmadong.modules.user.User;

@Controller
public class ApplicationQdController
{

	@Autowired
	ApplicationQdService applicationQdService;
	@Autowired
	SysCityService sysCityService;
	@Autowired
	IndustryService industryService; 
	@Autowired
	ApplicationService applicationService;
	@Autowired
	JedisClientSingle jedisClientSingle; 
	private  String key="application.entry.do";
	
	/**
	 * 首页供应商页面跳转
	 * 
	 * @return
	 */
	@RequestMapping("/application.listIndex.do")
	public String page() {
		return "/front/application/supplier";
	}

	/**
	 * 产品展示
	 */
	@RequestMapping("/application.listShow.do")
	public String preAdd() 
	{
		return "/front/application/p-productdisplay";
	}

	/**
	 * 查询首页优秀供应商
	 * @param response
	 */
	@RequestMapping("application.excellentSuppliers.do")
	public void findExcellentSuppliers(HttpServletResponse response) {
		String key = "application.excellentSuppliers.list";
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		List<ExcellentApplication> list = applicationQdService.findTopFamousCompany();
		String listStr = JsonUtil.listToJson(list);
		try {
			jedisClientSingle.set(key, listStr, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
		return;
	}
	
	
	/**
	 * 跳转到供应商库中的申请入驻
	 */
	@RequestMapping("application.entry.do")
	public String selectApplication() 
	{
		  User user=(User)Session.get("user");
		     //从redis中获取用户申请入驻的信息
		try
		{
			String application = jedisClientSingle.hget(key,user.getId());
			Application app=null;
			if(StringUtil.isNotEmpty(application)) 
			{
				ObjectMapper mapper=new ObjectMapper();
				app=mapper.readValue(application,Application.class);
                Request.set("application",app);
                return "/front/application/p-application";
			}
			
		} catch (Exception e)
		{
		}
		 /*根据用户id查询当前的申请入驻*/
		 Application app=applicationQdService.selectByUserId(user.getId());	
		 Request.set("application", app);
		 try
		{
			 jedisClientSingle.hset(key,user.getId(),JsonUtil.bean2json(app),Common.REDIS_48_HOUR_EXPIRE);
		} catch (Exception e)
		{
		}     
		return "/front/application/p-application";
	}
	
	/* 申请入驻上传审核 */
	@RequestMapping("application.uploadAudt.do")
	public void updateUploadAudit(HttpServletResponse res,@Validated({ValidatebApplicationUpdateAction.class})Application application,BindingResult bindingResult) {
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),res);
			return;
		}
		User user=(User)Session.get("user");
		//修改上传审批功能
		application.setUserId(user.getId());
		application.setState("3");
		boolean  state=applicationQdService.updateUploadAudit(application);
		if(state) 
		{
			 try
			{
				 	jedisClientSingle.hdel(key,user.getId());
				 	jedisClientSingle.del("application.list.action");
				 	
			} catch (Exception e)
			{
			}
			        AjaxUtil.write("succ", res);
		}else {
					AjaxUtil.write("fail", res);
		}
	}
	
	/**
	 * 查询优秀供应商
	 */
	@RequestMapping("application.findExcellentApplication.do")
	public void findExcellentApplication(HttpServletResponse response,@RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "5") Integer rows) {
		String key = "application.findExcellentApplication.do";
		String field = page + "-" + rows;
		try {
			String listStr = jedisClientSingle.hget(key,field);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = applicationQdService.page(page,rows);
		String listStr = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(key,field,listStr, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
		return;
	}
	



	/**
	 * 供应商公司展示页面跳转
	 */
	@RequestMapping("/application.applicationShow.do")
	public String applicationShow(String id) {
		 Request.set("applicationId",id);
		return "/front/application/companyShow";
	}

	/**
	 * 查询供应商联系我们
	 */
	@RequestMapping("application.companyContactInfo.do")
	public void companyContactInfo(HttpServletResponse response,String applicationId) {
		String key = "application.companyContactInfo.do";
		String field = applicationId;
		try {
			String listStr = jedisClientSingle.hget(key,field);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Application application = applicationQdService.selectCompanyById(applicationId);
		String listStr = JsonUtil.bean2json(application);
		try {
			jedisClientSingle.hset(key,field,listStr, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
		return;
	}
	
	/**
	 * 查询名企
	 * @param response
	 */
	@RequestMapping("/application.famousCompany.do")
	public void findFamousCompany(HttpServletResponse response) {
		String key = "application.famousCompany.list";
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		List<ExcellentApplication> list = applicationQdService.findFamousCompany();
		String listStr = JsonUtil.listToJson(list);
		try {
			jedisClientSingle.set(key, listStr, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
		return;
	}
	
	/**
	 * 查询名企采购墙
	 * @param response
	 */
	@RequestMapping("/application.famousCompanyWall.do")
	public void findFamousCompanyWall(HttpServletResponse response) {
		String key = "application.famousCompanyWall.list";
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		List<ExcellentApplication> list = applicationQdService.findFamousCompanyWall();
		String listStr = JsonUtil.listToJson(list);
		try {
			jedisClientSingle.set(key, listStr, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
		return;
	}
	
}
























