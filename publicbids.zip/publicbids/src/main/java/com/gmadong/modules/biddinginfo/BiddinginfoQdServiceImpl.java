package com.gmadong.modules.biddinginfo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.datasource.CustomerContextHolder;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.application.Application;
import com.gmadong.modules.application.ApplicationMapper;
import com.gmadong.modules.biddinginfo.BiddinginfoExample.Criteria;
import com.gmadong.modules.bids.Bids;
import com.gmadong.modules.bids.BidsExample;
import com.gmadong.modules.company.CompanyMapper;
import com.gmadong.modules.news.NewsQdService;

@Service("biddinginfoQdService")
public class BiddinginfoQdServiceImpl implements BiddinginfoQdService {
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private BiddinginfoMapper biddinginfoMapper;
	@Autowired
	private ApplicationMapper applicationMapper;
	
	@Override
	public Page page(String name, String type, String ctime, String province, String industry, Integer page,
			Integer rows) {

		BiddinginfoExample biddinginfoExample = new BiddinginfoExample();
		Criteria createCriteria = biddinginfoExample.createCriteria();
		if (!StringUtil.isEmpty(type)) {
			createCriteria.andProjectTypeEqualTo(type);
		}
		if (!StringUtil.isEmpty(name)) {
			createCriteria.andProjectNameLike("%" + name + "%");
		}
		if (!StringUtil.isEmpty(ctime)) {
			createCriteria.andCtimeGreaterThanOrEqualTo(ctime);
		}
		if (!StringUtil.isEmpty(province)) {
			createCriteria.andProvinceLike(province + "%");
		}
		if (!StringUtil.isEmpty(industry)) {
			createCriteria.andIndustryOneLike("%" + industry + "%");
		}
		createCriteria.andStateEqualTo("1");
		biddinginfoExample.setOrderByClause("ctime desc");
		PageHelper.startPage(page, rows);
		List<Biddinginfo> list = biddinginfoMapper.selectByExample(biddinginfoExample);
		PageInfo<Biddinginfo> pageInfo = new PageInfo<Biddinginfo>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public Biddinginfo details(String id) {
		return biddinginfoMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<Biddinginfo> findBidingInfoByType(String proType) {
		List<Biddinginfo> list = biddinginfoMapper.selectBidingInfoByType(proType);
		if(list.size() > 0) {
			return list;
		}
		return null;
	}

	@Override
	public boolean save(Biddinginfo biddinginfo) {
		biddinginfo.setId(UUIDUtil.getUUID());
		biddinginfo.setCtime(DateUtil.getCurrentDate());
		boolean flag = biddinginfoMapper.insert(biddinginfo) > 0;
		return flag;
	}

	@Override
	public boolean deleteById(String id) {
		if(biddinginfoMapper.deleteByPrimaryKey(id) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public Page pageUser(String userId, Integer page, Integer rows) {

		BiddinginfoExample biddinginfoExample = new BiddinginfoExample();
		Criteria createCriteria = biddinginfoExample.createCriteria();
		if (!StringUtil.isEmpty(userId)) {
			createCriteria.andUserIdEqualTo(userId);
		}
		PageHelper.startPage(page, rows);
		List<Biddinginfo> list = biddinginfoMapper.selectByExample(biddinginfoExample);
		PageInfo<Biddinginfo> pageInfo = new PageInfo<Biddinginfo>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public Page pageCompany(String applicationId, Integer page, Integer rows) {
		BiddinginfoExample biddinginfoExample = new BiddinginfoExample();
		Criteria createCriteria = biddinginfoExample.createCriteria();
		if (!StringUtil.isEmpty(applicationId)) {
			Application application = applicationMapper.selectByPrimaryKey(applicationId);
			String userId =application.getUserId();
			if(!StringUtil.isEmpty(userId)) {
				createCriteria.andUserIdEqualTo(userId);
				createCriteria.andStateEqualTo("1");
			}else {
				return null;
			}
		}
		PageHelper.startPage(page, rows);
		List<Biddinginfo> list = biddinginfoMapper.selectByExample(biddinginfoExample);
		PageInfo<Biddinginfo> pageInfo = new PageInfo<Biddinginfo>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}



}
