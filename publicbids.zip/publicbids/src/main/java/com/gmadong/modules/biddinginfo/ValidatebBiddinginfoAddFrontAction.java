package com.gmadong.modules.biddinginfo;

public interface ValidatebBiddinginfoAddFrontAction
{

}
