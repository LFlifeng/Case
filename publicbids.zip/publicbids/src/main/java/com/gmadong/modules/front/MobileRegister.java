package com.gmadong.modules.front;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class MobileRegister
{
	@NotBlank(message="手机号码不能为空!")
    @Size (min=11,max=15,message="请输入正确的手机号码!")
    private String phone;
	
	public String getCode()
	{
		return code;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	/** 验证码*/
	@Size (min=5,max=5,message="请输入正确的验证码")
	private String code;
	

	public String getPhone()
	{
		return phone;
	}

	public void setPhone(String phone)
	{
		this.phone = phone;
	}
}
