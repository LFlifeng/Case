package com.gmadong.modules.bidsCategory;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.XSSUtils;

/**
 * 招标分类
 * @author caodongdong
 *
 */
@Controller
public class BidsCategoryController 
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private BidsCategoryService bidsCategoryService;
	private static final String key = "bidsCategory.list.action";

	@RequestMapping("/bidsCategory.page.action")
	public String page()
	{
		return "/back/bidsCategory/page";
	}
	@RequestMapping("/bidsCategory.list.action")
	public void list(HttpServletResponse response,String name,String ctime,String level,@RequestParam(defaultValue="1") Integer page,@RequestParam(defaultValue="10") Integer rows)
	{
		String field = name+"_"+ctime+"_"+level+"_"+page+"_"+rows;
		try 
		{
			String list = jedisClientSingle.hget(key, field);
			if(StringUtil.isNotEmpty(list))
			{
				AjaxUtil.write(list,response);
				return;
			}
			
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
		Page toPage = bidsCategoryService.list(name, ctime, level, page, rows);
		String list =  Page.pageToJson(toPage);
		try
		{
			jedisClientSingle.hset(key, field, list,Common.REDIS_48_HOUR_EXPIRE);
			
		}catch (Exception e) 
		{
			e.printStackTrace();
		}
		AjaxUtil.write(list,response);
	}
	@RequestMapping("/bidsCategory.preAdd.action")
	public String preAdd()
	{
		List<BidsCategory> list = bidsCategoryService.getParentCategorys();
		Request.set("categorys", list);
		return "/back/bidsCategory/add";
	}
	@RequestMapping("/bidsCategory.doAdd.action")
	public void doAdd(HttpServletResponse response,@Validated({ ValidatebBidCategoryAddAction.class }) BidsCategory category,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		XSSUtils.clearXss(BidsCategory.class, category);
		if(bidsCategoryService.save(category))
		{
			try
			{
				jedisClientSingle.del(key);
				jedisClientSingle.del(BidsCategoryQdController.key);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("添加失败！",response);
		}
	}
	@RequestMapping("/bidsCategory.preEdit.action")
	public String preEdit(String id)
	{	
		BidsCategory info = bidsCategoryService.getInfoById(id);
		if(info == null)
		{
			return "/common/500";
		}
		Request.set("info", info);
		List<BidsCategory> list = bidsCategoryService.getParentCategorys();
		Request.set("categorys", list);
		return "/back/bidsCategory/edit";
	}
	@RequestMapping("/bidsCategory.doEdit.action")
	public void doEdit(HttpServletResponse response,@Validated({ ValidatebBidCategoryEditAction.class }) BidsCategory category,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		XSSUtils.clearXss(BidsCategory.class, category);
		if(bidsCategoryService.edit(category))
		{
			try
			{
				jedisClientSingle.del(key);
				jedisClientSingle.del(BidsCategoryQdController.key);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("修改失败！",response);
		}
	}
	@RequestMapping("/bidsCategory.doDelete.action")
	public void doDelete(HttpServletResponse response,String ids)
	{
		if(bidsCategoryService.deleteByIds(ids))
		{
			try
			{
				jedisClientSingle.del(key);
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("fail",response);
		}
	}
	@RequestMapping("/bidsCategoryQd.doDelete.do")
    public void dodelete(HttpServletResponse response) {
		if(bidsCategoryService.deleteByIds(key))
		{
			try
			{
				jedisClientSingle.del(key);
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("fail",response);
		}
	}
}
