package com.gmadong.modules.biddinginfo;

import com.gmadong.common.utils.StringUtil;

public class BidsInfo
{
	private String id;
	private String projectType;
	private String projectName;
	private String province;
	private String city;
	private String ctime;
	
	public String getProjectType()
	{
		return projectType;
	}
	public void setProjectType(String projectType)
	{
		this.projectType = projectType;
	}
	public String getProjectName()
	{
		return projectName;
	}
	public void setProjectName(String projectName)
	{
		this.projectName = projectName;
	}
	public String getProvince()
	{
		return province;
	}
	public void setProvince(String province)
	{
		this.province = province;
	}
	public String getCity()
	{
		return city;
	}
	public void setCity(String city)
	{
		this.city = city;
	}
	public String getCtime()
	{
		return ctime;
	}
	public void setCtime(String ctime)
	{
		if(StringUtil.isNotEmpty(ctime))
		{
			this.ctime = ctime.substring(0, 10);
		}
		else
		{
			this.ctime = ctime;
		}
	}
	public String getId()
	{
		return id;
	}
	public void setId(String id)
	{
		this.id = id;
	}
	
	
	
}
