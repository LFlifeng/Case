package com.gmadong.modules.user;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.PasswordUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.common.utils.PasswordUtil.PasswordUtilType;
import com.gmadong.modules.application.Application;
import com.gmadong.modules.application.ApplicationMapper;
import com.gmadong.modules.category.Category;
import com.gmadong.modules.category.CategoryExample;
import com.gmadong.modules.company.Company;
import com.gmadong.modules.company.CompanyMapper;
import com.gmadong.modules.staff.SysStaff;
import com.gmadong.modules.staff.SysStaffExample;
import com.gmadong.modules.user.UserExample.Criteria;
@Service("userService")
public class UserServiceImpl implements UserService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private UserMapper userMapper;
	private static final String parentCategorysKey = "userMapper.ParentCategorys";
	@Autowired
	private CompanyMapper companyMapper;
	@Autowired
	private ApplicationMapper applicationMapper; 
	
	@Override
	public Page page(String personalOffice, String grade, String starttime,String endtime,String status,String name,Integer page, Integer rows)
	{
		UserExample userExample = new UserExample();
		Criteria createCriteria = userExample.createCriteria();
		
		if (!StringUtil.isEmpty(personalOffice)) {
			createCriteria.andPersonalOfficeLike(personalOffice + "%");
		}
		if (!StringUtil.isEmpty(grade)) {
			createCriteria.andGradeLike(grade + "%");
		}
		if (!StringUtil.isEmpty(starttime)) {
			createCriteria.andCtimeGreaterThan(starttime+" 00:00:00");
		}
		if (!StringUtil.isEmpty(endtime)) {
			createCriteria.andCtimeLessThan(endtime+" 23:00:00");
		}
		if (!StringUtil.isEmpty(status)) {
			createCriteria.andStatusLike(status + "%");
		}
		if (!StringUtil.isEmpty(name)) {
			createCriteria.andNameLike(name + "%");
		}
		userExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<User> list = userMapper.selectByExample(userExample);
		PageInfo<User> pageInfo = new PageInfo<User>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}


	@Override
	public List<User> getParent()
	{
		try {// 从缓存中得到数据
			String list = jedisClientSingle.get(parentCategorysKey);
			if (StringUtil.isNotEmpty(list)) {
				ObjectMapper mapper = new ObjectMapper();
				List<User> keys = mapper.readValue(list, new TypeReference<List<User>>() {
				});
				return keys;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		UserExample userExample = new UserExample();
		Criteria createCriteria = userExample.createCriteria();
		userExample.setOrderByClause("ctime DESC");
		List<User> selectByExample = userMapper.selectByExample(userExample);
		try {// 添加缓存
			jedisClientSingle.set(parentCategorysKey, JsonUtil.listToJson(selectByExample));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return selectByExample;
	}


	@Override
	public boolean save(User user)
	{
		user.setId(UUIDUtil.getUUID());
		user.setPassword(PasswordUtil.encrypt(user.getPassword(), PasswordUtilType.NORMAL));
		user.setCtime(DateUtil.getCurrentDate());
		
		Company company = new Company();
		
		boolean users = userMapper.insert(user) > 0;
		company.setNumber(user.getPhone());
		company.setTitle("");
		company.setContacts(user.getContacts());
		company.setStaffId(user.getId());
		company.setId(UUIDUtil.getUUID());
		company.setCtime(DateUtil.getCurrentDate());
		company.setState("0");
		boolean companys = companyMapper.insert(company) > 0;
		
		//注册成功新增关联申请入驻的用户信息
		Application application=new Application();
		application.setId(UUIDUtil.getUUID());
		application.setCtime(DateUtil.getCurrentDate());
		application.setUserId(user.getId());
		application.setState("0");
		boolean app=applicationMapper.insertSelective(application) > 0;
		
		if (users && companys && app) {
			return true;
		}
		return false;
	}


	@Override
	public boolean deleteById(String ids)
	{
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			UserExample userExample = new UserExample();
			Criteria createCriteria = userExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			return userMapper.deleteByExample(userExample) > 0;
		}
		return false;
	}


	@Override
	public boolean update(User user)
	{
		user.setCtime(null);
		user.setPassword(null);
		return userMapper.updateByPrimaryKeySelective(user) > 0;
	}


	@Override
	public User getUserById(String id)
	{
		return userMapper.selectByPrimaryKey(id);
	}


	@Override
	public User getUsername(String name)
	{
		if(StringUtil.isEmpty(name))
		{
			return null;
		}
		UserExample userExample = new UserExample();
		Criteria criteria = userExample.createCriteria();
		criteria.andNameEqualTo(name.trim());
	    List<User> selectByExample = userMapper.selectByExample(userExample);
		if (selectByExample.size()>0)
		{
			return selectByExample.get(0);
		}
		return null;
	}

	@Override
	public User getUseraccount(String phone)
	{
		if(StringUtil.isEmpty(phone))
		{
			return null;
		}
		UserExample userExample = new UserExample();
		Criteria criteria = userExample.createCriteria();
		criteria.andPhoneEqualTo(phone.trim());
	    List<User> selectByExample = userMapper.selectByExample(userExample);
		if (selectByExample.size()>0)
		{
			return selectByExample.get(0);
		}
		return null;
	}


	@Override
	public List<User> getUser(String nickname)
	{
		String field = nickname;
		try
		{
			String json = jedisClientSingle.hget(parentCategorysKey, field);
			if(StringUtil.isNotEmpty(json))
			{
				ObjectMapper mapper = new ObjectMapper();
				List<User> keys = mapper.readValue(json, new TypeReference<List<User>>() {
				});
				return keys;
			}
		} catch (Exception e)
		{}
		UserExample userExample = new UserExample();
		Criteria createCriteria = userExample.createCriteria();
		createCriteria.andNameEqualTo(nickname);
		userExample.setOrderByClause("sort_index");
		List<User> list = userMapper.selectByExample(userExample);
		try
		{
			jedisClientSingle.hset(parentCategorysKey, field, JsonUtil.listToJson(list));
		}
		catch (Exception e) 
		{}
		return list;
	}


	@Override
	public String getNicknameById(String id)
	{
		return userMapper.getNicknameByPrimaryKey(id);
	}


	@Override
	public boolean updates(String id,String password)
	{
		 password = PasswordUtil.encrypt(password, PasswordUtilType.NORMAL);
		 return userMapper.updateByPassword(id,password)>0;
	}


	@Override
	public String getPhoneById(String id)
	{
		return userMapper.getPhoneByPrimaryKey(id);
	}

	@Override
	public Page getNotificationList(Integer page,Integer rows)
	{	
		PageHelper.startPage(page, rows);
		List<UserInfo> list = userMapper.getNotificationList();
		PageInfo<UserInfo> pageInfo = new PageInfo<UserInfo>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}


	
}
