package com.gmadong.modules.user;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gmadong.common.Common;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.IPUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.Md5Util;
import com.gmadong.common.utils.PasswordUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.PasswordUtil.PasswordUtilType;
import com.gmadong.modules.company.Company;
import com.gmadong.modules.company.CompanyService;

/**
 * 
 * 用户登录和注册功能
 * @author Administrator
 *
 */
@Controller
public class UserQdController {
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private UserQdService userQdService;
	@Autowired
	private UserService userService;
	private String key = "userQd.list.action";
	@Autowired
	private CompanyService companyService;


	/**
	 * 登录界面
	 * @return
	 */
	@RequestMapping("/userQd.login.do")
	public String login(HttpServletResponse response,HttpServletRequest req)
	{
		return "/front/common/login";	
	}
	/***
	 *       登录功能
	 * @throws IOException 
	 */
	@RequestMapping(value="/userQd.doLogin.do",method=RequestMethod.POST)
	public  void login(HttpServletResponse response,HttpServletRequest req ,@Validated LoginUserInfo loginUser,BindingResult bindingResult) throws IOException
	{
		//获取用户ip用户限制用户登录允许错误次数
		String ip = "userQd.doLogin.do_"+IPUtil.getIpAddr(req);
		try
		{
			long count = jedisClientSingle.incr(ip);
			if(count==1)
			{
				jedisClientSingle.expire(ip, Common.REDIS_3_MINUTE_EXPIRE);
			}
			else if(count >= 5)
			{
				AjaxUtil.write("您已被限制登录，请稍候登录",response);
				return;
			}
			
		}catch(Exception e)
		{}
		
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		//用户存到redis中key的格式“userQd”+用户名，值去redis中获取用户信息
		String phone=loginUser.getPhone();
		String pwd=loginUser.getPassword();
		if(pwd.length()>12&&pwd.length()<32) 
		{
			AjaxUtil.write("用户名或密码错误,请您重新输入",response);
			return;
		}
		//判断是否点击记住密码,登录成功则将用户信息保存到cookie中并设置时间:fasle  true
		String remember=loginUser.getRemember();
		String key="userQd-"+phone;
		User user = null;
		
		try
		{
			String  userQd= jedisClientSingle.get(key);
			if(StringUtil.isNotEmpty(userQd))
			{
				ObjectMapper mapper = new ObjectMapper();
				user = mapper.readValue(userQd, User.class);
			}
			
		}catch(Exception e)
		{}
		if(user==null)
		{
			user =  userQdService.selectUserByPhone(phone);
		}
		if(user==null)
		{
			AjaxUtil.write("用户名或密码错误,请您重新输入",response);
			return;
		}
		if(checkPwd(user, pwd))
		{
			try
			{
				jedisClientSingle.set(key, JsonUtil.bean2json(user),Common.REDIS_6_HOUR_EXPIRE);
					
			}catch(Exception e)
			{}
			if(remember.equals("true")) 
			{
                  Cookie cookie2=new Cookie("user","{\"phone\":\""+user.getPhone()+"\",\"key\":\""+Md5Util.md5(user.getPassword()+user.getId())+"\"}");
                  cookie2.setMaxAge(60*60*24*7);
                  response.addCookie(cookie2);
			}else 
			{
				Cookie[] cks=req.getCookies();
				if(cks!=null) {
					for(Cookie c:cks) {
						c.setMaxAge(0);
						response.addCookie(c);
					}
				}
			}
			userQdService.updateByltime(user.getPhone(),DateUtil.getCurrentDate());
		//	user.setPassword("");
			req.getSession().invalidate();;
			req.getSession(true);
			Session.set("user",user);
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("用户名或密码错误,请您重新输入",response);
		}
	} 	
	
	/**
	    * 登录之后前台界面显示用户的信息
	 */
	@RequestMapping("/userQd.message.do")
      public void userMessage(HttpServletRequest req,HttpServletResponse res) 
	   {
    	  try
		{
    		  AjaxUtil.write(Session.getString("user"), res);  
		} catch (Exception e)
		{
			
		}
      }
	/**
	 * 注册界面
	 */
	@RequestMapping("/userQd.register.do")
	public String register() 
	{
      return "/front/common/registe";
	}
	
	
	
	/**
	   *  注册功能
	 */
//BindingResult bindingResult,@Validated
	@RequestMapping(value="/userQd.doregister.do",method=RequestMethod.POST)
	public void register(HttpServletResponse response,HttpServletRequest req ,@Validated UserQdRegister reg,BindingResult bindingResult)throws IOException
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
		}
		try
		{
			String code = jedisClientSingle.get(reg.getPhone());
			if(StringUtil.isEmpty(code) || !reg.getCode().equals(code))
			{
				
				AjaxUtil.write("请输入正确的验证码", response);
				return;
			}
			
		}catch(Exception e)
		{}
//		//如果执行成功
		try
		{
			//根据手机号查看是否被注册过
			User use =  userQdService.selectUserByPhone(reg.getPhone());
			if(use==null) {
				Boolean bool=userQdService.saveUserRegister(reg);
				if(bool) {
					
					try
					{
						jedisClientSingle.del("user.list.action");
						jedisClientSingle.del("company.list.action");
						jedisClientSingle.del("application.list.action");
						jedisClientSingle.del(reg.getPhone());
						
					} catch (Exception e)
					{}
					
					AjaxUtil.write("succ", response);
				}
			}else
			{
				AjaxUtil.write("该手机号已经注册", response);
			}
			
			//新增关联公司信息
		} catch (Exception e)
		{
			AjaxUtil.write("系统出错", response);
		}
	
		     
    }
	private boolean checkPwd(User user,String pwd)
	{
		if(pwd.length()==32 && pwd.equals(Md5Util.md5(user.getPassword()+user.getId())))
		{
			return true;
		}
		else if(user.getPassword().equals(PasswordUtil.encrypt(pwd, PasswordUtilType.NORMAL)))
		{
			return true;
		}
		
		return false;
	}
	
	/**
	 * 跳转到用户中心底部的"关于我们"
	 * @return
	 */
	@RequestMapping("/userQd.bottomMessage.do")
	public String bottomsMessage()
	{
		
		
		return "/front/usercenter/about";
	}

     /**
      * 跳转到会员服务里边的服务标准
      * @return
      */
	@RequestMapping("/userQd.serviceStandards.do")
	public String  serviceStandards(HttpServletResponse res,HttpServletRequest req)
	{
		User user=(User)Session.get("user");
		try
		{
			String string = jedisClientSingle.get(UserCenterController.key+user.getId());
			if(StringUtil.isNotEmpty(string)) 
			{
				ObjectMapper mapper = new ObjectMapper();
				Company company = mapper.readValue(string, Company.class);
				Request.set("company", company);
				return "/front/usercenter/p-server";
			}
		} catch (Exception e)
		{}
		Company company = companyService.getCompanyByStaffId(user.getId());
		req.setAttribute("company", company == null ? new Company() : company);
		return "/front/usercenter/p-server";
	}
	/**
     * 跳转到会员服务里边的付费指导
     * @return
     */
	@RequestMapping("/userQd.paymentInstruction.do")
	public String paymentInstruction()
	{
		
		return "/front/usercenter/p-payment";
	}
	
	
	
	/** 跳转到忘记密码1界面
	 */
	@RequestMapping("/userQd.foundpwd.do")
	public String foundpwd(String phone,String msg)
	{
		if(StringUtil.isNotEmpty(msg))
		{
			try
			{
				msg = URLDecoder.decode(msg, "utf-8");
				msg = new String(msg.getBytes("iso-8859-1"),"utf-8");
				
			} catch (UnsupportedEncodingException e)
			{
				e.printStackTrace();
			}
		}
		Request.set("msg", msg);
		Request.set("phone",phone);
		return "/front/usercenter/foundpwd";
		
	}
	
	
	/**忘记密码第一步提交
	 * 
	 * @param req
	 * @param res
	 * @param forgetPwd
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	
	
	@RequestMapping("/userQd.forgetpwd.do")
	public String forgetpwd(HttpServletRequest req,HttpServletResponse res,@Validated ForgetPwd forgetPwd,BindingResult bindingResult) throws Exception
	{
		//ip限定
		String ip = "userQd.forgetpwd.do_"+IPUtil.getIpAddr(req);
		try
		{
			long count = jedisClientSingle.incr(ip);
			if(count==1)
			{
				jedisClientSingle.expire(ip, Common.REDIS_30_MINUTE_EXPIRE);
			}
			else if(count >= 11)
			{
				return "redirect:/userQd.foundpwd.do?phone="+forgetPwd.getPhone()+"&msg="+URLEncoder.encode("您操作次数过于频繁，请30分钟之后在重试", "utf-8");
			}
			
		}catch(Exception e)
		{}
		
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			return "redirect:/userQd.foundpwd.do?phone="+forgetPwd.getPhone()+"&msg="+URLEncoder.encode(error.getDefaultMessage(),"utf-8");
		}
		
		//判断用户是否存在
		User use =  userQdService.selectUserByPhone(forgetPwd.getPhone());
		
		String code=(String)Session.get("code");
		
		if(use == null) 
		{
			return "redirect:/userQd.foundpwd.do?phone="+forgetPwd.getPhone()+"&msg="+URLEncoder.encode("请输入正确的账号","utf-8");
			
		}
		if((code.toUpperCase()).equals((forgetPwd.getYzm()).toUpperCase()))
		{
			Session.set("userTemp", use);
			return "redirect:/userQd.forgetPwd2.do";
		}
		
		return "redirect:/userQd.foundpwd.do?phone="+forgetPwd.getPhone()+"&msg="+URLEncoder.encode("请输入正确验证码", "utf-8");
	}
	/**跳转到忘记密码第二界面提交功能
	 * 
	 * @param res
	 * @param req
	 * @param msg
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/userQd.forgetPwd2.do")
	public String forgetNextStep(HttpServletResponse res,HttpServletRequest req,String msg) throws Exception
	{
	
		if(StringUtil.isNotEmpty(msg))
		{
			try
			{
				msg = URLDecoder.decode(msg, "utf-8");
				msg = new String(msg.getBytes("iso-8859-1"),"utf-8");
			} catch (UnsupportedEncodingException e)
			{
				e.printStackTrace();
			}
		}
		User use =  (User) Session.get("userTemp");
		if(use == null) 
		{
			return "redirect:/userQd.foundpwd.do?phone=&msg="+URLEncoder.encode("请输入正确的账号", "utf-8");
		}
		Request.set("phone",use.getPhone());
		Request.set("email",use.getEmailAddress());
		
		
		Request.set("msg",msg);
		return "/front/usercenter/forgetPwd2";
	}
	
	
	/**忘记密码的第二步到第三步提交功能
	 * @param res
	 * @param req
	 * @param type
	 * @param phoneCode
	 * @param emailCode
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/userQd.ValidateCode.do")
	public String ValidateCode(HttpServletResponse res,HttpServletRequest req,String type,String phoneCode,String emailCode) throws Exception
	{
			User use =  (User) Session.get("userTemp");
			if(use == null || StringUtil.isEmpty(type) ) 
			{
				return "redirect:/userQd.foundpwd.do?phone=&msg="+URLEncoder.encode("请输入正确的账号", "utf-8");
			}
			String key = use.getPhone();
			if(type.equals("1"))
			{
				key = use.getEmailAddress();
			}
			try
			{
				String code=jedisClientSingle.get(key);
				if(StringUtil.isNotEmpty(code))
				{
					if(code.equals(phoneCode) || code.equals(emailCode))
					{
						use.setKey(key);
						return "redirect:/userQd.forgetThreeStep.do";
					}
				}
				
			} catch (Exception e)
			{}
			
			return "redirect:/userQd.forgetPwd2.do?msg="+URLEncoder.encode("请输入正确的验证码", "utf-8");
	}
	
	/** 跳转到忘记密码第三个界面
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping("userQd.forgetThreeStep.do")
	public String forgetThreeStep(String msg) throws Exception 
	{

		if(StringUtil.isNotEmpty(msg))
		{
			try
			{
				msg = URLDecoder.decode(msg, "utf-8");
				msg = new String(msg.getBytes("iso-8859-1"),"utf-8");
			} catch (UnsupportedEncodingException e)
			{
				e.printStackTrace();
			}
		}
		
		User use =  (User) Session.get("userTemp");
		if(use == null) 
		{
			return "redirect:/userQd.foundpwd.do?phone=&msg="+URLEncoder.encode("请输入正确的账号", "utf-8");
		}
		try
		{
			String code=jedisClientSingle.get(use.getKey());
			if(StringUtil.isEmpty(code))
			{
				return "redirect:/userQd.forgetPwd2.do?msg="+URLEncoder.encode("请输入正确的验证码", "utf-8");
			}
			
		} catch (Exception e)
		{}
		return "front/usercenter/forgetPwd3";
	}
	
	/** 忘记密码第三步到第四步中的提交
	 * @param password
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("userQd.forgetupdatePwd.do")
	public String updatePwd(String password) throws Exception 
	{
		User use =  (User) Session.get("userTemp");
		if(use == null) 
		{
			return "redirect:/userQd.foundpwd.do?phone=&msg="+URLEncoder.encode("请输入正确的账号", "utf-8");
		}
		try
		{
			String code=jedisClientSingle.get(use.getKey());
			if(StringUtil.isEmpty(code))
			{
				return "redirect:/userQd.forgetPwd2.do?msg="+URLEncoder.encode("请输入正确的验证码", "utf-8");
			}
			
		} catch (Exception e)
		{}
		
		if(StringUtil.isEmpty(password)||password.trim() == ""){ 
			return "redirect:/userQd.forgetThreeStep.do?msg="+URLEncoder.encode("密码不能为空", "utf-8");
		}
		boolean updatePwd = userQdService.updatePwd(PasswordUtil.encrypt(password, PasswordUtilType.NORMAL),use.getId());
		
		if(updatePwd)
		{
			try
			{
				String key="userQd-"+use.getPhone();
				jedisClientSingle.get(key);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			Session.set("userTemp",null);
			Session.set("user",null);
			return "redirect:/userQd.forgetPwdSucc.do";
		}
		return "redirect:/userQd.forgetThreeStep.do?msg="+URLEncoder.encode("重置密码失败", "utf-8");
	}
	
	
	/**跳转到忘记密码的第四个修界面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("userQd.forgetPwdSucc.do")
	public String forgetPwdSucc(String msg) throws Exception 
	{
		return "/front/usercenter/forgetPwd4";
	}
	
}

































