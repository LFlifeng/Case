package com.gmadong.modules.user;

public interface UserQdService {
	User selectUserByName(String username);

	// 修改登录时间
	int updateByltime(String phone, String dtime);

	// 注册功能
	boolean saveUserRegister(UserQdRegister userQdRegister);

	User selectUserByPhone(String phone);

	boolean updatePwd(String newPwd, String useId);

	boolean updatePhone(String phone, String id);

	boolean updateAccountInformation(String userId,String portrait, String portraitUrl, String nickName, String birthday, String sex);

	boolean updateEmail(String email, String id);

	User selectUserByEmail(String email);



}
