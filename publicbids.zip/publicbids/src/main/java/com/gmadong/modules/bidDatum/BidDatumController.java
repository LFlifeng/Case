package com.gmadong.modules.bidDatum;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.application.Application;
import com.gmadong.modules.attach.SysAttach;
import com.gmadong.modules.attach.SysAttachService;
import com.gmadong.modules.billinginfo.ValidatebBillinginfoEditAction;
import com.gmadong.modules.systemMsg.SystemMsg;
import com.gmadong.modules.systemMsg.ValidatebSystemMsgAddAction;

/**
 * 投标资料
 * @author Administrator
 *
 */
@Controller
public class BidDatumController
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private BidDatumService bidDatumService;
	private String listkey = "bidDatum.list.action";
	@Resource(name="sysAttachService")
	private SysAttachService sysAttachService;
	/**
	 * 列表页面
	 * @return
	 */
	@RequestMapping("/bidDatum.page.action")
	public String page()
	{
		return "/back/bidDatum/page";
	}
	
	/**
	 * 页面条件搜索
	 * @return
	 */
	@RequestMapping("/bidDatum.list.action")
	public void list(HttpServletResponse response,String tltle,String source, String ctime,@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows) 
	{
		String field = tltle + "_" + source + "_" + ctime + "_" + page + "_" + rows;
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = bidDatumService.page(tltle, source, ctime,page, rows);
		String list = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, list, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(Page.pageToJson(toPage), response);
	}
	/**
	 * 添加页面
	 * @return
	 */
	@RequestMapping("/bidDatum.preAdd.action")
	public String preAdd() 
	{
		return "/back/bidDatum/add";
	}
	/**
	 * 添加操作
	 * @return
	 */
	@RequestMapping("/bidDatum.doAdd.action")
	public void doAdd(HttpServletResponse response, @Validated({ ValidatebBidDatumAddAction.class }) BidDatum bidDatum,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		if(StringUtil.isNotEmpty(bidDatum.getAccessory()))
		{
			String attachId = bidDatum.getAccessory().replace(",", "");
			SysAttach row = sysAttachService.getRow(attachId);
			bidDatum.setAccessory(row.getUrl());
		}
		if(bidDatumService.save(bidDatum))
		{
			try {
				jedisClientSingle.del(listkey);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		}
		else {
			AjaxUtil.write("添加失败", response);
		}
	}
	/**
	 * 修改页面
	 * @return
	 */
	@RequestMapping("/bidDatum.preEdit.action")
	public String preEdit(String id) {
		BidDatum bidDatumById = bidDatumService.getBidDatumById(id);
		if (bidDatumById == null) {
			return "/common/500";
		}
		Request.set("info", bidDatumById);
		return "/back/bidDatum/edit";
	}
	/**
	 * 修改操作
	 */
	@RequestMapping("/bidDatum.doEdit.action")
	public void doEdit(HttpServletResponse response,@Validated({ ValidatebBidDatumEditAction.class }) BidDatum bidDatum, BindingResult bindingResult) 
	{
		if (bindingResult.hasErrors()) 
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(), response);
			return;
		}
		if(bidDatumService.update(bidDatum))
		{
			try
			{
				jedisClientSingle.del(listkey);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("修改失败！",response);
		}
	}
	/**
	 * 删除
	 * @return
	 */
	@RequestMapping("/bidDatum.doDelete.action")
	public void doDelete(HttpServletResponse response, String ids) {
		if (bidDatumService.deleteById(ids)) {
			try {
				jedisClientSingle.del("bidDatum.list.action");
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("fail", response);
		}
	}
}
