package com.gmadong.modules.systemMsg;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.user.UserService;

/**
 * 系统消息管理
 * @author Administrator
 *
 */
@Controller
public class SystemMsgController
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private SystemMsgService systemMsgService;
	private String listkey = "systemMsg.list.action";
	@Autowired
	private UserService userService;
	
	/**
	 * 列表页面
	 * @return
	 */
	@RequestMapping("/systemMsg.page.action")
	public String page()
	{
		return "/back/systemMsg/page";
	}
	
	/**
	 * 页面条件搜索
	 * @return
	 */
	@RequestMapping("/systemMsg.list.action")
	public void list(HttpServletResponse response, String msg, String type, String ctime,@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows)
	{
		String field = msg + "_" + type + "_" + ctime + "_" + page + "_" + rows;
		try
		{
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list))
			{
				AjaxUtil.write(list, response);
				return;
			}
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		Page toPage = systemMsgService.page(msg, type, ctime, page, rows);
		String list = Page.pageToJson(toPage);
		try
		{
			jedisClientSingle.hset(listkey, field, list, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		AjaxUtil.write(Page.pageToJson(toPage), response);
	}
	
	/**
	 * 添加页面
	 * @return
	 */
	@RequestMapping("/systemMsg.preAdd.action")
	public String preAdd() 
	{
		return "/back/systemMsg/add";
	}
	
	/**
	 * 添加操作
	 * @return
	 */
	@RequestMapping("/systemMsg.doAdd.action")
	public void doAdd(HttpServletResponse response, @Validated({ ValidatebSystemMsgAddAction.class }) SystemMsg systemMsg,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		if(systemMsgService.save(systemMsg))
		{
			try {
				jedisClientSingle.del(listkey);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		}
		else {
			AjaxUtil.write("添加失败", response);
		}
	}
	
	/**
	 * 修改页面
	 * @return
	 */
	@RequestMapping("/systemMsg.preEdit.action")
	public String preEdit(String id) {
		SystemMsg systemMsgById = systemMsgService.getSystemMsgById(id);
		if (systemMsgById == null) {
			return "/common/500";
		}
		Request.set("info", systemMsgById);
		if(StringUtil.isNotEmpty(systemMsgById.getUserId()))
		{
			Request.set("nickname", userService.getPhoneById(systemMsgById.getUserId()));
		}
		else
		{
			Request.set("nickname", "");
		}
		return "/back/systemMsg/edit";
	}

	/**
	 * 修改操作
	 * @return
	 */
	@RequestMapping("/systemMsg.doEdit.action")
	public void doEdit(HttpServletResponse response, @Validated(
	{ ValidatebSystemMsgEditAction.class }) SystemMsg SystemMsg, BindingResult bindingResult)
	{
		if (bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(), response);
			return;
		}
		if (systemMsgService.update(SystemMsg))
		{
			try
			{
				jedisClientSingle.del(listkey);
			} catch (Exception e)
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else
		{
			AjaxUtil.write("修改失败！", response);
		}
	}

	/***
	 * 删除
	 * @return
	 */
	@RequestMapping("/systemMsg.doDelete.action")
	public void doDelete(HttpServletResponse response, String ids)
	{
		if (systemMsgService.deleteById(ids))
		{
			try
			{
				jedisClientSingle.del(listkey);
			} catch (Exception e)
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else
		{
			AjaxUtil.write("fail", response);
		}
	}
}
