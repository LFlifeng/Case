package com.gmadong.modules.billinginfo;

public interface BillingInfoQdService
{
	public Billinginfo selectInvoiceById(String id);
	public boolean updateByPrimaryKey(Billinginfo billinginfo);
    public boolean saveBillingInfo(Billinginfo billinginfo);
}





