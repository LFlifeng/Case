package com.gmadong.modules.user;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.gmadong.common.utils.FileUtil;
import com.gmadong.common.utils.StringUtil;



public class User {
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebUserEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebUserEditAction.class} )
    private String id;
	
	/** 微信标签ID */
    private String openId;

    /** 微信标签 */
    private Integer tagId;
	
    /** 手机号码 */
	@NotBlank(message="手机号码不能为空!" ,groups = {ValidatebUserAddAction.class,ValidatebUserEditAction.class})
    @Size (min=11,max=15,message="请输入正确的手机号码!" ,groups = {ValidatebUserAddAction.class,ValidatebUserEditAction.class})
    private String phone;

    /** 个人角色 1：投标人  2：招标人  3：供应商  */
	@NotBlank(message="个人角色不能为空!" ,groups = {ValidatebUserAddAction.class,ValidatebUserEditAction.class})
    private String personalOffice;

    /** 用户名 */
    @Size (max=50,message="请输入正确的用户名!" ,groups = {ValidatebUserAddAction.class,ValidatebUserEditAction.class})
    private String name;

    /** 性别 0未知 1：女  2：男  */
    private String sex;

    /** 出生日期 */
    private String birthday = "";

    /** 昵称 */
    @Size (max=50,message="请输入正确的昵称!" ,groups = {ValidatebUserAddAction.class,ValidatebUserEditAction.class})
    private String nickname;

    /** 头像 */
    private String portrait;

    /** 所在省 */
    private String province;

    /** 所在市 */
    private String city;

    /** 所在县 */
    private String county;

    /** 详情地址 */
    @Size (max=50,message="请输入正确的详情地址!" ,groups = {ValidatebUserAddAction.class,ValidatebUserEditAction.class})
    private String address;

    /** 联系人 */
    @Size (max=10,message="请输入正确的联系人!" ,groups = {ValidatebUserAddAction.class,ValidatebUserEditAction.class})
    private String contacts;

    /** 邮政编码 */
    @Size (max=6,message="请输入正确的邮政编码!" ,groups = {ValidatebUserAddAction.class,ValidatebUserEditAction.class})
    private String postalCode;

    /** 邮箱地址 */
    @Size (max=50,message="请输入正确的邮箱地址!" ,groups = {ValidatebUserAddAction.class,ValidatebUserEditAction.class})
    private String emailAddress;

    /** 上传本人身份证正面 */
    private String idcardFront;

    /** 上传本人身份证背面 */
    private String idcardBack;

    /** 等级 0:普通用户  1:普通会员  2：高级会员  3：vip高级会员   4：钻石会员 */
    private String grade;

    /** 密码 */
	@NotBlank(message="密码不能为空!" ,groups = {ValidatebUserAddAction.class})
    @Size (min=6,max=12,message="请输入正确的密码!" ,groups = {ValidatebUserAddAction.class})
    private String password;

    /**  状态 0：正常 1：锁定 */
    private String status;

    private String ctime;

    /** 登录时间 */
    private String ltime;
    
    /** vip过期时间 */
    private String ptime;
    
  //后加的属性
    private String showPersonalOffice;
	private String portraitUrl;
    private String idcardFrontUrl;
    private String idcardBackUrl;
    private String showName;
    private String showGrade;
    private String key;
    
    public String getKey()
	{
		return key;
	}

	public void setKey(String key)
	{
		this.key = key;
	}

	public String getShowGrade()
	{
		return showGrade;
	}

	public void setShowGrade(String showGrade)
	{
		this.showGrade = showGrade;
	}

	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }
    
    public String getShowPersonalOffice()
	{
		return showPersonalOffice;
	}

	public void setShowPersonalOffice(String showPersonalOffice)
	{
		this.showPersonalOffice = showPersonalOffice;
	}

    /**
     * 手机号码
     * @return phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * 手机号码
     * @param phone
     */
    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    /**
     * 个人角色 1：投标人  2：招标人  3：供应商 
     * @return personalOffice
     */
    public String getPersonalOffice() {
        return personalOffice;
    }

    /**
     * 个人角色 1：投标人  2：招标人  3：供应商 
     * @param personalOffice
     */
    public void setPersonalOffice(String personalOffice) {
        this.personalOffice = personalOffice == null ? null : personalOffice.trim();
        switch (this.personalOffice)
		{
			case "1":
		        this.showPersonalOffice = "投标人";
			break;
			case "2":
			    this.showPersonalOffice = "投标人";
			break;
			case "3":
				this.showPersonalOffice = "供应商";
				break;
			case "4":
				this.showPersonalOffice = "投标人和招标人";
				break;
			case "5":
				this.showPersonalOffice = "投标人和供应商";
			break;
			case "6":
				this.showPersonalOffice = "投标人和投标人";
			break;
			case "7":
				this.showPersonalOffice = "全部";
			break;
		}
    }
    /**
     * 用户名
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * 用户名
     * @param name
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * 性别 0未知 1：女  2：男 
     * @return sex
     */
    public String getSex() {
        return sex;
    }

    /**
     * 性别 0未知 1：女  2：男 
     * @param sex
     */
    public void setSex(String sex) {
        this.sex = sex == null ? null : sex.trim();
    }

    /**
     * 出生日期
     * @return birthday
     */
    public String getBirthday() {
        return birthday;
    }

    /**
     * 出生日期
     * @param birthday
     */
    public void setBirthday(String birthday) {
        this.birthday = birthday == null ? null : birthday.trim();
    }

    /**
     * 昵称
     * @return nickname
     */
    public String getNickname() {
        return nickname;
    }

    /**
     * 昵称
     * @param nickname
     */
    public void setNickname(String nickname) {
        this.nickname = nickname == null ? null : nickname.trim();
    }

    /**
     * 头像
     * @return portrait
     */
    public String getPortrait() {
        return portrait;
    }

	/**
     * 头像
     * @param portrait
     */
    public void setPortrait(String portrait) {
    	if(StringUtil.isNotEmpty(portrait))
    	{
    		this.portraitUrl = "/upload/attach"+FileUtil.getPath(portrait)+portrait +".png";
    	}
    	else
    	{
    		this.portraitUrl ="/skin/default/front/img/head_placeholder.png";
    	}
        this.portrait = portrait == null ? null : portrait.trim();
    }

    public String getPortraitUrl()
	{
    	if(StringUtil.isEmpty(portraitUrl))
    	{
    		return "/skin/default/front/img/head_placeholder.png";
    	}
		return portraitUrl;
	}

	public void setPortraitUrl(String portraitUrl)
	{
		this.portraitUrl = portraitUrl;
	}

	public String getIdcardFrontUrl()
	{
		return idcardFrontUrl;
	}

	public void setIdcardFrontUrl(String idcardFrontUrl)
	{
		this.idcardFrontUrl = idcardFrontUrl;
	}

	public String getIdcardBackUrl()
	{
		return idcardBackUrl;
	}

	public void setIdcardBackUrl(String idcardBackUrl)
	{
		this.idcardBackUrl = idcardBackUrl;
	}

	/**
     * 所在省
     * @return province
     */
    public String getProvince() {
        return province;
    }

    /**
     * 所在省
     * @param province
     */
    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    /**
     * 所在市
     * @return city
     */
    public String getCity() {
        return city;
    }

    /**
     * 所在市
     * @param city
     */
    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    /**
     * 所在县
     * @return county
     */
    public String getCounty() {
        return county;
    }

    /**
     * 所在县
     * @param county
     */
    public void setCounty(String county) {
        this.county = county == null ? null : county.trim();
    }

    /**
     * 详情地址
     * @return address
     */
    public String getAddress() {
        return address;
    }

    /**
     * 详情地址
     * @param address
     */
    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    /**
     * 联系人
     * @return contacts
     */
    public String getContacts() {
        return contacts;
    }

    /**
     * 联系人
     * @param contacts
     */
    public void setContacts(String contacts) {
        this.contacts = contacts == null ? null : contacts.trim();
    }

    /**
     * 邮政编码
     * @return postalCode
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * 邮政编码
     * @param postalCode
     */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode == null ? null : postalCode.trim();
    }

    /**
     * 邮箱地址
     * @return emailAddress
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * 邮箱地址
     * @param emailAddress
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress == null ? null : emailAddress.trim();
    }

    /**
     * 上传本人身份证正面
     * @return idcardFront
     */
    public String getIdcardFront() {
        return idcardFront;
    }

    /**
     * 上传本人身份证正面
     * @param idcardFront
     */
    public void setIdcardFront(String idcardFront) {
    	if(StringUtil.isNotEmpty(idcardFront))
    	{
    		this.idcardFrontUrl = "/upload/attach"+FileUtil.getPath(idcardFront)+idcardFront +".png";
    	}
        this.idcardFront = idcardFront == null ? null : idcardFront.trim();
    }

    /**
     * 上传本人身份证背面
     * @return idcardBack
     */
    public String getIdcardBack() {
        return idcardBack;
    }

    /**
     * 上传本人身份证背面
     * @param idcardBack
     */
    public void setIdcardBack(String idcardBack) {
    	if(StringUtil.isNotEmpty(idcardBack))
    	{
    		this.idcardBackUrl = "/upload/attach"+FileUtil.getPath(idcardBack)+idcardBack +".png";
    	}
        this.idcardBack = idcardBack == null ? null : idcardBack.trim();
    }

    /**
     * 等级 0:普通用户  1:普通会员  2：高级会员  3：vip高级会员   4：钻石会员
     * @return grade
     */
    public String getGrade() {
        return grade;
    }

    /**
     * 等级 0:普通用户  1:普通会员  2：高级会员  3：vip高级会员   4：钻石会员
     * @param grade
     */
    public void setGrade(String grade) {
        this.grade = grade == null ? null : grade.trim();
        switch (this.grade)
		{
			case "0":
		        this.showGrade = "普通用户";
			break;
			case "1":
			    this.showGrade = "普通会员";
			break;
			case "2":
				this.showGrade = "高级会员";
				break;
			case "3":
				this.showGrade = "vip高级会员";
				break;
			case "4":
				this.showGrade = "钻石会员";
			break;
		}
    }

    /**
     * 密码
     * @return password
     */
    public String getPassword() {
        return password;
    }

    /**
     * 密码
     * @param password
     */
    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    /**
     *  状态 0：正常 1：锁定
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     *  状态 0：正常 1：锁定
     * @param status
     */
    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }

    /**
     * 登录时间
     * @return ltime
     */
    public String getLtime() {
        return ltime;
        
    }

    /**
     * 登录时间
     * @param ltime
     */
    public void setLtime(String ltime) {
        this.ltime = ltime == null ? null : ltime.trim();
    }
    public String getShowName()
	{
    	if(StringUtil.isEmpty(showName))
    	{
    		if(StringUtil.isNotEmpty(nickname))
    		{
    			showName = nickname;
    		}
    		if(StringUtil.isNotEmpty(name)) {
    			showName = name;
    		}
    		else
    		{
    			showName = contacts;
    		}
    	}
		return showName;
	}

	public void setShowName(String showName)
	{
		this.showName = showName;
	}

	

	@Override
	public String toString()
	{
		return "User [id=" + id + ", openId=" + openId + ", tagId=" + tagId + ", phone=" + phone + ", personalOffice="
				+ personalOffice + ", name=" + name + ", sex=" + sex + ", birthday=" + birthday + ", nickname="
				+ nickname + ", portrait=" + portrait + ", province=" + province + ", city=" + city + ", county="
				+ county + ", address=" + address + ", contacts=" + contacts + ", postalCode=" + postalCode
				+ ", emailAddress=" + emailAddress + ", idcardFront=" + idcardFront + ", idcardBack=" + idcardBack
				+ ", grade=" + grade + ", password=" + password + ", status=" + status + ", ctime=" + ctime + ", ltime="
				+ ltime + ", ptime=" + ptime + ", showPersonalOffice=" + showPersonalOffice + ", portraitUrl="
				+ portraitUrl + ", idcardFrontUrl=" + idcardFrontUrl + ", idcardBackUrl=" + idcardBackUrl
				+ ", showName=" + showName + ", showGrade=" + showGrade + ", key=" + key + "]";
	}

	public String getPtime()
	{
		return ptime;
	}

	public void setPtime(String ptime)
	{
		this.ptime = ptime;
	}

	public String getOpenId()
	{
		return openId;
	}

	public void setOpenId(String openId)
	{
		this.openId = openId;
	}

	public Integer getTagId()
	{
		return tagId;
	}

	public void setTagId(Integer tagId)
	{
		this.tagId = tagId;
	}

	
	
}