package com.gmadong.modules.projectDesigneds;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.designedinfo.Designedinfo;
import com.gmadong.modules.designedinfo.DesignedinfoQdService;
import com.gmadong.modules.user.User;

import net.sf.json.JSONObject;

/**
 *项目专盯控制层
 * 
 * @author Administrator
 *
 */
@Controller
public class ProjectDesignedsQdController {

	@Resource(name = "projectDesignedsQdService")
	private ProjectDesignedsQdService projectDesignedsQdService;

	@Autowired
	private JedisClientSingle jedisClientSingle;

	private String listkey = "projectDesigneds.list_";
	
	@Autowired
	private DesignedinfoQdService designedinfoQdService;

	/**
	 * 添加项目专盯
	 * 
	 * @param response
	 * @param id
	 */
	@RequestMapping("/projectDesigneds.add.do")
	public void addUserCollection(HttpServletResponse response, String biddingInfoId, String binddingInfoTitle) {
		User user = (User) Session.get("user");
		if (user == null) {
			AjaxUtil.write("用户未登陆", response);
			return;
		}
		String userId = user.getId();
		ProjectDesigneds projectDesigneds;
		//判断用户会员等级，根据等级限制专盯项目数量
		String grade = user.getGrade();
		Integer count = 0;
		if(grade == "0") {
			AjaxUtil.write("您为普通用户,无法享受专盯服务,请升级会员", response);
			return;
		}else if("1".equals(grade)) {
			AjaxUtil.write("您为普通会员,没有专盯次数,请升级会员", response);
			return;
		}else if("2".equals(grade)) {
			count = projectDesignedsQdService.selectDesignedsCountByUserId(userId);
			if(count >= 5) {
				AjaxUtil.write("您为高级会员,只有5次专盯次数,请升级会员", response);
				return;
			}
		}else if("3".equals(grade)) {
			count = projectDesignedsQdService.selectDesignedsCountByUserId(userId);
			if(count >= 10) {
				AjaxUtil.write("您为VIP高级会员,只有10次专盯次数,请升级会员", response);
				return;
			}
		}else if("4".equals(grade)) {
			count = projectDesignedsQdService.selectDesignedsCountByUserId(userId);
			if(count >=  15) {
				AjaxUtil.write("您为钻石会员,最多只有15次专盯次数", response);
				return;
			}
		}
		projectDesigneds = projectDesignedsQdService.selectByBiddingInfoId(userId,biddingInfoId);
		if (projectDesigneds != null) {
			AjaxUtil.write("项目已专盯，请勿重复专盯", response);
			return;
		}
		projectDesigneds = new ProjectDesigneds();
		projectDesigneds.setBiddinginfoId(biddingInfoId);
		projectDesigneds.setProjectsName(binddingInfoTitle);
		projectDesigneds.setUserId(userId);
		projectDesigneds.setId(UUIDUtil.getUUID());
		projectDesigneds.setCtime(DateUtil.getCurrentDate());
		if (projectDesignedsQdService.save(projectDesigneds)) {
			try {
				jedisClientSingle.del(listkey + userId);
			} catch (Exception e) {
				e.printStackTrace();
			}
			Designedinfo designedinfo = new Designedinfo();
			designedinfo.setId(UUIDUtil.getUUID());
			designedinfo.setCtime(DateUtil.getCurrentDate());
			designedinfo.setStaffId("fd9e19b0758c11e6914bc665a5105ea9");
			designedinfo.setRemark("专盯成功");
			designedinfo.setPeople("未指定");
			designedinfo.setProjectId(projectDesigneds.getId());
			designedinfo.setDesignedinfo("暂未更近");
			if(designedinfoQdService.addDesignedinfo(designedinfo)) {
				AjaxUtil.write("专盯成功", response);
			}else {
				AjaxUtil.write("专盯失败", response);
			}
		} else {
			AjaxUtil.write("专盯失败", response);

		}
	}
}
