      package com.gmadong.modules.columnCategory;

import com.gmadong.modules.columnCategory.ColumnCategory;
import com.gmadong.modules.columnCategory.ColumnCategoryExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ColumnCategoryMapper {
    int countByExample(ColumnCategoryExample example);

    int deleteByExample(ColumnCategoryExample example);

    int deleteByPrimaryKey(String id);

    int insert(ColumnCategory record);

    int insertSelective(ColumnCategory record);

    List<ColumnCategory> selectByExample(ColumnCategoryExample example);

    ColumnCategory selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") ColumnCategory record, @Param("example") ColumnCategoryExample example);

    int updateByExample(@Param("record") ColumnCategory record, @Param("example") ColumnCategoryExample example);

    int updateByPrimaryKeySelective(ColumnCategory record);

    int updateByPrimaryKey(ColumnCategory record);
    
    // 自己添加的
    List<ColumnCategory> selectAll();
    
}