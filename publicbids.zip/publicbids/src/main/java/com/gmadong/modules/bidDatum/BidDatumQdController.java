package com.gmadong.modules.bidDatum;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.application.ExcellentApplication;
import com.gmadong.modules.bids.BidsWithBLOBs;
import com.gmadong.modules.user.User;

import net.sf.json.JSONObject;

/**
 * 投标资料
 * 
 * @author Administrator
 *
 */
@Controller
public class BidDatumQdController {
	
	@Autowired
	private JedisClientSingle jedisClientSingle;
	
	@Autowired
	private BidDatumQdService bidDatumQdService;
	
	private String listkey = "bidDatum.indexlist.do";
	
	/**
	 * 投标资料列表跳转页面
	 * 
	 * @return
	 */
	@RequestMapping("/bidDatum.listIndex.do")
	public String page() {
		return "/front/biddatum/tenderList";
	}
	
	/**
	 * 投标资料列表查询
	 * @param response
	 * @param page
	 * @param rows
	 */
	@RequestMapping("/bidDatum.list.do")
	public void list(HttpServletResponse response,@RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "8") Integer rows) {
	
		String field =  page + "-" + rows;
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = bidDatumQdService.page(page, rows);
		String listStr = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, listStr, Common.REDIS_24_HOUR_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
	}
	
	/**
	 * 投标资料详情查询
	 * 
	 * @param response
	 * @param id       投标资料id
	 */
	@RequestMapping("/bidDatum.details.do")
	public String details(HttpServletResponse response, String id) {
		BidDatum bidDatum = null;
		String key = "bidDatum.details-" + id;
		try {

			String detail = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(detail)) {
				JSONObject jsonObject = JSONObject.fromObject(detail);
				bidDatum = (BidDatum) JSONObject.toBean(jsonObject, BidDatum.class);
				Request.set("detail", bidDatum);
				return "/front/biddatum/tenderDetail";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		bidDatum = bidDatumQdService.details(id);
		String detail = JsonUtil.bean2json(bidDatum);

		try {
			
			jedisClientSingle.set(key, detail, Common.REDIS_6_HOUR_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Request.set("detail", bidDatum);
		return "/front/biddatum/tenderDetail";
	}

	
	/**
	 * 查询首页招标资料
	 * @param response
	 */
	@RequestMapping("bidDatum.fidnbidDatumList.do")
	public void fidnbidDatumList(HttpServletResponse response) {
		String key = "bidDatum.fidnbidDatumList.do";
		try {
			String listStr = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		List<BidDatum> list = bidDatumQdService.fidnbidDatumList();
		String listStr = JsonUtil.listToJson(list);
		try {
			jedisClientSingle.set(key, listStr, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
		return;
	}

}
