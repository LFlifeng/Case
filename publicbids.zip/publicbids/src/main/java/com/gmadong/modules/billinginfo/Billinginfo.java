package com.gmadong.modules.billinginfo;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.gmadong.modules.company.ValidatebCompanyAddAction;
import com.gmadong.modules.company.ValidatebCompanyEditAction;

public class Billinginfo {
	/** 发票id */
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebBillinginfoEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebBillinginfoEditAction.class} )
    private String id;

    private String userId;

    /** 发票名称 */
   	@NotBlank(message="发票名称不能为空!" ,groups = {ValidatebBillinginfoUpdateAction.class,ValidatebBillinginfoAddAction.class,ValidatebBillinginfoEditAction.class})
    @Size (min=1,max=50,message="请输入正确的发票名称!" ,groups = {ValidatebBillinginfoUpdateAction.class,ValidatebBillinginfoAddAction.class,ValidatebBillinginfoEditAction.class})
    private String invoice;

    /** 发票类型  0企业增值税普通发票 1增值税发票 */
   	@NotBlank(message="发票类型不能为空!" ,groups = {ValidatebBillinginfoUpdateAction.class,ValidatebBillinginfoAddAction.class,ValidatebBillinginfoEditAction.class})
    private String invoiceType;

    /** 税务登记证号 */
   	@NotBlank(message="税务登记证号不能为空!" ,groups = {ValidatebBillinginfoUpdateAction.class,ValidatebBillinginfoAddAction.class,ValidatebBillinginfoEditAction.class})
	@Size (min=6,max=20,message="请输入正确的税务登记证号!" ,groups = {ValidatebBillinginfoUpdateAction.class,ValidatebBillinginfoAddAction.class,ValidatebBillinginfoEditAction.class})
    private String revenueCertificate;

    /** 开户行名称 */
 	@NotBlank(message="开户行名称不能为空!" ,groups = {ValidatebBillinginfoUpdateAction.class,ValidatebBillinginfoAddAction.class,ValidatebBillinginfoEditAction.class})
    @Size (min=1,max=50,message="请输入正确的开户行名称!" ,groups = {ValidatebBillinginfoUpdateAction.class,ValidatebBillinginfoAddAction.class,ValidatebBillinginfoEditAction.class})
    private String accountName;

    /** 开户行账号 */
	@NotBlank(message="开户行账号不能为空!" ,groups = {ValidatebBillinginfoUpdateAction.class,ValidatebBillinginfoAddAction.class,ValidatebBillinginfoEditAction.class})
	@Size (min=6,max=20,message="请输入正确的开户行账号!" ,groups = {ValidatebBillinginfoUpdateAction.class,ValidatebBillinginfoAddAction.class,ValidatebBillinginfoEditAction.class})
    private String accountNumber;

    /**注册场所地址 */
	@NotBlank(message="注册场所地址不能为空!" ,groups = {ValidatebBillinginfoUpdateAction.class,ValidatebBillinginfoAddAction.class,ValidatebBillinginfoEditAction.class})
    @Size (min=1,max=50,message="请输入正确的注册场所地址!" ,groups = {ValidatebBillinginfoUpdateAction.class,ValidatebBillinginfoAddAction.class,ValidatebBillinginfoEditAction.class})
    private String registeredAddress;

    /** 注册固定电话 */
	@NotBlank(message="注册固定电话不能为空!" ,groups = {ValidatebBillinginfoUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
	@Size (min=6,max=15,message="请输入正确的注册固定电话!" ,groups = {ValidatebBillinginfoUpdateAction.class,ValidatebCompanyAddAction.class,ValidatebCompanyEditAction.class})
    private String registeredLandline;

    private String ctime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    /**
     * 发票抬头
     * @return invoice
     */
    public String getInvoice() {
        return invoice;
    }

    /**
     * 发票抬头
     * @param invoice
     */
    public void setInvoice(String invoice) {
        this.invoice = invoice == null ? null : invoice.trim();
    }

    /**
     * 发票类型  0企业增值税普通发票 1增值税发票
     * @return invoiceType
     */
    public String getInvoiceType() {
        return invoiceType;
    }

    /**
     * 发票类型  0企业增值税普通发票 1增值税发票
     * @param invoiceType
     */
    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType == null ? null : invoiceType.trim();
    }

    /**
     * 税务登记证号
     * @return revenueCertificate
     */
    public String getRevenueCertificate() {
        return revenueCertificate;
    }

    /**
     * 税务登记证号
     * @param revenueCertificate
     */
    public void setRevenueCertificate(String revenueCertificate) {
        this.revenueCertificate = revenueCertificate == null ? null : revenueCertificate.trim();
    }

    /**
     * 开户行名称
     * @return accountName
     */
    public String getAccountName() {
        return accountName;
    }

    /**
     * 开户行名称
     * @param accountName
     */
    public void setAccountName(String accountName) {
        this.accountName = accountName == null ? null : accountName.trim();
    }

    /**
     * 开户行账号
     * @return accountNumber
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * 开户行账号
     * @param accountNumber
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber == null ? null : accountNumber.trim();
    }

    /**
     * 注册场所地址
     * @return registeredAddress
     */
    public String getRegisteredAddress() {
        return registeredAddress;
    }

    /**
     * 注册场所地址
     * @param registeredAddress
     */
    public void setRegisteredAddress(String registeredAddress) {
        this.registeredAddress = registeredAddress == null ? null : registeredAddress.trim();
    }

    /**
     * 注册固定电话
     * @return registeredLandline
     */
    public String getRegisteredLandline() {
        return registeredLandline;
    }

    /**
     * 注册固定电话
     * @param registeredLandline
     */
    public void setRegisteredLandline(String registeredLandline) {
        this.registeredLandline = registeredLandline == null ? null : registeredLandline.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }

	public Billinginfo()
	{
		super();
	}

	public Billinginfo(String userId)
	{
		super();
		this.userId = userId;
		this.id = "";
		this.invoice = "";
		this.invoiceType = "";
		this.revenueCertificate = "";
		this.accountName = "";
		this.accountNumber = "";
		this.registeredAddress = "";
		this.registeredLandline = "";
		this.ctime = "";
		
	}

    
    
}