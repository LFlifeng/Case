package com.gmadong.modules.projectDesigneds;

import com.gmadong.common.Page;


public interface ProjectDesignedsQdService
{

	Page page(String userId, Integer page, Integer rows);

	ProjectDesigneds selectByBiddingInfoId(String userId, String biddingInfoId);

	boolean save(ProjectDesigneds projectDesigneds);

	Integer selectDesignedsCountByUserId(String userId);

}
