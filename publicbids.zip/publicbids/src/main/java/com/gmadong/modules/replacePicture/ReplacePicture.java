package com.gmadong.modules.replacePicture;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.gmadong.common.utils.FileUtil;
import com.gmadong.common.utils.StringUtil;



public class ReplacePicture {
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebReplacePictureEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebReplacePictureEditAction.class} )
    private String id;

    /** 编号 */
	@NotBlank(message="编号不能为空!" ,groups = {ValidatebReplacePictureAddAction.class,ValidatebReplacePictureEditAction.class})
    @Size (min=1,max=10,message="请输入正确的编号!" ,groups = {ValidatebReplacePictureAddAction.class,ValidatebReplacePictureEditAction.class})
    private String number;
	
	/** 类型的序号 */
    private Integer position;

    /** 地址 */
    private String url;
	
    /** 图片 */
    private String picture;

    /** 过期时间 */
    private String ptime;

    private String ctime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }
    
    //后加的属性
    private String pictureUrl;
    
    /**
     * 编号
     * @return number
     */
    public String getNumber() {
        return number;
    }

    /**
     * 编号
     * @param number
     */
    public void setNumber(String number) {
        this.number = number == null ? null : number.trim();
    }
    

    public Integer getPosition()
	{
		return position;
	}

	public void setPosition(Integer position)
	{
		this.position = position;
	}

	public String getUrl()
	{
		return url;
	}

	public void setUrl(String url)
	{
		this.url = url;
	}

	/**
     * 图片
     * @return picture
     */
    public String getPicture() {
        return picture;
    }

    /**
     * 图片
     * @param picture
     */
    public void setPicture(String picture)
    {
    	if(StringUtil.isNotEmpty(picture))
    	{
    		if(picture.endsWith(".jpg"))
    		{
    			this.pictureUrl = picture;
    		}
    		else
    		{
    			this.pictureUrl = "/upload/attach"+FileUtil.getPath(picture)+picture +".png";
    		}
    		
    	}
        this.picture = picture == null ? null : picture.trim();
    }

    /**
     * 过期时间
     * @return ptime
     */
    public String getPtime() {
        return ptime;
    }

    /**
     * 过期时间
     * @param ptime
     */
    public void setPtime(String ptime) {
        this.ptime = ptime == null ? null : ptime.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }

	public String getPictureUrl()
	{
		return pictureUrl;
	}

	public void setPictureUrl(String pictureUrl)
	{
		this.pictureUrl = pictureUrl;
	}
    
}