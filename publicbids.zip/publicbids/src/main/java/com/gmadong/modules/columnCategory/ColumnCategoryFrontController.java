package com.gmadong.modules.columnCategory;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;

@Controller
public class ColumnCategoryFrontController
{

	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private ColumnCategoryService columnCategoryService;
	public static final String  key = "columnCategory.listAll.do";
	
	
	
	@RequestMapping("/columnCategory.listAll.do")
	public void querylist(HttpServletResponse response) 
	{
		
		try
		{
			String json = jedisClientSingle.get(key);
			if(StringUtil.isNotEmpty(json))
			{
				AjaxUtil.write(json,response);
				return ;
			}
			
		}catch(Exception e)
		{}
		List<ColumnCategoryMiniInfo> list = columnCategoryService.getMiniInfo();
		String json = JsonUtil.listToJson(list);
		try
		{
			jedisClientSingle.set(key, json);
			
		}catch (Exception e) 
		{}
		AjaxUtil.write(json,response);
	}	
}
