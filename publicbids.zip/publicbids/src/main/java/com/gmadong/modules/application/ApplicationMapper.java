package com.gmadong.modules.application;

import com.gmadong.modules.application.Application;
import com.gmadong.modules.application.ApplicationExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ApplicationMapper {
    int countByExample(ApplicationExample example);

    int deleteByExample(ApplicationExample example);

    int deleteByPrimaryKey(String id);

    int insert(Application record);

    int insertSelective(Application record);

    List<Application> selectByExampleWithBLOBs(ApplicationExample example);

    List<Application> selectByExample(ApplicationExample example);

    Application selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") Application record, @Param("example") ApplicationExample example);

    int updateByExampleWithBLOBs(@Param("record") Application record, @Param("example") ApplicationExample example);

    int updateByExample(@Param("record") Application record, @Param("example") ApplicationExample example);

    int updateByPrimaryKeySelective(Application record);

    int updateByPrimaryKeyWithBLOBs(Application record);

    int updateByPrimaryKey(Application record);
    
    /**
     * 个人新增
     * @param userId
     * @return
     */
    /*根据用户userid查询当前的申请入驻信息*/
	Application selectByUserId(String userId);

	List<ExcellentApplication> selectFamousCompany();

	List<ExcellentApplication> selectTopFamousCompany();
	
	List<ExcellentApplication> selectExcellentApplication();

	String selectUserIdByCompanyId(String applicationId);

	List<ExcellentApplication> selectFamousCompanyWall();

	//微信查询供应商接口
	List<ExcellentApplication> selectWechatApplication();
}