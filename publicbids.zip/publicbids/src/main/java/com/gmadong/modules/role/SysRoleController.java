package com.gmadong.modules.role;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Authority;
import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.log.StaffLogService;

/***
 * 
 * @ClassName: RoleController
 * @Description: 角色
 * @author caodong
 * @date 2016年9月8日 上午11:14:40
 *
 */
@Controller
public class SysRoleController 
{
   @Resource(name="sysRoleService")
   private SysRoleService sysRoleService;
   @Resource(name="staffLogService")
   private StaffLogService staffLogService;
   @Autowired
   private JedisClientSingle jedisClientSingle;
	/**
	 * 列表页
	 */
	@RequestMapping("/role.page.action")
	public String page()
	{
		return "/back/role/page";
	}
	/**
	 * list
	 */
	@RequestMapping("/role.list.action")
	public void list(HttpServletResponse response,String roleName,String remark,@RequestParam(defaultValue="1") Integer page,@RequestParam(defaultValue="10") Integer rows)
	{
		String key = "role.list";
		String field = roleName+"-"+remark+"-"+page+"-"+rows;
		
		try
		{
			String list = jedisClientSingle.hget(key, field);
			if(StringUtil.isNotEmpty(list))
			{
				AjaxUtil.write(list,response);
				return;
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		Page toPage = sysRoleService.page(roleName, remark, page, rows);
		String listStr = Page.pageToJson(toPage);
		try
		{
			jedisClientSingle.hset(key, field, listStr, Common.REDIS_48_HOUR_EXPIRE);
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		AjaxUtil.write(listStr,response);
	}
	@RequestMapping("/role.preAdd.action")
	public String preAdd()
	{
		String jsonStr = "[";
		String allActionString = "[" + Session.get("allActionString") + "]";
		JSONArray ja = JSONArray.fromObject(allActionString);
		Authority authority = new Authority();
		for(Iterator<?> iter = ja.iterator(); iter.hasNext();){
			JSONObject jsonObject = (JSONObject)iter.next();
			authority = (Authority)JSONObject.toBean(jsonObject, Authority.class);
			if(authority.getUser().indexOf("staff")!=-1 && authority.getType().indexOf("permit")!=-1){
				jsonStr += "{id:\""+authority.getId()+"\",pId:\""+authority.getParent()+"\",name:\""+authority.getName()+"\"},";
			}
		}
		jsonStr = jsonStr.substring(0, jsonStr.length()-1);
		jsonStr += "]";
		Request.set("jsonStr", jsonStr);
		return "/back/role/add";
	}
	@RequestMapping("/role.doAdd.action")
	public void doAdd(HttpServletResponse response,@Validated SysRole role,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		String actions = role.getActions();
		String allActionString = "[" + Session.get("allActionString") + "]";
		JSONArray ja = JSONArray.fromObject(allActionString);
		Authority authority = new Authority();
		List<Authority> list = new ArrayList<>();
		for(Iterator<?> iter = ja.iterator(); iter.hasNext();)
		{
			JSONObject jsonObject = (JSONObject)iter.next();
			authority = (Authority)JSONObject.toBean(jsonObject, Authority.class);
			if(authority.getType().indexOf("unanonymous") != -1)
			{
				actions += "," + authority.getId();
			}
			list.add(authority);
		}
		Authority a = new Authority();
		String[] p = null;
		// 隐只能继承显，隐不能继承隐，显可继承显，亦可继承隐，父前子后，多继承，全局如此
		for(int i=0; i<list.size(); i++)
		{
			a = (Authority)list.get(i);
			if(!a.getParent().equals("") && a.getType().indexOf("inherit")!=-1)
			{
				p = a.getParent().split(",");
				for(int j=0; j<p.length; j++)
				{
					if(p[j]!=null && !p[j].equals("") && actions.indexOf(p[j]) != -1 && actions.indexOf(a.getId()) == -1)
					{
						actions += "," + a.getId();
					}
				}
			}
		}
		if (!StringUtil.isEmpty(actions))
		{
			if (actions.startsWith(","))
			{
				actions = actions.substring(1);
			}
			if(actions.endsWith(","))
			{
				actions = actions.substring(actions.length()-1);
			}
		}
		 role.setActions(actions);
		if(sysRoleService.saveRold(role))
		{
			staffLogService.log(Session.getString("staffId"), role.getId(), Session.getString("staffName")+"—添加角色-"+role.getRoleName(), JsonUtil.bean2json(role));
			try
			{
				jedisClientSingle.del("role.list");
				jedisClientSingle.del("rolesJsonString");
				
			} catch (Exception e)
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("保存失败，请稍后重试!",response);
		}
	}
	/**
	 * 修改页面
	 */
	@RequestMapping("/role.preEdit.action")
	public String preEdit(String id)
	{
		SysRole role = sysRoleService.selectByRoleId(id);
		if(role==null)
		{
			Request.set("message", "id为空");
			return "/back/common/message";
		}
		String actions = role.getActions();

		String jsonStr = "[";
		String allActionString = "[" + Session.get("allActionString") + "]";
		JSONArray ja = JSONArray.fromObject(allActionString);
		Authority authority = new Authority();
		for(Iterator<?> iter = ja.iterator(); iter.hasNext();)
		{
			JSONObject jsonObject = (JSONObject)iter.next();
			authority = (Authority)JSONObject.toBean(jsonObject, Authority.class);
			if(authority.getUser().indexOf("staff")!=-1 && authority.getType().indexOf("permit")!=-1)
			{
				jsonStr += "{id:\""+authority.getId()+"\",pId:\""+authority.getParent()+"\",name:\""+authority.getName()+"\""+((actions.equals("all")||actions.indexOf(authority.getId()) != -1) ? ",checked:\"true\"" : "")+"},";
			}
		}
		jsonStr = jsonStr.substring(0, jsonStr.length()-1);
		jsonStr += "]";
		System.out.println(jsonStr);
		Request.set("jsonStr", jsonStr);
		Request.set("actions", actions);
		Request.set("roleId", id);
		Request.set("role", role);
		return "/back/role/edit";
	}
	@RequestMapping("/role.doEdit.action")
	public void doEdit(HttpServletResponse response,@Validated SysRole role,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		String actions =role.getActions();
		String allActionString = "[" + Session.get("allActionString") + "]";
		JSONArray ja = JSONArray.fromObject(allActionString);
		Authority authority = new Authority();
		List<Authority> list = new ArrayList<Authority>();
		for(Iterator<?> iter = ja.iterator(); iter.hasNext();)
		{
			JSONObject jsonObject = (JSONObject)iter.next();
			authority = (Authority)JSONObject.toBean(jsonObject, Authority.class);
			if(authority.getType().indexOf("unanonymous") != -1 && !actions.contains(authority.getId()))
			{
				actions += "," + authority.getId();
			}
			list.add(authority);
		}
		Authority a = new Authority();
		String[] p = null;
		// 隐只能继承显，隐不能继承隐，显可继承显，亦可继承隐，父前子后，多继承，全局如此
		for(int i=0; i<list.size(); i++)
		{
			a = (Authority)list.get(i);
			if(!a.getParent().equals("") && a.getType().indexOf("inherit")!=-1)
			{
				p = a.getParent().split(",");
				for(int j=0; j<p.length; j++)
				{
					if(p[j]!=null && !p[j].equals("") && actions.indexOf(p[j]) != -1 && actions.indexOf(a.getId()) == -1)
					{
						actions += "," + a.getId();
					}
				}
			}
		}
		if (!StringUtil.isEmpty(actions))
		{
			if (actions.startsWith(","))
			{
				actions = actions.substring(1);
			}
			if(actions.endsWith(","))
			{
				actions = actions.substring(actions.length()-1);
			}
		}
		role.setActions(actions);
		if(sysRoleService.updateRold(role))
		{
			try
			{
				jedisClientSingle.del("role.list");
				jedisClientSingle.del("rolesJsonString");
				
			} catch (Exception e)
			{
				e.printStackTrace();
			}
			staffLogService.log(Session.getString("staffId"), role.getId(), Session.getString("staffName")+"—修改角色-"+role.getRoleName(), JsonUtil.bean2json(role));
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("修改失败，请稍后重试!",response);
		}
	}
	@RequestMapping("/role.delete.action")
	public void delete(HttpServletResponse response,String ids)
	{
		if(StringUtil.isEmpty(ids))
		{
			AjaxUtil.write("删除失败，请稍后重试!",response);
			return;
		}
		if(sysRoleService.deleteByRoleIds(ids))
		{
			try
			{
				jedisClientSingle.del("role.list");
				jedisClientSingle.del("rolesJsonString");
				
			} catch (Exception e)
			{
				e.printStackTrace();
			}
			staffLogService.log(Session.getString("staffId"), ids, Session.getString("staffName")+"—删除角色", "");
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("删除失败，请稍后重试!",response);
		}
	}
}
