package com.gmadong.modules.bids;

public class BidsWithBLOBs extends Bids {
    /** 公告内容 */
    private String content;

    /** 公告内容(带html标签) */
    private String contentHtml;

    /** 附件名称 */
    private String attachmentName;

    /**
     * 公告内容
     * @return content
     */
    public String getContent() {
        return content;
    }

    /**
     * 公告内容
     * @param content
     */
    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    /**
     * 公告内容(带html标签)
     * @return contentHtml
     */
    public String getContentHtml() {
        return contentHtml;
    }

    /**
     * 公告内容(带html标签)
     * @param contentHtml
     */
    public void setContentHtml(String contentHtml) {
        this.contentHtml = contentHtml == null ? null : contentHtml.trim();
    }

    /**
     * 附件名称
     * @return attachmentName
     */
    public String getAttachmentName() {
        return attachmentName;
    }

    /**
     * 附件名称
     * @param attachmentName
     */
    public void setAttachmentName(String attachmentName) {
        this.attachmentName = attachmentName == null ? null : attachmentName.trim();
    }
}