package com.gmadong.modules.front;

import com.gmadong.modules.user.User;
import com.gmadong.modules.user.UserQdRegister;

public interface MobileUserService
{
	User selectUserByPhone(String phone);

	int updateByltime(String phone, String currentDate);

	Boolean saveUserRegister(MobileRegister reg);
	
	boolean updatePwd(String newPwd, String useId);
}
