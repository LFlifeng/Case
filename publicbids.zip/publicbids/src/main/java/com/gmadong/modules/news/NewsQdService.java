package com.gmadong.modules.news;

import java.util.Date;
import java.util.List;

import com.gmadong.common.Page;
import com.gmadong.modules.bids.Bids;

public interface NewsQdService {

	Page page(Integer page, Integer rows, String category,String title);

	News details(String id);

	List<News> findByCategory(String category);

	List<News> findTodayNews();

	List<News> findHotNews();

}
