package com.gmadong.modules.billinginfo;

import com.gmadong.common.Page;

public interface BillinginfoService
{
	public Page page(String invoice,String accountName,String invoiceType,String ctime,Integer page,Integer rows);
	public boolean save(Billinginfo billinginfo);
	public boolean update(Billinginfo billinginfo);
	public Billinginfo getBillinginfoById(String id);
	public boolean deleteById(String ids);
}
