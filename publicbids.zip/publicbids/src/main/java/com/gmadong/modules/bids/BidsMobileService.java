package com.gmadong.modules.bids;

import com.gmadong.common.Page;
import com.gmadong.modules.biddinginfo.Biddinginfo;
import com.gmadong.modules.biddinginfo.BidsParamsInfo;

public interface BidsMobileService
{
	Page page(BidMobileParamsInfo info, Integer page, Integer rows);
	BidsWithBLOBs details(Integer id);
}

