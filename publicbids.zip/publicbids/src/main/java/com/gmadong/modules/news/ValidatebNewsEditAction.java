package com.gmadong.modules.news;

public interface ValidatebNewsEditAction
{

}
