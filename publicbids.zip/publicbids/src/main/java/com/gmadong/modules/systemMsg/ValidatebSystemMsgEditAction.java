package com.gmadong.modules.systemMsg;

public interface ValidatebSystemMsgEditAction
{

}
