package com.gmadong.modules.usercollection;

public class UserCollection {
    /** 主键(uuid) */
    private String id;

    /** 用户id */
    private String userId;

    /** 项目名称 */
    private String biddinginfoId;

    /** 项目标题 */
    private String biddinginfoTitle;

    /** 创建时间 */
    private String ctime;

    /**
     * 主键(uuid)
     * @return id
     */
    public String getId() {
        return id;
    }

    /**
     * 主键(uuid)
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 用户id
     * @return userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * 用户id
     * @param userId
     */
    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    /**
     * 项目名称
     * @return biddinginfoId
     */
    public String getBiddinginfoId() {
        return biddinginfoId;
    }

    /**
     * 项目名称
     * @param biddinginfoId
     */
    public void setBiddinginfoId(String biddinginfoId) {
        this.biddinginfoId = biddinginfoId == null ? null : biddinginfoId.trim();
    }

    /**
     * 项目标题
     * @return biddinginfoTitle
     */
    public String getBiddinginfoTitle() {
        return biddinginfoTitle;
    }

    /**
     * 项目标题
     * @param biddinginfoTitle
     */
    public void setBiddinginfoTitle(String biddinginfoTitle) {
        this.biddinginfoTitle = biddinginfoTitle == null ? null : biddinginfoTitle.trim();
    }

    /**
     * 创建时间
     * @return ctime
     */
    public String getCtime() {
        return ctime;
    }

    /**
     * 创建时间
     * @param ctime
     */
    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }
}