package com.gmadong.modules.user;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class ForgetPwd
{
	@NotBlank(message="手机号不能为空!")
	@Size(min=11,max=11,message="请输入正确的手机号")
	private String phone;
	@NotBlank(message="验证码不能为空!")
	@Size(min=5,max=5,message="请输入正确的验证码")
	private String yzm;
	public String getPhone()
	{
		return phone;
	}
	public void setPhone(String phone)
	{
		this.phone = phone;
	}
	public String getYzm()
	{
		return yzm;
	}
	public void setYzm(String yzm)
	{
		this.yzm = yzm;
	}


}
