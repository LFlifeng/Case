package com.gmadong.modules.user;

import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gmadong.common.Common;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.ImageUtil;
import com.gmadong.common.utils.JMailUtil;
import com.gmadong.common.utils.SendMsgCodeUtil;
import com.gmadong.common.utils.StringUtil;

@Controller
public class UserFrontController
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	private String key = "userQd.getCode.do";
	
	@RequestMapping("/userQd.code.do")
    public String getCode(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
        response.setContentType("image/jpeg");
        //禁止图像缓存
        response.setHeader("Pragma","no-cache");
        response.setHeader("Cache-Control", "no-cache");
        response.setDateHeader("Expires", 0);
        HttpSession session = request.getSession();
        ImageUtil imageUtil = new ImageUtil(120, 40, 5,30);
        session.setAttribute("code", imageUtil.getCode());
        imageUtil.write(response.getOutputStream());
        return null;
    }
	@RequestMapping("/userQd.getEmailCode.do")
	public void getEmailCode(HttpServletResponse response,String email)
	{
		Integer count = 0;
		if(StringUtil.isEmpty(email)||!JMailUtil.checkEmail(email))
		{
			AjaxUtil.write("请输入正确的邮箱!", response);
			return;
		}
		try
		{
			String hget = jedisClientSingle.hget(key, email);
			if(StringUtil.isNotEmpty(hget))
			{
				count = Integer.valueOf(hget);
			}
			
		}catch (Exception e) 
		{}
		if(count >= 5)
		{
			AjaxUtil.write("发送次数过多,请明天重试!", response);
			return;
		}
		String code = randomCode();
		if(!JMailUtil.sendCode(email, code))
		{
			AjaxUtil.write("发送失败！请稍后重试", response);
			return;
		}
		try
		{
			
			jedisClientSingle.set(email, code,Common.REDIS_30_MINUTE_EXPIRE);
			if(count==0)
			{
				count++;
				jedisClientSingle.hset(key, email, count+"",Common.REDIS_24_HOUR_EXPIRE);
			}
			else
			{	
				count++;
				jedisClientSingle.hset(key, email, count+"");
			}
			
		}catch(Exception e)
		{}
		AjaxUtil.write("发送成功！请注意查收,验证码在半小时内有效", response);
		
				
	}
	@RequestMapping("/userQd.getCode.do")
	public void getCode(HttpServletResponse response,String phone)
	{
		Integer count = 0;
		if(StringUtil.isEmpty(phone)|| phone.length() !=11)
		{
			AjaxUtil.write("请输入正确的手机号!", response);
			return;
		}
		try
		{
			String hget = jedisClientSingle.hget(key, phone);
			if(StringUtil.isNotEmpty(hget))
			{
				count = Integer.valueOf(hget);
			}
			
		}catch (Exception e) 
		{}
		if(count >= 5)
		{
			AjaxUtil.write("发送次数过多,请明天重试!", response);
			return;
		}
		String code = randomCode();
		if(!SendMsgCodeUtil.sendCode(code, phone))
		{
			AjaxUtil.write("发送失败！请稍后重试", response);
			return;
		}
		
		try
		{
			
			jedisClientSingle.set(phone, code,Common.REDIS_30_MINUTE_EXPIRE);
			if(count==0)
			{
				count++;
				jedisClientSingle.hset(key, phone, count+"",Common.REDIS_24_HOUR_EXPIRE);
			}
			else
			{	
				count++;
				jedisClientSingle.hset(key, phone, count+"");
			}
			
		}catch(Exception e)
		{}
		AjaxUtil.write("发送成功！请注意查收,验证码在半小时内有效", response);
		
				
	}
	private String randomCode()
	{
		StringBuffer sb = new StringBuffer();
		Random random  = new Random();
		for(int i=0;i<5;i++)
		{
			sb.append(random.nextInt(10));
		}
		return sb.toString();
	}

	@RequestMapping("/userQd.agreement.do")
    public String agreement() throws Exception
	{
		return "/front/common/agreement";
	}
	@RequestMapping("/userQd.topic.do")
    public String topic() throws Exception
	{
		return "/front/application/topic";
	}
	
	/**
	 *  删除缓存 
	 */
	@RequestMapping("/redis.del.do")
	public void del(HttpServletResponse response) throws Exception
	{
		try
		{
			jedisClientSingle.del("bids.todayBids.do");
			
		} catch (Exception e)
		{
			// TODO: handle exception
		}
		AjaxUtil.write("succ", response);
		
	}
}
