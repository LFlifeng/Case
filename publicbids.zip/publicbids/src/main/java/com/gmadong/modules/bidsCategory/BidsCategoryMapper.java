package com.gmadong.modules.bidsCategory;

import com.gmadong.modules.bidsCategory.BidsCategory;
import com.gmadong.modules.bidsCategory.BidsCategoryExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BidsCategoryMapper {
    int countByExample(BidsCategoryExample example);

    int deleteByExample(BidsCategoryExample example);

    int deleteByPrimaryKey(String id);

    int insert(BidsCategory record);

    int insertSelective(BidsCategory record);

    List<BidsCategory> selectByExample(BidsCategoryExample example);

    BidsCategory selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") BidsCategory record, @Param("example") BidsCategoryExample example);

    int updateByExample(@Param("record") BidsCategory record, @Param("example") BidsCategoryExample example);

    int updateByPrimaryKeySelective(BidsCategory record);

    int updateByPrimaryKey(BidsCategory record);
    
  	//2019/3/12 列表功能：根据返回父类bids_category表id查询list
  	public List<BidsCategory> querylist();
}