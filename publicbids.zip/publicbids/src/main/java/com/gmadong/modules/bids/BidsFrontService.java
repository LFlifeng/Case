package com.gmadong.modules.bids;

import com.gmadong.common.Page;
import com.gmadong.modules.biddinginfo.BidsParamsInfo;

public interface BidsFrontService
{
	public Page page(BidsParamsInfo info, Integer page, Integer rows);
}
