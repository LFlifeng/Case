package com.gmadong.modules.bidsCategory;

import java.util.List;

import com.gmadong.common.Page;

public interface BidsCategoryService 
{
	public boolean save(BidsCategory category);
	public boolean edit(BidsCategory category);
	public List<BidsCategory> getParentCategorys();
	public Page list(String name,String ctime,String level,Integer page,Integer rows);
	public BidsCategory getInfoById(String id);
	public boolean deleteByIds(String ids);
	
	//2019/3/12 列表功能：根据返回父类bids_category表id查询list
	public List<BidsCategoryQd> querylist();
	
}
