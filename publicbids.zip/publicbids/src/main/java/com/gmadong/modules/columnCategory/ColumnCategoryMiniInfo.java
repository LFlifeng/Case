package com.gmadong.modules.columnCategory;

import java.util.ArrayList;
import java.util.List;

public class ColumnCategoryMiniInfo
{
	/** 跳转的地址 */
    private String url;
    /** 栏目名 */
    private String columnName;
    
    private List<ColumnCategoryMiniInfo> list = new ArrayList<ColumnCategoryMiniInfo>();

	public String getUrl()
	{
		return url;
	}

	public void setUrl(String url)
	{
		this.url = url;
	}

	public String getColumnName()
	{
		return columnName;
	}

	public void setColumnName(String columnName)
	{
		this.columnName = columnName;
	}

	public List<ColumnCategoryMiniInfo> getList()
	{
		return list;
	}

	public void setList(List<ColumnCategoryMiniInfo> list)
	{
		this.list = list;
	}

	public ColumnCategoryMiniInfo(String url, String columnName)
	{
		super();
		this.url = url;
		this.columnName = columnName;
	}
}
