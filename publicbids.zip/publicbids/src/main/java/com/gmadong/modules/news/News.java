package com.gmadong.modules.news;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;


public class News {
    /** 新闻id */
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebNewsEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebNewsEditAction.class} )
    private String id;

    /** 新闻标题 */
	@NotBlank(message="标题不能为空!" ,groups = {ValidatebNewsAddAction.class,ValidatebNewsEditAction.class})
    @Size (min=1,max=50,message="请输入正确的标题分类名!" ,groups = {ValidatebNewsAddAction.class,ValidatebNewsEditAction.class})
    private String title;

    /** 新闻类型1:行业资讯2：新规解读3：近期展会4：爆光台 */
    @NotBlank(message="类型不能为空!" ,groups = {ValidatebNewsAddAction.class,ValidatebNewsEditAction.class})
    private String category;

    /** 发表人 */
    @NotBlank(message="发表人名不能为空!" ,groups = {ValidatebNewsAddAction.class,ValidatebNewsEditAction.class})
    @Size (min=1,max=20,message="请输入正确的发表人名!" ,groups = {ValidatebNewsAddAction.class,ValidatebNewsEditAction.class})
    private String staffId;

    /** 发布人昵称 */
    @NotBlank(message="发布人昵称不能为空!" ,groups = {ValidatebNewsAddAction.class,ValidatebNewsEditAction.class})
    @Size (min=1,max=20,message="请输入正确的发布人昵称!" ,groups = {ValidatebNewsAddAction.class,ValidatebNewsEditAction.class})
    private String staffName;
    
    /** 新闻时间 */
    private String ctime;

    /** 新闻内容 */
    private String content;

    /**
     * 新闻id
     * @return id
     */
    public String getId() {
        return id;
    }

    /**
     * 新闻id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 新闻标题
     * @return title
     */
    public String getTitle() {
        return title;
    }

    /**
     * 新闻标题
     * @param title
     */
    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    /**
     * 新闻类型1:行业资讯2：新规解读3：近期展会4：爆光台
     * @return category
     */
    public String getCategory() {
        return category;
    }

    /**
     * 新闻类型1:行业资讯2：新规解读3：近期展会4：爆光台
     * @param category
     */
    public void setCategory(String category) {
        this.category = category == null ? null : category.trim();
    }

    /**
     * 发表人
     * @return staffId
     */
    public String getStaffId() {
        return staffId;
    }

    /**
     * 发表人
     * @param staffId
     */
    public void setStaffId(String staffId) {
        this.staffId = staffId == null ? null : staffId.trim();
    }

    /**
     * 发布人昵称
     * @return staffName
     */
    public String getStaffName() {
        return staffName;
    }

    /**
     * 发布人昵称
     * @param staffName
     */
    public void setStaffName(String staffName) {
        this.staffName = staffName == null ? null : staffName.trim();
    }

    /**
     * 新闻时间
     * @return ctime
     */
    public String getCtime() {
        return ctime;
    }

    /**
     * 新闻时间
     * @param ctime
     */
    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }

    /**
     * 新闻内容
     * @return content
     */
    public String getContent() {
        return content;
    }

    /**
     * 新闻内容
     * @param content
     */
    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

	@Override
	public String toString()
	{
		return "News [id=" + id + ", title=" + title + ", category=" + category + ", staffId=" + staffId
				+ ", staffName=" + staffName + ", ctime=" + ctime + ", content=" + content + "]";
	}
    
    
}