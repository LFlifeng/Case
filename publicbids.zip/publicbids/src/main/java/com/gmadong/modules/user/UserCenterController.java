package com.gmadong.modules.user;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.aspectj.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gmadong.common.Common;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JMailUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.PasswordUtil;
import com.gmadong.common.utils.SendMsgCodeUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.PasswordUtil.PasswordUtilType;
import com.gmadong.modules.company.Company;
import com.gmadong.modules.company.CompanyService;

/**
 * 用户中心 公共部分
 * 
 * @author caodongdong
 *
 */
@Controller
public class UserCenterController {
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private CompanyService companyService;
	public static String key = "userQd.center.do";

	@Autowired
	private UserQdService userQdService;
	/**
	 * 跳转到用户中心
	 * 
	 * @throws IOException
	 */
	@RequestMapping("/userQd.center.do")
	public String userCenter(HttpServletRequest req, HttpServletResponse res) {
		User user = (User) Session.get("user");
		try {
			String string = jedisClientSingle.hget(key,user.getId());
			if (StringUtil.isNotEmpty(string)) {

				ObjectMapper mapper = new ObjectMapper();
				Company company = mapper.readValue(string, Company.class);
				Request.set("company", company);
				return "/front/usercenter/usercenter";
			}

		} catch (Exception e) {
		}
		Company company = companyService.getCompanyByStaffId(user.getId());
		req.setAttribute("company", company == null ? new Company() : company);
		try {
			// 查询用户表信息以及相关公司
			jedisClientSingle.hset(key,user.getId(),JsonUtil.bean2json(company));

		} catch (Exception e) {
		}
		
		return "/front/usercenter/usercenter";
	}

	/**
	 * 标书服务
	 * 
	 * @return
	 */
	@RequestMapping("/userQd.tenderserver.do")
	public String tenderserver() {
		return "/front/usercenter/tenderserver";
	}

	/**
	 * 会员服务
	 * 
	 * @return
	 */
	@RequestMapping("/userQd.memberserver.do")
	public String memberserver() {
		return "/front/usercenter/membership";
	}

	/**
	 * 推广服务
	 * 
	 * @return
	 */
	@RequestMapping("/userQd.promotionserver.do")
	public String promotionserver() {
		return "/front/usercenter/promotionserver";
	}

	/**
	 * 发票申请
	 * 
	 * @return
	 */
	@RequestMapping("/userQd.applyinvoice.do")
	public String applyinvoice() {
		return "/front/usercenter/applyinvoice";
	}

	/**
	 * 发票列表
	 * 
	 * @return
	 */
	@RequestMapping("/userQd.invoicelists.do")
	public String invoicelists() {
		return "/front/usercenter/invoicelists";
	}

	/**
	 * 退出登录
	 * 
	 * @return
	 */
	@RequestMapping("/userQd.logout.do")
	public String logout(HttpServletRequest req) {
		req.getSession().invalidate();
		return "redirect:/main.index.do";
	}

	/**
	 * 跳转密码修改页面
	 * 
	 * @return
	 */
	@RequestMapping("/userQd.changePwdIndex.do")
	public String changePwdIndex() {
		return "/front/usercenter/changePwd";
	}

	/**
	 * 密码修改
	 * 
	 * @return
	 */
	@RequestMapping("/userQd.updatePwd.do")
	public void updatePwd(HttpServletResponse response, String oldPwd, String newPwd) {
		User user = (User) Session.get("user");
		if (user == null) {
			AjaxUtil.write("请先登录", response);
			return;
		}
		if (oldPwd.length() < 6 || oldPwd.length() > 12) {
			AjaxUtil.write("请输入正确的旧密码", response);
			return;
		}
		if (!user.getPassword().equals(PasswordUtil.encrypt(oldPwd, PasswordUtilType.NORMAL)) ) {
			AjaxUtil.write("密码错误", response);
			return;
		}
		if (newPwd.length() < 6 || newPwd.length() > 12) {
			AjaxUtil.write("请输入正确的新密码", response);
			return;
		}
		newPwd = PasswordUtil.encrypt(newPwd, PasswordUtilType.NORMAL);
		if(userQdService.updatePwd(newPwd,user.getId())) {
			user.setPassword(newPwd);
			try {
				String key="userQd-"+user.getPhone();
				jedisClientSingle.set(key, JsonUtil.bean2json(user),Common.REDIS_72_HOUR_EXPIRE);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
			return;
		}else {
			AjaxUtil.write("fail", response);
			return;
		}

	}
	
	/**
	 * 跳转更改手机页面
	 * 
	 * @return
	 */
	@RequestMapping("/userQd.changePhoneIndex.do")
	public String changePhoneIndex() {
		return "/front/usercenter/changePhone";
	}

	/**
	 * 手机号修改
	 * 
	 * @return
	 */
	@RequestMapping("/userQd.updatePhone.do")
	public void updatePhone(HttpServletResponse response, String phone,String verificationCode) {
		User user = (User) Session.get("user");
		if (user == null) {
			AjaxUtil.write("请先登录", response);
			return;
		}
		if(StringUtil.isEmpty(phone) || phone.length() != 11) {
			AjaxUtil.write("请输入正确的手机号", response);
			return;
		}
		String code = jedisClientSingle.get(phone);
		if(StringUtil.isEmpty(code) || !code.equals(verificationCode))
		{	
			AjaxUtil.write("请输入正确的验证码", response);
			return;
		}
		//根据手机号查看是否被注册过
		User use =  userQdService.selectUserByPhone(phone);
		if(use!=null)	
		{
			AjaxUtil.write("该手机号已经注册", response);
			return;
		}
		if(userQdService.updatePhone(phone,user.getId())) {
			
			String key="userQd-"+user.getPhone();
			try {
				jedisClientSingle.del(user.getPhone());
				user.setPhone(phone);
				key="userQd-"+user.getPhone();
				jedisClientSingle.set(key, JsonUtil.bean2json(user),Common.REDIS_72_HOUR_EXPIRE);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
			return;
		}else {
			AjaxUtil.write("fail", response);
			return;
		}

	}
	
	/**
	 * 跳转更改账号信息页面
	 * 
	 * @return
	 */
	@RequestMapping("/userQd.accountInformationIndex.do")
	public String accountInformationIndex() {
		return "/front/usercenter/accountinformation";
	}

	/**
	 * 账号信息修改
	 * 
	 * @param response
	 * @param portrait 头像
	 * @param nickname 昵称
	 * @param year     年
	 * @param month    月
	 * @param date     日
	 * @param sex      性别
	 */
	@RequestMapping("/userQd.updateAccountInformation.do")
	public void updateAccountInformation(HttpServletResponse response, @Validated({ValidatebAccountEditAction.class}) Account account,
			BindingResult bindingResult) {
		User user = (User) Session.get("user");
		if (user == null) {
			AjaxUtil.write("请先登录", response);
			return;
		}
		if (bindingResult.hasErrors()) {
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(), response);
			return;
		}
		String portrait = account.getPortrait();
		String portraitUrl = account.getPortraitUrl();
		String nickName = account.getNickName();
		String year = account.getYear();
		String month = account.getMonth();
		String date = account.getDate();
		String sex = account.getSex();
		String birthday = year +"-"+ month +"-"+ date;
		String userId = user.getId();
		
		if (userQdService.updateAccountInformation(userId, portrait, portraitUrl, nickName, birthday, sex)) {
			try {
				user.setBirthday(birthday);
				user.setSex(sex);
				user.setPortrait(portrait);
				user.setPortraitUrl(portraitUrl);
				user.setNickname(nickName);
				key = "userQd-" + user.getPhone();
				jedisClientSingle.set(key, JsonUtil.bean2json(user), Common.REDIS_72_HOUR_EXPIRE);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
			return;
		} else {
			AjaxUtil.write("fail", response);
			return;
		}

	}
	
	/**
	 * 跳转绑定邮箱页面
	 * 
	 * @return
	 */
	@RequestMapping("/userQd.bindEmailIndex.do")
	public String bindEmail() {
		return "/front/usercenter/bindEmail";
	}
	/**
	 * 绑定邮箱
	 * @param response
	 * @param email
	 * @param verificationCode
	 */
	@RequestMapping("/userQd.bindEmail.do")
	public void bindEmail(HttpServletResponse response, String email,String verificationCode) {
		User user = (User) Session.get("user");
		if (user == null) {
			AjaxUtil.write("请先登录", response);
			return;
		}
		if(StringUtil.isEmpty(email) || !JMailUtil.checkEmail(email)) {
			AjaxUtil.write("请输入正确的邮箱", response);
			return;
		}
		String code = jedisClientSingle.get(email);
		if(StringUtil.isEmpty(verificationCode) || !code.equals(verificationCode))
		{	
			AjaxUtil.write("请输入正确的验证码", response);
			return;
		}
		//根据邮箱查看是否被绑定过
		User use =  userQdService.selectUserByEmail(email);
		if(use!=null)	
		{
			AjaxUtil.write("该邮箱已经被使用", response);
			return;
		}
		if(userQdService.updateEmail(email,user.getId())) {
			
			String key="userQd-"+user.getPhone();
			try {
				user.setEmailAddress(email);
				jedisClientSingle.del(email);
				jedisClientSingle.set(key, JsonUtil.bean2json(user),Common.REDIS_72_HOUR_EXPIRE);		
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
			return;
		}else {
			AjaxUtil.write("fail", response);
			return;
		}

	}
	
	/**
	 * 跳转供应商登陆页面
	 * 
	 * @return
	 */
	@RequestMapping("/userQd.supplierIndex.do")
	public String supplierIndex() {
		return "/front/application/supplier_login";
	}
}
