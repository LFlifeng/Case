package com.gmadong.modules.projectDesigneds;

import com.gmadong.modules.projectDesigneds.ProjectDesigneds;
import com.gmadong.modules.projectDesigneds.ProjectDesignedsExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ProjectDesignedsMapper {
    int countByExample(ProjectDesignedsExample example);

    int deleteByExample(ProjectDesignedsExample example);

    int deleteByPrimaryKey(String id);

    int insert(ProjectDesigneds record);

    int insertSelective(ProjectDesigneds record);

    List<ProjectDesigneds> selectByExample(ProjectDesignedsExample example);

    ProjectDesigneds selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") ProjectDesigneds record, @Param("example") ProjectDesignedsExample example);

    int updateByExample(@Param("record") ProjectDesigneds record, @Param("example") ProjectDesignedsExample example);

    int updateByPrimaryKeySelective(ProjectDesigneds record);

    int updateByPrimaryKey(ProjectDesigneds record);

    //个人新增
	Integer selectDesignedsCountByUserId(@Param("userId")String userId);
}