package com.gmadong.modules.columnCategory;

public interface ValidatebColumnCategoryEditAction
{

}
