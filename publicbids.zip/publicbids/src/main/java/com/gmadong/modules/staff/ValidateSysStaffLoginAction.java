package com.gmadong.modules.staff;

public interface ValidateSysStaffLoginAction
{

}
