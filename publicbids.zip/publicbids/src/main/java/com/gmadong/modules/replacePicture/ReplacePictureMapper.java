package com.gmadong.modules.replacePicture;

import com.gmadong.modules.replacePicture.ReplacePicture;
import com.gmadong.modules.replacePicture.ReplacePictureExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ReplacePictureMapper {
    int countByExample(ReplacePictureExample example);

    int deleteByExample(ReplacePictureExample example);

    int deleteByPrimaryKey(String id);

    int insert(ReplacePicture record);

    int insertSelective(ReplacePicture record);

    List<ReplacePicture> selectByExample(ReplacePictureExample example);

    ReplacePicture selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") ReplacePicture record, @Param("example") ReplacePictureExample example);

    int updateByExample(@Param("record") ReplacePicture record, @Param("example") ReplacePictureExample example);

    int updateByPrimaryKeySelective(ReplacePicture record);

    int updateByPrimaryKey(ReplacePicture record);
}