package com.gmadong.modules.systemInfo;

import javax.servlet.http.HttpServletResponse;

import org.apache.http.client.HttpClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.ApplicationContextUtil;
import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.StringUtil;




/**
 * 系统信息管理
 * @author Administrator
 *
 */
@Controller
public class SystemInfoController
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private SystemInfoService systemInfoService;
	private String listkey = "systemInfo.list.action";
	
	/**
	 * 列表页面
	 * @return
	 */
	@RequestMapping("/systemInfo.page.action")
	public String page()
	{
		return "/back/systemInfo/page";
	}
	
	/**
	 * 页面条件搜索
	 * @return
	 */
	@RequestMapping("/systemInfo.list.action")
	public void list(HttpServletResponse response,String companyName,String companyPhone,String companySite,String ctime,@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows) 
	{
		String field = companyName +"_" + companyPhone +"_" + companySite + "_" + ctime + "_" + page + "_" + rows;
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = systemInfoService.page(companyName,companyPhone,companySite,ctime,page, rows);
		String list = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, list, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(Page.pageToJson(toPage), response);
	}
	/**
	 * 添加页面
	 * @return
	 */
	@RequestMapping("/systemInfo.preAdd.action")
	public String preAdd() 
	{
		return "/back/systemInfo/add";
	}
	/**
	 * 添加操作
	 * @return
	 */
	@RequestMapping("/systemInfo.doAdd.action")
	public void doAdd(HttpServletResponse response,@Validated({ ValidatebSystemInfoAddAction.class }) SystemInfo systemInfo,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		if(systemInfoService.save(systemInfo))
		{
			try {
				jedisClientSingle.del(listkey);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		}
		else {
			AjaxUtil.write("添加失败", response);
		}
	}
	/**
	 * 修改页面
	 * @return
	 */
	@RequestMapping("/systemInfo.preEdit.action")
	public String preEdit(String id) 
	{
		Request.set("info", Session.getSession().getServletContext().getAttribute("systemInfo"));
		return "/back/systemInfo/edit";
	}
	/**
	 * 修改操作
	 */
	@RequestMapping("/systemInfo.doEdit.action")
	public void doEdit(HttpServletResponse response,@Validated({ ValidatebSystemInfoEditAction.class }) SystemInfo systemInfo, BindingResult bindingResult) 
	{
		if (bindingResult.hasErrors()) 
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(), response);
			return;
		}
		if(systemInfoService.update(systemInfo))
		{
			try
			{
				jedisClientSingle.del(listkey);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			Session.getSession().getServletContext().setAttribute("systemInfo", systemInfo);
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("修改失败！",response);
		}
	}
	/**
	 * 删除
	 * @return
	 */
	@RequestMapping("/systemInfo.doDelete.action")
	public void doDelete(HttpServletResponse response, String ids) {
		if (systemInfoService.deleteById(ids)) {
			try {
				jedisClientSingle.del(listkey);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("fail", response);
		}
	}
}
