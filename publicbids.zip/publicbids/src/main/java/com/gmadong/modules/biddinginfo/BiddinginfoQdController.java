package com.gmadong.modules.biddinginfo;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.bids.Bids;
import com.gmadong.modules.browsingHistory.BrowsingHistory;
import com.gmadong.modules.browsingHistory.BrowsingHistoryService;
import com.gmadong.modules.category.Category;
import com.gmadong.modules.category.CategoryService;
import com.gmadong.modules.city.SysCity;
import com.gmadong.modules.city.SysCityService;
import com.gmadong.modules.industry.Industry;
import com.gmadong.modules.industry.IndustryService;
import com.gmadong.modules.user.User;

import net.sf.json.JSONObject;

/**
 * 前台项目中心控制层
 * 
 * @author Administrator
 *
 */
@Controller
public class BiddinginfoQdController {
	@Autowired
	private JedisClientSingle jedisClientSingle;

	@Resource(name = "biddinginfoQdService")
	private BiddinginfoQdService biddinginfoQdService;

	private String listkey = "Biddinginfo.list.do";

	@Autowired
	private CategoryService categoryService;

	@Autowired
	private SysCityService sysCityService;

	@Autowired
	private BrowsingHistoryService browsingHistoryService;

	@Autowired
	private IndustryService industryService;

	
	
	/**
	 * 项目中心列表页跳转
	 * 
	 * @return
	 */
	@RequestMapping("/biddinginfo.listIndex.do")
	public String page() {
		return "/front/biddinginfo/list";
	}

	/**
	 * 项目中心列表页查询
	 * 
	 * @param response
	 * @param name     项目名称
	 * @param type     项目分类
	 * @param ctime    创建时间
	 * @param province 省份
	 * @param industry 行业类型
	 * @param page     页
	 * @param rows     行
	 */
	@RequestMapping("/biddinginfo.list.do")
	public void list(HttpServletResponse response, String name, String type, String ctime, String province,
			String industry, @RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "20") Integer rows) {
		String field = name + "-" + type + "-" + ctime + "-" + province + "-" + industry + "-" + page + "-" + rows;
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = biddinginfoQdService.page(name, type, ctime, province, industry, page, rows);
		String listStr = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, listStr, Common.REDIS_6_HOUR_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
	}

	/**
	 * 项目详情查询
	 * 
	 * @param response
	 * @param id       公告id
	 */
	@RequestMapping("/biddinginfo.details.do")
	public String details(HttpServletResponse response, String id) {
		Biddinginfo biddinginfo = null;
		String key = "biddinginfo.details-" + id;
		
		//获取用户等级级别
		User user=(User)Session.get("user");
		String grade=(user==null?"0":user.getGrade());
		int memberGrade=Integer.parseInt(grade);
		try {
			String detail = jedisClientSingle.get(key);
			if (StringUtil.isNotEmpty(detail)) {
				JSONObject jsonObject = JSONObject.fromObject(detail);
				biddinginfo = (Biddinginfo) JSONObject.toBean(jsonObject, Biddinginfo.class);
				if(biddinginfo != null) {
					addBrowHistory(biddinginfo);
				}
				Request.set("detail", biddinginfo);
				
				//grade级别      0:普通用户  1:普通会员  2：高级会员  3：vip高级会员   4：钻石会员
					//高级会员可以查看拟建项目
				if(memberGrade >= 2)
				{
					return "/front/biddinginfo/detail";
				}
				biddinginfo.setContent("");
				return "/front/biddinginfo/detail2";
				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		biddinginfo = biddinginfoQdService.details(id);
		String detail = JsonUtil.bean2json(biddinginfo);
		if (biddinginfo != null) {
			addBrowHistory(biddinginfo);
		}
			try {

				jedisClientSingle.set(key, detail, Common.REDIS_30_MINUTE_EXPIRE);
			} catch (Exception e) {
				e.printStackTrace();	
		}
		Request.set("detail", biddinginfo);
		
		if(memberGrade >= 2)
		{
			return "/front/biddinginfo/detail";
		}
		biddinginfo.setContent("");
		return "/front/biddinginfo/detail2";
		
	}

	/**
	 * 首页不同项目类型列表查询
	 * 
	 * @param response
	 * @param leixing
	 */
	@RequestMapping("/biddinginfo.findBidingInfoByType.do")
	public void findBidingInfoByType(HttpServletResponse response, String proType) {
		String field =proType;
		try {
			String listStr = jedisClientSingle.hget(listkey,field);
			if (StringUtil.isNotEmpty(listStr)) {
				AjaxUtil.write(listStr, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		List<Biddinginfo> list = biddinginfoQdService.findBidingInfoByType(proType);
		String listStr = JsonUtil.listToJson(list);
		try {
			jedisClientSingle.hset(listkey,field, listStr, Common.REDIS_6_HOUR_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}

		AjaxUtil.write(listStr, response);
		return;
	}

	/**
	 * 个人中心-发布项目信息页面跳转
	 * 
	 * @return
	 */
	@RequestMapping("/publishInformation.index.do")
	public String publishInformationIndex() {
		List<Category> categorys = categoryService.getCategorys("4");
		Request.set("categorys", categorys);
		return "/front/usercenter/publishInformation";
	}

	/**
	 * 个人中心-管理发布页面跳转
	 * 
	 * @return
	 */
	@RequestMapping("/mangerelease.index.do")
	public String mangereleaseIndex() {
		return "/front/usercenter/mangerelease";
	}

	/**
	 * 个人中心-发布项目信息
	 * 
	 * @param response
	 * @param biddinginfo
	 * @param bindingResult
	 */
	@RequestMapping("/biddinginfo.add.do")
	public void addBiddingInfo(HttpServletResponse response,
			@Validated({ ValidatebBiddinginfoAddFrontAction.class }) Biddinginfo biddinginfo, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(), response);
			return;
		}
		
		biddinginfo.setState("0");
		User user = (User) Session.get("user");
		if (user == null) {
			AjaxUtil.write("用户未登陆", response);
			return;
		}
		biddinginfo.setUserId(user.getId());


		if (biddinginfoQdService.save(biddinginfo)) {
			try {
				jedisClientSingle.del(listkey + user.getId());
				jedisClientSingle.del("biddinginfo.list.action");
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("fail", response);

		}
	}

	/**
	 * 个人中心-删除项目信息
	 * 
	 * @param response
	 * @param id
	 */
	@RequestMapping("/biddinginfo.delete.do")
	public void deleteBiddingInfo(HttpServletResponse response, String id) {
		User user = (User)Session.get("user");
		if (biddinginfoQdService.deleteById(id)) {
			try {
				jedisClientSingle.del(listkey+ user.getId());
				jedisClientSingle.del("biddinginfo.list.action");
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("fail", response);
		}
	}
	/**
	 * 个人中心-管理发布列表查询
	 * @param response
	 * @param page
	 * @param rows
	 */
	@RequestMapping("/biddinginfo.Userlist.do")
	public void list(HttpServletResponse response, @RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "10") Integer rows) {

		User user = (User) Session.get("user");
		if (user == null) {
			AjaxUtil.write("用户未登陆", response);
			return;
		}
		String userId = user.getId();
		String key = listkey + userId;
		String field = page + "-" + rows ;
		try {
			
			String list = jedisClientSingle.hget(key, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = biddinginfoQdService.pageUser(userId, page, rows);
		String listStr = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(key, field, listStr, Common.REDIS_6_HOUR_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
	}

	
	
	/**
	 * 添加浏览历史
	 * @param biddinginfo
	 */
	public void addBrowHistory(Biddinginfo biddinginfo) {
		User user = (User) Session.get("user");
		if (user == null) {
			return;
		}
		BrowsingHistory browsingHistory = new BrowsingHistory();
		browsingHistory.setId(UUIDUtil.getUUID());
		browsingHistory.setCtime(DateUtil.getCurrentDate());
		browsingHistory.setUserId(user.getId());
		browsingHistory.setBiddinginfoId(biddinginfo.getId());
		browsingHistory.setBiddinginfoTitle(biddinginfo.getProjectName());
		try {
			if (browsingHistoryService.save(browsingHistory)) {	
				jedisClientSingle.del("browsingHistory.list_" + user.getId());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 根据公司id查询投标采购公告
	 * 
	 * @param response
	 * @param companyId
	 * @param page
	 * @param rows
	 */
	@RequestMapping("/biddinginfo.companyBiddingInfolist.do")
	public void companylist(HttpServletResponse response, String applicationId,
			@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows) {

		String field = applicationId + "-" + page + "-" + rows;
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = biddinginfoQdService.pageCompany(applicationId, page, rows);
		String listStr = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, listStr, Common.REDIS_6_HOUR_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(listStr, response);
	}


}