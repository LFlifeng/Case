package com.gmadong.modules.tracker;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.company.CompanyExample;
import com.gmadong.modules.tracker.TrackerExample.Criteria;


@Service("trackerService")
public class TrackerServiceImpl implements TrackerService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private TrackerMapper trackerMapper;
	
	@Override
	public Page page(String trackerName, String searchType, String ctime, Integer page, Integer rows)
	{
		TrackerExample trackerExample = new TrackerExample();
		Criteria createCriteria = trackerExample.createCriteria();
		if (!StringUtil.isEmpty(trackerName)) {
			createCriteria.andTrackerNameLike(trackerName + "%");
		}
		if (!StringUtil.isEmpty(searchType)) {
			createCriteria.andSearchTypeLike(searchType + "%");
		}
		if (!StringUtil.isEmpty(ctime)) {
			createCriteria.andCtimeLike(ctime + "%");
		}
		trackerExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<Tracker> list = trackerMapper.selectByExample(trackerExample);
		PageInfo<Tracker> pageInfo = new PageInfo<Tracker>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean save(Tracker tracker)
	{
		tracker.setId(UUIDUtil.getUUID());
		tracker.setCtime(DateUtil.getCurrentDate());
		boolean flag = trackerMapper.insert(tracker) > 0;
		return flag;
	}

	@Override
	public boolean update(Tracker tracker)
	{
		tracker.setCtime(null);
		return trackerMapper.updateByPrimaryKeySelective(tracker) > 0;
	}

	@Override
	public Tracker getTrackerById(String id)
	{
		return trackerMapper.selectByPrimaryKey(id);
	}

	@Override
	public boolean deleteById(String ids)
	{
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			TrackerExample trackerExample = new TrackerExample();
			Criteria createCriteria = trackerExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			return trackerMapper.deleteByExample(trackerExample) > 0;
		}
		return false;
	}

}
