package com.gmadong.modules.product;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.product.ProductExample.Criteria;

@Service("productService")
public class ProductServiceImpl implements ProductService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private ProductMapper productMapper;
	
	@Override
	public Page page(String productName, String productDescribe, String ctime, Integer page, Integer rows)
	{
		ProductExample productExample = new ProductExample();
		Criteria createCriteria = productExample.createCriteria();
		if (!StringUtil.isEmpty(productName)) {
			createCriteria.andProductNameLike(productName + "%");
		}
		if (!StringUtil.isEmpty(productDescribe)) {
			createCriteria.andProductDescribeLike(productDescribe + "%");
		}
		if (!StringUtil.isEmpty(ctime)) {
			createCriteria.andCtimeLike(ctime + "%");
		}
		productExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<Product> list = productMapper.selectByExample(productExample);
		PageInfo<Product> pageInfo = new PageInfo<Product>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean save(Product product)
	{
		product.setId(UUIDUtil.getUUID());
		product.setCtime(DateUtil.getCurrentDate());
		boolean flag = productMapper.insert(product) > 0;
		return flag;
	}

	@Override
	public boolean update(Product product)
	{
		product.setCtime(null);
		return productMapper.updateByPrimaryKeySelective(product) > 0;
	}

	@Override
	public Product getProductById(String id)
	{
		return productMapper.selectByPrimaryKey(id);
	}

	@Override
	public boolean deleteById(String ids)
	{
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			ProductExample productExample = new ProductExample();
			Criteria createCriteria = productExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			return productMapper.deleteByExample(productExample) > 0;
		}
		return false;
	}
	
}


