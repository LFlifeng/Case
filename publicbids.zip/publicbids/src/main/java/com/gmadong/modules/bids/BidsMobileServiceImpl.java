package com.gmadong.modules.bids;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.datasource.CustomerContextHolder;
import com.gmadong.modules.biddinginfo.Biddinginfo;
import com.gmadong.modules.biddinginfo.BiddinginfoMapper;
import com.gmadong.modules.biddinginfo.BidsInfo;

@Service("bidsMobileService")
public class BidsMobileServiceImpl implements BidsMobileService
{

	@Autowired
	private BidsMapper bidsMapper;
	@Override
	public Page page(BidMobileParamsInfo info, Integer page, Integer rows)
	{
		PageHelper.startPage(page, rows);
		CustomerContextHolder.setCustomerType(CustomerContextHolder.BIDS_DATA_SOURCE_MSSQL);
		List<BidsInfo> list = bidsMapper.selectBidingByMobileParamsInfo(info);
		CustomerContextHolder.clearCustomerType();
		PageInfo<BidsInfo> pageInfo = new PageInfo<BidsInfo>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}
	@Override
	public BidsWithBLOBs details(Integer id)
	{ 
		CustomerContextHolder.setCustomerType(CustomerContextHolder.BIDS_DATA_SOURCE_MSSQL);
		BidsWithBLOBs selectByPrimaryKey = bidsMapper.selectByPrimaryKey(id);
		CustomerContextHolder.clearCustomerType();
		return selectByPrimaryKey;
	}
}










