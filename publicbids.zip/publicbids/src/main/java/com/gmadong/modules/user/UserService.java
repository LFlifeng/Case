package com.gmadong.modules.user;

import java.util.List;

import com.gmadong.common.Page;
import com.gmadong.modules.category.Category;


public interface UserService
{
	public Page page(String personalOffice,String grade,String starttime,String endtime,String status,String name,Integer page,Integer rows);
	public List<User> getParent();
	public boolean save(User user);
	public boolean deleteById(String ids);
	public boolean update(User user);
	public User getUserById(String id);
	/**
	 * 根据登录名查找用户信息
	 * @param name 登录名
	 * @return
	 */
	public User getUsername(String name);
	/**
	 * 根据登录名查找用户信息
	 * @param name 登录名
	 * @return
	 */
	public User getUseraccount(String phone);
	
	public List<User> getUser(String nickname);
	
	public String getNicknameById(String id);
	
	public String getPhoneById(String id);
	
	//重置密码
	public boolean updates(String id,String password);
	
	public Page getNotificationList(Integer page,Integer rows);
}
