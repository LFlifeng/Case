package com.gmadong.modules.systemInfo;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.gmadong.common.utils.FileUtil;
import com.gmadong.common.utils.StringUtil;




public class SystemInfo {
	@NotBlank(message="ID不能为空!" ,groups = {ValidatebSystemInfoEditAction.class} )
	@Size(min=32,max=32,message="非法数据！" ,groups = {ValidatebSystemInfoEditAction.class} )
    private String id;

    /** 公司名称 */
    @Size (max=50,message="请输入正确的公司名称!" ,groups = {ValidatebSystemInfoAddAction.class,ValidatebSystemInfoEditAction.class})
    private String companyName;

    /** 公司电话 */
    @Size (max=18,message="请输入正确的公司电话!" ,groups = {ValidatebSystemInfoAddAction.class,ValidatebSystemInfoEditAction.class})
    private String companyPhone;

    /** 公司地址 */
    @Size (max=100,message="请输入正确的公司地址!" ,groups = {ValidatebSystemInfoAddAction.class,ValidatebSystemInfoEditAction.class})
    private String companySite;

    /** 客服电话 */
    @Size (max=18,message="请输入正确的客服电话!" ,groups = {ValidatebSystemInfoAddAction.class,ValidatebSystemInfoEditAction.class})
    private String servicePhone;
	
	 /** 地址 */
    private String url;
	
    /** 传真 */
    @Size (max=10,message="请输入正确的传真!" ,groups = {ValidatebSystemInfoAddAction.class,ValidatebSystemInfoEditAction.class})
    private String fax;

    /** 邮编 */
    @Size (max=6,message="请输入正确的邮编!" ,groups = {ValidatebSystemInfoAddAction.class,ValidatebSystemInfoEditAction.class})
    private String postcode;

    /** 关键字 */
    @Size (max=100,message="请输入正确的关键字!" ,groups = {ValidatebSystemInfoAddAction.class,ValidatebSystemInfoEditAction.class})
    private String keywords;

    /** 描述 */
    @Size (max=100,message="请输入正确的描述!" ,groups = {ValidatebSystemInfoAddAction.class,ValidatebSystemInfoEditAction.class})
    private String description;

    /** app下载图片 */
    private String appPicture;

    /** 微信公众号 */
    private String officialAccountPicture;

    /** 版权所有 */
    @Size (max=100,message="请输入正确的版权所有!" ,groups = {ValidatebSystemInfoAddAction.class,ValidatebSystemInfoEditAction.class})
    private String copyrightAll;

    private String ctime;
    
  //后加的属性
    private String appPictureUrl;
    private String officialAccountPictureUrl;
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 公司名称
     * @return companyName
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * 公司名称
     * @param companyName
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName == null ? null : companyName.trim();
    }

    /**
     * 公司电话
     * @return companyPhone
     */
    public String getCompanyPhone() {
        return companyPhone;
    }

    /**
     * 公司电话
     * @param companyPhone
     */
    public void setCompanyPhone(String companyPhone) {
        this.companyPhone = companyPhone == null ? null : companyPhone.trim();
    }

    /**
     * 公司地址
     * @return companySite
     */
    public String getCompanySite() {
        return companySite;
    }

    /**
     * 公司地址
     * @param companySite
     */
    public void setCompanySite(String companySite) {
        this.companySite = companySite == null ? null : companySite.trim();
    }

    /**
     * 客服电话
     * @return servicePhone
     */
    public String getServicePhone() {
        return servicePhone;
    }

    /**
     * 客服电话
     * @param servicePhone
     */
    public void setServicePhone(String servicePhone) {
        this.servicePhone = servicePhone == null ? null : servicePhone.trim();
    }

    /**
     * 传真
     * @return fax
     */
    public String getFax() {
        return fax;
    }

    /**
     * 传真
     * @param fax
     */
    public void setFax(String fax) {
        this.fax = fax == null ? null : fax.trim();
    }

    /**
     * 邮编
     * @return postcode
     */
    public String getPostcode() {
        return postcode;
    }

    /**
     * 邮编
     * @param postcode
     */
    public void setPostcode(String postcode) {
        this.postcode = postcode == null ? null : postcode.trim();
    }

    /**
     * 关键字
     * @return keywords
     */
    public String getKeywords() {
        return keywords;
    }

    /**
     * 关键字
     * @param keywords
     */
    public void setKeywords(String keywords) {
        this.keywords = keywords == null ? null : keywords.trim();
    }

    /**
     * 描述
     * @return description
     */
    public String getDescription() {
        return description;
    }

    /**
     * 描述
     * @param description
     */
    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    /**
     * app下载图片
     * @return appPicture
     */
    public String getAppPicture() {
        return appPicture;
    }

    /**
     * app下载图片
     * @param appPicture
     */
    public void setAppPicture(String appPicture) {
    	if(StringUtil.isNotEmpty(appPicture))
    	{
    		if(appPicture.endsWith(".png"))
    		{
    			this.appPictureUrl = appPicture;
    		}
    		else
    		{
    			this.appPictureUrl = "/upload/attach"+FileUtil.getPath(appPicture)+appPicture +".png";
    		}
    		
    	}
        this.appPicture = appPicture == null ? null : appPicture.trim();
    }

    /**
     * 微信公众号
     * @return officialAccountPicture
     */
    public String getOfficialAccountPicture() {
        return officialAccountPicture;
    }

    /**
     * 微信公众号
     * @param officialAccountPicture
     */
    public void setOfficialAccountPicture(String officialAccountPicture) {
    	if(StringUtil.isNotEmpty(officialAccountPicture))
    	{
    		if(officialAccountPicture.endsWith(".jpg"))
    		{
    			this.officialAccountPictureUrl = officialAccountPicture;
    		}
    		else
    		{
    			this.officialAccountPictureUrl = "/upload/attach"+FileUtil.getPath(officialAccountPicture)+officialAccountPicture +".png";
    		}
    		
    	}
        this.officialAccountPicture = officialAccountPicture == null ? null : officialAccountPicture.trim();
    }

    /**
     * 版权所有
     * @return copyrightAll
     */
    public String getCopyrightAll() {
        return copyrightAll;
    }

    /**
     * 版权所有
     * @param copyrightAll
     */
    public void setCopyrightAll(String copyrightAll) {
        this.copyrightAll = copyrightAll == null ? null : copyrightAll.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }

	public String getAppPictureUrl()
	{
		return appPictureUrl;
	}

	public void setAppPictureUrl(String appPictureUrl)
	{
		this.appPictureUrl = appPictureUrl;
	}

	public String getOfficialAccountPictureUrl()
	{
		return officialAccountPictureUrl;
	}

	public void setOfficialAccountPictureUrl(String officialAccountPictureUrl)
	{
		this.officialAccountPictureUrl = officialAccountPictureUrl;
	}

	public String getUrl()
	{
		return url;
	}

	public void setUrl(String url)
	{
		this.url = url;
	}

	@Override
	public String toString()
	{
		return "SystemInfo [id=" + id + ", companyName=" + companyName + ", companyPhone=" + companyPhone
				+ ", companySite=" + companySite + ", servicePhone=" + servicePhone + ", url=" + url + ", fax=" + fax
				+ ", postcode=" + postcode + ", keywords=" + keywords + ", description=" + description + ", appPicture="
				+ appPicture + ", officialAccountPicture=" + officialAccountPicture + ", copyrightAll=" + copyrightAll
				+ ", ctime=" + ctime + ", appPictureUrl=" + appPictureUrl + ", officialAccountPictureUrl="
				+ officialAccountPictureUrl + "]";
	}
	
	
    
}