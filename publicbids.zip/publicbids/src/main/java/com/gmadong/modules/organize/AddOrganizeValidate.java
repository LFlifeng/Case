package com.gmadong.modules.organize;

import javax.validation.constraints.NotNull;

public class AddOrganizeValidate
{
	@NotNull(message="部门名不能为空")
	private String organizeName;
	@NotNull(message="请选择上级部门")
	private String parentId;
	private String remark;
	private String type;
	
	public String getOrganizeName()
	{
		return organizeName;
	}
	public void setOrganizeName(String organizeName)
	{
		this.organizeName = organizeName;
	}
	public String getParentId()
	{
		return parentId;
	}
	public void setParentId(String parentId)
	{
		this.parentId = parentId;
	}
	public String getRemark()
	{
		return remark;
	}
	public void setRemark(String remark)
	{
		this.remark = remark;
	}
	public String getType()
	{
		return type;
	}
	public void setType(String type)
	{
		this.type = type;
	}
   
	
}
