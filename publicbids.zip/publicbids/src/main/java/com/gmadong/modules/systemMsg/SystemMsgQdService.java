package com.gmadong.modules.systemMsg;

import com.gmadong.common.Page;

public interface SystemMsgQdService
{
	Page page(String id,String type,String day, Integer page, Integer rows);
	boolean deleteSystemById(String id);
}
