package com.gmadong.modules.bids;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.tracker.CityInfo;

public class BidsMobileSearch
{

	/** 关键字 */
	private String keywords;
	
	public String getKeywords() {
		return keywords;
	}
	/**
	 * 关键字
	 * @param keywords
	 */

	public void setKeywords(String keywords) 
	{
		this.keywords = keywords == null ? null : keywords.trim();
	}
	/** 地区 */
	private String regions;

	/** 信息类型 1招标公告 2招标预告 3招标变更 4中标结果 5拟在建项目 6vip独家项目 7政府采购 8企业采购 9业主委托项目 */
	private String infoType;

	private String date;
	private List<CityInfo> regionList = new ArrayList<>();


	@Override
	public String toString()
	{
		return "BidsMobileSearch [keywords=" + keywords + ", regions=" + regions + ", infoType=" + infoType + ", date="
				+ date + ", regionList=" + regionList + "]";
	}

	public List<CityInfo> getRegionList()
	{
		return regionList;
	}

	public void setRegionList(List<CityInfo> regionList)
	{
		this.regionList = regionList;
	}

	public String getRegions()
	{
		return regions;
	}

	public void setRegions(String regions)
	{
		this.regions = regions;
	}

	public String getInfoType()
	{
		return infoType;
	}

	public void setInfoType(String infoType)
	{
		this.infoType = infoType;
	}

	public String getDate()
	{
		return date;
	}

	public void setDate(String date)
	{
		this.date = date;
	}

}
