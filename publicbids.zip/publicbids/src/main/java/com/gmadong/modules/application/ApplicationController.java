package com.gmadong.modules.application;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.billinginfo.ValidatebBillinginfoEditAction;

import com.gmadong.modules.user.UserService;
/**
 * 供应商管理
 * @author Administrator
 *
 */
@Controller
public class ApplicationController
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private ApplicationService applicationService;
	public static String listkey = "application.list.action";
	@Autowired
	private UserService userService;
	
	/**
	 * 列表页面
	 * @return
	 */
	@RequestMapping("/application.page.action")
	public String page()
	{
		return "/back/application/page";
	}
	
	/**
	 * 页面条件搜索
	 * @return
	 */
	@RequestMapping("/application.list.action")
	public void list(HttpServletResponse response,String enterpriseName, String representative, String code, String phone,
			String state,String showType,String ctime,@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer rows) 
	{
		String field = enterpriseName + "_" + representative + "_" + code + "_" + phone+ "_" + state + "_" + showType + "_" + ctime + "_" + page + "_" + rows;
		try {
			String list = jedisClientSingle.hget(listkey, field);
			if (StringUtil.isNotEmpty(list)) {
				AjaxUtil.write(list, response);
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Page toPage = applicationService.page(enterpriseName, representative, code,phone,state,showType,ctime,page, rows);
		String list = Page.pageToJson(toPage);
		try {
			jedisClientSingle.hset(listkey, field, list, Common.REDIS_30_MINUTE_EXPIRE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AjaxUtil.write(Page.pageToJson(toPage), response);
	}
	/**
	 * 添加页面
	 * @return
	 */
	@RequestMapping("/application.preAdd.action")
	public String preAdd() 
	{
		return "/back/application/add";
	}
	/**
	 * 添加操作
	 * @return
	 */
	@RequestMapping("/application.doAdd.action")
	public void doAdd(HttpServletResponse response, @Validated({ ValidatebApplicationAddAction.class }) Application application,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(),response);
			return;
		}
		if(applicationService.save(application))
		{
			try {
				jedisClientSingle.del(listkey);
				jedisClientSingle.hdel("application.entry.do", application.getUserId());
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		}
		else {
			AjaxUtil.write("添加失败", response);
		}
	}
	/**
	 * 修改页面
	 * @return
	 */
	@RequestMapping("/application.preEdit.action")
	public String preEdit(String id) {
		Application applicationById = applicationService.getApplicationById(id);
		if (applicationById == null) {
			return "/common/500";
		}
		Request.set("info", applicationById);
		if(StringUtil.isNotEmpty(applicationById.getUserId()))
		{
			Request.set("nickname", userService.getPhoneById(applicationById.getUserId()));
		}
		else
		{
			Request.set("nickname", "");
		}
		return "/back/application/edit";
	}
	/**
	 * 修改操作
	 */
	@RequestMapping("/application.doEdit.action")
	public void doEdit(HttpServletResponse response,
			@Validated({ ValidatebBillinginfoEditAction.class }) Application application, BindingResult bindingResult) 
	{
		if (bindingResult.hasErrors()) 
		{
			ObjectError error = bindingResult.getAllErrors().get(0);
			AjaxUtil.write(error.getDefaultMessage(), response);
			return;
		}
		if(applicationService.update(application))
		{
			try
			{
				jedisClientSingle.del(listkey);
				jedisClientSingle.hdel("application.entry.do", application.getUserId());
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			AjaxUtil.write("succ",response);
		}
		else
		{
			AjaxUtil.write("修改失败！",response);
		}
	}
	/**
	 * 删除
	 * @return
	 */
	@RequestMapping("/application.doDelete.action")
	public void doDelete(HttpServletResponse response, String ids) {
		if (applicationService.deleteById(ids)) {
			try {
				jedisClientSingle.del(listkey);
			} catch (Exception e) {
				e.printStackTrace();
			}
			AjaxUtil.write("succ", response);
		} else {
			AjaxUtil.write("fail", response);
		}
	}
}
