package com.gmadong.modules.qualification;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.qualification.QualificationExample.Criteria;

@Service("qualificationService")
public class QualificationServiceImpl implements QualificationService
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private QualificationMapper qualificationMapper;
	
	@Override
	public Page page(String aptitudeName, String ctime, Integer page, Integer rows)
	{
		QualificationExample qualificationExample = new QualificationExample();
		Criteria createCriteria = qualificationExample.createCriteria();
		if (!StringUtil.isEmpty(aptitudeName)) {
			createCriteria.andAptitudeNameLike(aptitudeName + "%");
		}
		if (!StringUtil.isEmpty(ctime)) {
			createCriteria.andCtimeLike(ctime + "%");
		}
		qualificationExample.setOrderByClause("ctime DESC");
		PageHelper.startPage(page, rows);
		List<Qualification> list = qualificationMapper.selectByExample(qualificationExample);
		PageInfo<Qualification> pageInfo = new PageInfo<Qualification>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}

	@Override
	public boolean save(Qualification qualification)
	{
		qualification.setId(UUIDUtil.getUUID());
		qualification.setCtime(DateUtil.getCurrentDate());
		boolean flag = qualificationMapper.insert(qualification) > 0;
		return flag;
	}

	@Override
	public boolean update(Qualification qualification)
	{
		qualification.setCtime(null);
		return qualificationMapper.updateByPrimaryKeySelective(qualification) > 0;
	}

	@Override
	public Qualification getQualificationById(String id)
	{
		return qualificationMapper.selectByPrimaryKey(id);
	}

	@Override
	public boolean deleteById(String ids)
	{
		if (!StringUtil.isEmpty(ids)) {
			if (ids.startsWith(",")) {
				ids = ids.substring(1);
			}
			if (ids.endsWith(",")) {
				ids = ids.substring(ids.length() - 1);
			}
			ids = ids.replaceAll("'", "");
			QualificationExample qualificationExample = new QualificationExample();
			Criteria createCriteria = qualificationExample.createCriteria();
			createCriteria.andIdIn(Arrays.asList(ids.split(",")));
			return qualificationMapper.deleteByExample(qualificationExample) > 0;
		}
		return false;
	}

}
