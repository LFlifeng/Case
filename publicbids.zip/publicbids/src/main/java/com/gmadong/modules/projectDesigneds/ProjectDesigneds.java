package com.gmadong.modules.projectDesigneds;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;


public class ProjectDesigneds {
    private String id;

    /** 客户ID */
    private String userId;

    /** 项目id */
    private String biddinginfoId;

    /** 项目名称 */
    @NotBlank(message="项目名称不能为空!" ,groups = {ValidatebProjectDesignedsAddAction.class,ValidatebProjectDesignedsEditAction.class})
    @Size (min=1,max=200,message="请输入正确的项目名称!" ,groups = {ValidatebProjectDesignedsAddAction.class,ValidatebProjectDesignedsEditAction.class})
    private String projectsName;

    private String ctime;

    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 客户ID
     * @return userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * 客户ID
     * @param userId
     */
    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    /**
     * 项目id
     * @return biddinginfoId
     */
    public String getBiddinginfoId() {
        return biddinginfoId;
    }

    /**
     * 项目id
     * @param biddinginfoId
     */
    public void setBiddinginfoId(String biddinginfoId) {
        this.biddinginfoId = biddinginfoId == null ? null : biddinginfoId.trim();
    }

    /**
     * 项目名称
     * @return projectsName
     */
    public String getProjectsName() {
        return projectsName;
    }

    /**
     * 项目名称
     * @param projectsName
     */
    public void setProjectsName(String projectsName) {
        this.projectsName = projectsName == null ? null : projectsName.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }
}