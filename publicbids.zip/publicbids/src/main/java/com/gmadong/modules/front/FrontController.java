
package com.gmadong.modules.front;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.modules.user.User;

@Controller
public class FrontController
{
	/**
	 *  前端首页
	 */
	@RequestMapping("/main.index.do")
	public String index() throws Exception
	{
		
		User user=(User)Session.get("user");
		int grade= (user==null?0: Integer.parseInt(user.getGrade()));
		
		if(grade == 0)
		{
			Request.set("centerUrl", "userQd.serviceStandards.do");
		}
		else
		{
			Request.set("centerUrl", "userQd.center.do");
		}
		
		 return "/front/common/index";
	}
	
	/**
	 *   服务大厅页面
	 */
	@RequestMapping("/serviceHall.listIndex.do")
	public String serviceHallIndex() throws Exception
	{
		 return "/front/servicehall/servicehall";
	}
	
	/**
	 *  服务标准页面
	 */
	@RequestMapping("/service.index.do")
	public String serviceStandard() throws Exception
	{
		 return "/front/common/service";
	}
	
}
