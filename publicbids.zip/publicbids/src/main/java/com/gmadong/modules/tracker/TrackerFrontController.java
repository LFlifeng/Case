package com.gmadong.modules.tracker;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gmadong.common.Common;
import com.gmadong.common.Page;
import com.gmadong.common.Request;
import com.gmadong.common.Session;
import com.gmadong.common.jedis.JedisClientSingle;
import com.gmadong.common.utils.AjaxUtil;
import com.gmadong.common.utils.JsonUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.modules.user.User;

/**
 * 跟踪器 前台
 * @author caodongdong
 *
 */
@Controller
public class TrackerFrontController
{
	@Autowired
	private JedisClientSingle jedisClientSingle;
	@Autowired
	private TrackerFrontService trackerFrontService;
	@Autowired
	private TrackerService trackerService;
	private String listkey = "tracker.list.do";
	/**
	 * 内容页
	 * @return
	 */
	@RequestMapping("/trackerFront.page.do")
	public String page()
	{
		return "/front/usercenter/tracker";
	}
	@RequestMapping("/trackerFront.addTracker.do")
	public String addTracker()
	{
		/*
		User user = (User) Session.get("user");
		if("0".equals(user.getGrade())|| "1".equals(user.getGrade()))
		{
			return "/front/common/noAuthority";
		}*/
		return "/front/usercenter/addTracker";
	}
	@RequestMapping("/trackerFront.editTracker.do")
	public String editTracker(String id)
	{
		String key = "trackerFront.editTracker.do";
		String field = id;
		try
		{
			String string = jedisClientSingle.hget(key, field);
			if(StringUtil.isNotEmpty(string))
			{
				ObjectMapper mapper = new ObjectMapper();
				Tracker tracker =  mapper.readValue(string, new TypeReference<Tracker>() {});
				Request.set("info", tracker);
				return "/front/usercenter/editTracker";
			}
			
		}catch (Exception e)
		{}
		Tracker trackerById = trackerService.getTrackerById(id);
		try
		{
			String string = JsonUtil.bean2json(trackerById);
			jedisClientSingle.hset(key, field, string,Common.REDIS_30_MINUTE_EXPIRE);
			
		} catch (Exception e)
		{}
		Request.set("info", trackerById);
		
		return "/front/usercenter/editTracker";
	}
	@RequestMapping("/trackerFront.doAdd.do")
	public void doAdd(HttpServletResponse response, Tracker tracker)
	{
		User user = (User) Session.get("user");
		if(user == null)
		{
			AjaxUtil.write("fail", response);
			return;
		}
		tracker.setUserId(user.getId());
		if(tracker.getTrackerName()==null ||tracker.getTrackerName().length() >20 || tracker.getTrackerName().length()==0)
		{
			AjaxUtil.write("请输入合法的跟踪器名!", response);
			return;
		}
		if(trackerFrontService.save(tracker))
		{
			try
			{
				jedisClientSingle.hdel(listkey, user.getId());
				
			} catch (Exception e)
			{}
			AjaxUtil.write("succ", response);
			return;
		}
		AjaxUtil.write("fail", response);
	}
	@RequestMapping("/trackerFront.doEdit.do")
	public void doEdit(HttpServletResponse response, Tracker tracker)
	{
		User user = (User) Session.get("user");
		if(user == null)
		{
			AjaxUtil.write("fail", response);
			return;
		}
		tracker.setUserId(user.getId());
		if(tracker.getTrackerName()==null ||tracker.getTrackerName().length() >20 || tracker.getTrackerName().length()==0)
		{
			AjaxUtil.write("请输入合法的跟踪器名!", response);
			return;
		}
		if(StringUtil.isEmpty(tracker.getId()) || tracker.getId().length()!=32)
		{
			AjaxUtil.write("修改失败!", response);
			return;
		}
		if(trackerFrontService.update(tracker))
		{
			try
			{
				jedisClientSingle.hdel(listkey, user.getId());
				jedisClientSingle.del("biddinginfoFront.list.do_"+user.getId());
				jedisClientSingle.hdel( "trackerFront.editTracker.do", tracker.getId());
				
			} catch (Exception e)
			{}
			AjaxUtil.write("succ", response);
			return;
		}
		AjaxUtil.write("fail", response);
	}
	@RequestMapping("/trackerFront.list.do")
	public void list(HttpServletResponse response,@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "20") Integer rows)
	{
		User user = (User) Session.get("user");
		if(user ==null)
		{
			AjaxUtil.write(Page.pageToJson(Page.getEmptyPage()), response);
			return;
		}
		String field = user.getId();
		try
		{
			String list =  jedisClientSingle.hget(listkey, field);
			if(StringUtil.isNotEmpty(list))
			{
				AjaxUtil.write(list, response);
				return;
			}
			
		}catch (Exception e) {}
		
		 Page toPage = trackerFrontService.page(field, page, rows);
		 String string = Page.pageToJson(toPage);
		 
		 try
		 {
			jedisClientSingle.hset(listkey, field, string);
			 
		 } catch (Exception e)
		 {}
		 AjaxUtil.write(string, response);
	}
	@RequestMapping("/trackerFront.delete.do")
	public void delete(HttpServletResponse response,String id)
	{
		if(trackerService.deleteById(id))
		{
			try
			{
				jedisClientSingle.del(listkey);
				String key = "trackerFront.editTracker.do";
				jedisClientSingle.hdel(key, id);
				
			} catch (Exception e)
			{}
			AjaxUtil.write("succ", response);
		}
		AjaxUtil.write("fail", response);
	}
}
