package com.gmadong.modules.user;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class LoginUserInfo 
{  
	@NotBlank(message="手机号不能为空!")
	@Size (min=11,max=11,message="请输入正确的手机号!" )
	private String phone;
    /** 密码 */
	@NotBlank(message="密码不能为空!" )
    @Size (min=6,max=32,message="请输入合法的密码!" )
    private String password;
	/**记住密码*/
	private String remember;
	public String getRemember()
	{
		return remember;
	}
	public void setRemember(String remember)
	{
		this.remember = remember;
	}
	public String getPhone()
	{
		return phone;
	}
	public void setPhone(String phone)
	{
		this.phone = phone;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
}
