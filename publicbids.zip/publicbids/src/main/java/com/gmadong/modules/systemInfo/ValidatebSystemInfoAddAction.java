package com.gmadong.modules.systemInfo;

public interface ValidatebSystemInfoAddAction
{

}
