package com.gmadong.modules.manageCondition;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gmadong.common.Page;
import com.gmadong.common.utils.DateUtil;
import com.gmadong.common.utils.StringUtil;
import com.gmadong.common.utils.UUIDUtil;
import com.gmadong.modules.manageCondition.ManageConditionExample.Criteria;
@Service("manageConditionQdService")
public class ManageConditionQdServiceImpl implements ManageConditionQdService
{
	@Autowired
	private ManageConditionMapper manageConditionMapper;
	@Override
	public Page page(String id, Integer page, Integer rows)
	{
		ManageConditionExample manageConditionExample = new ManageConditionExample();
		Criteria createCriteria = manageConditionExample.createCriteria();
		createCriteria.andUserIdEqualTo(id);
		manageConditionExample.setOrderByClause("operations DESC");
		PageHelper.startPage(page, rows);
		List<ManageCondition> list = manageConditionMapper.selectByExample(manageConditionExample);
		PageInfo<ManageCondition> pageInfo = new PageInfo<ManageCondition>(list);
		long total = pageInfo.getTotal();
		Page toPage = new Page(total, page, list);
		return toPage;
	}
	@Override
	public boolean deleteByPrimaryKey(String id)
	{
		return manageConditionMapper.deleteByPrimaryKey(id) > 0;
	}
	@Override
	public boolean save(ManageCondition manageCondition)
	{
		manageCondition.setId(UUIDUtil.getUUID());
		manageCondition.setCtime(DateUtil.getCurrentDate());
		boolean flag = manageConditionMapper.insert(manageCondition) > 0;
		return flag;
	}

}
