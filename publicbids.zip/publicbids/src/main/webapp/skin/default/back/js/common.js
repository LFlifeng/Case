/**
 * common.js Napoleon 2013-04-09
 */
	importCss(skinPath() + 'back/css/style.css');
	importJs(skinPath() + 'js/jquery/jquery.js');
	importJs(skinPath() + 'js/jquery/jquery.easyui.min.js');
function importJs(src){
	var head = document.getElementsByTagName("head")[0];
	var element = document.createElement("script");
	element.setAttribute('type', 'text/javascript');
	element.setAttribute('src', src);
	head.appendChild(element);
}

function importCss(href){
	var head = document.getElementsByTagName("head")[0];
	var element = document.createElement("link");
	element.setAttribute('type', 'text/css');
	element.setAttribute('rel', 'stylesheet');
	element.setAttribute('href', href);
	head.appendChild(element);
}

function skinPath(){
	var head = document.getElementsByTagName("head")[0];
	var nodes = head.childNodes;
	for(var i=0; i<nodes.length; i++){
		if(nodes[i].tagName == 'SCRIPT'){
			var src = nodes[i].getAttribute('src');
			if(src.indexOf('back/js/common.js') != -1){
				var arr = src.split('back/js/common.js');
				return arr[0];
			}
		}
	}
}