/**
 * page.js Napoleon 2013-04-02
 */
$.fn.showLoading = function(options) {
	var indicatorID;
   	var settings = {'addClass':'','beforeShow':'','afterShow':'','hPos':'center','vPos':'center','indicatorZIndex':9999,'overlayZIndex':9999,'parent':'','marginTop':0,'marginLeft':0,'overlayWidth':null,'overlayHeight':null};
	$.extend(settings, options);
   	var loadingDiv = $('<div>正在处理，请稍等...</div>');
	var overlayDiv = $('<div></div>');
	if ( settings.indicatorID ) {
		indicatorID = settings.indicatorID;
	}else {
		indicatorID = $(this).attr('id');
	}
	$(loadingDiv).attr('id', 'loading-indicator-' + indicatorID );
	$(loadingDiv).addClass('loading-indicator');
	if ( settings.addClass ){
		$(loadingDiv).addClass(settings.addClass);
	}
	$(overlayDiv).css('display', 'none');
	$(document.body).append(overlayDiv);
	$(overlayDiv).attr('id', 'loading-indicator-' + indicatorID + '-overlay');
	
	$(overlayDiv).addClass('loading-indicator-overlay');
	
	if ( settings.addClass ){
		$(overlayDiv).addClass(settings.addClass + '-overlay');
	}
	var overlay_width;
	var overlay_height;
	var border_top_width = $(this).css('border-top-width');
	var border_left_width = $(this).css('border-left-width');
	border_top_width = isNaN(parseInt(border_top_width)) ? 0 : border_top_width;
	border_left_width = isNaN(parseInt(border_left_width)) ? 0 : border_left_width;
	
	var overlay_left_pos = $(this).offset().left + parseInt(border_left_width);
	var overlay_top_pos = $(this).offset().top + parseInt(border_top_width);
	
	if ( settings.overlayWidth !== null ) {
		overlay_width = settings.overlayWidth;
	}else {
		overlay_width = parseInt($(this).width()) + parseInt($(this).css('padding-right')) + parseInt($(this).css('padding-left'));
	}
	if ( settings.overlayHeight !== null ) {
		overlay_height = settings.overlayWidth;
	}else {
		overlay_height = parseInt($(this).height()) + parseInt($(this).css('padding-top')) + parseInt($(this).css('padding-bottom'));
	}
	$(overlayDiv).css('width', overlay_width.toString() + 'px');
	$(overlayDiv).css('height', overlay_height.toString() + 'px');

	$(overlayDiv).css('left', overlay_left_pos.toString() + 'px');
	$(overlayDiv).css('position', 'absolute');

	$(overlayDiv).css('top', overlay_top_pos.toString() + 'px' );
	$(overlayDiv).css('z-index', settings.overlayZIndex);
	if ( settings.overlayCSS ) {
		$(overlayDiv).css ( settings.overlayCSS );
	}
	$(loadingDiv).css('display', 'none');
	$(document.body).append(loadingDiv);
	$(loadingDiv).css('position', 'absolute');
	$(loadingDiv).css('z-index', settings.indicatorZIndex);
	var indicatorTop = overlay_top_pos;
	if ( settings.marginTop ) {
		indicatorTop += parseInt(settings.marginTop);
	}
	var indicatorLeft = overlay_left_pos;
	
	if ( settings.marginLeft ) {
		indicatorLeft += parseInt(settings.marginTop);
	}
	if ( settings.hPos.toString().toLowerCase() == 'center' ) {
		$(loadingDiv).css('left', (indicatorLeft + (($(overlayDiv).width() - parseInt($(loadingDiv).width())) / 2)).toString()  + 'px');
	}
	else if ( settings.hPos.toString().toLowerCase() == 'left' ) {
		$(loadingDiv).css('left', (indicatorLeft + parseInt($(overlayDiv).css('margin-left'))).toString() + 'px');
	}
	else if ( settings.hPos.toString().toLowerCase() == 'right' ) {
		$(loadingDiv).css('left', (indicatorLeft + ($(overlayDiv).width() - parseInt($(loadingDiv).width()))).toString()  + 'px');
	}
	else {
		$(loadingDiv).css('left', (indicatorLeft + parseInt(settings.hPos)).toString() + 'px');
	}		
	if ( settings.vPos.toString().toLowerCase() == 'center' ) {
		$(loadingDiv).css('top', (indicatorTop + (($(overlayDiv).height() - parseInt($(loadingDiv).height())) / 2)).toString()  + 'px');
	}
	else if ( settings.vPos.toString().toLowerCase() == 'top' ) {
		$(loadingDiv).css('top', indicatorTop.toString() + 'px');
	}
	else if ( settings.vPos.toString().toLowerCase() == 'bottom' ) {
		$(loadingDiv).css('top', (indicatorTop + ($(overlayDiv).height() - parseInt($(loadingDiv).height()))).toString()  + 'px');
	}
	else {
		$(loadingDiv).css('top', (indicatorTop + parseInt(settings.vPos)).toString() + 'px' );
	}		
	if ( settings.css ) {
		$(loadingDiv).css ( settings.css );
	}
	var callback_options = {
		'overlay': overlayDiv,
		'indicator': loadingDiv,
		'element': this
	};
	if ( typeof(settings.beforeShow) == 'function' ) {
		settings.beforeShow( callback_options );
	}
	$(overlayDiv).show();
	$(loadingDiv).show();
	if ( typeof(settings.afterShow) == 'function' ) {
		settings.afterShow( callback_options );
	}
	
	setTimeout(function(){
		loadingDiv.html('系统繁忙,请稍后重试.');
		loadingDiv.css('color', '#FF0000');
		setTimeout(function(){
			$(options).hideLoading();
		}, 1000);
	}, 10000);
	
	return this;
};
$.fn.hideLoading = function(options) {
	var settings = {};
	$.extend(settings, options);
	if ( settings.indicatorID ) {
		indicatorID = settings.indicatorID;
	}else {
		indicatorID = $(this).attr('id');
	}
	$(document.body).find('#loading-indicator-' + indicatorID ).remove();
	$(document.body).find('#loading-indicator-' + indicatorID + '-overlay' ).remove();
	
	return this;
};
function trim(str){
    return str.replace(/(^\s*)|(\s*$)/g, "");
}
function login(){
	var loginName = trim(document.getElementById("loginName").value);	
	var pwd = trim(document.getElementById("pwd").value);
	if (null == loginName || "" == loginName) {
		notice('用户名不能为空');
		document.getElementById("loginName").focus();
		return false;
	}else if (null == pwd || "" == pwd) {
		notice('密码不能为空');
		document.getElementById("pwd").focus();
		return false;
	}else if(loginName!=null && null!=pwd){
		$('div.login').showLoading();
		$.ajax( {
			url : 'back.check.action',
			type : 'POST',
			data : {
				loginname : loginName,
				pwd : pwd
			},
			error : function() 
			{
				notice('系统错误，请稍后重试');
			},
			success : function(res)
			{
				if('success' == res)
				{
					top.location.href = "back.index.action";
				}else if('fail' == res)
				{
					notice('用户名或密码错误');
				}else
				{
					notice(res);
				}
				$('div.login').hideLoading();
			}
		});
	}
	return false;
}



function notice(str){
	var div = document.getElementById('notice');
	div.innerHTML = str;
	setTimeout(function(){div.innerHTML = '';}, 3000);
}
window.onload = function(){
	$('#loginName').focus();
}