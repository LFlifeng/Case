/**
 * index.js Napoleon 2013-03-01
 */
var setting = {
	data: {
		simpleData: {
			enable: true
		}
	},
	callback: {
		onClick: onClick
	}
};

function showIconForTree(treeId, treeNode) {
	return false;
};

var zNodes = menuJson;
function onClick(event, treeId, treeNode, clickFlag) {
	if(treeNode.isParent == false && treeNode.menuUrl != '#'){
		addTab(treeNode.name, treeNode.menuUrl);
	}else if(treeNode.isParent == true){
		var zTree = $.fn.zTree.getZTreeObj("treeDemo");
		zTree.expandNode(treeNode);
	}else{
		return;
	}
}

// 浏览器加载完DOM后
$(document).ready(function(){
	//$.fn.zTree.init($("#treeDemo"), setting, zNodes);
	//$("#expandAllBtn").bind("click", {type:"expandAll"}, expandNode);
	///$("#collapseAllBtn").bind("click", {type:"collapseAll"}, expandNode);
	
	setWestMenuHeight();
	
	//expandNode({data:{type:'expandAll'}});
	
	var menus =new Array();
	var map = new Map();
	
	for(var i=0;i<menuJson.length;i++)
	{
		var item = menuJson[i];
		var pId = item.pId;
		var id = item.id;
		var url = item.menuUrl;
		var name = item.name;
		
		var obj = new Object();
		obj.pId = pId;
		obj.name = name;
		obj.id = id;
		obj.url = url;
		obj.array = [];
		if(pId == "")
		{
			if(!map.hasOwnProperty(id))
			{
				map[id]= obj;
				menus.push(obj);
			}
		}
		else
		{
		  
		   if(map.hasOwnProperty(pId))
		   {
		   		var ob = map[pId];
		    	ob.array.push(obj);
		   }
		   else
		   {
		   		var obj1 = new Object();
				obj1.pId = "";
				obj1.name = pId;
				obj1.id = pId;
				obj1.url = "";
				obj1.array = [];
				
				map[pId]= obj1;
				obj1.array.push(obj);
		   }
		}
	}
    
    for(var i=0;i<menus.length;i++)
    {
    	var item=menus[i];
    	
    	addParent(item);
    	addChild(item);
    }

	   
      $(".list_dt").on("click",function () 
      {
          $('.list_dd').stop();
          $(this).siblings("dt").removeAttr("id");
          if($(this).attr("id")=="open"){
              $(this).removeAttr("id").siblings("dd").slideUp();
          }else{
              $(this).attr("id","open").next().slideDown().siblings("dd").slideUp();
          }
      });	
});


function addChild(item)
{
    var html ='<dd class="list_dd"><ul>';
		for(var j=0;j<item.array.length;j++)
	{
		var child = item.array[j];
		html = html + '<li  class="list_li" onclick="clickItem(\''+child.name+'\',\''+child.url+'\',this)">'+child.name+'</li>';
		
	}
	html  = html + "</ul></dd>";
	
	
	$("#list_dl").append(html);
}
function clickItem(name,url,item)
{
	$(".list_li_selected").removeClass("list_li_selected");
	$(item).addClass("list_li_selected");
	addTab(name,url);
}
function addParent(item)
{
	$("#list_dl").append("<dt class='list_dt'><span class='_after'></span><p>"+item.name+"</p><i class='list_dt_icon'></i></dt>")
}







// 浏览器改变尺寸时
$(window).resize(function() {
	setWestMenuHeight();
});

function setWestMenuHeight(){
	// 左侧菜单高度
	$('#west_menu').css("height", ($(document.body).height() - 123)+'px');
}

function expandNode(e) {
	var zTree = $.fn.zTree.getZTreeObj("treeDemo"),
	type = e.data.type,
	nodes = zTree.getSelectedNodes();
	if (type.indexOf("All")<0 && nodes.length == 0) {
		alert("请先选择一个父节点");
	}

	if (type == "expandAll") {
		zTree.expandAll(true);
	} else if (type == "collapseAll") {
		zTree.expandAll(false);
	} else {
		var callbackFlag = $("#callbackTrigger").attr("checked");
		for (var i=0, l=nodes.length; i<l; i++) {
			zTree.setting.view.fontCss = {};
			if (type == "expand") {
				zTree.expandNode(nodes[i], true, null, null, callbackFlag);
			} else if (type == "collapse") {
				zTree.expandNode(nodes[i], false, null, null, callbackFlag);
			} else if (type == "toggle") {
				zTree.expandNode(nodes[i], null, null, null, callbackFlag);
			} else if (type == "expandSon") {
				zTree.expandNode(nodes[i], true, true, null, callbackFlag);
			} else if (type == "collapseSon") {
				zTree.expandNode(nodes[i], false, true, null, callbackFlag);
			}
		}
	}
}
var index = 0;
function addTab(title, url){
	if ($('#easyui-tabs').tabs('exists', title)){
		$('#easyui-tabs').tabs('select', title);
	} else {
		$('#easyui-tabs').tabs('add',{
			title:title,
			content: '<iframe width="100%" height="100%" frameborder="no" src="'+url+'"></iframe>',
			closable: true
		});
	}
}
function removeTab(){
	var tab = $('#easyui-tabs').tabs('getSelected');
	if (tab){
		var index = $('#easyui-tabs').tabs('getTabIndex', tab);
		$('#easyui-tabs').tabs('close', index);
	}
}
function removeAllTabs(){
	var tabs = $("#easyui-tabs").tabs("tabs");
    var length = tabs.length;
    if(length > 1){
		if(window.confirm('确定要关闭所有标签吗？')){
		    for (var i = 1; i < length; i++) {
		        var onetab = tabs[1];
		        var title = onetab.panel('options').tab.text();
		        $("#easyui-tabs").tabs("close", title);
		    }
		}
    }
}
function west_tree_collapse(){
	$('#easyui-layout').layout('collapse','west');
}
setInterval(function(){
	$('#current_time').html(new Date().toLocaleString());
}, 500);
function home(){
	addTab('首页');
}
function refresh(){
	var currTab =  $('#easyui-tabs').tabs('getSelected');
	var url = $(currTab.panel('options').content).attr('src');
	var iframes = document.getElementsByTagName('IFRAME');
	for(var i in iframes){
		if(iframes[i].src && iframes[i].src.indexOf(url) != -1){
			iframes[i].contentWindow.location.reload();
		}
	}
}
function openDialog(title, href, handler, toolbar){
	if(!$('#dialog_div').attr('id')){
		$(document.body).append('<div id="dialog_div"></div>');
	}
	toolbar = toolbar==false ? false : [{text:'保存',iconCls:'a_save',handler:handler}];
	$('#dialog_div').dialog({  
	    title: title,  
	    width: 800,  
	    height: 400,  
	    closed: false,  
	    cache: false,  
	    href: href,  
	    toolbar:toolbar,
	    modal: true  
	});
}
function doPwd(){
	$('#form_form').form('submit', {  
		url:$('#form_form').attr('action'),
		onSubmit: function(){
			var isValid = $(this).form('validate');
			if (!isValid){
				$.messager.progress('close');
			}
			return isValid;
		},
	    success:function(data){
	    	if(data == 'succ'){
	    		$.messager.show({title:'操作提示',msg:'修改成功',showType:'slide',timeout:2000});
				$('#dialog_div').dialog('close');
			}else if(data == 'oldPwd'){
	    		$.messager.show({title:'操作提示',msg:'原密码错误',showType:'slide',timeout:2000});
			}else if(data == 'newPwd'){
	    		$.messager.show({title:'操作提示',msg:'新密码输入不一致',showType:'slide',timeout:2000});
			}else{
				$.messager.show({title:'操作提示',msg:'系统错误，请稍后重试',showType:'slide',timeout:2000});
			}
	    }  
	});  
}
function doProfile(){
	$('#form_form').form('submit', {  
		url:$('#form_form').attr('action'),
		onSubmit: function(){
			var isValid = $(this).form('validate');
			if (!isValid){
				$.messager.progress('close');
			}
			return isValid;
		},
	    success:function(data){
	    	if(data == 'succ'){
	    		$.messager.show({title:'操作提示',msg:'修改成功',showType:'slide',timeout:2000});
				$('#dialog_div').dialog('close');
			}else{
				$.messager.show({title:'操作提示',msg:'系统错误，请稍后重试',showType:'slide',timeout:2000});
			}
	    }  
	});  
}