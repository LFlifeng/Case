/**
 * page.js caodong 2016-04-02
 */
$(function(){
	var datagridId = 'list_table';
	$('#' + datagridId).datagrid({
		autoRowHeight:false,
		selectOnCheck:false,
		checkOnSelect:false,
		scrollbarSize:18,
		pagination:true,
		rownumbers:true,
		fitColumns:true,
		onLoadSuccess:function(data){
			if(!data.rows.length){
				var body = $(this).data().datagrid.dc.body2;
				body.find('table tbody').append('<tr><td width="' + body.width() + '" style="height:25px;text-align:center;color:#AA0000;">无数据返回</td></tr>');
			}
			else
			{
				$(this).datagrid("fixRownumber");
			}
		}
		
	});
	$('#' + datagridId).resizeDataGrid(0, 0, 0, 0);
	$(window).resize(function() {
		$('#' + datagridId).resizeDataGrid(0, 0, 0, 0);
	});
});
$.fn.extend({
	resizeDataGrid:function(heightMargin, widthMargin, minHeight, minWidth){
		var height = $(document.body).height() - heightMargin;
		var width = $(document.body).width() - widthMargin;
		height = height < minHeight ? minHeight : height;
		width = width < minWidth ? minWidth : width;
		$(this).datagrid('resize', {
			width : width
		});
	}
});
function timestampToString(timestamp)
{  
	var inputTime = parseInt(timestamp);
	if(inputTime<=0||isNaN(inputTime))
	{
		return "未知";
	}
   var date = new Date(inputTime);	
   var y = date.getFullYear();  
   var m = date.getMonth() + 1;  
   m = m < 10 ? ('0' + m) : m;  
   var d = date.getDate();  
   d = d < 10 ? ('0' + d) : d;  
   var h = date.getHours();  
   h=h < 10 ? ('0' + h) : h;  
   var minute = date.getMinutes();  
   minute = minute < 10 ? ('0' + minute) : minute;  
   var second=date.getSeconds();  
   second=second < 10 ? ('0' + second) : second;  
   return y + '-' + m + '-' + d+' '+h+':'+minute+':'+second;  
}; 
function dateFormat(date){
	var y = date.getFullYear();
	var m = date.getMonth()+1;
	var d = date.getDate();
	return y+'-'+(m<10?('0'+m):m)+'-'+(d<10?('0'+d):d);
}

function dateTimeFormat(date){
	var y = date.getFullYear();
	var m = date.getMonth()+1;
	var d = date.getDate();
	var h = date.getHours()
	var i = date.getMinutes();
	var s = date.getSeconds();
	return y+'-'+(m<10?('0'+m):m)+'-'+(d<10?('0'+d):d)+' '+h+':'+i+':'+s;
}
function formatBean(value, row, index){
	return eval('row.' + $(this).attr("field"));
}
function formatMultiple(value, row, index){
	var arr = $(this).attr("field").split('.');
	var str = 'row';
	for(var i in arr){
		str += '["' + arr[i] + '"]';
	}
	return eval(str);
}
function pageSearch(){
	var elems = document.getElementById('search_form').elements;
	var str = '{';
	for(var i=0; i<elems.length; i++){
		if(elems[i].name){
			str += elems[i].getAttribute('name') + ':"' + elems[i].value + '",';
		}
	}
	str = (str.length>1 ? str.substring(0, str.length-1) : str) + '}';
	$('#list_table').datagrid('load',eval('('+str+')'));
}
function pageResetSearch(){
	document.getElementById('search_form').reset();
	var str = '{}';
	$('#list_table').datagrid('load',eval('('+str+')'));
}
function editField(url, id, field, val)
{
	$.messager.confirm('系统提示','确认要进行该操作吗',function(r){
	    if (r)
	    {
	    	$.ajax({
				type:"post",
				url:url + '?id='+id+'&field='+field+'&val='+val,
				beforeSend: function(XMLHttpRequest){
					//ShowLoading();
				},
				success: function(data, textStatus){
					$('#list_table').datagrid('reload');
				},
				complete: function(XMLHttpRequest, textStatus){
					//HideLoading();
				},
				error: function(){
					alert('error in editField Function.');
				}
			});
	    }
	});
}
function toggleYesNo(url, id, value, obj){
	var toggleValue = obj.className == 'ico_yes' ? 'no' : 'yes';
	var valueArray = value.split(',');
	var val = toggleValue == 'yes' ? valueArray[0] : valueArray[1];
	$.ajax({
		type:"post",
		url:url + '?id='+id+'&val='+val,
		beforeSend: function(XMLHttpRequest){
			//ShowLoading();
		},
		success: function(data, textStatus){
			obj.className = 'ico_' + toggleValue;
		},
		complete: function(XMLHttpRequest, textStatus){
			//HideLoading();
		},
		error: function(){
			alert('error in toggleYesNo Function.');
		}
	});
}
function openFrameDialog(title, href, toolbar){
	if($('#frame_dialog_div').attr('id')){
		$('#frame_dialog_div').remove();
	}
	if(!$('#frame_dialog_div').attr('id')){
		$(document.body).append('<div id="frame_dialog_div"><iframe width="100%" height="100%" frameborder="0" src="'+href+'"></iframe></div>');
	}
	toolbar = toolbar==false ? false : toolbar;
	$('#frame_dialog_div').dialog({  
	    title: title,  
	    width: 900,  
	    height: 450,  
	    closed: false,  
	    cache: false,  
	    toolbar:toolbar,
	    modal: true  
	});
}
function openDialog(title, href, toolbar){
	if(!$('#dialog_div').attr('id'))
	{
		$(document.body).append('<div id="dialog_div" ></div>');
	}
	toolbar = toolbar==false ? false : [{iconCls:'icons a_save',text:'保存',handler:submitForm}];
	$('#dialog_div').dialog({  
	    title: title,  
	    width: 900,  
	    height: 450,  
	    closed: false,  
	    cache: false,  
	    href: href,  
	    toolbar:toolbar,
	    modal: true  
	});
}
function openDialogResize(title, href,w,h,toolbar){
	if(!$('#dialog_div').attr('id'))
	{
		$(document.body).append('<div id="dialog_div" ></div>');
	}
	toolbar = toolbar==false ? false : [{iconCls:'icons a_save',text:'保存',handler:submitForm}];
	$('#dialog_div').dialog({ 
	    title: title,  
	    width: w,  
	    height: h,  
	    closed: false,  
	    cache: false,  
	    href: href,  
	    toolbar:toolbar,
	    modal: true  
	});
}
var refreshFlag = false;
function openDispatchDialog(title, href, toolbar)
{
	if(!$('#dialog_div').attr('id'))
	{
		$(document.body).append('<div id="dialog_div"></div>');
	}
	else
	{
		$("#dialog_div").css("overflow","auto");
	}		
	//toolbar = toolbar==false ? false : [{iconCls:'icons a_save',text:'保存',handler:submitForm},{iconCls:'icons a_save',text:'平分',handler:groupDispatch}];
	$('#dialog_div').dialog({  
	    title: title,  
	    width: 950,  
	    height: 450,  
	    closed: false,  
	    cache: false,  
	    href: href, 
	    modal: true
	});
	if(toolbar)
	{
		if(typeof toolbar == "function")
    	{
			$("#dialog_div").dialog({  
			    onClose: function () 
			    { 
			         $("#dialog_div").dialog('destroy');
			         $("#dialog_div").remove();
			         if(refreshFlag)
			         {
			        	 toolbar();
			        	 refreshFlag = false;
			         }
			    }  
			});
		}
		else
		{
			$("#dialog_div").dialog({  
			    onClose: function () 
			    { 
			         $("#dialog_div").dialog('destroy');
			         $("#dialog_div").remove(); 
			         if(refreshFlag)
			         {
			        	 $('#list_table').datagrid('reload');
			        	 refreshFlag = false;
			         }
			    }  
			});
		}
	}
	else
	{
		$("#dialog_div").dialog({  
		    onClose: function () 
		    { 
		         $("#dialog_div").dialog('destroy');
		         $("#dialog_div").remove(); 
		    }  
		});
	}
	
	
}
function submitForm(){
	$('#form_form').form('submit', {  
		url:$('#form_form').attr('action'),
		onSubmit: function(){
			var isValid = $(this).form('validate');
			if(typeof specialVerify == "function")
			{
				isValid = specialVerify() && isValid ? isValid : false;
			}
			if(isValid){
				$('div.window').showLoading();
			}
			return isValid;
		},
	    success:function(data){
	    	if(data == 'succ')
	    	{
				$('div.window').hideLoading();
				$('#dialog_div').dialog('close');
				$('#list_table').datagrid('reload');
			}
	    	else if(typeof handleResult == "function")
	    	{
				handleResult(data);
			}
	    	else
	    	{
	    		$('div.window').hideLoading();
				showNotice(data);
			}
	    }  
	});  
}
function showNotice(msg)
{
	$.messager.alert('系统提示',msg);
}
function del(url, id){
	batchEditField(url, "'" + id + "'", 'status', '0');
}
function batchDel(url, id){
	var row = $('#list_table').datagrid('getChecked');
	var ids = "";
	for(var i=0; i<row.length; i++){
		ids += "'" + row[i][id] + "',";
	}
	if(ids.length > 0){
		ids = ids.substring(0, ids.length-1);
	}
	if(!ids){
		showNotice("请选择要删除的记录");
		return;
	}
	batchEditField(url, ids, 'status', '0');
}
function batchEditField(url, ids, field, val){
	if(!ids)
	{
		showNotice("请选择记录");
		return;
	}
	$.messager.confirm('系统提示','确认要进行该操作吗？',function(r){
	    if (r)
	    {
	    	$.ajax({
				type:"post",
				url:url + '?ids='+ids+'&field='+field+'&val='+val,
				beforeSend: function(XMLHttpRequest){
					//ShowLoading();
				},
				success: function(data, textStatus){
					$('#list_table').datagrid('reload');
				},
				complete: function(XMLHttpRequest, textStatus){
					//HideLoading();
				},
				error: function(){
					alert('error in editField Function.');
				}
			});
	    }
	});
}

function delet(url, id){
	batchEditFieldet(url, "'" + id + "'", 'status', '0');
}

function batchEditFieldet(url, id, field, val){
	if(!id){
		alert('请选择记录');
		return;
	}
	if(confirm('删除后工作日志及隐患排查信息一并删除，是否想要删除？')){
		$.ajax({
			type:"post",
			url:url + '?id='+id+'&field='+field+'&val='+val,
			beforeSend: function(XMLHttpRequest){
				//ShowLoading();
			},
			success: function(data, textStatus){
				$('#list_table').datagrid('reload');
			},
			complete: function(XMLHttpRequest, textStatus){
				//HideLoading();
			},
			error: function(){
				alert('error in editField Function.');
			}
		});
	}
}

$.extend($.fn.validatebox.defaults.rules, {
	equals:{
		validator:function(value, param) {
			return value == $(param[0]).val();
		},
		message: '输入不一致'
	},
	pwdEquals:{
		validator:function(value, param) {
			return value == $(param[0]).val();
		},
		message: '两次密码输入不一致'
	}
});
$.fn.showLoading = function(options) {
	var indicatorID;
   	var settings = {'addClass':'','beforeShow':'','afterShow':'','hPos':'center','vPos':'center','indicatorZIndex':9999,'overlayZIndex':9999,'parent':'','marginTop':0,'marginLeft':0,'overlayWidth':null,'overlayHeight':null};
	$.extend(settings, options);
   	var loadingDiv = $('<div>正在处理，请稍等...</div>');
	var overlayDiv = $('<div></div>');
	if ( settings.indicatorID ) {
		indicatorID = settings.indicatorID;
	}else {
		indicatorID = $(this).attr('id');
	}
	$(loadingDiv).attr('id', 'loading-indicator-' + indicatorID );
	$(loadingDiv).addClass('loading-indicator');
	if ( settings.addClass ){
		$(loadingDiv).addClass(settings.addClass);
	}
	$(overlayDiv).css('display', 'none');
	$(document.body).append(overlayDiv);
	$(overlayDiv).attr('id', 'loading-indicator-' + indicatorID + '-overlay');
	
	$(overlayDiv).addClass('loading-indicator-overlay');
	
	if ( settings.addClass ){
		$(overlayDiv).addClass(settings.addClass + '-overlay');
	}
	var overlay_width;
	var overlay_height;
	var border_top_width = $(this).css('border-top-width');
	var border_left_width = $(this).css('border-left-width');
	border_top_width = isNaN(parseInt(border_top_width)) ? 0 : border_top_width;
	border_left_width = isNaN(parseInt(border_left_width)) ? 0 : border_left_width;
	
	var overlay_left_pos = $(this).offset().left + parseInt(border_left_width);
	var overlay_top_pos = $(this).offset().top + parseInt(border_top_width);
	
	if ( settings.overlayWidth !== null ) {
		overlay_width = settings.overlayWidth;
	}else {
		overlay_width = parseInt($(this).width()) + parseInt($(this).css('padding-right')) + parseInt($(this).css('padding-left'));
	}
	if ( settings.overlayHeight !== null ) {
		overlay_height = settings.overlayWidth;
	}else {
		overlay_height = parseInt($(this).height()) + parseInt($(this).css('padding-top')) + parseInt($(this).css('padding-bottom'));
	}
	$(overlayDiv).css('width', overlay_width.toString() + 'px');
	$(overlayDiv).css('height', overlay_height.toString() + 'px');

	$(overlayDiv).css('left', overlay_left_pos.toString() + 'px');
	$(overlayDiv).css('position', 'absolute');

	$(overlayDiv).css('top', overlay_top_pos.toString() + 'px' );
	$(overlayDiv).css('z-index', settings.overlayZIndex);
	if ( settings.overlayCSS ) {
		$(overlayDiv).css ( settings.overlayCSS );
	}
	$(loadingDiv).css('display', 'none');
	$(document.body).append(loadingDiv);
	$(loadingDiv).css('position', 'absolute');
	$(loadingDiv).css('z-index', settings.indicatorZIndex);
	var indicatorTop = overlay_top_pos;
	if ( settings.marginTop ) {
		indicatorTop += parseInt(settings.marginTop);
	}
	var indicatorLeft = overlay_left_pos;
	
	if ( settings.marginLeft ) {
		indicatorLeft += parseInt(settings.marginTop);
	}
	if ( settings.hPos.toString().toLowerCase() == 'center' ) {
		$(loadingDiv).css('left', (indicatorLeft + (($(overlayDiv).width() - parseInt($(loadingDiv).width())) / 2)).toString()  + 'px');
	}
	else if ( settings.hPos.toString().toLowerCase() == 'left' ) {
		$(loadingDiv).css('left', (indicatorLeft + parseInt($(overlayDiv).css('margin-left'))).toString() + 'px');
	}
	else if ( settings.hPos.toString().toLowerCase() == 'right' ) {
		$(loadingDiv).css('left', (indicatorLeft + ($(overlayDiv).width() - parseInt($(loadingDiv).width()))).toString()  + 'px');
	}
	else {
		$(loadingDiv).css('left', (indicatorLeft + parseInt(settings.hPos)).toString() + 'px');
	}		
	if ( settings.vPos.toString().toLowerCase() == 'center' ) {
		$(loadingDiv).css('top', (indicatorTop + (($(overlayDiv).height() - parseInt($(loadingDiv).height())) / 2)).toString()  + 'px');
	}
	else if ( settings.vPos.toString().toLowerCase() == 'top' ) {
		$(loadingDiv).css('top', indicatorTop.toString() + 'px');
	}
	else if ( settings.vPos.toString().toLowerCase() == 'bottom' ) {
		$(loadingDiv).css('top', (indicatorTop + ($(overlayDiv).height() - parseInt($(loadingDiv).height()))).toString()  + 'px');
	}
	else {
		$(loadingDiv).css('top', (indicatorTop + parseInt(settings.vPos)).toString() + 'px' );
	}		
	if ( settings.css ) {
		$(loadingDiv).css ( settings.css );
	}
	var callback_options = {
		'overlay': overlayDiv,
		'indicator': loadingDiv,
		'element': this
	};
	if ( typeof(settings.beforeShow) == 'function' ) {
		settings.beforeShow( callback_options );
	}
	$(overlayDiv).show();
	$(loadingDiv).show();
	if ( typeof(settings.afterShow) == 'function' ) {
		settings.afterShow( callback_options );
	}
	
	setTimeout(function(){
		loadingDiv.html('系统繁忙,请稍后重试.');
		loadingDiv.css('color', '#FF0000');
		setTimeout(function(){
			$(options).hideLoading();
		}, 1000);
	}, 180000);
	
	return this;
};
$.fn.hideLoading = function(options) {
	var settings = {};
	$.extend(settings, options);
	if ( settings.indicatorID ) {
		indicatorID = settings.indicatorID;
	}else {
		indicatorID = $(this).attr('id');
	}
	$(document.body).find('#loading-indicator-' + indicatorID ).remove();
	$(document.body).find('#loading-indicator-' + indicatorID + '-overlay' ).remove();
	
	return this;
};
$.fn.dialog.defaults.onMove = function(left, top) {
    var parentObj = $(this).panel('panel').parent();
    if (top < 0) {
        $(this).window('move', {
            top : 1
        });
    }
};
$.extend($.fn.datagrid.methods, {
    fixRownumber : function (jq) {
        return jq.each(function () {
            var panel = $(this).datagrid("getPanel");
            //获取最后一行的number容器,并拷贝一份
            var clone = $(".datagrid-cell-rownumber", panel).last().clone();
            //由于在某些浏览器里面,是不支持获取隐藏元素的宽度,所以取巧一下
            clone.css({
                "position" : "absolute",
                left : -1000
            }).appendTo("body");
            var width = clone.width("auto").width();
            //默认宽度是25,所以只有大于25的时候才进行fix
            if (width > 25) {
                //多加5个像素,保持一点边距
                $(".datagrid-header-rownumber,.datagrid-cell-rownumber", panel).width(width + 5);
                //修改了宽度之后,需要对容器进行重新计算,所以调用resize
                $(this).datagrid("resize");
                //一些清理工作
                clone.remove();
                clone = null;
            } else {
                //还原成默认状态
                $(".datagrid-header-rownumber,.datagrid-cell-rownumber", panel).removeAttr("style");
            }
        });
    }
});
//easyui自定义验证
//扩展easyui表单的验证  
$.extend($.fn.validatebox.defaults.rules, {  
    //验证汉子  
    CHS: {  
        validator: function (value) {  
            return /^[\u0391-\uFFE5]+$/.test(value);  
        },  
        message: '只能输入汉字'  
    },  
    //移动手机号码验证  
    mobile: {//value值为文本框中的值  
        validator: function (value) {  
            var reg = /^((17[0-9])|(13[0-9])|(15[^4,\\D])|(18[0,5-9]))\d{8}$/;  
            return reg.test(value);  
        },  
        message: '输入手机号码格式不准确.'  
    }, 
    tel:
    {//value值为文本框中的值  
        validator: function (value) {  
            var reg = /^(0[0-9]{2,3}\-)?([2-9][0-9]{6,7})+(\-[0-9]{1,4})?$/;  
            return reg.test(value);  
        },  
        message: '输入座机号格式不准确.'  
    }, 
    //国内邮编验证  
    zipcode: {  
        validator: function (value) {  
            var reg = /^[1-9]\d{5}$/;  
            return reg.test(value);  
        },  
        message: '邮编必须是非0开始的6位数字.'  
    },  
    checkWSDL: {     
        validator: function(value,param){               
             var reg = "^(http://|([0-9]{1,3}[.]{1}[0-9]{1,3}[.]{1}[0-9]{1,3}[.]{1}[0-9]{1,3}:[0-9]{1,4}))[/a-zA-Z0-9._%&:=(),?+]*[?]{1}wsdl$";  
             return reg.test(value);  
        },     
        message: '请输入合法的WSDL地址.'     
    }, 
    IDCard: {
    	validator: function(value,param){               
            var reg = "/^\d{15}(\d{2}[A-Za-z0-9])?$/";  
            return reg.test(value);  
       },     
       message: '请输入合法的身份证号.'   
    },
    checkIp : {// 验证IP地址  
        validator : function(value) {  
            var reg = /^((1?\d?\d|(2([0-4]\d|5[0-5])))\.){3}(1?\d?\d|(2([0-4]\d|5[0-5])))$/ ;  
            return reg.test(value);  
        },  
        message : 'IP地址格式不正确'  
    },
    selectValueRequired: {   
        validator: function(value,param){             
             if (value == "" || value.indexOf('请选择') >= 0) {   
                return false;  
             }else {  
                return true;  
             }    
        },   
        message: '该下拉框为必选项'   
    }   
})  